package dev.autobox.splat;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

/**
 * End-to-end hosting check using the plugin's own SplatPack: serves the built zip on loopback,
 * resolves the tunnel's current hostname exactly as a match start does, and downloads the pack
 * back through Cloudflare. Needs worlds-pack-tunnel.service; not part of `gradle check`.
 */
public final class PackServeCheck {
    static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }

    public static void main(String[] args) throws Exception {
        byte[] zip = Files.readAllBytes(Path.of(args[0]));
        SplatPack pack = new SplatPack(Logger.getLogger("SplatPack"), zip);
        pack.start();
        require(pack.serving(), "Pack server did not bind 127.0.0.1:" + SplatPack.LOCAL_PORT);
        try {
            HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).followRedirects(HttpClient.Redirect.NORMAL).build();
            HttpResponse<byte[]> local = get(client, "http://127.0.0.1:" + SplatPack.LOCAL_PORT + SplatPack.PATH);
            require(local.statusCode() == 200 && SplatPack.sha1(local.body()).equals(pack.sha1()), "Local download hash");
            require(get(client, "http://127.0.0.1:" + SplatPack.LOCAL_PORT + "/other").statusCode() == 404, "Only the pack is served");

            Optional<String> url = pack.resolve().get(10, TimeUnit.SECONDS);
            require(url.isPresent(), "No tunnel hostname: is worlds-pack-tunnel.service running?");
            // A brand-new quick-tunnel hostname can take a little while to resolve publicly.
            byte[] remote = null;
            String last = "no attempt";
            for (int attempt = 0; attempt < 60 && remote == null; attempt++) {
                try {
                    HttpResponse<byte[]> response = get(client, url.get());
                    if (response.statusCode() == 200) remote = response.body();
                    else last = "HTTP " + response.statusCode();
                } catch (IOException failure) {
                    last = failure.toString();
                }
                if (remote == null) Thread.sleep(2000);
            }
            require(remote != null, "Public download failed: " + last);
            require(SplatPack.sha1(remote).equals(pack.sha1()), "Public download hash mismatch");
            System.out.println("PACK_SERVE_CHECK_PASSED url=" + url.get() + " sha1=" + pack.sha1() + " bytes=" + zip.length);
        } finally {
            pack.stop();
        }
    }

    static HttpResponse<byte[]> get(HttpClient client, String url) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(10))
                .header("User-Agent", "Minecraft Java/26.2").GET().build();
        return client.send(request, HttpResponse.BodyHandlers.ofByteArray());
    }
}
