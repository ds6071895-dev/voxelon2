package dev.autobox.ratseek;

import org.bukkit.Material;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/** Checks final block geometry, including cover and all floors, without booting Paper. */
public final class RatSeekHouseCheck {
    private static final RatSeekHouse HOUSE = new RatSeekHouse();
    private static final int[][] DIRECTIONS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    public static void main(String[] args) throws Exception {
        // RatSeekGame caches one blueprint for the whole session, which is only safe while it is deterministic.
        RatSeekHouse again = new RatSeekHouse();
        require(again.blocks.equals(HOUSE.blocks) && again.spawns.equals(HOUSE.spawns)
                && again.cheese.equals(HOUSE.cheese) && again.chandeliers.equals(HOUSE.chandeliers),
                "RatSeekHouse must build the same blueprint every time");
        require(HOUSE.hides.size() >= 100, "Expected at least 100 hiding spots");
        require(HOUSE.passages.size() == 4, "Expected four service tunnels");
        require(HOUSE.spawns.size() >= 17, "Need distributed spawns");
        require(new HashSet<>(HOUSE.cheese).size() >= 39, "Need distinct cheese sites");
        Set<RatSeekHouse.Pos> human = reachable(2, 0);
        Set<RatSeekHouse.Pos> rat = reachable(1, 0);
        for (RatSeekHouse.Pos pos : HOUSE.spawns) {
            require(human.contains(pos), "Human cannot reach spawn " + pos);
            require(rat.contains(pos), "Rat cannot reach spawn " + pos);
        }
        for (RatSeekHouse.Pos pos : HOUSE.cheese)
            require(human.contains(pos) && rat.contains(pos), "Unreachable cheese " + pos);
        for (RatSeekHouse.Hide hide : HOUSE.hides) {
            require(rat.contains(hide.position()), "Unreachable hiding spot " + hide);
            if (hide.name().contains("table") || hide.name().contains("bench")) {
                boolean swattable = false;
                for (int[] dir : DIRECTIONS) {
                    RatSeekHouse.Pos edge = hide.position().offset(dir[0], 0, dir[1]);
                    RatSeekHouse.Pos seeker = hide.position().offset(2 * dir[0], 0, 2 * dir[1]);
                    if (human.contains(seeker) && passable(HOUSE.at(edge)) && passable(HOUSE.at(hide.position()))) {
                        swattable = true;
                        break;
                    }
                }
                require(swattable, "No reachable, open swat approach to " + hide);
            }
        }
        for (RatSeekHouse.Passage passage : HOUSE.passages) {
            require(human.contains(passage.exitA()) && human.contains(passage.exitB()), "Unsafe tunnel exit " + passage);
            for (int z = passage.z1(); z <= passage.z2(); z++) {
                RatSeekHouse.Pos pos = new RatSeekHouse.Pos(passage.x(), passage.y(), z);
                require(rat.contains(pos), "Disconnected tunnel " + pos);
                require(!human.contains(pos), "Human fits inside rat tunnel " + pos);
            }
        }
        // Either staircase alone must connect all room spawns, preventing a single choke point.
        for (int disabled : new int[]{-1, 1}) {
            Set<RatSeekHouse.Pos> alternative = reachable(2, disabled);
            for (RatSeekHouse.Pos spawn : HOUSE.spawns)
                require(alternative.contains(spawn), "No alternate staircase route to " + spawn);
        }
        require(human.contains(RatSeekHouse.KEEPER), "Rescue keeper is inaccessible");
        require(!rat.contains(RatSeekHouse.CAGE), "Rats can enter/escape locked cage on foot");
        require(!rat.contains(RatSeekHouse.WAITING), "Waiting booth is open");
        require(standable(RatSeekHouse.CAGE, 1), "Unsafe cage spawn");
        require(standable(RatSeekHouse.WAITING, 2), "Unsafe Human waiting spawn");
        require(HOUSE.chandelierLevers.size() == 4 && HOUSE.chandeliers.size() == 4,
                "Every floor needs a chandelier lever and a chandelier");
        for (RatSeekHouse.Pos lever : HOUSE.chandelierLevers)
            require(rat.contains(lever), "Chandelier lever unreachable for rats " + lever);
        for (RatSeekHouse.Pos hang : HOUSE.chandeliers) {
            RatSeekHouse.Pos floor = hang.offset(0, -4, 0);
            require(human.contains(floor), "Chandelier drop zone is not walkable " + floor);
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++)
                require(HOUSE.at(floor.offset(dx, -1, dz)) != Material.POLISHED_ANDESITE_STAIRS,
                        "Chandelier drop zone overlaps a staircase at " + floor.offset(dx, 0, dz));
        }
        for (RatSeekHouse.Pos step : new RatSeekHouse.Pos[]{RatSeekHouse.PODIUM_FIRST, RatSeekHouse.PODIUM_SECOND,
                RatSeekHouse.PODIUM_THIRD, RatSeekHouse.PODIUM_CROWD}) {
            require(standable(step, 2), "Podium spot cannot hold a full-size player " + step);
        }
        for (int dx = -2; dx <= 2; dx++) for (int dz = 0; dz <= 0; dz++) {
            RatSeekHouse.Pos crowd = RatSeekHouse.PODIUM_CROWD.offset(dx, 0, dz);
            require(standable(crowd, 2), "Podium crowd area is blocked at " + crowd);
        }
        // No rat can step onto the exterior perimeter, roof or outside the estate.
        for (RatSeekHouse.Pos pos : rat) {
            require(pos.x() > -25 && pos.x() < 34 && pos.z() > -21 && pos.z() < 34,
                    "Escapable perimeter " + pos);
            require(pos.y() < 99, "Rat can escape onto roof " + pos);
        }
        writePlan();
        System.out.printf("Manor checks passed: %d hides, %d tunnels, %d spawns, %d cheese sites; %d Human / %d rat reachable cells.%n",
                HOUSE.hides.size(), HOUSE.passages.size(), HOUSE.spawns.size(), HOUSE.cheese.size(), human.size(), rat.size());
    }

    private static Set<RatSeekHouse.Pos> reachable(int height, int disabledStair) {
        Set<RatSeekHouse.Pos> seen = new HashSet<>();
        ArrayDeque<RatSeekHouse.Pos> queue = new ArrayDeque<>();
        queue.add(RatSeekHouse.RELEASE);
        seen.add(RatSeekHouse.RELEASE);
        while (!queue.isEmpty()) {
            RatSeekHouse.Pos from = queue.removeFirst();
            for (int[] dir : DIRECTIONS) for (int dy = -1; dy <= 1; dy++) {
                RatSeekHouse.Pos to = from.offset(dir[0], dy, dir[1]);
                if (to.x() < -27 || to.x() > 36 || to.z() < -23 || to.z() > 36 || to.y() < 74 || to.y() > 112) continue;
                if (disabledStair != 0 && HOUSE.at(to.offset(0, -1, 0)) == Material.POLISHED_ANDESITE_STAIRS
                        && Integer.signum(to.z()) == disabledStair) continue;
                if (!standable(to, height)) continue;
                // A jump also needs headroom above the departure block.
                if (dy > 0 && !passable(HOUSE.at(from.offset(0, height, 0)))) continue;
                if (seen.add(to)) queue.addLast(to);
            }
        }
        return seen;
    }
    private static boolean standable(RatSeekHouse.Pos pos, int height) {
        if (passable(HOUSE.at(pos.offset(0, -1, 0)))) return false;
        for (int dy = 0; dy < height; dy++) if (!passable(HOUSE.at(pos.offset(0, dy, 0)))) return false;
        return true;
    }
    private static boolean passable(Material material) {
        return material == Material.AIR || material == Material.FLOWER_POT || material == Material.LANTERN
                || material == Material.LEVER;
    }
    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static void writePlan() throws Exception {
        StringBuilder svg = new StringBuilder("<svg xmlns='http://www.w3.org/2000/svg' width='1440' height='1510' viewBox='0 0 1440 1510'>");
        svg.append("<rect width='1440' height='1510' fill='#121a23'/><g font-family='sans-serif' fill='#f0e9db'>")
                .append("<text x='40' y='48' font-size='30' font-weight='bold'>RAT &amp; SEEK — THE CROOKED MANOR</text>")
                .append("<text x='40' y='78' font-size='16'>104 hiding spots · 4 service tunnels · 2 staircases · 16 furnished rooms + greenhouse</text>");
        String[] labels = {"CELLAR", "GROUND FLOOR &amp; GARDEN", "UPPER FLOOR", "ATTIC"};
        for (int level = 0; level < 4; level++) {
            int ox = 40 + (level % 2) * 700, oy = 130 + (level / 2) * 680;
            int y = 75 + level * 6;
            svg.append("<text x='").append(ox).append("' y='").append(oy - 15).append("' font-size='20'>").append(labels[level]).append("</text>");
            for (int x = -25; x <= 34; x++) for (int z = -21; z <= 34; z++) {
                RatSeekHouse.Pos pos = new RatSeekHouse.Pos(x, y, z);
                Material feet = HOUSE.at(pos), above = HOUSE.at(pos.offset(0, 1, 0));
                String color = passable(HOUSE.at(pos.offset(0, -1, 0))) ? "#121a23" : "#b9aa8a";
                if (feet != Material.AIR) color = switch (feet) {
                    case DARK_OAK_PLANKS, STRIPPED_DARK_OAK_LOG -> "#53402f";
                    case CALCITE -> "#e6dccb";
                    case GLASS, LIGHT_BLUE_STAINED_GLASS -> "#71b6c8";
                    case AZALEA_LEAVES -> "#416e46";
                    case POLISHED_ANDESITE_STAIRS -> "#8e9daa";
                    default -> "#6f665b";
                };
                else if (!passable(above)) color = "#ba9050";
                svg.append("<rect x='").append(ox + (x + 25) * 10).append("' y='").append(oy + (z + 21) * 10)
                        .append("' width='10' height='10' fill='").append(color).append("'/>");
            }
            for (RatSeekHouse.Hide hide : HOUSE.hides) if (hide.position().y() == y) marker(svg, hide.position(), ox, oy, "#f6c857", 3);
            for (RatSeekHouse.Pos spawn : HOUSE.spawns) if (spawn.y() == y) marker(svg, spawn, ox, oy, "#62e5b5", 4);
            for (RatSeekHouse.Pos spot : HOUSE.cheese) if (spot.y() == y) marker(svg, spot, ox, oy, "#ffffff", 2);
            for (RatSeekHouse.Room room : HOUSE.rooms) if (room.y1() == y && room.x1() != -3 && !room.name().contains("garden") && !room.name().contains("courtyard")) {
                svg.append("<text x='").append(ox + ((room.x1() + room.x2()) / 2.0 + 25.5) * 10)
                        .append("' y='").append(oy + ((room.z1() + room.z2()) / 2.0 + 22) * 10)
                        .append("' text-anchor='middle' font-size='10' fill='#ffffff' stroke='#121a23' stroke-width='2' paint-order='stroke'>")
                        .append(room.name()).append("</text>");
            }
        }
        svg.append("<text x='40' y='1465' font-size='16'>Gold: hiding spots   Mint: rat spawns   White: cheese sites   Grey steps: staircases</text></g></svg>");
        Path output = Path.of("build/reports/ratseek-manor.svg");
        Files.createDirectories(output.getParent());
        Files.writeString(output, svg);
    }
    private static void marker(StringBuilder svg, RatSeekHouse.Pos pos, int ox, int oy, String color, int radius) {
        svg.append("<circle cx='").append(ox + (pos.x() + 25.5) * 10).append("' cy='").append(oy + (pos.z() + 21.5) * 10)
                .append("' r='").append(radius).append("' fill='").append(color).append("'/>");
    }
}
