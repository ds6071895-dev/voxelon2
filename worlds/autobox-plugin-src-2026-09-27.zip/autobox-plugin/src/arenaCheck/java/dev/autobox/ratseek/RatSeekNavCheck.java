package dev.autobox.ratseek;

import java.util.List;

/** Checks the AI seekers' navigation over the manor blueprint without booting Paper. */
public final class RatSeekNavCheck {
    public static void main(String[] args) {
        long built = System.nanoTime();
        RatSeekHouse house = new RatSeekHouse();
        RatSeekNav nav = new RatSeekNav(house);
        long buildMs = (System.nanoTime() - built) / 1_000_000;
        RatSeekHouse.Pos r = RatSeekHouse.RELEASE;
        int[] release = nav.nearest(r.x() + 0.5, r.y(), r.z() + 0.5, 1);
        require(release != null, "Release point is not walkable");
        require(nav.walkableCount() > 3000, "Suspiciously small walkable area: " + nav.walkableCount());

        require(nav.searchRooms().size() >= 20, "Expected every room to be searchable, got " + nav.searchRooms().size());
        int spots = 0;
        long worst = 0;
        double longest = 0;
        for (RatSeekNav.SearchRoom room : nav.searchRooms()) {
            long start = System.nanoTime();
            List<double[]> toRoom = nav.path(release, room.centre());
            worst = Math.max(worst, System.nanoTime() - start);
            require(toRoom != null, "No path from the release to the " + room.name());
            longest = Math.max(longest, RatSeekNav.length(toRoom));
            checkWalk(nav, toRoom, "release → " + room.name());
            for (RatSeekNav.Spot spot : room.spots()) {
                spots++;
                List<double[]> toSpot = nav.path(room.centre(), spot.from());
                require(toSpot != null, "Can't reach " + spot.name() + " in the " + room.name());
                checkWalk(nav, toSpot, room.name() + " → " + spot.name());
                int[] h = spot.hide(), f = spot.from();
                require(Math.hypot(h[0] - f[0], h[2] - f[2]) <= 3.2 && Math.abs(h[1] - f[1]) <= 2,
                        "Checking spot too far from " + spot.name() + " in the " + room.name());
            }
        }
        require(spots > 100, "Too few hiding spots are checkable: " + spots);

        // Every floor connects both ways (stairs up and down).
        RatSeekNav.SearchRoom cellar = nav.searchRoom("wine cellar"), attic = nav.searchRoom("music room");
        require(cellar != null && attic != null, "Missing cellar or attic rooms");
        require(nav.path(cellar.centre(), attic.centre()) != null, "Cellar → attic has no route");
        require(nav.path(attic.centre(), cellar.centre()) != null, "Attic → cellar has no route");

        for (RatSeekHouse.Passage passage : house.passages) {
            for (RatSeekHouse.Pos exit : new RatSeekHouse.Pos[]{passage.exitA(), passage.exitB()}) {
                require(nav.nearest(exit.x() + 0.5, exit.y(), exit.z() + 0.5, 2) != null,
                        "AI can't ambush the " + passage.name() + " exit " + exit);
            }
        }
        RatSeekHouse.Pos keeper = RatSeekHouse.KEEPER;
        for (double dz : new double[]{2.5, -2.5}) {
            int[] post = nav.nearest(keeper.x() - 2.5, keeper.y(), keeper.z() + dz, 2);
            require(post != null && nav.path(release, post) != null, "Guard post near the keeper is unreachable");
        }
        for (RatSeekHouse.Pos hang : house.chandeliers) {
            RatSeekHouse.Pos floor = hang.offset(0, -4, 0);
            int[] under = nav.nearest(floor.x() + 0.5, floor.y(), floor.z() + 0.5, 1);
            require(under != null, "Chandelier drop zone not walkable " + floor);
            boolean escape = false;
            for (int[] dir : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                int[] out = nav.nearest(floor.x() + 0.5 + dir[0] * 3.8, floor.y(), floor.z() + 0.5 + dir[1] * 3.8, 2);
                if (out != null && nav.path(under, out) != null) {
                    escape = true;
                }
            }
            require(escape, "No way to dodge the chandelier at " + floor);
        }
        List<int[]> chokepoints = nav.chokepoints();
        require(chokepoints.size() >= 16, "Expected mousehole trap sites, got " + chokepoints.size());
        for (int[] c : chokepoints) {
            int[] from = nav.nearest(c[0] + 0.5, c[1], c[2] + 0.5, 2);
            require(from != null && nav.path(release, from) != null, "Trap site unreachable " + c[0] + "," + c[1] + "," + c[2]);
        }
        // Humans must not fit through rat-only gaps (wardrobes and shelf recesses are open to both).
        for (RatSeekHouse.Hide hide : house.hides) {
            if (!hide.name().equals("mousehole") && !hide.name().endsWith("table") && !hide.name().endsWith("bench")) {
                continue;
            }
            RatSeekHouse.Pos p = hide.position();
            require(!nav.walkable(p.x(), p.y(), p.z()), "A human could stand inside " + hide);
        }
        for (RatSeekHouse.Passage passage : house.passages) {
            for (int z = passage.z1(); z <= passage.z2(); z++) {
                require(!nav.walkable(passage.x(), passage.y(), z), "A human could walk the " + passage.name());
            }
        }
        require(!nav.walkable(RatSeekHouse.CAGE.x(), RatSeekHouse.CAGE.y(), RatSeekHouse.CAGE.z()),
                "AI could walk into the cage");
        // Steady-state cost once the JIT has warmed up: random cross-house trips like a bot makes.
        java.util.Random random = new java.util.Random(7);
        List<RatSeekNav.SearchRoom> rooms = nav.searchRooms();
        long slowest = 0, total = 0;
        int trips = 600;
        for (int i = 0; i < trips; i++) {
            int[] a = rooms.get(random.nextInt(rooms.size())).centre();
            int[] b = rooms.get(random.nextInt(rooms.size())).centre();
            long start = System.nanoTime();
            require(nav.path(a, b) != null, "Random trip failed");
            long took = System.nanoTime() - start;
            if (i >= 100) {
                slowest = Math.max(slowest, took);
                total += took;
            }
        }
        System.out.printf("Path timing (warm): avg %.3f ms, slowest %.3f ms over %d trips.%n",
                total / 1e6 / (trips - 100), slowest / 1e6, trips - 100);
        System.out.printf("AI navigation checks passed: %d walkable cells, %d rooms, %d spots, %d trap sites; "
                        + "built in %d ms, slowest room path %.2f ms, longest %.0f blocks.%n",
                nav.walkableCount(), nav.searchRooms().size(), spots, chokepoints.size(), buildMs,
                worst / 1e6, longest);
    }

    /** Walks a path in small steps: every point must be on a walkable cell, climbs are one block and drops at most three. */
    private static void checkWalk(RatSeekNav nav, List<double[]> path, String label) {
        for (int i = 1; i < path.size(); i++) {
            double[] a = path.get(i - 1), b = path.get(i);
            require(b[1] - a[1] <= 1.01, label + ": climbs more than a block at once");
            require(a[1] - b[1] <= 3.01, label + ": drops more than three blocks at once");
            double length = Math.hypot(b[0] - a[0], b[2] - a[2]);
            if (a[1] != b[1]) {
                require(length < 1.5, label + ": a level change is not a single step");
                continue;
            }
            for (double t = 0; t <= length; t += 0.2) {
                double x = a[0] + (b[0] - a[0]) * t / Math.max(length, 1e-6);
                double z = a[2] + (b[2] - a[2]) * t / Math.max(length, 1e-6);
                require(nav.walkable((int) Math.floor(x), (int) a[1], (int) Math.floor(z)),
                        label + ": walks through a wall near " + x + "," + a[1] + "," + z);
            }
        }
    }

    private static void require(boolean value, String message) {
        if (!value) {
            throw new AssertionError(message);
        }
    }
}
