package dev.autobox.ratseek;

import org.bukkit.Material;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Finds places a rat can get to where no seeker can tag it. Rats (0.9 tall at Small) fit
 * one-block gaps and jump like players; seekers need two blocks and three to jump. A rat cell
 * is fair if a human cell has an eye within attack reach and a clear line to the rat, or a
 * crouched swat into a low gap. Secret passages are exempt (seekers ambush their exits).
 */
public final class RatSeekReachCheck {
    static final int MIN_X = RatSeekNav.MIN_X, MAX_X = RatSeekNav.MAX_X, MIN_Y = RatSeekNav.MIN_Y,
            MAX_Y = RatSeekNav.MAX_Y + 8, MIN_Z = RatSeekNav.MIN_Z, MAX_Z = RatSeekNav.MAX_Z;
    static final int SX = MAX_X - MIN_X + 1, SZ = MAX_Z - MIN_Z + 1, SY = MAX_Y - MIN_Y + 1;
    static final int[][] STEPS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    static final double REACH = 3.0;

    static RatSeekHouse house;

    public static void main(String[] args) {
        house = new RatSeekHouse();
        long started = System.nanoTime();
        RatSeekNav nav = new RatSeekNav(house);
        long navMs = (System.nanoTime() - started) / 1_000_000;
        RatSeekHouse.Pos r = RatSeekHouse.RELEASE;
        BitSet human = reach(2, 1, List.of(new int[]{r.x(), r.y(), r.z()}));
        BitSet bot = new BitSet();
        int humanOnly = 0;
        for (int i = human.nextSetBit(0); i >= 0; i = human.nextSetBit(i + 1)) {
            if (nav.walkable(xOf(i), yOf(i), zOf(i))) bot.set(i);
            // Standing on a flower pot is possible but not a place anyone needs to be.
            else if (at(xOf(i), yOf(i) - 1, zOf(i)) != Material.FLOWER_POT) humanOnly++;
        }
        System.out.println("nav " + navMs + " ms, human cells " + human.cardinality() + ", AI cells " + nav.walkableCount()
                + ", human-only " + humanOnly + ", unfair perches " + nav.unfairPerchCount());
        require(humanOnly == 0, humanOnly + " cells a jumping player can stand on are missing from the AI's nav");

        // Normal play: every spot a rat can reach must be taggable by the AI.
        BitSet rat = reach(1, 1, spawnCells());
        List<String> unfair = new ArrayList<>();
        for (int i = rat.nextSetBit(0); i >= 0; i = rat.nextSetBit(i + 1)) {
            int x = xOf(i), y = yOf(i), z = zOf(i);
            if (!inPassage(x, y, z) && !tagable(bot, x, y, z)) unfair.add(x + "," + y + "," + z);
        }
        require(unfair.isEmpty(), "Rat spots no seeker can tag: " + unfair);

        // Bouncy House (Jump Boost III): anything untaggable must be a perch the rat slips off.
        BitSet bouncy = reach(1, 3, spawnCells());
        Map<String, Integer> perches = new TreeMap<>();
        List<String> missed = new ArrayList<>();
        for (int i = bouncy.nextSetBit(0); i >= 0; i = bouncy.nextSetBit(i + 1)) {
            int x = xOf(i), y = yOf(i), z = zOf(i);
            if (inPassage(x, y, z) || tagable(bot, x, y, z)) continue;
            perches.merge(at(x, y - 1, z).name().toLowerCase(), 1, Integer::sum);
            if (!nav.unfairPerch(x, y, z)) missed.add(x + "," + y + "," + z);
        }
        System.out.println("Bouncy House perches that slip: " + perches);
        require(missed.isEmpty(), "Untaggable perches the slip rule misses: " + missed);
        System.out.println("Rat and Seek reach check passed");
    }

    static void require(boolean ok, String message) {
        if (!ok) throw new IllegalStateException(message);
    }

    static int nearestFloor(BitSet bot, int x, int y, int z) {
        for (int d = 0; d < 10; d++) {
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                if (inside(x + dx, y - d, z + dz) && bot.get(index(x + dx, y - d, z + dz))) return y - d;
            }
        }
        return -99;
    }

    static List<int[]> spawnCells() {
        List<int[]> result = new ArrayList<>();
        for (RatSeekHouse.Pos p : house.spawns) result.add(new int[]{p.x(), p.y(), p.z()});
        return result;
    }

    static boolean inPassage(int x, int y, int z) {
        for (RatSeekHouse.Passage p : house.passages) {
            if (x == p.x() && y == p.y() && z >= p.z1() && z <= p.z2()) return true;
            if (Math.abs(x) == 20 && y == p.y() && (z == 12 || z == -12) && Integer.signum(x) == Integer.signum(p.x())) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ geometry

    static Material at(int x, int y, int z) {
        return house.at(new RatSeekHouse.Pos(x, y, z));
    }

    static boolean free(int x, int y, int z) {
        if (!inside(x, y, z)) return false;
        Material m = at(x, y, z);
        if (!RatSeekNav.passable(m)) return false;
        // Walls and bars stick up half a block into the space above them.
        Material below = at(x, y - 1, z);
        return below != Material.STONE_BRICK_WALL && below != Material.IRON_BARS;
    }

    static boolean support(int x, int y, int z) {
        Material m = at(x, y - 1, z);
        return !RatSeekNav.passable(m) && m != Material.STONE_BRICK_WALL && m != Material.IRON_BARS;
    }

    static boolean clear(int x, int y, int z, int tall) {
        for (int k = 0; k < tall; k++) if (!free(x, y + k, z)) return false;
        return true;
    }

    /** Every standing cell a body {@code tall} blocks high can walk, jump, drop or leap to. */
    static BitSet reach(int tall, int jump, List<int[]> starts) {
        BitSet seen = new BitSet(SX * SY * SZ);
        ArrayDeque<int[]> queue = new ArrayDeque<>();
        for (int[] s : starts) {
            seen.set(index(s[0], s[1], s[2]));
            queue.add(s);
        }
        while (!queue.isEmpty()) {
            int[] c = queue.removeFirst();
            int x = c[0], y = c[1], z = c[2];
            for (int[] d : STEPS) {
                // Walk, or jump up one (needs a block of headroom over the take-off spot).
                for (int dy = 0; dy <= jump; dy++) {
                    int tx = x + d[0], ty = y + dy, tz = z + d[1];
                    if (dy > 0 && !clear(x, y, z, tall + dy)
                            && at(tx, ty - 1, tz) != Material.POLISHED_ANDESITE_STAIRS) continue;
                    if (clear(tx, ty, tz, tall) && support(tx, ty, tz)) add(seen, queue, tx, ty, tz);
                }
                // Step off an edge and drop.
                int tx = x + d[0], tz = z + d[1];
                if (clear(tx, y, tz, tall) && !support(tx, y, tz)) {
                    int fy = y;
                    while (fy > MIN_Y && free(tx, fy - 1, tz) && !support(tx, fy, tz)) fy--;
                    if (support(tx, fy, tz) && clear(tx, fy, tz, tall)) add(seen, queue, tx, fy, tz);
                }
                // Sprint-jump over a one- or two-block gap to the same level or one lower.
                if (clear(x, y, z, tall + 1)) {
                    for (int gap = 1; gap <= 2; gap++) {
                        boolean open = true;
                        for (int k = 1; k <= gap && open; k++) open = clear(x + d[0] * k, y, z + d[1] * k, tall + 1);
                        if (!open) break;
                        int lx = x + d[0] * (gap + 1), lz = z + d[1] * (gap + 1);
                        for (int dy = 0; dy >= -1; dy--) {
                            if (clear(lx, y + dy, lz, tall) && support(lx, y + dy, lz)) {
                                add(seen, queue, lx, y + dy, lz);
                                break;
                            }
                        }
                    }
                }
            }
        }
        return seen;
    }

    static void add(BitSet seen, ArrayDeque<int[]> queue, int x, int y, int z) {
        int i = index(x, y, z);
        if (!seen.get(i)) {
            seen.set(i);
            queue.add(new int[]{x, y, z});
        }
    }

    /**
     * True if a seeker standing anywhere it can reach can tag a rat pressed into the worst spot of
     * this cell (every rat position in the cell must be covered by some seeker).
     */
    static boolean tagable(BitSet seekers, int x, int y, int z) {
        double[] offs = {0.15, 0.5, 0.85};
        for (double ox : offs) for (double oz : offs) {
            if (!tagableAt(seekers, x + ox, y, z + oz)) return false;
        }
        return true;
    }

    static boolean tagableAt(BitSet seekers, double rx, double ry, double rz) {
        int bx = (int) Math.floor(rx), bz = (int) Math.floor(rz);
        for (int hy = (int) ry - 4; hy <= (int) ry + 3; hy++) {
            for (int hx = bx - 4; hx <= bx + 4; hx++) {
                for (int hz = bz - 4; hz <= bz + 4; hz++) {
                    if (!inside(hx, hy, hz) || !seekers.get(index(hx, hy, hz))) continue;
                    // A seeker can stand anywhere in its cell (30 cm from its edges).
                    double ex = Math.max(hx + 0.3, Math.min(hx + 0.7, rx));
                    double ez = Math.max(hz + 0.3, Math.min(hz + 0.7, rz));
                    for (double eyeY : new double[]{hy + 1.62, hy + 1.27}) {
                        if (hit(ex, eyeY, ez, rx, ry, rz)) return true;
                    }
                    // Crouched swat into a low gap: 2.7 blocks, same level.
                    if (Math.abs(hy - ry) <= 1.2 && Math.hypot(ex - rx, ez - rz) < 2.7
                            && ray(ex, hy + 0.38, ez, rx, ry + 0.3, rz)) return true;
                }
            }
        }
        return false;
    }

    /** Attack: some point of the rat's box within reach with a clear line from the eye. */
    static boolean hit(double ex, double ey, double ez, double rx, double ry, double rz) {
        for (double py : new double[]{ry + 0.1, ry + 0.45, ry + 0.8}) {
            for (double[] o : new double[][]{{0, 0}, {-0.14, 0}, {0.14, 0}, {0, -0.14}, {0, 0.14}}) {
                double px = rx + o[0], pz = rz + o[1];
                double d = Math.sqrt((px - ex) * (px - ex) + (py - ey) * (py - ey) + (pz - ez) * (pz - ez));
                if (d <= REACH && ray(ex, ey, ez, px, py, pz)) return true;
            }
        }
        return false;
    }

    static boolean ray(double ax, double ay, double az, double bx, double by, double bz) {
        double len = Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay) + (bz - az) * (bz - az));
        int steps = Math.max(1, (int) (len / 0.05));
        for (int s = 1; s < steps; s++) {
            double t = (double) s / steps;
            int cx = (int) Math.floor(ax + (bx - ax) * t), cy = (int) Math.floor(ay + (by - ay) * t),
                    cz = (int) Math.floor(az + (bz - az) * t);
            Material m = at(cx, cy, cz);
            if (!RatSeekNav.passable(m) && m != Material.IRON_BARS && m != Material.LANTERN
                    && m != Material.FLOWER_POT) return false;
        }
        return true;
    }

    // ------------------------------------------------------------------ cells

    static boolean inside(int x, int y, int z) {
        return x >= MIN_X && x <= MAX_X && y >= MIN_Y && y <= MAX_Y && z >= MIN_Z && z <= MAX_Z;
    }

    static int index(int x, int y, int z) {
        return ((y - MIN_Y) * SZ + (z - MIN_Z)) * SX + (x - MIN_X);
    }

    static int xOf(int i) { return i % SX + MIN_X; }
    static int zOf(int i) { return (i / SX) % SZ + MIN_Z; }
    static int yOf(int i) { return i / (SX * SZ) + MIN_Y; }
}
