package dev.autobox.zombie;

import org.bukkit.Material;
import java.nio.file.*;
import java.util.*;

/** Verifies actual arena geometry and full match outcomes for every supported party size. */
public final class ZombieCheck {
    private static void require(boolean ok,String message) { if(!ok) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        require(!ZombieRules.validParty(1) && !ZombieRules.validParty(7),"Invalid parties accepted");
        int bosses=0;
        for(int wave=1;wave<=30;wave++) if(ZombieRules.bossWave(wave)) bosses++;
        require(bosses==6,"Must have six bosses");
        for(int party=2;party<=6;party++) {
            require(ZombieRules.validParty(party),"Supported party rejected");
            int credits=40, totalSeconds=15;
            for(int wave=1;wave<=30;wave++) {
                for(int second=0;second<50;second++) {
                    require(ZombieRules.outcome(wave,second,false,party)==ZombieRules.Outcome.FIGHT,"Wave ended early");
                    require(ZombieRules.outcome(wave,second,true,0)==ZombieRules.Outcome.DEFEAT,"Wipe did not end match");
                }
                var expected=wave==30?ZombieRules.Outcome.VICTORY:ZombieRules.Outcome.CLEAR;
                require(ZombieRules.outcome(wave,50,false,1)==expected,"Last survivor cannot rescue team / win");
                if(ZombieRules.bossWave(wave)) {
                    require(ZombieRules.outcome(wave,50,true,party)==ZombieRules.Outcome.FIGHT,"Live boss skipped");
                    require(ZombieRules.outcome(wave,89,true,party)==ZombieRules.Outcome.FIGHT,"Overtime ends early");
                    require(ZombieRules.outcome(wave,90,true,party)==ZombieRules.Outcome.DEFEAT,"Boss overtime unbounded");
                    require(ZombieRules.outcome(wave,89,false,party)==expected,"Boss kill in overtime cannot progress");
                }
                require(ZombieRules.enemies(wave,party)>0 && ZombieRules.enemies(wave,party)<100,"Unbounded wave budget");
                require(ZombieRules.bossHealth(wave,party)>ZombieRules.health(wave,false),"Boss is weaker than a zombie");
                if(party>2) require(ZombieRules.bossHealth(wave,party)>ZombieRules.bossHealth(wave,party-1),"No party scaling");
                credits+=ZombieRules.reward(wave); totalSeconds+=50+(wave==30?0:10);
            }
            require(totalSeconds==1805,"Normal 30-wave run should take about 30 minutes");
            int cost=0; for(int tier=0;tier<5;tier++) cost+=ZombieRules.upgradeCost(tier);
            require(cost<=credits,"Players cannot finish an upgrade path without kill stealing");
            require(ZombieRules.upgradeCost(5)>credits,"Maxed tier permits repeated purchases");
        }
        ZombieCity city=new ZombieCity(); Set<ZombieCity.Pos> visited=new HashSet<>();
        ArrayDeque<ZombieCity.Pos> queue=new ArrayDeque<>(); var start=new ZombieCity.Pos(0,81,0); queue.add(start); visited.add(start);
        int[][] steps={{1,0},{-1,0},{0,1},{0,-1}};
        while(!queue.isEmpty()) {
            var p=queue.remove();
            for(var step:steps) { int x=p.x()+step[0], z=p.z()+step[1]; var next=new ZombieCity.Pos(x,81,z);
                if(Math.abs(x)<40 && Math.abs(z)<40 && city.walkable(x,z) && visited.add(next)) queue.add(next); }
        }
        for(var gate:ZombieCity.GATES) require(visited.contains(gate),"Gate cannot reach players: "+gate);
        for(int x=-3;x<=3;x++) for(int z=-1;z<=3;z++) require(visited.contains(new ZombieCity.Pos(x,81,z)),"Unsafe player spawn");
        for(int x=-39;x<40;x++) for(int z=-39;z<40;z++)
            if(city.walkable(x,z)) require(visited.contains(new ZombieCity.Pos(x,81,z)),"Isolated walkable space at "+x+","+z);
        for(int i=-40;i<=40;i++) for(int y=81;y<=84;y++)
            require(city.at(i,y,-40)==Material.DEEPSLATE_BRICKS && city.at(i,y,40)==Material.DEEPSLATE_BRICKS
                    && city.at(-40,y,i)==Material.DEEPSLATE_BRICKS && city.at(40,y,i)==Material.DEEPSLATE_BRICKS,"Containment gap");
        StringBuilder svg=new StringBuilder("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 810 870'><rect width='810' height='870' fill='#101719'/><text x='20' y='32' fill='#a7ed93' font-family='sans-serif' font-size='23'>ZOMBIE APOCALYPSE · QUARANTINE CITY</text>");
        for(int x=-40;x<=40;x++) for(int z=-40;z<=40;z++) {
            Material top=city.at(x,81,z); String colour=!city.walkable(x,z)?"#4e6a62":Math.abs(x)<=5||Math.abs(z)<=5?"#29363c":"#82928a";
            if(top==Material.AIR && city.at(x,80,z)==Material.CRYING_OBSIDIAN) colour="#c672e4";
            if(Math.abs(x)<=5 && Math.abs(z)<=5) colour="#b4ec94";
            svg.append("<rect x='").append((x+40)*10).append("' y='").append(55+(z+40)*10).append("' width='10' height='10' fill='").append(colour).append("'/>");
        }
        svg.append("</svg>"); Path report=Path.of("build/reports/zombie-quarantine-city.svg"); Files.createDirectories(report.getParent()); Files.writeString(report,svg);
        System.out.println("Zombie checks passed: full 30-wave runs for 2–6 players, six boss deadlines, wipes, overtime victory, upgrades, "+visited.size()+" connected city tiles, all spawns and containment.");
    }
}
