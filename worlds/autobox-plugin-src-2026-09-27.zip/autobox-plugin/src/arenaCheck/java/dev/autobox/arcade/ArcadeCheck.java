package dev.autobox.arcade;

import dev.autobox.holeinwall.WallCourse;
import dev.autobox.luckypillars.LuckyLoot;
import dev.autobox.luckypillars.PillarRules;
import dev.autobox.sumo.SumoArena;
import dev.autobox.sumo.SumoArenas;
import dev.autobox.sumo.SumoMutator;
import dev.autobox.sumo.SumoRules;
import org.bukkit.Material;
import org.bukkit.util.BoundingBox;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/** Course reachability, rotated hitboxes and combat timing regressions. */
public final class ArcadeCheck {
    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        int checked = 0;
        Set<String> patterns = new HashSet<>();
        for (int seed = 0; seed < 100; seed++) {
            Random random = new Random(seed);
            for (int wave = 1; wave <= WallCourse.FINAL_WAVE; wave++) {
                for (boolean tiny : new boolean[]{false, true}) {
                    var pattern = WallCourse.pattern(random, wave, tiny);
                    patterns.add(pattern.name());
                    for (int direction = 0; direction < 4; direction++) {
                        boolean route = false;
                        for (int across = -4; across <= 4; across++) {
                            double y = pattern.name().equals("JUMP GATE") ? 1.05 : 0;
                            double x = WallCourse.x(direction, across, 0) + 0.5;
                            double z = WallCourse.z(direction, across, 0) + 0.5;
                            BoundingBox body = new BoundingBox(x - 0.3, y, z - 0.3, x + 0.3, y + 1.8, z + 0.3);
                            if (!hits(pattern.solid(), direction, body)) route = true;
                        }
                        require(route, "No reachable full-height route: " + pattern.name() + " direction " + direction);
                        // The wall must still cover both sides of the entire deck.
                        for (int across : new int[]{-6, 6}) {
                            double x = WallCourse.x(direction, across, 0) + 0.5;
                            double z = WallCourse.z(direction, across, 0) + 0.5;
                            require(hits(pattern.solid(), direction, new BoundingBox(x - 0.3, 0, z - 0.3,
                                    x + 0.3, 1.8, z + 0.3)), "Open wall border");
                        }
                        checked++;
                    }
                }
            }
        }
        require(patterns.size() == 6, "Missing course variety");
        for (int cleared = 0; cleared < 24; cleared++) {
            require(WallCourse.moveInterval(cleared, true) >= 3, "Unreadable wall speed");
            require(WallCourse.moveInterval(cleared, false) * 9 >= 27, "No direction warning time");
            if (cleared > 0) require(WallCourse.moveInterval(cleared, false)
                    <= WallCourse.moveInterval(cleared - 1, false), "Difficulty regressed");
        }
        checkSumo();
        checkLuckyPillars();
        System.out.println("Arcade checks passed: " + checked + " reachable rotated wall layouts, full-body gaps, sealed edges, speed limits, Sumo modes/arenas/spawns/bags/pads/crates/collapse/heart/sudden-death schedule, vault upgrades, comeback balance, capture pacing, knockout expiry and Lucky Pillars loot odds/layouts/twists/lava/border.");
    }

    private static void checkSumo() {
        SumoRules.Mode marathon = SumoRules.Mode.MARATHON;
        SumoRules.Mode gauntlet = SumoRules.Mode.GAUNTLET;
        for (SumoRules.Mode mode : SumoRules.Mode.values()) {
            int end = SumoRules.matchTicks(mode);
            int events = 0;
            for (int tick = 0; tick < end + SumoRules.suddenDeathTicks(mode); tick++) {
                if (!SumoRules.eventStarts(mode, tick)) continue;
                events++;
                require(tick + SumoRules.EVENT_LENGTH <= end, mode + ": event cut off by time-up");
                require(tick >= 20 * 20, mode + ": event before warmup");
            }
            require(events >= 1, mode + ": no arena event");
            int collapses = 0;
            for (int tick = 0; tick <= end; tick++) {
                int index = SumoRules.collapseIndex(mode, tick);
                if (index < 0) continue;
                require(index == collapses++, mode + ": collapses out of order");
                require(SumoRules.nextCollapseTick(mode, tick - 1) == tick, mode + ": collapse warning skips a collapse");
                require(tick <= end - 15 * 20, mode + ": collapse too close to time-up");
            }
            require(collapses == SumoRules.collapseCount(), mode + ": wrong number of collapses");
            require(SumoRules.nextCollapseTick(mode, end) == -1, mode + ": phantom collapse after the finale");
            int finale = -1;
            for (int tick = 0; tick <= end; tick++) if (SumoRules.collapseIndex(mode, tick) == collapses - 1) finale = tick;
            require(!SumoRules.isOverdrive(mode, finale - 1) && SumoRules.isOverdrive(mode, finale),
                    mode + ": overdrive not tied to the final collapse");
            int crateCount = 0;
            for (int tick = 0; tick < end + SumoRules.suddenDeathTicks(mode); tick++) {
                if (SumoRules.isCrateTick(mode, tick)) {
                    crateCount++;
                    require(tick < end, mode + ": crate in sudden death");
                }
            }
            require(crateCount >= 4, mode + ": only " + crateCount + " crates");
        }
        require(SumoRules.MATCH_TICKS == 3 * 4 * 60 * 20, "Marathon is not three times the old four minutes");
        require(SumoRules.ROUND_TICKS <= 2 * 60 * 20, "Gauntlet rounds drag");
        int marathonEvents = 0;
        for (int tick = 0; tick < SumoRules.MATCH_TICKS; tick++) if (SumoRules.eventStarts(marathon, tick)) marathonEvents++;
        require(marathonEvents >= SumoRules.Event.values().length - 1, "Marathon cannot show every event");
        int hearts = 0;
        for (int tick = 0; tick < SumoRules.MATCH_TICKS; tick++) {
            require(!SumoRules.isHeartTick(gauntlet, tick) && !SumoRules.isSphereTick(gauntlet, tick),
                    "Gauntlet rounds use crates, not spheres or hearts");
            if (!SumoRules.isHeartTick(marathon, tick)) continue;
            hearts++;
            require(SumoRules.nextHeartTick(marathon, tick - 1) == tick, "Heart countdown skips a crystal");
            require(SumoRules.collapseIndex(marathon, tick) < 0, "Heart crystal spawns on a collapse tick");
        }
        require(hearts == 3 && SumoRules.nextHeartTick(marathon, SumoRules.MATCH_TICKS) == -1, "Heart crystal schedule");
        require(SumoRules.LIFE_CAP > SumoRules.MAX_LIVES, "Heart crystals cannot add a life at full health");
        require(SumoRules.vaultCooldown(0, SumoRules.Event.CALM) == 200, "Starter rescue unavailable");
        require(SumoRules.vaultCooldown(2, SumoRules.Event.CALM) == 120, "Vault upgrade does not help");
        require(SumoRules.vaultCooldown(0, SumoRules.Event.SKY_RUSH) == 80, "Sky rush not available to beginners");
        require(SumoRules.recentHit(160, 0) && !SumoRules.recentHit(161, 0)
                && !SumoRules.recentHit(100, -1) && !SumoRules.recentHit(10, 20), "Stale or invalid knockout credit");
        for (int level = 0; level <= 5; level++) for (int leader = 0; leader <= 5; leader++) {
            int boosted = SumoRules.comebackLevel(level, leader);
            require(boosted >= level && boosted <= 5, "Comeback demotes or exceeds max level");
            require(boosted == level + (leader - level >= 2 ? 1 : 0), "Comeback boosts a leading player");
        }
        for (int level = 1; level <= SumoRules.MAX_LEVEL; level++) {
            require(SumoRules.captureTicks(level) > SumoRules.captureTicks(level - 1), "Upgrades do not get harder");
            require(SumoRules.captureTicks(level) <= 10 * 20, "Sphere cannot be captured before it expires");
        }
        require(SumoRules.streakCallout(1) == null && SumoRules.streakCallout(SumoRules.BOUNTY_STREAK) != null,
                "Bounty streak has no callout");
        require(SumoRules.meteorPush(0) > SumoRules.meteorPush(3.0) && SumoRules.meteorPush(3.0) > 0
                && SumoRules.meteorPush(3.3) == 0, "Meteor blast falloff");
        require(SumoRules.meteorPush(2.3, SumoRules.ANVIL_RADIUS_TENTHS) == 0, "Anvil blast too wide");
        require(SumoRules.WOOL_LIFETIME > SumoRules.WOOL_WARNING, "Wool crumbles without warning");

        // Votes: majority wins, ties go to Gauntlet, silence picks by player count.
        require(SumoRules.resolveVote(2, 1, 3) == gauntlet && SumoRules.resolveVote(0, 1, 2) == marathon, "Vote majority");
        require(SumoRules.resolveVote(1, 1, 2) == gauntlet && SumoRules.resolveVote(0, 0, 3) == gauntlet
                && SumoRules.resolveVote(0, 0, 6) == marathon, "Vote tie-break");
        require(!SumoRules.gauntletOver(SumoRules.ROUND_WINS - 1, SumoRules.MAX_ROUNDS - 1)
                && SumoRules.gauntletOver(SumoRules.ROUND_WINS, 3)
                && SumoRules.gauntletOver(0, SumoRules.MAX_ROUNDS), "Gauntlet does not end");
        // With 3 players someone must reach 3 wins before the round cap (no draws: 3*(3-1)+1 = 7 rounds).
        require(SumoRules.MAX_ROUNDS >= 3 * (SumoRules.ROUND_WINS - 1) + 1, "Round cap can stop a 3-way Gauntlet");

        // Crates: weights add to 100 and every item can drop.
        int weights = 0;
        Set<SumoRules.CrateItem> rolled = new HashSet<>();
        for (SumoRules.CrateItem item : SumoRules.CrateItem.values()) weights += item.weight;
        for (int roll = 0; roll < 100; roll++) rolled.add(SumoRules.crateRoll(roll));
        require(weights == 100, "Crate weights add to " + weights);
        require(rolled.size() == SumoRules.CrateItem.values().length, "A crate item can never drop");

        checkShuffleBags();
        for (SumoArena.Kind kind : SumoArena.Kind.values()) checkSumoArena(SumoArenas.get(kind));

        // Bounce House pads must land players on the tower, from every pad, with vanilla air physics.
        SumoArena bounce = SumoArenas.get(SumoArena.Kind.BOUNCE);
        int pads = 0;
        int[] target = SumoArenas.BOUNCE_TARGET;
        for (SumoArena.Block block : bounce.blocks()) {
            if (block.material() != Material.SLIME_BLOCK) continue;
            pads++;
            double startX = block.x() + 0.5;
            double startZ = block.z() + 0.5;
            double startY = block.y() + 1;
            double[] v = SumoRules.padLaunch(target[0] + 0.5 - startX, target[1] - startY, target[2] + 0.5 - startZ);
            double x = startX, y = startY, z = startZ, vx = v[0], vy = v[1], vz = v[2];
            boolean landed = false;
            for (int tick = 0; tick < 200; tick++) {
                x += vx;
                y += vy;
                z += vz;
                vx *= 0.91;
                vz *= 0.91;
                vy = (vy - 0.08) * 0.98;
                if (vy < 0 && y <= target[1]) {
                    landed = Math.hypot(x - 0.5, z - 0.5) <= 3.0;
                    break;
                }
            }
            require(landed, "Pad at " + block.x() + "," + block.z() + " misses the tower");
            require(SumoRules.apex(v[1]) < SumoArena.SWEEP_TOP + 30 - startY, "Pad launch absurdly high");
        }
        require(pads == 8, "Bounce House has " + pads + " pads");
        require(SumoRules.sweeperSpeed(gauntlet, 0) < SumoRules.sweeperSpeed(gauntlet, SumoRules.ROUND_TICKS)
                && SumoRules.sweeperSpeed(gauntlet, SumoRules.ROUND_TICKS) * Math.PI / 180 * 12 < 1.2,
                "Sweeper arm too fast to detect a player");
    }

    private static void checkShuffleBags() {
        Random random = new Random(7);
        List<Integer> items = List.of(1, 2, 3, 4, 5, 6);
        SumoRules.ShuffleBag<Integer> bag = new SumoRules.ShuffleBag<>(items, random);
        Integer previous = null;
        for (int cycle = 0; cycle < 200; cycle++) {
            Set<Integer> seen = new HashSet<>();
            for (int i = 0; i < items.size(); i++) {
                Integer next = bag.next(item -> true);
                require(seen.add(next), "Shuffle bag repeated before emptying");
                require(!next.equals(previous), "Shuffle bag repeated back to back");
                previous = next;
            }
        }
        // Filtered draws never hand out a rejected item, and never get stuck.
        for (int i = 0; i < 500; i++) {
            Integer next = bag.next(item -> item % 2 == 0);
            require(next != null && next % 2 == 0, "Filtered draw returned " + next);
            require(!next.equals(previous) || i == 0, "Filtered draw repeated back to back");
            previous = next;
        }
        require(bag.next(item -> item == 3) == 3 && bag.next(item -> item == 3) == 3, "Only-choice draw failed");
        // Every arena, twist and event actually comes up, and no banned pair is drawn.
        SumoRules.ShuffleBag<SumoMutator> twists = new SumoRules.ShuffleBag<>(List.of(SumoMutator.values()), random);
        SumoRules.ShuffleBag<SumoRules.Event> events = new SumoRules.ShuffleBag<>(List.of(SumoRules.Event.values()), random);
        Set<SumoMutator> seenTwists = new HashSet<>();
        Set<SumoRules.Event> seenEvents = new HashSet<>();
        for (int i = 0; i < 600; i++) {
            SumoArena.Kind arena = SumoArena.Kind.values()[i % SumoArena.Kind.values().length];
            SumoMutator twist = twists.next(candidate -> candidate.allowedOn(arena));
            require(twist != null && twist.allowedOn(arena), "Banned twist " + twist + " on " + arena);
            seenTwists.add(twist);
            for (SumoRules.Mode mode : SumoRules.Mode.values()) {
                SumoRules.Event event = events.next(candidate -> SumoRules.eventAllowed(candidate, mode, arena, twist));
                require(event != null && event != SumoRules.Event.CALM
                        && SumoRules.eventAllowed(event, mode, arena, twist), "Banned event " + event);
                require(mode == SumoRules.Mode.MARATHON || event != SumoRules.Event.DOUBLE_CHARGE, "Sphere event in Gauntlet");
                seenEvents.add(event);
            }
        }
        require(seenTwists.size() == SumoMutator.values().length, "A twist never comes up");
        require(seenEvents.size() == SumoRules.Event.values().length - 1, "An event never comes up");
        require(!SumoRules.eventAllowed(SumoRules.Event.ICE_AGE, SumoRules.Mode.GAUNTLET, SumoArena.Kind.FROSTBITE,
                SumoMutator.NORMAL), "Ice Age on the ice rink");
    }

    private static void checkSumoArena(SumoArena arena) {
        String name = arena.kind().label;
        Map<Long, Material> solid = new HashMap<>();
        for (SumoArena.Block block : arena.blocks()) {
            require(Math.abs(block.x()) <= SumoArena.SWEEP_RADIUS && Math.abs(block.z()) <= SumoArena.SWEEP_RADIUS
                    && block.y() >= SumoArena.SWEEP_BOTTOM && block.y() <= SumoArena.SWEEP_TOP,
                    name + ": block outside the sweep box at " + block);
            require(solid.put(key(block.x(), block.y(), block.z()), block.material()) == null, name + ": duplicate block");
        }
        require(arena.blocks().size() < 6000, name + ": too many blocks to build between rounds");
        require(arena.radii().length == SumoRules.collapseCount(), name + ": needs one radius per collapse");
        int last = arena.startRadius();
        for (int radius : arena.radii()) {
            require(radius < last, name + ": a collapse does not shrink the arena");
            last = radius;
        }
        require(arena.suddenDeathRadius() < last, name + ": sudden death does not shrink the finale");
        require(arena.lowestFloor() > SumoArena.BASE_Y - 12 + 4, name + ": floor too close to the void line");
        for (int[] spawn : arena.spawns()) {
            require(solid.containsKey(key(spawn[0], spawn[1] - 1, spawn[2])), name + ": spawn over air at "
                    + spawn[0] + "," + spawn[1] + "," + spawn[2]);
            require(!solid.containsKey(key(spawn[0], spawn[1], spawn[2]))
                    && !solid.containsKey(key(spawn[0], spawn[1] + 1, spawn[2])), name + ": spawn inside a block");
            require(spawn[1] + 2 <= SumoArena.SWEEP_TOP + 3, name + ": spawn above the build limit");
        }
        for (int[] spot : arena.spots()) {
            require(solid.containsKey(key(spot[0], spot[1], spot[2])) && !solid.containsKey(key(spot[0], spot[1] + 1, spot[2])),
                    name + ": pickup spot is not an open surface");
        }
        // Three players can always start 9+ blocks apart.
        List<int[]> start = within(arena.spawns(), arena.startRadius());
        boolean spread = false;
        for (int a = 0; a < start.size() && !spread; a++)
            for (int b = a + 1; b < start.size() && !spread; b++)
                for (int c = b + 1; c < start.size() && !spread; c++)
                    spread = far(start.get(a), start.get(b)) && far(start.get(b), start.get(c)) && far(start.get(a), start.get(c));
        require(spread, name + ": no three spawns 9 blocks apart");
        // After every collapse and in sudden death there are still spawns standing on surviving blocks.
        for (int index = 0; index < arena.radii().length; index++) {
            require(within(arena.spawns(), arena.radiusAfter(index)).size() >= 3, name + ": spawns run out after collapse " + index);
            require(!within(arena.spots(), arena.radiusAfter(index) - 0.5).isEmpty(), name + ": no pickup spots after collapse " + index);
        }
        require(within(arena.spawns(), arena.suddenDeathRadius()).size() >= 3, name + ": sudden death has no room for 3");
    }

    private static List<int[]> within(List<int[]> points, double radius) {
        List<int[]> inside = new ArrayList<>();
        for (int[] point : points) if (Math.hypot(point[0], point[2]) <= radius - 0.5) inside.add(point);
        return inside;
    }

    private static boolean far(int[] a, int[] b) {
        return Math.hypot(a[0] - b[0], a[2] - b[2]) >= 9;
    }

    private static long key(int x, int y, int z) {
        return ((long) (x + 512) << 20) | ((long) (y + 512) << 10) | (z + 512);
    }

    private static void checkLuckyPillars() {
        // Loot table: 30-100 hand-picked items, sensible odds per tier, and no duplicates.
        int size = LuckyLoot.TABLE.size();
        require(size >= 30 && size <= 100, "Loot table has " + size + " items (want 30-100)");
        Set<String> names = new HashSet<>();
        for (LuckyLoot.Entry entry : LuckyLoot.TABLE) {
            require(entry.weight() > 0, entry.name() + " has no weight");
            require(names.add(entry.name() + entry.rarity()), "Duplicate loot " + entry.name());
        }
        double common = LuckyLoot.chance(LuckyLoot.Rarity.COMMON, 1.0);
        double legendary = LuckyLoot.chance(LuckyLoot.Rarity.LEGENDARY, 1.0);
        require(common > 0.4 && common < 0.65, "Common odds off: " + common);
        require(legendary > 0.002 && legendary < 0.015, "Legendary odds off: " + legendary);
        for (LuckyLoot.Rarity rarity : LuckyLoot.Rarity.values()) {
            require(LuckyLoot.chance(rarity, 1.0) > 0, rarity + " never drops");
        }
        double late = PillarRules.lootBoost(PillarRules.Twist.SLIME_FLOOR, 0, false);
        require(late == 1.0, "Loot starts boosted");
        require(PillarRules.lootBoost(PillarRules.Twist.SLIME_FLOOR, PillarRules.MAIN_TICKS, false) > 1.5,
                "Loot never heats up");
        require(LuckyLoot.chance(LuckyLoot.Rarity.EPIC, PillarRules.lootBoost(PillarRules.Twist.LUCKY_STREAK, 0, false))
                > 2 * LuckyLoot.chance(LuckyLoot.Rarity.EPIC, 1.0), "Lucky Streak barely changes the odds");
        Random random = new Random(7);
        Map<LuckyLoot.Rarity, Integer> rolled = new HashMap<>();
        for (int i = 0; i < 20000; i++) {
            rolled.merge(LuckyLoot.roll(random, 1.0).rarity(), 1, Integer::sum);
            require(LuckyLoot.rollStarter(random).starter(), "Starter drop is not a building block");
        }
        require(Math.abs(rolled.get(LuckyLoot.Rarity.COMMON) / 20000.0 - common) < 0.02, "Roll does not follow weights");

        // Layouts: one pillar per player, never on the crown, never two on one column, all inside the border.
        for (PillarRules.Layout layout : PillarRules.Layout.values()) {
            for (int players = 2; players <= 10; players++) {
                List<PillarRules.Pillar> pillars = PillarRules.pillars(layout, players, random.nextDouble() * 7);
                require(pillars.size() == players, "Wrong pillar count");
                Set<Long> columns = new HashSet<>();
                int half = PillarRules.borderSize(layout, players) / 2;
                for (PillarRules.Pillar pillar : pillars) {
                    require(columns.add(((long) pillar.x() << 32) ^ (pillar.z() & 0xffffffffL)), "Two pillars share a column");
                    require(Math.hypot(pillar.x(), pillar.z()) >= 6, "Pillar too close to the crown");
                    require(Math.abs(pillar.x()) + 5 < half && Math.abs(pillar.z()) + 5 < half, "Pillar outside the border");
                    require(pillar.topY() <= PillarRules.TOP_Y && pillar.topY() >= PillarRules.TOP_Y - 6, "Pillar height off");
                    require(half + 2 < PillarRules.SWEEP_RADIUS, "Reset sweep misses the arena");
                }
                for (int i = 0; i < pillars.size(); i++) {
                    for (int j = i + 1; j < pillars.size(); j++) {
                        double gap = Math.hypot(pillars.get(i).x() - pillars.get(j).x(), pillars.get(i).z() - pillars.get(j).z());
                        require(gap >= 5, layout + " pillars " + gap + " apart with " + players + " players");
                    }
                }
            }
        }
        require(PillarRules.ringRadius(2) == 15 && PillarRules.ringRadius(10) == 32, "Ring radius off");

        // Twists: every twist appears, never one of the last few.
        Set<PillarRules.Twist> seen = new HashSet<>();
        java.util.ArrayDeque<PillarRules.Twist> recent = new java.util.ArrayDeque<>();
        for (int game = 0; game < 2000; game++) {
            PillarRules.Twist twist = PillarRules.pickTwist(random, recent);
            require(!recent.contains(twist), "Twist repeated within " + PillarRules.RECENT_TWIST_MEMORY + " games");
            seen.add(twist);
            recent.addLast(twist);
            if (recent.size() > PillarRules.RECENT_TWIST_MEMORY) recent.removeFirst();
        }
        require(seen.size() == PillarRules.Twist.values().length, "A twist never appears");
        PillarRules.Layout lastLayout = null;
        for (int game = 0; game < 200; game++) {
            PillarRules.Layout layout = PillarRules.pickLayout(random, 3, lastLayout);
            require(layout != lastLayout && layout != PillarRules.Layout.STAR, "Bad layout pick for 3 players");
            lastLayout = layout;
        }

        // Timings: 3s loot, 5 min + 2 min, frenzy and crown faster, deathmatch never slower.
        require(PillarRules.MAIN_TICKS == 6000 && PillarRules.DEATHMATCH_TICKS == 2400, "Match is not 5m + 2m");
        require(PillarRules.lootInterval(PillarRules.Twist.SLIME_FLOOR, false, false) == 60, "Loot is not every 3s");
        require(PillarRules.lootInterval(PillarRules.Twist.LOOT_FRENZY, false, false) == 30, "Frenzy is not 1.5s");
        require(PillarRules.lootInterval(PillarRules.Twist.SLIME_FLOOR, false, true) == 30, "Crown does not double loot");
        require(PillarRules.lootInterval(PillarRules.Twist.SLIME_FLOOR, true, false) <= 60, "Deathmatch loot slower");

        // Rising lava: starts at the pillar bottoms, stays below the tops all main phase, reaches them in deathmatch.
        require(PillarRules.lavaLevel(0, 0) == PillarRules.BOTTOM_Y, "Lava starts in the wrong place");
        int previous = PillarRules.lavaLevel(0, 0);
        for (int t = 0; t <= PillarRules.MAIN_TICKS; t += 20) {
            int level = PillarRules.lavaLevel(t, 0);
            require(level >= previous && level < PillarRules.TOP_Y, "Lava drops or floods the tops early");
            previous = level;
        }
        require(PillarRules.lavaLevel(PillarRules.MAIN_TICKS, PillarRules.DEATHMATCH_TICKS) == PillarRules.TOP_Y,
                "Lava never reaches the tops");
        require(PillarRules.voidY(PillarRules.Twist.SLIME_FLOOR) < PillarRules.BOTTOM_Y - 1
                && PillarRules.voidY(PillarRules.Twist.TNT_RAIN) > PillarRules.SWEEP_MIN_Y, "Void line off");
        require(PillarRules.MID_BORDER_SECONDS * 20 < PillarRules.DEATHMATCH_TICKS
                && PillarRules.FINAL_BORDER < PillarRules.MID_BORDER
                && PillarRules.MID_BORDER / 2 > PillarRules.DEATHMATCH_PLATFORM_RADIUS, "Border schedule off");
        for (int players = 2; players <= 10; players++) {
            int shift = PillarRules.shuffleShift(random, players);
            require(shift >= 1 && shift < players, "Shuffle leaves someone in place");
        }
    }

    private static boolean hits(boolean[][] pattern, int direction, BoundingBox body) {
        for (int across = 0; across < WallCourse.WIDTH; across++) {
            for (int y = 0; y < WallCourse.HEIGHT; y++) {
                if (!pattern[across][y]) continue;
                int x = WallCourse.x(direction, across - 6, 0);
                int z = WallCourse.z(direction, across - 6, 0);
                if (body.overlaps(new BoundingBox(x, y, z, x + 1, y + 1, z + 1).expand(0.06, 0, 0.06))) return true;
            }
        }
        return false;
    }
}
