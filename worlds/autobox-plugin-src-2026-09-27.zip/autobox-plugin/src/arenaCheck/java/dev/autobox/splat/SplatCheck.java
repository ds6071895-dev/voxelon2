package dev.autobox.splat;

import dev.autobox.lobby.GameType;
import dev.autobox.splat.SplatArena.Blueprint;
import dev.autobox.splat.SplatArena.MapDef;
import dev.autobox.splat.SplatArena.Pos;
import dev.autobox.splat.SplatRules.Team;
import org.bukkit.Material;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Team rules, ratings, ranked scoring, map fairness/navigation and pack contents, without a running server. */
public final class SplatCheck {
    static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }

    public static void main(String[] args) throws Exception {
        rules();
        rating();
        ranked();
        balance();
        int notes = music();
        StringBuilder maps = new StringBuilder();
        for (MapDef map : SplatArena.MAPS) {
            int reachable = arena(map);
            maps.append(map.name()).append(" (").append(map.blueprint().turf().size()).append(" turf, ").append(reachable)
                    .append(" reachable, tower ").append(map.towerGoal()).append(" steps) ");
        }
        mapsApart();
        int files = pack(args[0]);
        System.out.println("SPLAT_CHECK_PASSED: team splits and rating drafts, Elo/ranks/levels, ranked counts/penalties/overtime, "
                + maps + "with every mode anchor reachable, " + Kit.values().length + " kits, " + files + " pack files, "
                + notes + " in-range music notes, unrelated queue limits.");
    }

    static void rules() {
        require(!SplatRules.validParty(1) && SplatRules.validParty(2) && SplatRules.validParty(10) && !SplatRules.validParty(11), "Party bounds");
        for (int party = 2; party <= 10; party++) {
            for (int seed = 0; seed < 300; seed++) {
                List<UUID> ids = new ArrayList<>();
                Map<UUID, Integer> ratings = new HashMap<>();
                Random random = new Random(seed);
                for (int i = 0; i < party; i++) { ids.add(new UUID(1, i)); ratings.put(ids.getLast(), 700 + random.nextInt(900)); }
                for (Map<UUID, Team> teams : List.of(SplatRules.assign(ids, new Random(seed)), SplatRating.draft(ids, ratings, new Random(seed)))) {
                    require(teams.keySet().equals(new HashSet<>(ids)), "Every player gets a team");
                    Map<Team, Integer> sizes = new EnumMap<>(Team.class);
                    for (Team team : Team.values()) sizes.put(team, 0);
                    teams.values().forEach(team -> sizes.merge(team, 1, Integer::sum));
                    int orange = sizes.get(Team.ORANGE), blue = sizes.get(Team.BLUE);
                    require(Math.abs(orange - blue) <= 1 && orange > 0 && blue > 0, "Balanced teams for " + party);
                    for (Team team : Team.values()) {
                        boolean smaller = sizes.get(team) < sizes.get(team.opponent());
                        double boost = smaller ? sizes.get(team.opponent()) / (double) sizes.get(team) : 1;
                        require(SplatRules.regenMultiplier(team, sizes) == boost, "Comeback regen");
                        require(Math.abs(SplatRules.damageTaken(10, team, sizes) * boost - 10) < 1e-9, "Underdog damage");
                        require(SplatRules.respawnTicks(team, sizes) <= SplatRules.RESPAWN && SplatRules.respawnTicks(team, sizes) > 0, "Underdog respawn");
                    }
                }
                if (party >= 2) {
                    Map<UUID, Team> draft = SplatRating.draft(ids, ratings, new Random(seed));
                    List<UUID> byRating = ids.stream().sorted(Comparator.comparingInt((UUID id) -> ratings.get(id)).reversed()).toList();
                    if (!ratings.get(byRating.get(0)).equals(ratings.get(byRating.get(1))))
                        require(draft.get(byRating.get(0)) != draft.get(byRating.get(1)), "The two best players are split up");
                }
            }
        }
        require(SplatRules.percent(0, 0) == 0 && SplatRules.percent(1, 4) == 25, "Percent maths");
        require(SplatRules.winner(3, 3) == null && SplatRules.winner(4, 3) == Team.ORANGE && SplatRules.winner(2, 9) == Team.BLUE, "Winner and draw");
        require(SplatRules.format(33.333).equals("33.3%") && SplatRules.clock(3600).equals("3:00") && SplatRules.clock(19).equals("0:01"), "HUD formatting");
        for (GameType type : GameType.values())
            require(type.minPlayers() == 2 && type.maxPlayers() == (type == GameType.SPLAT || type == GameType.RAT_SEEK || type == GameType.LUCKY_PILLARS ? 10 : 6), "Unrelated queue changed");
        for (SplatMode mode : SplatMode.values()) {
            require(SplatMode.byKey(mode.key) == mode && mode.howTo.size() == 3, "Mode keys and how-to " + mode);
            require(mode.ranked == (mode != SplatMode.TURF_WAR) && mode.playTicks >= 3600, "Mode lengths " + mode);
        }
        require(SplatMode.RANKED.size() == 4 && SplatMode.RANKED.stream().allMatch(m -> m.ranked), "Ranked rotation");
    }

    static void rating() {
        Random random = new Random(5);
        for (int i = 0; i < 2000; i++) {
            double a = 600 + random.nextInt(1200), b = 600 + random.nextInt(1200);
            int sa = 1 + random.nextInt(5), sb = 1 + random.nextInt(5);
            double ea = SplatRating.expected(a, b, sa, sb), eb = SplatRating.expected(b, a, sb, sa);
            require(Math.abs(ea + eb - 1) < 1e-9 && ea > 0 && ea < 1, "Expected scores are complementary");
            int matches = random.nextInt(30);
            require(SplatRating.delta(matches, ea, 1, false) >= 0 && SplatRating.delta(matches, ea, 0, false) <= 0, "Wins never lose rating, losses never gain");
            require(SplatRating.delta(matches, ea, 1, true) >= SplatRating.delta(matches, ea, 1, false), "Knockout wins earn at least as much");
        }
        require(SplatRating.expected(1000, 1000, 2, 3) > 0.5, "The outnumbered team is expected to be stronger");
        double even = SplatRating.expected(1000, 1000, 1, 1);
        require(SplatRating.delta(0, even, 1, false) == (int) Math.round(SplatRating.K_PLACEMENT / 2)
                && SplatRating.delta(20, even, 0, false) == -(int) Math.round(SplatRating.K / 2), "Even 1v1 swings by K/2");
        require(SplatRating.delta(20, even, 0.5, false) == 0, "Even draw changes nothing");
        SplatRating.Rank[] ranks = SplatRating.Rank.values();
        for (int i = 1; i < ranks.length; i++) require(ranks[i].from > ranks[i - 1].from, "Rank thresholds rise");
        require(SplatRating.rank(SplatRating.START) == SplatRating.Rank.B && SplatRating.rank(0) == SplatRating.Rank.C_MINUS
                && SplatRating.rank(5000) == SplatRating.Rank.X, "Rank letters");
        require(SplatRating.label(1500, SplatRating.PROVISIONAL - 1).equals("?") && SplatRating.label(1500, SplatRating.PROVISIONAL).equals("X"), "Provisional ranks");
        require(SplatRating.level(0) == 1 && SplatRating.level(SplatRating.xpToNext(1) - 1) == 1 && SplatRating.level(SplatRating.xpToNext(1)) == 2, "First level-up");
        require(SplatRating.xpIntoLevel(SplatRating.xpToNext(1) + 7) == 7, "XP into level");
        require(SplatRating.level(Long.MAX_VALUE / 4) == SplatRating.MAX_LEVEL, "Level cap");
        long xp = 0;
        int last = 1;
        for (int i = 0; i < 400; i++) {
            xp += SplatRating.matchXp(i % 2 == 0, false, 300, 3, 2, 1);
            int level = SplatRating.level(xp);
            require(level >= last && level - last <= 1, "Levels climb one at a time");
            last = level;
        }
        require(last > 20 && last < SplatRating.MAX_LEVEL, "Level curve is neither instant nor endless: " + last);
    }

    static void ranked() {
        require(RankedRules.leader(40, 60) == Team.ORANGE && RankedRules.leader(60, 40) == Team.BLUE && RankedRules.leader(50, 50) == null, "Lower count leads");
        require(RankedRules.knockout(0, 30) == Team.ORANGE && RankedRules.knockout(30, 0) == Team.BLUE && RankedRules.knockout(5, 5) == null, "Knockouts");
        require(RankedRules.overtime(40, 60, Team.BLUE, 0) && !RankedRules.overtime(40, 60, Team.ORANGE, 0) && !RankedRules.overtime(40, 60, null, 0),
                "Overtime only while the trailing team holds the objective");
        require(RankedRules.overtime(50, 50, Team.BLUE, 0) && !RankedRules.overtime(40, 60, Team.BLUE, RankedRules.OVERTIME_CAP), "Tied overtime and cap");
        require(RankedRules.overtimeDecided(60, 40, Team.BLUE) && !RankedRules.overtimeDecided(40, 60, Team.BLUE) && !RankedRules.overtimeDecided(40, 60, null),
                "Overtime ends when the holder takes the lead");
        require(RankedRules.penaltyAfterLoss(0) == 0 && RankedRules.penaltyAfterLoss(10) == 7.5 && RankedRules.penaltyAfterLoss(1000) == RankedRules.PENALTY_CAP, "Penalty");
        require(RankedRules.zoneControl(null, 70, 0, 100) == Team.ORANGE && RankedRules.zoneControl(null, 69, 0, 100) == null, "Zone threshold");
        require(RankedRules.zoneControl(Team.ORANGE, 60, 20, 100) == Team.ORANGE && RankedRules.zoneControl(Team.ORANGE, 30, 40, 100) == null
                && RankedRules.zoneControl(Team.ORANGE, 10, 75, 100) == Team.BLUE, "Holders keep, lose and hand over the zone");
        require(RankedRules.progressCount(0) == 100 && RankedRules.progressCount(1) == 0 && RankedRules.progressCount(0.456) == 54, "Progress counts");

        // Zones simulation: Orange holds 30 s, Blue steals for 10 s, Orange retakes and must burn its penalty first.
        double orange = 100, blue = 100, orangePenalty = 0, scored = 0;
        for (int t = 0; t < 600; t++) { orange -= RankedRules.ZONE_RATE; scored += RankedRules.ZONE_RATE; }
        orangePenalty += RankedRules.penaltyAfterLoss(scored);
        for (int t = 0; t < 200; t++) blue -= RankedRules.ZONE_RATE;
        double before = orange;
        for (int t = 0; t < 200; t++) {
            if (orangePenalty > 0) orangePenalty = Math.max(0, orangePenalty - RankedRules.ZONE_RATE);
            else orange -= RankedRules.ZONE_RATE;
        }
        require(Math.abs(orange - 70) < 1e-6 && Math.abs(blue - 90) < 1e-6 && orange == before && orangePenalty > 0, "Penalty burns before the count moves");
        require(RankedRules.winner(orange, blue) == Team.ORANGE, "Zones leader");
    }

    /** Hits needed to splat from full health with a given per-hit damage. */
    static int hits(double damage) { return (int) Math.ceil(SplatRules.MAX_HEALTH / damage - 1e-9); }

    static double shot(Weapon w, int age) {
        Weapon.Ballistics b = w.ballistics;
        return SplatRules.falloff(w.damage, age, b.fullUntil(), b.fadeUntil(), b.minFactor());
    }

    static void balance() {
        for (Weapon w : Weapon.values()) {
            Weapon.Ballistics b = w.ballistics;
            require(w.model.matches("[a-z_]+") && w.title != null && !w.help.isBlank(), "Weapon metadata " + w);
            if (b == null) continue;
            require(b.fullUntil() <= b.fadeUntil() && b.minFactor() > 0 && b.minFactor() <= 1 && b.speed() > 0 && b.straightTicks() >= 0, "Ballistics shape " + w);
            double previous = Double.MAX_VALUE;
            for (int age = 0; age < 40; age++) {
                double d = shot(w, age);
                require(d <= previous + 1e-9 && d >= w.damage * b.minFactor() - 1e-9, "Falloff must fade monotonically " + w);
                previous = d;
            }
        }
        require(hits(shot(Weapon.SPLATTERSHOT, 0)) == 3, "Close Splattershot splats in exactly three hits");
        require(hits(shot(Weapon.SPLATTERSHOT, 40)) >= 5, "Long-range Splattershot is weaker");
        require(hits(shot(Weapon.DUALIES, 0)) == 4, "Dualies splat in four hits");
        require(hits(shot(Weapon.BLASTER, 0)) == 1 && Weapon.BLASTER_SPLASH < SplatRules.MAX_HEALTH / 2, "Blaster direct hits splat, splash doesn't");
        require(hits(Weapon.SLOSHER.damage) == 2 && Weapon.SLOSHER.damage + 2 * Weapon.SLOSH_TRAIL_DAMAGE < SplatRules.MAX_HEALTH, "Slosher: two lead hits, not one full slosh");
        require(shot(Weapon.INKBRUSH, 0) * Weapon.INKBRUSH.ballistics.pellets() < SplatRules.MAX_HEALTH, "Inkbrush flicks never one-shot");
        int pellets = Weapon.ROLLER.ballistics.pellets();
        require(shot(Weapon.ROLLER, 0) * pellets >= SplatRules.MAX_HEALTH, "Point-blank roller fling splats");
        require(shot(Weapon.ROLLER, 0) * 2 < SplatRules.MAX_HEALTH, "Two roller pellets must not splat");
        require(Weapon.ROLL_DAMAGE >= SplatRules.MAX_HEALTH && Weapon.FLATTEN_SPEED < 0.2, "Rolling into a foe at walking pace splats");
        for (int held = 0; held < Weapon.CHARGE_TICKS; held++) {
            double charge = SplatRules.charge(held, SplatRules.MAX_INK);
            require(charge < 1 && SplatRules.chargerDamage(charge) < SplatRules.MAX_HEALTH, "Partial charger shot one-shots at " + held + " ticks");
            require(SplatRules.chargerRange(charge) < Weapon.CHARGER_RANGE, "Partial charge range");
        }
        require(SplatRules.charge(Weapon.CHARGE_TICKS, SplatRules.MAX_INK) == 1
                && SplatRules.chargerDamage(1) >= SplatRules.MAX_HEALTH, "Full charge splats");
        require(SplatRules.charge(Weapon.CHARGE_TICKS, Weapon.CHARGER_MIN_INK) == 0
                && SplatRules.chargerInk(SplatRules.charge(Weapon.CHARGE_TICKS, 12)) <= 12 + 1e-9, "Charge is capped by the ink tank");
        require(Weapon.CHARGE_TICKS >= 20, "Full charge must take at least a second");
        require(Weapon.CHARGE_RELEASE > 4, "Java's 4-tick use repeat must not read as a release");
        require(SplatRules.falloff(10, 5, 5, 5, 0.5) == 10 && SplatRules.falloff(10, 6, 5, 5, 0.5) == 5, "Degenerate falloff");

        Set<Weapon> mains = new HashSet<>();
        for (Kit kit : Kit.values()) {
            require(kit.main.kind == Weapon.Kind.MAIN && kit.sub.kind == Weapon.Kind.SUB && kit.special.kind == Weapon.Kind.SPECIAL, "Kit slots " + kit);
            require(mains.add(kit.main) && Kit.of(kit.main) == kit, "One kit per main " + kit);
            require(kit.main.specialTurf > 0 && SplatRules.specialPerTurf(kit.main) > 0, "Special gauge for " + kit);
        }
        require(mains.equals(new HashSet<>(Arrays.asList(Weapon.MAIN))), "Every main has a kit");
        require(Kit.values().length < SplatGame.LOCKER_SLOT, "Kit selectors fit in the hotbar before the locker");
        Set<Integer> slots = Set.of(SplatGame.MAIN_SLOT, SplatGame.SUB_SLOT, SplatGame.SPECIAL_SLOT, SplatGame.JUMP_SLOT, SplatGame.SQUID_SLOT);
        require(slots.size() == 5, "In-match hotbar slots are distinct (squid slot stays empty)");
        require(Weapon.Kind.values().length == 5 && Weapon.SUPER_JUMP.kind == Weapon.Kind.UTILITY, "Weapon kinds");
    }

    static int music() {
        int notes = 0;
        for (SplatMusic.Track track : SplatMusic.Track.values()) {
            int length = SplatMusic.length(track);
            require(length > 0, "Empty track " + track);
            for (int step = 0; step < length; step++) {
                for (SplatMusic.Note note : SplatMusic.step(track, step)) {
                    require(note.pitch() >= 0.5f - 1e-4 && note.pitch() <= 2f + 1e-4, "Note block pitch out of range in " + track + " step " + step);
                    require(note.volume() > 0 && note.volume() <= 1, "Volume in " + track);
                    notes++;
                }
            }
            require(!track.loops || length % SplatMusic.BAR == 0, "Looping track must end on a bar " + track);
        }
        require(SplatMusic.length(SplatMusic.Track.COUNTDOWN) * SplatMusic.STEP_TICKS == SplatRules.COUNTDOWN, "Countdown riser lands on GO");
        require(SplatMusic.length(SplatMusic.Track.JUDGING) * SplatMusic.STEP_TICKS == SplatRules.JUDGING, "Drumroll fills judging");
        require(SplatMusic.length(SplatMusic.Track.VICTORY) >= SplatMusic.length(SplatMusic.Track.DEFEAT)
                && SplatMusic.length(SplatMusic.Track.VICTORY) >= SplatMusic.length(SplatMusic.Track.DRAW), "Results track length drives playback");
        require(SplatMusic.step(SplatMusic.Track.BATTLE, SplatMusic.length(SplatMusic.Track.BATTLE)).equals(SplatMusic.step(SplatMusic.Track.BATTLE, 0)), "Battle loops");
        require(SplatMusic.step(SplatMusic.Track.VICTORY, 10_000).isEmpty(), "One-shot tracks end");
        require(SplatMusic.midi("C4") == 60 && SplatMusic.midi("F#3") == 54 && SplatMusic.midi("Bb4") == 70, "Note names");
        return notes;
    }

    static int arena(MapDef map) {
        Blueprint arena = map.blueprint();
        Map<Pos, Material> blocks = arena.blocks();
        String name = map.name() + ": ";
        for (Map.Entry<Pos, Material> entry : blocks.entrySet()) {
            Pos p = entry.getKey();
            require(arena.bounds().contains(p), name + "block outside bounds " + p);
            Material mirrored = blocks.get(map.mirror(p));
            Material expected = entry.getValue() == Team.ORANGE.glass ? Team.BLUE.glass
                    : entry.getValue() == Team.BLUE.glass ? Team.ORANGE.glass : entry.getValue();
            require(mirrored == expected, name + "not point-symmetric at " + p);
        }
        for (Pos p : arena.paintable()) require(blocks.get(p) == SplatArena.TURF, name + "paintable non-turf " + p);
        for (Pos p : arena.turf()) require(arena.paintable().contains(p) && !blocks.containsKey(p.add(0, 1, 0)), name + "covered turf " + p);
        long west = arena.turf().stream().filter(p -> p.x() < map.offsetX()).count(), east = arena.turf().stream().filter(p -> p.x() > map.offsetX()).count();
        require(west == east && arena.turf().size() > 1500, name + "unequal or tiny turf: " + west + "/" + east);

        for (Team team : Team.values()) {
            List<Pos> spawns = arena.spawns().get(team);
            require(spawns.size() == SplatRules.MAX_PLAYERS && new HashSet<>(spawns).size() == spawns.size(), name + "ten unique spawns");
            for (Pos s : spawns) {
                require(standable(blocks, s) && blocks.get(s.add(0, -1, 0)) == SplatArena.BASE, name + "unsafe spawn " + s);
                require(map.inBase(team, s.x() + 0.5) && !map.inBase(team.opponent(), s.x() + 0.5), name + "spawn outside base " + s);
            }
        }
        for (int i = 0; i < SplatRules.MAX_PLAYERS; i++)
            require(map.mirror(arena.spawns().get(Team.ORANGE).get(i)).equals(arena.spawns().get(Team.BLUE).get(i)), name + "mirrored spawns");

        Set<Pos> visited = reachable(map);
        for (Pos s : arena.spawns().get(Team.BLUE)) require(visited.contains(s), name + "Blue base unreachable from Orange " + s);
        int reachable = 0;
        for (Pos p : arena.turf()) {
            Pos feet = p.add(0, 1, 0);
            require(standable(blocks, feet), name + "turf nobody can stand on " + p);
            require(visited.contains(feet), name + "unreachable turf " + p);
            require(!map.inBase(Team.ORANGE, p.x() + 0.5) && !map.inBase(Team.BLUE, p.x() + 0.5), name + "turf inside a base " + p);
            reachable++;
        }
        anchors(map, visited);
        return reachable;
    }

    static Set<Pos> reachable(MapDef map) {
        Blueprint arena = map.blueprint();
        Map<Pos, Material> blocks = arena.blocks();
        Set<Pos> visited = new HashSet<>();
        ArrayDeque<Pos> queue = new ArrayDeque<>();
        Pos start = arena.spawns().get(Team.ORANGE).getFirst();
        visited.add(start);
        queue.add(start);
        while (!queue.isEmpty()) {
            Pos cur = queue.poll();
            for (int[] d : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                for (int dy = 1; dy >= -3; dy--) {
                    Pos next = cur.add(d[0], dy, d[1]);
                    if (!standable(blocks, next) || !arena.bounds().contains(next)) continue;
                    if (dy == 1 && blocks.containsKey(cur.add(0, 2, 0))) continue;
                    if (dy < 0 && (blocks.containsKey(new Pos(next.x(), cur.y(), next.z())) || blocks.containsKey(new Pos(next.x(), cur.y() + 1, next.z())))) continue;
                    if (visited.add(next)) queue.add(next);
                }
            }
        }
        return visited;
    }

    /** Every mode's props fit in open air, are symmetric and can be reached on foot. */
    static void anchors(MapDef map, Set<Pos> visited) {
        Blueprint arena = map.blueprint();
        Map<Pos, Material> blocks = arena.blocks();
        SplatArena.Anchors a = map.anchors();
        String name = map.name() + ": ";

        require(a.zone().size() >= 60 && arena.turf().containsAll(a.zone()), name + "zone is turf and big enough");
        for (Pos p : a.zone()) require(a.zone().contains(map.mirror(p)), name + "zone is symmetric");

        int goal = map.towerGoal();
        require(goal >= 15 && map.towerAt(0).x() == map.offsetX() && map.towerAt(0).z() == 0, name + "tower starts in the middle");
        Set<Pos> previous = null;
        for (int step = -goal; step <= goal; step++) {
            Pos c = map.towerAt(step);
            if (step > -goal) {
                Pos before = map.towerAt(step - 1);
                require(c.x() - before.x() == 1 && Math.abs(c.y() - before.y()) <= 1 && c.z() == 0, name + "tower path moves one block at a time at " + step);
            }
            require(map.towerAt(-step).equals(map.mirror(c)), name + "tower path is mirrored");
            Set<Pos> tower = TowerObjective.blocks(c, null).keySet();
            for (Pos p : tower) require(!blocks.containsKey(p) && arena.bounds().contains(p), name + "tower overlaps the map at step " + step + " " + p);
            // A rider can stand on the platform next to the pillar.
            require(tower.contains(c.add(1, 0, 0)) && !tower.contains(c.add(1, 1, 0)), name + "tower has room to ride");
            previous = tower;
        }
        require(previous != null, name + "tower path");
        for (int checkpoint : a.checkpoints()) require(checkpoint > 0 && checkpoint < goal, name + "checkpoints inside the path");
        Pos standBeside = map.towerAt(0).add(0, 0, 2);
        require(visited.stream().anyMatch(v -> Math.abs(v.x() - standBeside.x()) <= 3 && Math.abs(v.z()) <= 3 && v.y() >= map.towerAt(0).y() - 1),
                name + "players can reach the tower's starting height");

        for (Team team : Team.values()) {
            Pos g = a.goal().get(team);
            require(arena.turf().contains(g) && a.goal().get(team.opponent()).equals(map.mirror(g)), name + "goals are mirrored turf");
            require(map.progress(team, g.x() + 0.5) == 1 && map.progress(team, map.offsetX() + 0.5) == 0, name + "goal progress");
            require(team == Team.ORANGE ? g.x() > map.offsetX() : g.x() < map.offsetX(), name + "each team pushes toward the enemy base");
            require(visited.contains(g.add(1, 1, 0)) && visited.contains(g.add(-1, 1, 0)), name + "goal reachable " + g);
            require(Math.abs(g.x() - map.towerAt(team == Team.ORANGE ? goal : -goal).x()) == 0, name + "tower ends at the goal");
            // Rainmaker pedestal (y+1) and Clam basket (y+1..y+4) sit in open air.
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    for (int dy = 1; dy <= ClamObjective.BARRIER_Y; dy++)
                        require(!blocks.containsKey(g.add(dx, dy, dz)), name + "goal props overlap the map at " + g.add(dx, dy, dz));
            int towardCentre = team == Team.ORANGE ? -1 : 1;
            require(visited.contains(g.add(2 * towardCentre, 1, 0)) && visited.contains(g.add(0, 1, 2)), name + "room to approach the basket and pedestal");
        }
        Pos shield = a.shield();
        require(map.mirror(shield).equals(shield), name + "shield in the exact middle");
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
                for (int dz = -1; dz <= 1; dz++)
                    if (Math.abs(dx) + Math.abs(dy) + Math.abs(dz) <= 2)
                        require(!blocks.containsKey(shield.add(dx, dy, dz)), name + "shield overlaps the map");
        require(blocks.containsKey(shield.add(0, -2, 0)) && visited.contains(shield.add(2, -1, 0)), name + "shield rests on a reachable floor");

        require(a.clams().size() >= 10 && a.clams().size() % 2 == 0, name + "clam spots");
        for (Pos c : a.clams()) {
            require(arena.turf().contains(c) && visited.contains(c.add(0, 1, 0)), name + "clam spot on reachable turf " + c);
            require(a.clams().contains(map.mirror(c)), name + "clam spots are mirrored");
        }
    }

    static void mapsApart() {
        List<MapDef> maps = SplatArena.MAPS;
        require(maps.size() >= 2, "At least two maps");
        for (int i = 0; i < maps.size(); i++)
            for (int j = i + 1; j < maps.size(); j++) {
                SplatArena.Bounds a = maps.get(i).blueprint().bounds(), b = maps.get(j).blueprint().bounds();
                require(a.maxX() + 48 < b.minX() || b.maxX() + 48 < a.minX(), "Maps are far enough apart not to see each other's props");
            }
    }

    static boolean standable(Map<Pos, Material> blocks, Pos feet) {
        return blocks.containsKey(feet.add(0, -1, 0)) && !blocks.containsKey(feet) && !blocks.containsKey(feet.add(0, 1, 0));
    }

    static int pack(String path) throws Exception {
        try (ZipFile zip = new ZipFile(path)) {
            String meta = read(zip, "pack.mcmeta");
            require(meta.contains("\"min_format\": 88") && meta.contains("\"max_format\": 88"), "Pack format for 26.2");
            for (String block : List.of("white_concrete", "orange_concrete", "blue_concrete")) image(zip, "assets/minecraft/textures/block/" + block + ".png");
            List<String[]> items = new ArrayList<>();
            for (Weapon weapon : Weapon.values()) items.add(new String[]{weapon.model, weapon.base.name()});
            for (Team team : Team.values()) items.add(new String[]{Weapon.inkModel(team), Weapon.PROJECTILE.name()});
            Set<String> models = new HashSet<>();
            for (String[] item : items) {
                String model = item[0], base = item[1].toLowerCase(Locale.ROOT);
                require(models.add(model), "Duplicate model name " + model);
                require(read(zip, "assets/splat/models/item/" + model + ".json").contains("splat:item/" + model), "Model texture " + model);
                BufferedImage art = image(zip, "assets/splat/textures/item/" + model + ".png");
                int opaque = 0;
                for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) if ((art.getRGB(x, y) >>> 24) != 0) opaque++;
                require(opaque >= 12, "Item art is not blank: " + model);
                String definition = read(zip, "assets/minecraft/items/" + base + ".json");
                require(definition.contains("\"when\": \"" + model + "\"") && definition.contains("\"model\": \"minecraft:item/" + base + "\""),
                        "Item definition must select " + model + " and fall back to vanilla " + base);
            }
            return zip.size();
        }
    }

    static String read(ZipFile zip, String name) throws Exception {
        ZipEntry entry = zip.getEntry(name);
        require(entry != null, "Pack is missing " + name);
        try (var in = zip.getInputStream(entry)) { return new String(in.readAllBytes(), StandardCharsets.UTF_8); }
    }

    static BufferedImage image(ZipFile zip, String name) throws Exception {
        ZipEntry entry = zip.getEntry(name);
        require(entry != null, "Pack is missing " + name);
        try (var in = zip.getInputStream(entry)) {
            BufferedImage img = ImageIO.read(in);
            require(img != null && img.getWidth() == 16 && img.getHeight() == 16, "Texture must be 16x16: " + name);
            return img;
        }
    }
}
