package dev.autobox.splatpack;

import dev.autobox.splat.SplatRules.Team;
import dev.autobox.splat.Weapon;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Draws and zips the in-match Splatoon pack. Output is byte-for-byte reproducible, so the
 * SHA-1 sent to clients only changes when the art or models change.
 */
public final class PackGenerator {
    /** Minecraft 26.2 resource pack format (version.json resource_major). */
    public static final int PACK_FORMAT = 88;
    private static final int OUTLINE = 0x1B1D22;
    private final TreeMap<String, byte[]> files = new TreeMap<>();

    public static void main(String[] args) throws IOException {
        Path out = Path.of(args[0]);
        Files.createDirectories(out.getParent());
        PackGenerator pack = new PackGenerator();
        pack.generate();
        try (OutputStream stream = Files.newOutputStream(out)) { pack.write(stream); }
        System.out.println("Splatoon pack: " + pack.files.size() + " files -> " + out);
    }

    void generate() throws IOException {
        text("pack.mcmeta", """
                {
                  "pack": {
                    "description": "Worlds Splatoon ink textures (in-match only)",
                    "pack_format": %d,
                    "min_format": %d,
                    "max_format": %d
                  }
                }
                """.formatted(PACK_FORMAT, PACK_FORMAT, PACK_FORMAT));
        png("pack.png", icon());
        png("assets/minecraft/textures/block/white_concrete.png", turf());
        for (Team team : Team.values()) {
            png("assets/minecraft/textures/block/" + name(team.ink.name()) + ".png", ink(team.color.asRGB(), team.ordinal()));
        }

        Map<String, List<String>> overrides = new TreeMap<>();
        for (Weapon weapon : Weapon.values()) {
            boolean held = weapon.kind == Weapon.Kind.MAIN || weapon == Weapon.RAINMAKER || weapon == Weapon.TRIZOOKA;
            model(weapon.model, held ? "handheld" : "generated");
            png("assets/splat/textures/item/" + weapon.model + ".png", weapon(weapon));
            overrides.computeIfAbsent(name(weapon.base.name()), key -> new ArrayList<>()).add(weapon.model);
        }
        for (Team team : Team.values()) {
            String model = Weapon.inkModel(team);
            model(model, "generated");
            png("assets/splat/textures/item/" + model + ".png", blob(team.color.asRGB()));
            overrides.computeIfAbsent(name(Weapon.PROJECTILE.name()), key -> new ArrayList<>()).add(model);
        }
        // Vanilla item definitions select our model by custom_model_data string and otherwise stay vanilla.
        for (Map.Entry<String, List<String>> entry : overrides.entrySet()) {
            StringBuilder cases = new StringBuilder();
            for (String model : entry.getValue()) {
                if (!cases.isEmpty()) cases.append(",\n");
                cases.append("      {\"when\": \"").append(model).append("\", \"model\": {\"type\": \"minecraft:model\", \"model\": \"splat:item/")
                        .append(model).append("\"}}");
            }
            text("assets/minecraft/items/" + entry.getKey() + ".json", """
                    {
                      "model": {
                        "type": "minecraft:select",
                        "property": "minecraft:custom_model_data",
                        "index": 0,
                        "cases": [
                    %s
                        ],
                        "fallback": {"type": "minecraft:model", "model": "minecraft:item/%s"}
                      }
                    }
                    """.formatted(cases, entry.getKey()));
        }
    }

    void write(OutputStream out) throws IOException {
        try (ZipOutputStream zip = new ZipOutputStream(out)) {
            for (Map.Entry<String, byte[]> file : files.entrySet()) {
                ZipEntry entry = new ZipEntry(file.getKey());
                entry.setTimeLocal(LocalDateTime.of(2026, 1, 1, 0, 0));
                zip.putNextEntry(entry);
                zip.write(file.getValue());
                zip.closeEntry();
            }
        }
    }

    private static String name(String material) { return material.toLowerCase(Locale.ROOT); }

    private void text(String path, String content) { files.put(path, content.getBytes(StandardCharsets.UTF_8)); }

    private void png(String path, BufferedImage image) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ImageIO.write(image, "png", bytes);
        files.put(path, bytes.toByteArray());
    }

    private void model(String model, String parent) {
        text("assets/splat/models/item/" + model + ".json",
                "{\"parent\": \"minecraft:item/" + parent + "\", \"textures\": {\"layer0\": \"splat:item/" + model + "\"}}\n");
    }

    // ------------------------------------------------------------------ art

    private static BufferedImage canvas(int size) { return new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB); }

    private static void set(BufferedImage img, int x, int y, int rgb) {
        if (x >= 0 && y >= 0 && x < img.getWidth() && y < img.getHeight()) img.setRGB(x, y, 0xFF000000 | rgb);
    }

    private static int shade(int rgb, double factor) {
        int[] c = {rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255};
        for (int i = 0; i < 3; i++) {
            c[i] = factor >= 1 ? (int) (c[i] + (255 - c[i]) * (factor - 1)) : (int) (c[i] * factor);
            c[i] = Math.max(0, Math.min(255, c[i]));
        }
        return c[0] << 16 | c[1] << 8 | c[2];
    }

    private static void disc(BufferedImage img, double cx, double cy, double r, int rgb) {
        for (int x = 0; x < img.getWidth(); x++)
            for (int y = 0; y < img.getHeight(); y++)
                if (Math.pow(x + 0.5 - cx, 2) + Math.pow(y + 0.5 - cy, 2) <= r * r) set(img, x, y, rgb);
    }

    /** Tileable disc: also drawn across every edge so block textures wrap seamlessly. */
    private static void wrapDisc(BufferedImage img, double cx, double cy, double r, int rgb) {
        int s = img.getWidth();
        for (int x = 0; x < s; x++)
            for (int y = 0; y < s; y++)
                for (int ox = -s; ox <= s; ox += s)
                    for (int oy = -s; oy <= s; oy += s)
                        if (Math.pow(x + 0.5 - cx - ox, 2) + Math.pow(y + 0.5 - cy - oy, 2) <= r * r) set(img, x, y, rgb);
    }

    private static void line(BufferedImage img, int x0, int y0, int x1, int y1, int width, int rgb) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= steps; i++) {
            int x = Math.round(x0 + (x1 - x0) * (float) i / Math.max(1, steps));
            int y = Math.round(y0 + (y1 - y0) * (float) i / Math.max(1, steps));
            for (int dx = 0; dx < width; dx++) for (int dy = 0; dy < width; dy++) set(img, x + dx - width / 2, y + dy - width / 2, rgb);
        }
    }

    private static BufferedImage outline(BufferedImage img, int rgb) {
        BufferedImage out = canvas(img.getWidth());
        out.setData(img.getData());
        for (int x = 0; x < img.getWidth(); x++) {
            for (int y = 0; y < img.getHeight(); y++) {
                if ((img.getRGB(x, y) >>> 24) != 0) continue;
                for (int[] d : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                    int nx = x + d[0], ny = y + d[1];
                    if (nx >= 0 && ny >= 0 && nx < img.getWidth() && ny < img.getHeight() && (img.getRGB(nx, ny) >>> 24) != 0) {
                        set(out, x, y, rgb);
                        break;
                    }
                }
            }
        }
        return out;
    }

    private static BufferedImage turf() {
        BufferedImage img = canvas(16);
        Random random = new Random(11);
        for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) set(img, x, y, x == 0 || y == 0 ? 0xDCE0E5 : 0xF2F3F5);
        for (int i = 0; i < 10; i++) set(img, 1 + random.nextInt(15), 1 + random.nextInt(15), 0xE8EAEE);
        return img;
    }

    private static BufferedImage ink(int rgb, int seed) {
        BufferedImage img = canvas(16);
        Random random = new Random(seed * 31L + 7);
        for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) set(img, x, y, rgb);
        for (int i = 0; i < 6; i++) wrapDisc(img, random.nextDouble() * 16, random.nextDouble() * 16, 1.5 + random.nextDouble() * 1.8, shade(rgb, 1.22));
        for (int i = 0; i < 4; i++) wrapDisc(img, random.nextDouble() * 16, random.nextDouble() * 16, 1.1, shade(rgb, 0.78));
        for (int i = 0; i < 9; i++) set(img, random.nextInt(16), random.nextInt(16), shade(rgb, 0.85));
        for (int i = 0; i < 3; i++) {
            int x = random.nextInt(13), y = random.nextInt(13);
            set(img, x, y + 1, shade(rgb, 1.65));
            set(img, x + 1, y, shade(rgb, 1.65));
        }
        return img;
    }

    private static BufferedImage blob(int rgb) {
        BufferedImage img = canvas(16);
        disc(img, 8, 10, 4.5, rgb);
        line(img, 8, 3, 8, 7, 2, rgb);
        disc(img, 6.5, 8.5, 1.2, shade(rgb, 1.6));
        return outline(img, shade(rgb, 0.45));
    }

    private static BufferedImage weapon(Weapon weapon) {
        BufferedImage img = canvas(16);
        switch (weapon) {
            case SPLATTERSHOT -> {
                line(img, 4, 11, 10, 5, 2, 0x9AA3AD);
                line(img, 10, 5, 13, 2, 1, 0xD5DAE0);
                line(img, 4, 11, 2, 14, 2, 0x50565E);
                disc(img, 7, 8, 2.4, 0x19D3C5);
                set(img, 6, 7, 0xC8FFF9);
            }
            case ROLLER -> {
                line(img, 2, 14, 9, 7, 1, 0x6B7280);
                line(img, 6, 3, 13, 10, 3, 0xD9DEE4);
                line(img, 6, 3, 13, 10, 1, 0xFF3FA4);
            }
            case CHARGER -> {
                line(img, 2, 13, 13, 2, 2, 0x9AA3AD);
                line(img, 3, 12, 12, 3, 1, 0x19D3C5);
                disc(img, 8.5, 5.5, 1.4, 0x2B2F36);
                line(img, 2, 13, 1, 15, 2, 0x50565E);
            }
            case BOMB -> {
                disc(img, 8, 9.5, 5, 0xD9DEE4);
                line(img, 3, 10, 13, 10, 1, 0xFF3FA4);
                line(img, 7, 2, 7, 4, 2, 0x6B7280);
                disc(img, 6, 7.5, 1.1, 0xFFFFFF);
            }
            case DUALIES -> {
                line(img, 2, 9, 7, 4, 2, 0x9AA3AD);
                line(img, 9, 12, 14, 7, 2, 0x9AA3AD);
                line(img, 2, 9, 2, 12, 2, 0x50565E);
                line(img, 9, 12, 9, 15, 2, 0x50565E);
                disc(img, 5, 7, 1.6, 0xFF3FA4);
                disc(img, 12, 10, 1.6, 0x19D3C5);
            }
            case SLOSHER -> {
                for (int y = 5; y <= 13; y++) line(img, 3 + (y - 5) / 4, y, 12 - (y - 5) / 4, y, 1, 0xD9DEE4);
                line(img, 3, 5, 12, 5, 1, 0x19D3C5);
                line(img, 2, 4, 5, 1, 1, 0x6B7280);
                line(img, 5, 1, 13, 4, 1, 0x6B7280);
                disc(img, 7.5, 9, 1.5, 0x9AA3AD);
            }
            case BLASTER -> {
                line(img, 3, 12, 9, 6, 3, 0x6B7280);
                disc(img, 11, 4.5, 3, 0xFFD23F);
                disc(img, 11, 4.5, 1.4, 0x2B2F36);
                line(img, 3, 12, 2, 15, 2, 0x50565E);
            }
            case INKBRUSH -> {
                line(img, 2, 14, 9, 7, 1, 0xA0673A);
                disc(img, 11, 5, 3.2, 0xFF3FA4);
                line(img, 10, 2, 14, 6, 1, 0xFFFFFF);
            }
            case BURST_BOMB -> {
                disc(img, 8, 10, 4, 0x19D3C5);
                line(img, 8, 2, 8, 6, 3, 0x19D3C5);
                disc(img, 6.5, 8.5, 1.1, 0xFFFFFF);
            }
            case SUCTION_BOMB -> {
                disc(img, 8, 7, 4.5, 0x9ACD32);
                line(img, 8, 11, 8, 13, 2, 0x6B7280);
                line(img, 4, 14, 12, 14, 2, 0xFF3FA4);
                disc(img, 6.5, 5.5, 1.1, 0xFFFFFF);
            }
            case SPRINKLER -> {
                line(img, 4, 13, 12, 13, 2, 0x6B7280);
                line(img, 8, 13, 8, 6, 2, 0x9AA3AD);
                line(img, 4, 6, 12, 6, 2, 0x19D3C5);
                for (int[] d : new int[][]{{2, 3}, {14, 3}, {8, 1}}) set(img, d[0], d[1], 0x19D3C5);
            }
            case BEAKON -> {
                disc(img, 8, 11, 4.5, 0x50565E);
                disc(img, 8, 11, 2.5, 0xFFD23F);
                line(img, 8, 2, 8, 7, 1, 0xFFF3A0);
                set(img, 6, 4, 0xFFF3A0);
                set(img, 10, 4, 0xFFF3A0);
            }
            case TRIZOOKA -> {
                line(img, 2, 13, 12, 3, 4, 0x6B7280);
                for (int[] d : new int[][]{{12, 2}, {14, 4}, {12, 5}}) disc(img, d[0], d[1], 1, 0xFFD23F);
                line(img, 5, 12, 4, 15, 2, 0x50565E);
            }
            case BUBBLER -> {
                disc(img, 8, 8, 6, 0x7FD8FF);
                disc(img, 8, 8, 4.8, 0xBFEFFF);
                disc(img, 5.5, 5.5, 1.3, 0xFFFFFF);
            }
            case INK_STORM -> {
                disc(img, 5, 6, 3, 0xD9DEE4);
                disc(img, 9, 5, 3.5, 0xD9DEE4);
                disc(img, 12, 7, 2.5, 0xD9DEE4);
                for (int x : new int[]{4, 8, 12}) line(img, x, 10, x - 1, 14, 1, 0x19D3C5);
            }
            case BOOYAH -> {
                disc(img, 8, 8, 6.5, 0xFFD23F);
                disc(img, 8, 8, 4.5, 0xFF3FA4);
                disc(img, 8, 8, 2, 0xFFFFFF);
            }
            case RAINMAKER -> {
                line(img, 2, 12, 12, 4, 4, 0xFFD23F);
                disc(img, 12.5, 3.5, 2.5, 0xFFB000);
                set(img, 13, 3, 0x2B2F36);
                line(img, 5, 12, 3, 15, 2, 0x8B5A00);
            }
            case CLAM -> {
                disc(img, 8, 9, 5, 0xF2E6D8);
                for (int x = 4; x <= 12; x += 2) line(img, 8, 13, x, 5, 1, 0xC9B8A6);
                line(img, 4, 13, 12, 13, 1, 0xC9B8A6);
            }
            case POWER_CLAM -> {
                disc(img, 8, 9, 5.5, 0xFFD23F);
                for (int x = 3; x <= 13; x += 2) line(img, 8, 13, x, 4, 1, 0xFFB000);
                set(img, 2, 2, 0xFFFFFF);
                set(img, 14, 3, 0xFFFFFF);
            }
            case SUPER_JUMP -> {
                line(img, 3, 13, 8, 3, 2, 0x19D3C5);
                line(img, 8, 3, 13, 13, 2, 0x19D3C5);
                line(img, 5, 5, 8, 2, 2, 0xFFFFFF);
                line(img, 8, 2, 11, 5, 2, 0xFFFFFF);
            }
            case LOCKER -> {
                for (int y = 3; y <= 14; y++) line(img, 3, y, 12, y, 1, 0x6B7280);
                line(img, 8, 3, 8, 14, 1, 0x2B2F36);
                set(img, 7, 8, 0xFFD23F);
                set(img, 9, 8, 0xFFD23F);
            }
            case SPLASHDOWN -> {
                for (int[] tip : new int[][]{{8, 1}, {8, 14}, {1, 8}, {14, 8}, {3, 3}, {13, 13}, {3, 13}, {13, 3}}) line(img, 8, 8, tip[0], tip[1], 2, 0xFFD23F);
                disc(img, 8, 8, 4.5, 0xFFD23F);
                disc(img, 8, 8, 2.6, 0xFF3FA4);
                set(img, 7, 7, 0xFFFFFF);
            }
        }
        return outline(img, OUTLINE);
    }

    private static BufferedImage icon() {
        BufferedImage img = canvas(64);
        for (int x = 0; x < 64; x++) for (int y = 0; y < 64; y++) set(img, x, y, x < 32 ? Team.ORANGE.color.asRGB() : Team.BLUE.color.asRGB());
        disc(img, 32, 34, 16, 0xFFFFFF);
        line(img, 32, 10, 32, 24, 8, 0xFFFFFF);
        return img;
    }
}
