package dev.autobox.zombie;

import dev.autobox.AutoBoxPlugin;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import java.lang.reflect.*;
import java.util.*;

/** Isolated-server checks. Never install this test-only plugin on a player server. */
public final class ZombieSmoke extends JavaPlugin {
    private Object game;
    private Object call(String name,Class<?>[] types,Object... args) throws Exception {
        Method m=game.getClass().getDeclaredMethod(name,types); m.setAccessible(true); return m.invoke(game,args);
    }
    private Object call(String name) throws Exception { return call(name,new Class<?>[0]); }
    private Object get(String name) throws Exception { Field f=game.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(game); }
    private void set(String name,Object value) throws Exception { Field f=game.getClass().getDeclaredField(name); f.setAccessible(true); f.set(game,value); }
    private void require(boolean value,String message) { if(!value) throw new AssertionError(message); }
    @Override public void onEnable() {
        Bukkit.getScheduler().runTaskLater(this,()-> {
            try {
                game=((AutoBoxPlugin)Bukkit.getPluginManager().getPlugin("Worlds")).getZombieApocalypse();
                ((BukkitTask)get("ticker")).cancel();
                require((boolean)get("ready"),"City did not finish building");
                World world=Bukkit.getWorld(ZombieApocalypseGame.WORLD_NAME);
                require(world!=null && world.getDifficulty()==Difficulty.NORMAL && !world.getPVP(),"Wrong PvE world settings");
                for(var p:ZombieCity.GATES) require(world.getBlockAt(p.x(),p.y(),p.z()).isEmpty()
                        && world.getBlockAt(p.x(),p.y()-1,p.z()).getType().isSolid(),"Unsafe live gate");
                ItemStack item=(ItemStack)call("item",new Class<?>[]{Material.class,String.class,String.class,String[].class},
                        Material.BOW,"Smoke bow",null,new String[]{"Smoke test"});
                item.addEnchantment(org.bukkit.enchantments.Enchantment.INFINITY,1);
                require(item.getItemMeta().isUnbreakable(),"Broken kit item metadata");
                int tested=0;
                for(int party=2;party<=6;party++) {
                    set("partySize",party);
                    for(int wave=5;wave<=30;wave+=5) {
                        set("wave",wave-1); call("beginWave");
                        Mob boss=(Mob)get("boss"); require(boss!=null && boss.isValid() && !boss.isDead(),"Boss missing at wave "+wave);
                        require(boss.getHealth()>100,"Boss health not configured");
                        double hp=boss.getHealth(); boss.damage(1);
                        require(boss.getHealth()<hp,"Generic game listener blocked zombie-world damage");
                        call("bossAttack"); set("seconds",10000); call("resolveHazards");
                        for(int i=0;i<60;i++) call("spawnEnemy",new Class<?>[]{boolean.class},false);
                        require(((Map<?,?>)get("enemies")).size()<=ZombieRules.MOB_CAP,"Entity cap exceeded");
                        call("clearWave");
                        require(((Map<?,?>)get("enemies")).isEmpty(),"Enemies leaked into next wave");
                        require(((List<?>)get("hazards")).isEmpty(),"Hazards leaked into next wave");
                        tested++;
                    }
                }
                call("reset");
                require(!((ZombieApocalypseGame)game).isRunning(),"Reset left game running");
                require(world.getLivingEntities().isEmpty(),"Live mobs leaked after reset");
                getLogger().info("ZOMBIE_SMOKE_PASSED: "+tested+" boss encounters, live spawn gates, item registry, damage routing, mob cap, abilities and cleanup.");
            } catch(Throwable e) { getLogger().log(java.util.logging.Level.SEVERE,"ZOMBIE_SMOKE_FAILED",e); }
            finally { Bukkit.shutdown(); }
        },600L);
    }
}
