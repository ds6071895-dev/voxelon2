package dev.autobox.ratseek;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Human tools: a battery flashlight that exposes rats, snap mousetraps and fake cheese bait. */
final class RatSeekGadgets {
    static final int TRAP_CHARGES = 3;
    static final int BAIT_CHARGES = 2;
    private static final int BATTERY = 200;
    private static final int BEAM_RANGE = 14;
    private static final double BEAM_COS = 0.93;
    private static final int TRAP_RECHARGE = 400;
    private static final int BAIT_RECHARGE = 600;
    private static final int TRAP_SPACING_SQ = 9;

    record Trap(UUID owner, Location block) { }

    private static final class Kit {
        boolean lightOn;
        int battery = BATTERY;
        int traps = TRAP_CHARGES;
        int baits = BAIT_CHARGES;
        final List<Integer> trapRefills = new ArrayList<>();
        final List<Integer> baitRefills = new ArrayList<>();
    }

    private final RatSeekGame game;
    private final World world;
    private final NamespacedKey key;
    private final Map<UUID, Kit> kits = new HashMap<>();
    private final Map<Location, Trap> traps = new LinkedHashMap<>();
    private final Map<Item, UUID> baits = new LinkedHashMap<>();
    private final Map<UUID, Integer> spottedMessages = new HashMap<>();

    RatSeekGadgets(RatSeekGame game, World world, NamespacedKey key) {
        this.game = game;
        this.world = world;
        this.key = key;
    }

    // ------------------------------------------------------------------ kit

    void giveKit(Player human, RatSeekSettings settings) {
        Kit kit = kits.computeIfAbsent(human.getUniqueId(), id -> new Kit());
        human.getInventory().setItem(3, settings.flashlight ? game.taggedItem(Material.END_ROD, "flashlight",
                "Flashlight" + (kit.lightOn ? " (ON)" : ""), NamedTextColor.YELLOW,
                "Right-click: toggle • rats in the beam glow • battery on XP bar") : null);
        human.getInventory().setItem(4, settings.mousetraps && kit.traps > 0 ? amount(game.taggedItem(
                Material.HEAVY_WEIGHTED_PRESSURE_PLATE, "mousetrap", "Snap Mousetrap", NamedTextColor.RED,
                "Right-click a floor: snare the next rat that steps here"), kit.traps) : null);
        human.getInventory().setItem(5, settings.bait && kit.baits > 0 ? amount(game.taggedItem(
                Material.HONEYCOMB, "bait", "Cheese Bait", NamedTextColor.GOLD,
                "Right-click a floor: fake cheese that makes a rat sticky and glowing"), kit.baits) : null);
        showBattery(human, kit);
    }

    private static ItemStack amount(ItemStack item, int amount) {
        item.setAmount(Math.max(1, amount));
        return item;
    }

    void forget(UUID id) {
        if (id == null) {
            return;
        }
        kits.remove(id);
        spottedMessages.remove(id);
    }

    // ------------------------------------------------------------------ AI seekers

    /** AI seekers carry the same kit (same charges, battery and recharge timers), keyed by their body id. */
    void addBot(UUID bot) {
        if (bot != null) {
            kits.computeIfAbsent(bot, id -> new Kit());
        }
    }

    int botTraps(UUID bot) {
        Kit kit = bot == null ? null : kits.get(bot);
        return kit == null ? 0 : kit.traps;
    }

    int botBaits(UUID bot) {
        Kit kit = bot == null ? null : kits.get(bot);
        return kit == null ? 0 : kit.baits;
    }

    /** Battery charge from 0 to 1. */
    double botBattery(UUID bot) {
        Kit kit = bot == null ? null : kits.get(bot);
        return kit == null ? 0 : kit.battery / (double) BATTERY;
    }

    boolean botLightOn(UUID bot) {
        Kit kit = bot == null ? null : kits.get(bot);
        return kit != null && kit.lightOn;
    }

    void setBotLight(UUID bot, boolean on) {
        Kit kit = bot == null ? null : kits.get(bot);
        if (kit == null || kit.lightOn == on || (on && kit.battery < 20)) {
            return;
        }
        kit.lightOn = on;
        Location eye = game.botEye(bot);
        if (eye != null) {
            world.playSound(eye, Sound.BLOCK_LEVER_CLICK, 0.6f, on ? 1.6f : 1.0f);
        }
    }

    /** Whether a trap (or bait) may go in this air block; the same rules a human's click follows. */
    boolean canPlaceAt(Block target, boolean trap) {
        if (!target.getType().isAir() || !target.getRelative(BlockFace.DOWN).getType().isSolid()
                || game.inSecretPassage(target.getLocation()) || game.nearCageOrKeeper(target.getLocation())) {
            return false;
        }
        if (trap) {
            for (Location other : traps.keySet()) {
                if (other.distanceSquared(target.getLocation()) < TRAP_SPACING_SQ) {
                    return false;
                }
            }
        }
        return true;
    }

    boolean botPlaceTrap(UUID bot, Block target, String name) {
        Kit kit = kits.get(bot);
        if (kit == null || kit.traps <= 0 || !canPlaceAt(target, true)) {
            return false;
        }
        Location spot = target.getLocation();
        target.setType(Material.HEAVY_WEIGHTED_PRESSURE_PLATE, false);
        traps.put(spot, new Trap(bot, spot));
        kit.traps--;
        world.playSound(spot, Sound.BLOCK_IRON_TRAPDOOR_OPEN, 0.8f, 1.6f);
        game.notifyHumans(Component.text(name + " set a mousetrap in the " + game.roomAt(spot) + ".",
                NamedTextColor.GRAY));
        return true;
    }

    boolean botPlaceBait(UUID bot, Block target, String name) {
        Kit kit = kits.get(bot);
        if (kit == null || kit.baits <= 0 || !canPlaceAt(target, false)) {
            return false;
        }
        Location spot = target.getLocation().add(0.5, 0, 0.5);
        dropBait(spot, bot);
        kit.baits--;
        world.playSound(spot, Sound.BLOCK_HONEY_BLOCK_PLACE, 0.8f, 1.2f);
        return true;
    }

    String hud(UUID human, RatSeekSettings settings) {
        Kit kit = kits.get(human);
        if (kit == null) {
            return "";
        }
        List<String> parts = new ArrayList<>();
        if (settings.flashlight) {
            parts.add("Light " + (kit.battery * 100 / BATTERY) + "%" + (kit.lightOn ? "*" : ""));
        }
        if (settings.mousetraps) {
            parts.add("Traps " + kit.traps);
        }
        if (settings.bait) {
            parts.add("Bait " + kit.baits);
        }
        return String.join(" • ", parts);
    }

    // ------------------------------------------------------------------ use

    /** Handles a right-click with a gadget. Returns true if the tag belonged to a gadget. */
    boolean use(Player human, String tag, Block clicked, BlockFace face, RatSeekSettings settings, boolean hunting) {
        if (!"flashlight".equals(tag) && !"mousetrap".equals(tag) && !"bait".equals(tag)) {
            return false;
        }
        Kit kit = kits.get(human.getUniqueId());
        if (kit == null || !game.isHuman(human)) {
            return true;
        }
        if (!hunting) {
            human.sendActionBar(Component.text("Gadgets unlock when the hunt begins.", NamedTextColor.RED));
            return true;
        }
        switch (tag) {
            case "flashlight" -> {
                if (!settings.flashlight) {
                    return true;
                }
                if (!kit.lightOn && kit.battery < 20) {
                    human.sendActionBar(Component.text("Battery flat — let it recharge.", NamedTextColor.RED));
                    return true;
                }
                kit.lightOn = !kit.lightOn;
                human.playSound(human.getLocation(), Sound.BLOCK_LEVER_CLICK, 1f, kit.lightOn ? 1.6f : 1.0f);
                giveKit(human, settings);
            }
            case "mousetrap" -> {
                if (settings.mousetraps) {
                    placeTrap(human, kit, clicked, face, settings);
                }
            }
            default -> {
                if (settings.bait) {
                    placeBait(human, kit, clicked, face, settings);
                }
            }
        }
        return true;
    }

    private Block floorTarget(Player human, Block clicked, BlockFace face) {
        if (clicked == null || face != BlockFace.UP || !clicked.getType().isSolid()) {
            human.sendActionBar(Component.text("Aim at the top of a floor block.", NamedTextColor.RED));
            return null;
        }
        Block target = clicked.getRelative(BlockFace.UP);
        if (!target.getType().isAir()) {
            human.sendActionBar(Component.text("Something is already there.", NamedTextColor.RED));
            return null;
        }
        if (game.inSecretPassage(target.getLocation()) || game.nearCageOrKeeper(target.getLocation())) {
            human.sendActionBar(Component.text("You can't set that here.", NamedTextColor.RED));
            return null;
        }
        return target;
    }

    private void placeTrap(Player human, Kit kit, Block clicked, BlockFace face, RatSeekSettings settings) {
        if (kit.traps <= 0) {
            human.sendActionBar(Component.text("No mousetraps left — they come back after they snap.",
                    NamedTextColor.RED));
            return;
        }
        Block target = floorTarget(human, clicked, face);
        if (target == null) {
            return;
        }
        Location spot = target.getLocation();
        for (Location other : traps.keySet()) {
            if (other.distanceSquared(spot) < TRAP_SPACING_SQ) {
                human.sendActionBar(Component.text("Too close to another trap.", NamedTextColor.RED));
                return;
            }
        }
        target.setType(Material.HEAVY_WEIGHTED_PRESSURE_PLATE, false);
        traps.put(spot, new Trap(human.getUniqueId(), spot));
        kit.traps--;
        world.playSound(spot, Sound.BLOCK_IRON_TRAPDOOR_OPEN, 0.8f, 1.6f);
        human.sendActionBar(Component.text("Mousetrap set in the " + game.roomAt(spot) + ".", NamedTextColor.GOLD));
        giveKit(human, settings);
    }

    private void placeBait(Player human, Kit kit, Block clicked, BlockFace face, RatSeekSettings settings) {
        if (kit.baits <= 0) {
            human.sendActionBar(Component.text("No bait left — it comes back after a rat bites.", NamedTextColor.RED));
            return;
        }
        Block target = floorTarget(human, clicked, face);
        if (target == null) {
            return;
        }
        Location spot = target.getLocation().add(0.5, 0, 0.5);
        dropBait(spot, human.getUniqueId());
        kit.baits--;
        human.playSound(human.getLocation(), Sound.BLOCK_HONEY_BLOCK_PLACE, 1f, 1.2f);
        human.sendActionBar(Component.text("Bait laid in the " + game.roomAt(spot) + ".", NamedTextColor.GOLD));
        giveKit(human, settings);
    }

    private void dropBait(Location spot, UUID owner) {
        // Identical to real cheese so rats can't tell it apart at a glance.
        ItemStack stack = game.taggedItem(Material.GOLD_NUGGET, "cheese", "Stolen Cheese",
                NamedTextColor.GOLD, "Rats earn 1 point by grabbing this");
        Item item = world.dropItem(spot, stack);
        item.setVelocity(new Vector());
        item.setGravity(false);
        item.setPickupDelay(20);
        item.setUnlimitedLifetime(true);
        item.getPersistentDataContainer().set(key, PersistentDataType.STRING, "bait");
        baits.put(item, owner);
    }

    // ------------------------------------------------------------------ bait pickup

    /** A free rat grabbed bait: sticky, glowing and reported. */
    void biteBait(Player rat, Item item, RatSeekSettings settings) {
        UUID owner = baits.remove(item);
        item.remove();
        rat.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 2, false, false, true));
        rat.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 80, 0, false, false, false));
        rat.sendTitle("§6§lIT'S A TRAP!", "§fSticky bait — you're slowed and glowing", 0, 35, 5);
        world.playSound(rat.getLocation(), Sound.BLOCK_SLIME_BLOCK_BREAK, 1.4f, 0.7f);
        world.spawnParticle(Particle.FALLING_HONEY, rat.getLocation().add(0, 0.6, 0), 20, 0.3, 0.3, 0.3, 0);
        game.pointHumanCompasses(rat.getLocation());
        game.notifyHumans(Component.text("Bait taken in the " + game.roomAt(rat.getLocation()) + "!",
                NamedTextColor.GOLD, TextDecoration.BOLD));
        game.baitBitten(owner, item.getLocation(), rat);
        refill(owner, false, settings);
    }

    boolean isBait(Item item) {
        return baits.containsKey(item);
    }

    // ------------------------------------------------------------------ tick

    void tick(int ticks, RatSeekSettings settings, boolean hunting) {
        for (Map.Entry<UUID, Kit> entry : kits.entrySet()) {
            Player human = org.bukkit.Bukkit.getPlayer(entry.getKey());
            Kit kit = entry.getValue();
            tickRefills(human, kit, settings);
            if (human == null) {
                tickBotLight(entry.getKey(), kit, ticks, settings, hunting);
                continue;
            }
            if (human.getWorld() != world) {
                continue;
            }
            if (kit.lightOn && (!hunting || !settings.flashlight)) {
                kit.lightOn = false;
                giveKit(human, settings);
            }
            if (kit.lightOn) {
                kit.battery--;
                if (kit.battery <= 0) {
                    kit.battery = 0;
                    kit.lightOn = false;
                    human.playSound(human.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 0.8f, 1.8f);
                    human.sendActionBar(Component.text("Flashlight battery died!", NamedTextColor.RED));
                    giveKit(human, settings);
                } else if (ticks % 4 == 0) {
                    beam(human.getEyeLocation(), human);
                }
            } else if (kit.battery < BATTERY && ticks % 2 == 0) {
                kit.battery++;
            }
            if (ticks % 5 == 0) {
                showBattery(human, kit);
            }
        }
        spottedMessages.replaceAll((id, left) -> Math.max(0, left - 1));
        if (hunting && ticks % 2 == 0) {
            tickTraps(settings);
        }
        if (ticks % 40 == 20) {
            baits.keySet().removeIf(item -> !item.isValid());
            for (Item item : baits.keySet()) {
                world.spawnParticle(Particle.WAX_ON, item.getLocation().add(0, 0.35, 0), 3, 0.15, 0.15, 0.15, 0);
            }
        }
    }

    private void tickRefills(Player human, Kit kit, RatSeekSettings settings) {
        boolean changed = countDown(kit.trapRefills, () -> kit.traps = Math.min(TRAP_CHARGES, kit.traps + 1));
        changed |= countDown(kit.baitRefills, () -> kit.baits = Math.min(BAIT_CHARGES, kit.baits + 1));
        if (changed && human != null && human.isOnline()) {
            giveKit(human, settings);
            human.playSound(human.getLocation(), Sound.ITEM_ARMOR_EQUIP_IRON, 0.7f, 1.4f);
        }
    }

    private static boolean countDown(List<Integer> timers, Runnable onDone) {
        boolean changed = false;
        for (int i = timers.size() - 1; i >= 0; i--) {
            int left = timers.get(i) - 1;
            if (left <= 0) {
                timers.remove(i);
                onDone.run();
                changed = true;
            } else {
                timers.set(i, left);
            }
        }
        return changed;
    }

    private void refill(UUID owner, boolean trap, RatSeekSettings settings) {
        Kit kit = owner == null ? null : kits.get(owner);
        if (kit != null) {
            (trap ? kit.trapRefills : kit.baitRefills).add(trap ? TRAP_RECHARGE : BAIT_RECHARGE);
        }
    }

    private void showBattery(Player human, Kit kit) {
        human.setLevel(0);
        human.setExp(Math.max(0f, Math.min(0.999f, kit.battery / (float) BATTERY)));
    }

    private void tickBotLight(UUID bot, Kit kit, int ticks, RatSeekSettings settings, boolean hunting) {
        Location eye = game.botEye(bot);
        if (eye == null) {
            return;
        }
        if (kit.lightOn && (!hunting || !settings.flashlight)) {
            kit.lightOn = false;
        }
        if (kit.lightOn) {
            if (--kit.battery <= 0) {
                kit.battery = 0;
                kit.lightOn = false;
                world.playSound(eye, Sound.BLOCK_BEACON_DEACTIVATE, 0.6f, 1.8f);
            } else if (ticks % 4 == 0) {
                beam(eye, null);
            }
        } else if (kit.battery < BATTERY && ticks % 2 == 0) {
            kit.battery++;
        }
    }

    /** Shines a beam from an eye; {@code human} is null for an AI seeker. */
    private void beam(Location eye, Player human) {
        Vector direction = eye.getDirection().normalize();
        RayTraceResult wall = world.rayTraceBlocks(eye, direction, BEAM_RANGE, FluidCollisionMode.NEVER, true);
        double reach = wall == null ? BEAM_RANGE : wall.getHitPosition().distance(eye.toVector());
        Particle.DustOptions light = new Particle.DustOptions(Color.fromRGB(0xFFF4B0), 0.7f);
        for (double d = 1.2; d < reach; d += 1.4) {
            world.spawnParticle(Particle.DUST, eye.clone().add(direction.clone().multiply(d)), 1, 0.05, 0.05, 0.05, 0, light);
        }
        for (UUID id : game.freeRats()) {
            Player rat = org.bukkit.Bukkit.getPlayer(id);
            if (rat == null || rat.getWorld() != world) {
                continue;
            }
            Location centre = rat.getLocation().add(0, rat.getHeight() / 2, 0);
            Vector toRat = centre.toVector().subtract(eye.toVector());
            double distance = toRat.length();
            if (distance > BEAM_RANGE || distance < 0.01 || toRat.clone().normalize().dot(direction) < BEAM_COS) {
                continue;
            }
            if (world.rayTraceBlocks(eye, toRat.clone().normalize(), distance, FluidCollisionMode.NEVER, true) != null) {
                continue;
            }
            rat.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 25, 0, false, false, false));
            if (spottedMessages.getOrDefault(id, 0) == 0) {
                spottedMessages.put(id, 10);
                rat.sendActionBar(Component.text("SPOTTED by a flashlight!", NamedTextColor.RED, TextDecoration.BOLD));
                if (human != null) {
                    human.sendActionBar(Component.text("Beam on " + rat.getName() + "!", NamedTextColor.YELLOW));
                }
                rat.playSound(rat.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASEDRUM, 0.8f, 1.6f);
            }
        }
    }

    private void tickTraps(RatSeekSettings settings) {
        if (traps.isEmpty()) {
            return;
        }
        for (UUID id : game.freeRats()) {
            Player rat = org.bukkit.Bukkit.getPlayer(id);
            if (rat == null || rat.getWorld() != world) {
                continue;
            }
            Location feet = rat.getLocation().getBlock().getLocation();
            Trap trap = traps.get(feet);
            if (trap != null) {
                snap(rat, trap, settings);
            }
        }
    }

    private void snap(Player rat, Trap trap, RatSeekSettings settings) {
        traps.remove(trap.block());
        trap.block().getBlock().setType(Material.AIR, false);
        Location at = trap.block().clone().add(0.5, 0.1, 0.5);
        rat.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, 6, false, false, true));
        rat.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, false, false, false));
        rat.setVelocity(new Vector());
        rat.sendTitle("§c§lSNAP!", "§fA mousetrap has you pinned", 0, 30, 5);
        world.playSound(at, Sound.ENTITY_ITEM_BREAK, 1.6f, 0.6f);
        world.playSound(at, Sound.BLOCK_IRON_TRAPDOOR_CLOSE, 2f, 1.4f);
        world.spawnParticle(Particle.CRIT, at, 25, 0.25, 0.1, 0.25, 0.3);
        game.pointHumanCompasses(at);
        game.notifyHumans(Component.text("SNAP in the " + game.roomAt(at) + "! " + rat.getName() + " is pinned!",
                NamedTextColor.RED, TextDecoration.BOLD));
        game.trapSnapped(trap.owner(), at, rat);
        for (Player human : game.humanPlayers()) {
            human.playSound(human.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.8f);
        }
        refill(trap.owner(), true, settings);
    }

    /** Removes a trap near {@code origin} for a disarming rat; returns the trap removed, or null. */
    Trap disarmNear(Location origin, double radius) {
        Iterator<Map.Entry<Location, Trap>> iterator = traps.entrySet().iterator();
        while (iterator.hasNext()) {
            Trap trap = iterator.next().getValue();
            if (trap.block().getWorld() == origin.getWorld()
                    && trap.block().clone().add(0.5, 0, 0.5).distanceSquared(origin) <= radius * radius) {
                iterator.remove();
                trap.block().getBlock().setType(Material.AIR, false);
                return trap;
            }
        }
        return null;
    }

    /** Gives the trap's owner a recharge after a rat disarms it. */
    void trapGone(Trap trap, RatSeekSettings settings) {
        refill(trap.owner(), true, settings);
    }

    List<Location> trapLocations() {
        return new ArrayList<>(traps.keySet());
    }

    List<Location> baitLocations() {
        List<Location> result = new ArrayList<>();
        for (Item item : baits.keySet()) {
            if (item.isValid()) {
                result.add(item.getLocation());
            }
        }
        return result;
    }

    /** Clears every placed trap and bait, and all per-human state. */
    void reset() {
        for (Location location : traps.keySet()) {
            if (location.getBlock().getType() == Material.HEAVY_WEIGHTED_PRESSURE_PLATE) {
                location.getBlock().setType(Material.AIR, false);
            }
        }
        traps.clear();
        baits.keySet().forEach(Item::remove);
        baits.clear();
        kits.clear();
        spottedMessages.clear();
    }
}
