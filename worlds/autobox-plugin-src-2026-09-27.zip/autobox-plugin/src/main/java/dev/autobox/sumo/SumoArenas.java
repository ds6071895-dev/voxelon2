package dev.autobox.sumo;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static dev.autobox.sumo.SumoArena.BASE_Y;

/** The six Block Sumo maps. Every layout is centred on block (0, 0) and generated once. */
public final class SumoArenas {
    /** Bounce House pads fling players to the top of the central tower (feet position). */
    public static final int[] BOUNCE_TARGET = {0, BASE_Y + 9, 0};
    /** Sweeper arms pivot here and ride just above the plate. */
    public static final int SWEEPER_PLATE_Y = BASE_Y + 2;
    public static final double SWEEPER_ARM_START = 2.2;
    /** Hex Layers floors, top first. */
    public static final int[] HEX_LAYERS = {BASE_Y + 12, BASE_Y + 6, BASE_Y};

    private static final Map<SumoArena.Kind, SumoArena> ARENAS = new EnumMap<>(SumoArena.Kind.class);

    public static SumoArena get(SumoArena.Kind kind) {
        return ARENAS.computeIfAbsent(kind, SumoArenas::build);
    }

    private static SumoArena build(SumoArena.Kind kind) {
        return switch (kind) {
            case RIFT -> rift();
            case DOHYO -> dohyo();
            case FROSTBITE -> frostbite();
            case BOUNCE -> bounce();
            case HEX -> hex();
            case SWEEPER -> sweeper();
        };
    }

    private static SumoArena rift() {
        Builder b = new Builder();
        // A floating rift archipelago: every island has its own elevation and silhouette.
        b.platform(0, BASE_Y + 6, 0, 5, Material.POLISHED_BLACKSTONE_BRICKS, Material.AMETHYST_BLOCK);
        b.platform(-8, BASE_Y + 4, 0, 3, Material.DARK_PRISMARINE, Material.CYAN_WOOL);
        b.platform(8, BASE_Y + 2, 0, 3, Material.PURPUR_BLOCK, Material.MAGENTA_WOOL);
        b.platform(0, BASE_Y + 3, -8, 3, Material.DEEPSLATE_TILES, Material.BLUE_WOOL);
        b.platform(0, BASE_Y + 5, 8, 3, Material.POLISHED_BLACKSTONE, Material.PURPLE_WOOL);
        b.platform(-15, BASE_Y, 0, 3, Material.DEEPSLATE_BRICKS, Material.CYAN_WOOL);
        b.platform(15, BASE_Y + 3, 0, 3, Material.DARK_PRISMARINE, Material.SEA_LANTERN);
        b.platform(0, BASE_Y + 1, -15, 3, Material.POLISHED_BLACKSTONE_BRICKS, Material.BLUE_WOOL);
        b.platform(0, BASE_Y + 5, 15, 3, Material.PURPUR_PILLAR, Material.MAGENTA_WOOL);
        b.platform(-10, BASE_Y + 3, -10, 3, Material.DARK_PRISMARINE, Material.CYAN_WOOL);
        b.platform(10, BASE_Y, -10, 3, Material.DEEPSLATE_TILES, Material.PURPLE_WOOL);
        b.platform(-10, BASE_Y + 6, 10, 3, Material.POLISHED_BLACKSTONE_BRICKS, Material.SEA_LANTERN);
        b.platform(10, BASE_Y + 2, 10, 3, Material.PURPUR_BLOCK, Material.BLUE_WOOL);
        // Four changing-height spokes reach the reactor; diagonal paths create risky shortcuts.
        b.bridge(-15, BASE_Y, 0, -8, BASE_Y + 4, 0, Material.CYAN_WOOL);
        b.bridge(15, BASE_Y + 3, 0, 8, BASE_Y + 2, 0, Material.MAGENTA_WOOL);
        b.bridge(0, BASE_Y + 1, -15, 0, BASE_Y + 3, -8, Material.BLUE_WOOL);
        b.bridge(0, BASE_Y + 5, 15, 0, BASE_Y + 5, 8, Material.PURPLE_WOOL);
        b.bridge(-8, BASE_Y + 4, 0, 0, BASE_Y + 6, 0, Material.CYAN_WOOL);
        b.bridge(8, BASE_Y + 2, 0, 0, BASE_Y + 6, 0, Material.MAGENTA_WOOL);
        b.bridge(0, BASE_Y + 3, -8, 0, BASE_Y + 6, 0, Material.BLUE_WOOL);
        b.bridge(0, BASE_Y + 5, 8, 0, BASE_Y + 6, 0, Material.PURPLE_WOOL);
        b.bridge(-10, BASE_Y + 3, -10, -5, BASE_Y + 5, -5, Material.CYAN_WOOL);
        b.bridge(10, BASE_Y, -10, 5, BASE_Y + 4, -5, Material.PURPLE_WOOL);
        b.bridge(-10, BASE_Y + 6, 10, -5, BASE_Y + 6, 5, Material.SEA_LANTERN);
        b.bridge(10, BASE_Y + 2, 10, 5, BASE_Y + 5, 5, Material.BLUE_WOOL);
        // Small detached shards reward vaulting and emergency block placement.
        int[][] shards = {
                {-13, 2, -7}, {-7, 5, -13}, {7, 2, -13}, {13, 5, -7},
                {-13, 4, 7}, {-7, 7, 13}, {7, 4, 13}, {13, 3, 7}
        };
        for (int[] shard : shards) {
            b.platform(shard[0], BASE_Y + shard[1], shard[2], 1, Material.CRYING_OBSIDIAN, Material.AMETHYST_BLOCK);
        }
        // x, platform height above BASE_Y, z. The last five ring the reactor so late respawns and
        // sudden death do not stack on one block.
        int[][] spawns = {
                {-15, 0, 0}, {15, 3, 0}, {0, 1, -15}, {0, 5, 15},
                {-10, 3, -10}, {10, 0, -10}, {-10, 6, 10}, {10, 2, 10},
                {-8, 4, 0}, {8, 2, 0}, {0, 3, -8}, {0, 5, 8},
                {0, 6, 0}, {-3, 6, 0}, {3, 6, 0}, {0, 6, -3}, {0, 6, 3}
        };
        int[][] spots = {
                {0, 6, 0}, {-8, 4, 0}, {8, 2, 0}, {0, 3, -8}, {0, 5, 8},
                {-10, 3, -10}, {10, 0, -10}, {-10, 6, 10}, {10, 2, 10}
        };
        List<int[]> spawnList = new ArrayList<>();
        for (int[] spawn : spawns) spawnList.add(new int[]{spawn[0], BASE_Y + spawn[1] + 1, spawn[2]});
        List<int[]> spotList = new ArrayList<>();
        for (int[] spot : spots) spotList.add(new int[]{spot[0], BASE_Y + spot[1], spot[2]});
        return b.arena(SumoArena.Kind.RIFT, spawnList, spotList, 18, new int[]{14, 10, 7}, 5);
    }

    private static SumoArena dohyo() {
        Builder b = new Builder();
        int surface = BASE_Y + 2;
        for (int x = -11; x <= 11; x++) {
            for (int z = -11; z <= 11; z++) {
                double d = Math.hypot(x, z);
                if (d > 11.25) continue;
                Material top = d > 10.2 ? Material.HAY_BLOCK : Material.TERRACOTTA;
                // The two white start lines of a real dohyo.
                if ((x == -2 || x == 2) && Math.abs(z) <= 1) top = Material.WHITE_TERRACOTTA;
                b.add(x, surface, z, top);
                if (d <= 10.5) b.add(x, surface - 1, z, Material.MUD_BRICKS);
                if (d <= 8.25) b.add(x, surface - 2, z, Material.PACKED_MUD);
                if (d <= 5.25) b.add(x, surface - 3, z, Material.POLISHED_BLACKSTONE);
                if (d <= 2.25) b.add(x, surface - 4, z, Material.POLISHED_BLACKSTONE);
            }
        }
        List<int[]> spawns = ring(8, 7, surface + 1, 0);
        spawns.addAll(inner(surface + 1));
        List<int[]> spots = ring(6, 5, surface, 0);
        spots.add(new int[]{0, surface, 0});
        return b.arena(SumoArena.Kind.DOHYO, spawns, spots, 12, new int[]{9, 7, 5}, 3);
    }

    private static SumoArena frostbite() {
        Builder b = new Builder();
        int surface = BASE_Y + 1;
        for (int x = -15; x <= 15; x++) {
            for (int z = -15; z <= 15; z++) {
                double d = Math.hypot(x, z);
                if (d > 15.25) continue;
                boolean stripe = Math.floorMod(x + z, 6) == 0 || Math.floorMod(x - z, 6) == 0;
                Material top = d > 13.2 ? Material.BLUE_ICE : stripe ? Material.BLUE_ICE : Material.PACKED_ICE;
                b.add(x, surface, z, top);
                if (d <= 14.5) b.add(x, surface - 1, z, Material.SNOW_BLOCK);
                if (d <= 11.25) b.add(x, surface - 2, z, Material.PACKED_ICE);
                if (d <= 7.25) b.add(x, surface - 3, z, Material.BLUE_ICE);
                if (d <= 3.25) b.add(x, surface - 4, z, Material.POLISHED_BLACKSTONE);
            }
        }
        // A grippy snow mound in the middle and four snow posts to hide behind.
        for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) b.add(x, surface + 1, z, Material.SNOW_BLOCK);
        for (int[] post : new int[][]{{-7, -7}, {7, -7}, {-7, 7}, {7, 7}}) {
            b.add(post[0], surface + 1, post[1], Material.SNOW_BLOCK);
            b.add(post[0], surface + 2, post[1], Material.SNOW_BLOCK);
        }
        List<int[]> spawns = ring(8, 10, surface + 1, 22.5);
        spawns.add(new int[]{0, surface + 2, 0});
        spawns.add(new int[]{3, surface + 1, 0});
        spawns.add(new int[]{-3, surface + 1, 0});
        spawns.add(new int[]{0, surface + 1, 3});
        spawns.add(new int[]{0, surface + 1, -3});
        List<int[]> spots = ring(6, 5, surface, 0);
        spots.add(new int[]{0, surface + 1, 0});
        return b.arena(SumoArena.Kind.FROSTBITE, spawns, spots, 16, new int[]{12, 9, 6}, 4);
    }

    private static SumoArena bounce() {
        Builder b = new Builder();
        int tower = BOUNCE_TARGET[1] - 1;
        b.platform(0, tower, 0, 4, Material.WHITE_CONCRETE, Material.LIME_CONCRETE);
        int mid = BASE_Y + 4;
        int[][] mids = {{9, 0}, {-9, 0}, {0, 9}, {0, -9}};
        for (int[] m : mids) {
            b.platform(m[0], mid, m[1], 3, Material.LIME_CONCRETE, Material.WHITE_CONCRETE);
            b.add(m[0], mid, m[1], Material.SLIME_BLOCK);
            // Honey patches: slow to walk on, but they soak up knockback.
            int sideX = Integer.signum(m[0]);
            int sideZ = Integer.signum(m[1]);
            b.add(m[0] + sideX * 2 + sideZ, mid, m[1] + sideZ * 2 + sideX, Material.HONEY_BLOCK);
            b.add(m[0] + sideX * 2 - sideZ, mid, m[1] + sideZ * 2 - sideX, Material.HONEY_BLOCK);
        }
        int low = BASE_Y;
        int[][] lows = {{11, 11}, {-11, 11}, {-11, -11}, {11, -11}};
        for (int[] l : lows) {
            b.platform(l[0], low, l[1], 3, Material.PINK_CONCRETE, Material.WHITE_CONCRETE);
            b.add(l[0], low, l[1], Material.SLIME_BLOCK);
        }
        // Each low corner has one walkway up to the next mid platform, clockwise.
        b.bridge(11, low, 11, 0, mid, 9, Material.PINK_CONCRETE);
        b.bridge(-11, low, 11, -9, mid, 0, Material.PINK_CONCRETE);
        b.bridge(-11, low, -11, 0, mid, -9, Material.PINK_CONCRETE);
        b.bridge(11, low, -11, 9, mid, 0, Material.PINK_CONCRETE);
        List<int[]> spawns = new ArrayList<>();
        for (int[] l : lows) spawns.add(new int[]{l[0] - Integer.signum(l[0]) * 2, low + 1, l[1] - Integer.signum(l[1]) * 2});
        for (int[] m : mids) spawns.add(new int[]{m[0] + Integer.signum(m[0]) * 2, mid + 1, m[1] + Integer.signum(m[1]) * 2});
        spawns.add(new int[]{0, tower + 1, 0});
        spawns.add(new int[]{2, tower + 1, 0});
        spawns.add(new int[]{-2, tower + 1, 0});
        spawns.add(new int[]{0, tower + 1, 2});
        spawns.add(new int[]{0, tower + 1, -2});
        List<int[]> spots = new ArrayList<>();
        spots.add(new int[]{0, tower, 0});
        for (int[] m : mids) spots.add(new int[]{m[0] + Integer.signum(m[0]), mid, m[1] + Integer.signum(m[1])});
        for (int[] l : lows) spots.add(new int[]{l[0] - Integer.signum(l[0]), low, l[1] - Integer.signum(l[1])});
        return b.arena(SumoArena.Kind.BOUNCE, spawns, spots, 18, new int[]{14, 11, 6}, 4);
    }

    private static SumoArena hex() {
        Builder b = new Builder();
        Material[][] shades = {
                {Material.LIGHT_BLUE_STAINED_GLASS, Material.CYAN_STAINED_GLASS, Material.BLUE_STAINED_GLASS},
                {Material.MAGENTA_STAINED_GLASS, Material.PINK_STAINED_GLASS, Material.PURPLE_STAINED_GLASS},
                {Material.YELLOW_STAINED_GLASS, Material.ORANGE_STAINED_GLASS, Material.LIME_STAINED_GLASS}
        };
        for (int layer = 0; layer < HEX_LAYERS.length; layer++) {
            for (int x = -11; x <= 11; x++) {
                for (int z = -11; z <= 11; z++) {
                    if (Math.hypot(x, z) > 11.25) continue;
                    b.add(x, HEX_LAYERS[layer], z, shades[layer][hexShade(x, z)]);
                }
            }
        }
        List<int[]> spawns = new ArrayList<>();
        for (int layer = 0; layer < HEX_LAYERS.length; layer++) {
            spawns.addAll(ring(6, 8, HEX_LAYERS[layer] + 1, layer * 20));
        }
        spawns.addAll(inner(HEX_LAYERS[0] + 1));
        List<int[]> spots = new ArrayList<>();
        for (int layer = 0; layer < HEX_LAYERS.length; layer++) spots.addAll(ring(5, 5, HEX_LAYERS[layer], layer * 30));
        return b.arena(SumoArena.Kind.HEX, spawns, spots, 12, new int[]{10, 8, 6}, 4);
    }

    /** Three-colours a pointy-top hex grid (cells about 2.3 blocks across) so tiles read as hexes. */
    static int hexShade(int x, int z) {
        double size = 2.3;
        double q = (Math.sqrt(3) / 3 * x - z / 3.0) / size;
        double r = (2.0 / 3 * z) / size;
        double s = -q - r;
        long rq = Math.round(q);
        long rr = Math.round(r);
        long rs = Math.round(s);
        double dq = Math.abs(rq - q);
        double dr = Math.abs(rr - r);
        double ds = Math.abs(rs - s);
        if (dq > dr && dq > ds) rq = -rr - rs;
        else if (dr > ds) rr = -rq - rs;
        return (int) Math.floorMod(rq - rr, 3);
    }

    private static SumoArena sweeper() {
        Builder b = new Builder();
        int plate = SWEEPER_PLATE_Y;
        for (int x = -13; x <= 13; x++) {
            for (int z = -13; z <= 13; z++) {
                double d = Math.hypot(x, z);
                if (d > 13.25) continue;
                double angle = Math.toDegrees(Math.atan2(z, x));
                boolean spoke = d > 2.5 && Math.abs(angle - Math.round(angle / 45.0) * 45.0) * Math.PI / 180 * d < 0.5;
                Material top = d > 12.3 ? Material.RED_CONCRETE : spoke ? Material.BLACK_CONCRETE : Material.SMOOTH_QUARTZ;
                b.add(x, plate, z, top);
                if (d <= 12.5) b.add(x, plate - 1, z, Material.POLISHED_BLACKSTONE);
                if (d <= 9.25) b.add(x, plate - 2, z, Material.POLISHED_BLACKSTONE);
                if (d <= 5.25) b.add(x, plate - 3, z, Material.CRYING_OBSIDIAN);
            }
        }
        // The hub the arms spin around: a small safe-ish perch.
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                b.add(x, plate + 1, z, Material.BLACK_CONCRETE);
                b.add(x, plate + 2, z, x == 0 && z == 0 ? Material.REDSTONE_LAMP : Material.BLACK_CONCRETE);
            }
        }
        List<int[]> spawns = ring(6, 8, plate + 1, 30);
        spawns.addAll(ring(3, 3, plate + 1, 0));
        spawns.add(new int[]{0, plate + 3, 0});
        List<int[]> spots = ring(6, 6, plate, 0);
        spots.add(new int[]{0, plate + 2, 0});
        return b.arena(SumoArena.Kind.SWEEPER, spawns, spots, 14, new int[]{11, 8, 5}, 4);
    }

    /** {@code count} points evenly around a circle, rounded to blocks. */
    private static List<int[]> ring(int count, double radius, int y, double offsetDegrees) {
        List<int[]> points = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            double angle = Math.toRadians(offsetDegrees + 360.0 * i / count);
            points.add(new int[]{(int) Math.round(Math.cos(angle) * radius), y, (int) Math.round(Math.sin(angle) * radius)});
        }
        return points;
    }

    private static List<int[]> inner(int y) {
        List<int[]> points = new ArrayList<>();
        points.add(new int[]{0, y, 0});
        points.add(new int[]{2, y, 0});
        points.add(new int[]{-2, y, 0});
        points.add(new int[]{0, y, 2});
        points.add(new int[]{0, y, -2});
        return points;
    }

    private static final class Builder {
        private final Map<Long, SumoArena.Block> blocks = new LinkedHashMap<>();

        void add(int x, int y, int z, Material material) {
            blocks.put(key(x, y, z), new SumoArena.Block(x, y, z, material));
        }

        void platform(int centerX, int surfaceY, int centerZ, int radius, Material floor, Material accent) {
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    double distance = Math.hypot(x, z);
                    if (distance > radius + 0.25) continue;
                    Material top = distance > radius - 0.8 || ((x * 3 + z) & 7) == 0 ? accent : floor;
                    add(centerX + x, surfaceY, centerZ + z, top);
                    if (distance <= radius - 0.55) add(centerX + x, surfaceY - 1, centerZ + z, Material.OBSIDIAN);
                }
            }
            for (int depth = 2; depth <= Math.min(4, radius + 1); depth++) {
                int lowerRadius = Math.max(0, radius - depth);
                for (int x = -lowerRadius; x <= lowerRadius; x++) {
                    for (int z = -lowerRadius; z <= lowerRadius; z++) {
                        if (Math.hypot(x, z) <= lowerRadius + 0.25) {
                            add(centerX + x, surfaceY - depth, centerZ + z,
                                    depth == 2 ? Material.CRYING_OBSIDIAN : Material.POLISHED_BLACKSTONE);
                        }
                    }
                }
            }
            add(centerX, surfaceY, centerZ, Material.SEA_LANTERN);
        }

        void bridge(int startX, int startY, int startZ, int endX, int endY, int endZ, Material accent) {
            int steps = Math.max(Math.abs(endX - startX), Math.abs(endZ - startZ));
            for (int step = 0; step <= steps; step++) {
                double progress = steps == 0 ? 0 : step / (double) steps;
                int x = (int) Math.round(startX + (endX - startX) * progress);
                int y = (int) Math.round(startY + (endY - startY) * progress);
                int z = (int) Math.round(startZ + (endZ - startZ) * progress);
                Material material = step % 3 == 0 ? accent : Material.POLISHED_BLACKSTONE_BRICKS;
                // Keep platform centres (pads, lanterns) intact where a bridge starts or ends.
                if (!blocks.containsKey(key(x, y, z))) add(x, y, z, material);
                // Alternate the second lane to produce a broken, parkour-like silhouette.
                if ((step & 1) == 0) {
                    int sideX = Math.abs(endX - startX) >= Math.abs(endZ - startZ) ? 0 : 1;
                    int sideZ = sideX == 0 ? 1 : 0;
                    if (!blocks.containsKey(key(x + sideX, y, z + sideZ))) add(x + sideX, y, z + sideZ, material);
                }
            }
        }

        SumoArena arena(SumoArena.Kind kind, List<int[]> spawns, List<int[]> spots, int startRadius, int[] radii,
                        int suddenDeathRadius) {
            int lowest = blocks.values().stream().mapToInt(SumoArena.Block::y).min().orElse(BASE_Y);
            return new SumoArena(kind, List.copyOf(blocks.values()), List.copyOf(spawns), List.copyOf(spots),
                    startRadius, radii.clone(), suddenDeathRadius, lowest);
        }

        static long key(int x, int y, int z) {
            return ((long) (x + 512) << 20) | ((long) (y + 512) << 10) | (z + 512);
        }
    }

    private SumoArenas() { }
}
