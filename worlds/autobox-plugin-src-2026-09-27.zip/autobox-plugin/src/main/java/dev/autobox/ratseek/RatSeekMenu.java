package dev.autobox.ratseek;

import dev.autobox.ratseek.RatSeekSettings.CheeseSupply;
import dev.autobox.ratseek.RatSeekSettings.HintRate;
import dev.autobox.ratseek.RatSeekSettings.Preset;
import dev.autobox.ratseek.RatSeekSettings.RatSize;
import dev.autobox.ratseek.RatSeekSettings.RespawnMode;
import dev.autobox.ratseek.RatSeekSettings.Twist;
import dev.autobox.ratseek.RatSeekSettings.TwistRate;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/** Renders the Rat and Seek host menus. Click handling lives in {@link RatSeekGame}. */
final class RatSeekMenu {

    enum Page { MAIN, TWISTS, ROLES, EXTRAS, CLASSES }

    /** Identifies our menus by holder instead of by title, so titles can be dynamic. */
    static final class Holder implements InventoryHolder {
        final Page page;
        final boolean lobby;
        private Inventory inventory;

        Holder(Page page, boolean lobby) {
            this.page = page;
            this.lobby = lobby;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    /** What the viewer is allowed to do, and where the match currently is. */
    record View(boolean lobby, boolean editable, String status, NamedTextColor statusColor,
                boolean canStart, boolean canEditRoles, int pickedHumans) { }

    record RoleEntry(Player player, boolean human) { }

    private static final int[] ROLE_SLOTS = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24};
    private static final int[] TWIST_SLOTS = {10, 11, 12, 13, 14, 15, 16};

    private final NamespacedKey key;

    RatSeekMenu(NamespacedKey key) {
        this.key = key;
    }

    Inventory main(RatSeekSettings s, View view) {
        Preset preset = s.preset();
        Holder holder = new Holder(Page.MAIN, view.lobby());
        Inventory inv = create(holder, 54, Component.text("Rat and Seek ", NamedTextColor.GOLD, TextDecoration.BOLD)
                .append(Component.text("» Host Settings", NamedTextColor.DARK_GRAY)));
        frame(inv, 54, preset);

        inv.setItem(4, header(s, view, preset));
        section(inv, 9, 17, Material.ORANGE_STAINED_GLASS_PANE, "Match Setup", NamedTextColor.GOLD);
        section(inv, 18, 26, Material.YELLOW_STAINED_GLASS_PANE, "Balance", NamedTextColor.YELLOW);
        section(inv, 27, 35, Material.LIME_STAINED_GLASS_PANE, "Abilities", NamedTextColor.GREEN);
        section(inv, 36, 44, Material.MAGENTA_STAINED_GLASS_PANE, "Presets", NamedTextColor.LIGHT_PURPLE);

        inv.setItem(10, choice(view, "set:hide", Material.CLOCK, "Hide Time", NamedTextColor.GOLD,
                "Head start before the humans are released.", ints(RatSeekSettings.HIDE_SECONDS),
                s.hideSeconds + "s", v -> v + "s", view.lobby() ? null : "Changes the countdown right now"));
        inv.setItem(11, choice(view, "set:hunt", Material.RECOVERY_COMPASS, "Hunt Time", NamedTextColor.GOLD,
                "How long the humans have to cage every rat.", ints(RatSeekSettings.HUNT_MINUTES),
                s.huntMinutes + " min", v -> v + " min", null));
        if (view.lobby() && view.pickedHumans() > 0) {
            inv.setItem(12, button(view.editable() ? "nav:roles" : "noop", Material.IRON_SWORD,
                    "Starting Humans: Picked (" + view.pickedHumans() + ")", NamedTextColor.RED, true,
                    List.of(line("The host picked exactly who hunts.", NamedTextColor.GRAY),
                            line("Clear the picks to use Auto/None/1-3 again.", NamedTextColor.DARK_GRAY),
                            Component.empty(), hint(view.editable() ? "Click to open Pick Seekers" : lockText(view)))));
        } else {
            inv.setItem(12, choice(view, "set:humans", Material.IRON_SWORD, "Starting Humans", NamedTextColor.RED,
                    "Random seekers at the start. Auto: 1, 2 at 7+, 3 at 10, minus AI.",
                    List.of("Auto", "None", "1", "2", "3"), s.humanCountName(), Function.identity(),
                    view.lobby() ? "Or pick exact players: Pick Seekers" : "In a match, use Assign Roles"));
        }
        inv.setItem(13, choice(view, "set:size", Material.RABBIT_HIDE, "Rat Size", NamedTextColor.AQUA,
                s.ratSize.description + ".", names(RatSize.values(), r -> r.displayName),
                s.ratSize.displayName, Function.identity(), null));
        inv.setItem(14, choice(view, "set:respawn", Material.ENDER_PEARL, "Rat Respawn", s.respawnMode.color,
                s.respawnMode.description + ".", names(RespawnMode.values(), r -> r.displayName),
                s.respawnMode.displayName, Function.identity(), "Rescues, escapes and drainpipe slips"));
        inv.setItem(15, choice(view, "set:speed", Material.SUGAR, "Human Speed", NamedTextColor.RED,
                "How fast humans run compared to rats.", doubles(RatSeekSettings.HUMAN_SPEEDS),
                RatSeekSettings.speedName(s.humanSpeed), Function.identity(), null));
        inv.setItem(16, choice(view, "set:rescue", Material.GOLD_INGOT, "Rescue Price", NamedTextColor.YELLOW,
                "Cheese a free rat trades to free a friend or bank an escape.", ints(RatSeekSettings.RESCUE_COSTS),
                s.rescueCost + " cheese", v -> v + " cheese", null));
        inv.setItem(17, choice(view, "set:bots", Material.PLAYER_HEAD, "AI Seekers", NamedTextColor.RED,
                "Add 0-3 AI hunters; humans and AI share 3 seeker slots.", List.of("0", "1", "2", "3"),
                Integer.toString(s.aiSeekers), Function.identity(), "Skill and learning: Manor Extras"));

        inv.setItem(19, choice(view, "set:cheese", Material.CAKE, "Cheese Supply", NamedTextColor.GOLD,
                "How much cheese is on the map at once.", names(CheeseSupply.values(),
                        c -> c.displayName + " (" + c.maxCheese + ")"),
                s.cheese.displayName + " (" + s.cheese.maxCheese + ")", Function.identity(), null));
        inv.setItem(20, choice(view, "set:hints", Material.SPYGLASS, "Compass Hints", NamedTextColor.YELLOW,
                "How often the seeker compass locks onto a rat.", names(HintRate.values(), h -> h.displayName),
                s.hints.displayName, Function.identity(), null));
        inv.setItem(21, toggle(view, "set:glow", Material.GLOW_INK_SAC, "Glowing Rats", s.ratsGlow,
                "Every rat glows through walls for the whole round."));
        inv.setItem(22, toggle(view, "set:escape", Material.PAPER, "Starting Escape Card", s.startingEscape,
                "Every rat starts with a Get Out of Jail Free card."));
        inv.setItem(23, toggle(view, "set:finalglow", Material.REDSTONE_TORCH, "Final Minute Frenzy",
                s.finalMinuteGlow, "Free rats glow during the last 60 seconds."));
        inv.setItem(24, twistsButton(s, view));
        inv.setItem(25, toggle(view, "set:danger", Material.SCULK_SENSOR, "Danger Sense", s.dangerSense,
                "Rats get heartbeat warnings when a human is close."));

        inv.setItem(28, toggle(view, "set:scamper", Material.RABBIT_FOOT, "Scamper Dash", s.scamper,
                "Rats can burst forward on a 12 second cooldown."));
        inv.setItem(29, toggle(view, "set:taunt", Material.BONE, "Squeak Taunt", s.taunt,
                "Rats squeak for +1 point but reveal themselves."));
        inv.setItem(30, toggle(view, "set:scent", Material.SNIFFER_EGG, "Scent Pulse", s.scentPulse,
                "Humans can reveal the nearest rat every 15 seconds."));
        inv.setItem(31, toggle(view, "set:rattle", Material.TRIPWIRE_HOOK, "Cage Rattle", s.cageRattle,
                "Caged rats expose the humans and boost free rats."));
        inv.setItem(32, toggle(view, "set:rescues", Material.BELL, "Cheese Trading", s.rescues,
                "The keeper frees caged rats or banks escapes for cheese."));
        inv.setItem(33, toggle(view, "set:tunnels", Material.LADDER, "Noisy Tunnels", s.tunnelAntiCamp,
                "Rats camping in service tunnels get flushed out."));
        inv.setItem(34, toggle(view, "set:rush", Material.GOAT_HORN, "Last Rat Rush", s.lastRatRush,
                "The final free rat gets a speed burst and dash reset."));

        int[] presetSlots = {37, 39, 41, 43};
        Preset[] presets = {Preset.EASY, Preset.NORMAL, Preset.HARD, Preset.CHAOS};
        for (int i = 0; i < presets.length; i++) {
            inv.setItem(presetSlots[i], presetButton(view, presets[i], preset == presets[i]));
        }

        inv.setItem(45, button("nav:extras", Material.SPYGLASS, "Manor Extras", NamedTextColor.AQUA, true,
                List.of(line("Costumes, cinematics, gadgets, classes", NamedTextColor.GRAY),
                        line("and the living house.", NamedTextColor.GRAY), Component.empty(),
                        hint("Click to open"))));
        inv.setItem(47, button(view.editable() ? "action:reset" : "noop", Material.TNT, "Reset to Defaults",
                NamedTextColor.RED, false, List.of(line("Restore every setting to the classic rules.", NamedTextColor.GRAY),
                        Component.empty(), hint(view.editable() ? "Click to reset" : lockText(view)))));
        inv.setItem(49, button("action:close", Material.BARRIER, "Done", NamedTextColor.GREEN, false,
                List.of(line("Close the settings menu.", NamedTextColor.GRAY))));
        if (view.lobby()) {
            inv.setItem(53, button(view.editable() ? "nav:roles" : "noop", Material.PLAYER_HEAD, "Pick Seekers",
                    NamedTextColor.GOLD, view.pickedHumans() > 0,
                    List.of(line("Choose exactly which players are humans", NamedTextColor.GRAY),
                            line("and how many AI seekers join them.", NamedTextColor.GRAY), Component.empty(),
                            hint(view.editable() ? "Click to open" : lockText(view)))));
            inv.setItem(51, view.canStart()
                    ? button("action:start", Material.LIME_CONCRETE, "Start the Match!", NamedTextColor.GREEN, true,
                    List.of(line("Everyone queued is ready to go.", NamedTextColor.GRAY), Component.empty(),
                            hint("Click to start")))
                    : button("noop", Material.GRAY_CONCRETE, "Waiting for Players", NamedTextColor.GRAY, false,
                    List.of(line(s.aiSeekers > 0 ? "AI seekers allow a solo rat." : "Rat and Seek needs 2 players.", NamedTextColor.GRAY))));
        } else {
            inv.setItem(51, button(view.canEditRoles() ? "nav:roles" : "noop", Material.PLAYER_HEAD,
                    "Assign Roles", NamedTextColor.GOLD, false,
                    List.of(line("Choose who hunts, who hides and the AI.", NamedTextColor.GRAY), Component.empty(),
                            hint(view.canEditRoles() ? "Click to open" : "Only during the hiding countdown"))));
        }
        return inv;
    }

    Inventory twists(RatSeekSettings s, View view) {
        Holder holder = new Holder(Page.TWISTS, view.lobby());
        Inventory inv = create(holder, 36, Component.text("House Twists ", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD)
                .append(Component.text("» Shake up the hunt", NamedTextColor.DARK_GRAY)));
        frame(inv, 36, s.preset());
        inv.setItem(4, choice(view, "set:twistrate", Material.COMPARATOR, "Twist Frequency", NamedTextColor.LIGHT_PURPLE,
                "Random events that shake up the hunt.", names(TwistRate.values(), r -> r.displayName),
                s.twistRate.displayName, Function.identity(), null));
        for (int i = 0; i < Twist.values().length; i++) {
            Twist twist = Twist.values()[i];
            boolean on = s.twists.contains(twist);
            List<Component> lore = new ArrayList<>();
            lore.add(line(twist.description + ".", NamedTextColor.GRAY));
            lore.add(Component.empty());
            lore.add(line(on ? "✔ ENABLED" : "✘ DISABLED", on ? NamedTextColor.GREEN : NamedTextColor.RED));
            lore.add(hint(view.editable() ? "Click to toggle" : lockText(view)));
            inv.setItem(TWIST_SLOTS[i], button(view.editable() ? "twist:" + twist.name() : "noop",
                    on ? twist.icon : Material.GRAY_DYE, twist.displayName, on ? twist.color : NamedTextColor.DARK_GRAY,
                    on, lore));
        }
        inv.setItem(20, button(view.editable() ? "twist:all" : "noop", Material.LIME_DYE, "Enable All",
                NamedTextColor.GREEN, false, List.of(hint("Turn every twist on"))));
        inv.setItem(24, button(view.editable() ? "twist:none" : "noop", Material.GRAY_DYE, "Disable All",
                NamedTextColor.RED, false, List.of(hint("Turn every twist off"))));
        inv.setItem(31, button("nav:main", Material.ARROW, "Back", NamedTextColor.WHITE, false,
                List.of(hint("Return to the host settings"))));
        return inv;
    }

    Inventory extras(RatSeekSettings s, View view) {
        Holder holder = new Holder(Page.EXTRAS, view.lobby());
        Inventory inv = create(holder, 54, Component.text("Manor Extras ", NamedTextColor.AQUA, TextDecoration.BOLD)
                .append(Component.text("» Make it spooky", NamedTextColor.DARK_GRAY)));
        frame(inv, 54, s.preset());
        inv.setItem(4, button("noop", Material.SPYGLASS, "Manor Extras", NamedTextColor.AQUA, true,
                List.of(line(view.status(), view.statusColor()), Component.empty(),
                        line("None of these change the balance presets.", NamedTextColor.DARK_GRAY))));
        section(inv, 9, 17, Material.CYAN_STAINED_GLASS_PANE, "Presentation", NamedTextColor.AQUA);
        inv.setItem(10, toggle(view, "set:costumes", Material.PLAYER_HEAD, "Rat Costumes", s.costumes,
                "Rats wear a rat face and fur."));
        inv.setItem(11, toggle(view, "set:cinematic", Material.ENDER_EYE, "Cinematic Intro & Podium", s.cinematic,
                "A camera sweep before hiding and a podium with awards at the end."));
        inv.setItem(12, toggle(view, "set:blindfold", Material.BLACK_WOOL, "Blindfolded Humans", s.blindfold,
                "Humans can't watch the rats hide from the waiting booth."));
        section(inv, 18, 26, Material.RED_STAINED_GLASS_PANE, "Human Gadgets", NamedTextColor.RED);
        inv.setItem(19, toggle(view, "set:flashlight", Material.END_ROD, "Flashlight", s.flashlight,
                "A battery torch; rats caught in the beam glow."));
        inv.setItem(20, toggle(view, "set:mousetraps", Material.HEAVY_WEIGHTED_PRESSURE_PLATE, "Snap Mousetraps",
                s.mousetraps, "Three floor traps that pin a rat and ping the humans."));
        inv.setItem(21, toggle(view, "set:bait", Material.HONEYCOMB, "Cheese Bait", s.bait,
                "Fake cheese that leaves a rat sticky and glowing."));
        inv.setItem(23, choice(view, "set:botskill", Material.ZOMBIE_HEAD, "AI Seeker Skill", s.botSkill.color,
                s.botSkill.description + ". AI seekers run as fast as a human player.",
                names(RatSeekSettings.BotSkill.values(), b -> b.displayName), s.botSkill.displayName,
                Function.identity(), "They only see and hear what a player could"));
        inv.setItem(24, toggle(view, "set:botlearning", Material.KNOWLEDGE_BOOK, "AI Learning", s.botLearning,
                "AI seekers remember hiding spots, habits, tricks and good trap sites between matches."));
        inv.setItem(25, button(view.editable() && view.lobby() ? "action:forgetai" : "noop", Material.BOOK,
                "Forget AI Lessons", NamedTextColor.GRAY, false,
                List.of(line("Wipes everything the AI seekers have learned.", NamedTextColor.GRAY),
                        hint(view.lobby() ? "Click to wipe (lobby only)" : "Only from the lobby menu"))));
        section(inv, 27, 35, Material.PURPLE_STAINED_GLASS_PANE, "Rat Classes", NamedTextColor.LIGHT_PURPLE);
        inv.setItem(28, toggle(view, "set:classes", Material.ARMOR_STAND, "Rat Classes", s.classes,
                "Rats pick Scout, Thief, Trickster or Tinkerer while hiding."));
        section(inv, 36, 44, Material.ORANGE_STAINED_GLASS_PANE, "Living House", NamedTextColor.GOLD);
        inv.setItem(37, choice(view, "set:cat", Material.STRING, "Mr. Whiskers", NamedTextColor.DARK_GRAY,
                "A house cat that pounces on nearby rats. " + s.cat.description + ".",
                names(RatSeekSettings.CatMode.values(), c -> c.displayName), s.cat.displayName,
                Function.identity(), "Taunts distract the cat"));
        inv.setItem(38, toggle(view, "set:chandeliers", Material.LANTERN, "Chandeliers", s.chandeliers,
                "Rats pull the hall rope to drop a chandelier on humans."));
        inv.setItem(49, button("nav:main", Material.ARROW, "Back", NamedTextColor.WHITE, false,
                List.of(hint("Return to the host settings"))));
        return inv;
    }

    /** The rat class picker shown during hiding. */
    Inventory classes(RatClass current, java.util.Map<RatClass, Integer> counts, int cap) {
        Holder holder = new Holder(Page.CLASSES, false);
        Inventory inv = create(holder, 27, Component.text("Choose Your Rat ", NamedTextColor.GOLD, TextDecoration.BOLD)
                .append(Component.text("» Class", NamedTextColor.DARK_GRAY)));
        frame(inv, 27, Preset.CUSTOM);
        int[] slots = {10, 12, 14, 16};
        RatClass[] values = RatClass.values();
        for (int i = 0; i < values.length; i++) {
            RatClass ratClass = values[i];
            int count = counts.getOrDefault(ratClass, 0);
            boolean selected = ratClass == current;
            boolean full = !selected && count >= cap;
            List<Component> lore = new ArrayList<>();
            lore.add(stat("Passive", ratClass.passive, NamedTextColor.WHITE));
            lore.add(stat("Ability", ratClass.abilityName, ratClass.color));
            lore.add(line("  " + ratClass.abilityDescription + " (" + ratClass.cooldownTicks / 20 + "s)",
                    NamedTextColor.GRAY));
            lore.add(Component.empty());
            lore.add(line("Picked: " + count + "/" + cap, full ? NamedTextColor.RED : NamedTextColor.DARK_GRAY));
            lore.add(selected ? line("✔ YOUR CLASS", NamedTextColor.GREEN)
                    : hint(full ? "Class is full" : "Click to choose"));
            inv.setItem(slots[i], button(full ? "noop" : "class:" + ratClass.name(), ratClass.icon,
                    ratClass.displayName, ratClass.color, selected, lore));
        }
        inv.setItem(22, button("action:close", Material.BARRIER, "Done", NamedTextColor.GREEN, false,
                List.of(line("No pick? You get the least popular class when the hunt starts.", NamedTextColor.GRAY))));
        return inv;
    }

    /**
     * Human/AI seeker picker. In the lobby it records the host's exact picks for the next match
     * (no picks = the Starting Humans setting decides); in a match it swaps roles live.
     */
    Inventory roles(List<RoleEntry> roster, int humans, int aiSeekers, int maxSeekers, boolean lobby) {
        Holder holder = new Holder(Page.ROLES, lobby);
        Inventory inv = create(holder, 36, Component.text(lobby ? "Pick Seekers " : "Assign Roles ",
                NamedTextColor.DARK_RED, TextDecoration.BOLD)
                .append(Component.text("» Click to swap", NamedTextColor.DARK_GRAY)));
        frame(inv, 36, Preset.CUSTOM);
        boolean random = lobby && humans == 0;
        inv.setItem(4, button("noop", Material.IRON_SWORD, "Seekers: " + (random ? "Starting Humans" : humans + " human")
                        + (random || humans == 1 ? "" : "s") + " + " + aiSeekers + " AI", NamedTextColor.RED, false,
                List.of(line("Click a head to swap a player's role.", NamedTextColor.GRAY),
                        line("Humans and AI share " + maxSeekers + " seeker slots.", NamedTextColor.DARK_GRAY),
                        line(random ? "No picks yet: the Starting Humans setting chooses." : "Everyone else is a rat.",
                                NamedTextColor.DARK_GRAY))));
        for (int i = 0; i < roster.size() && i < ROLE_SLOTS.length; i++) {
            RoleEntry entry = roster.get(i);
            String role = entry.human() ? "HUMAN" : random ? "RAT or random human" : "RAT";
            ItemStack head = button("role:" + entry.player().getUniqueId(), Material.PLAYER_HEAD,
                    entry.player().getName(), entry.human() ? NamedTextColor.RED : NamedTextColor.GOLD, entry.human(),
                    List.of(line(role, entry.human() ? NamedTextColor.RED : NamedTextColor.GOLD),
                            Component.empty(), hint(entry.human() ? "Click to make a rat" : "Click to make a human")));
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(entry.player());
            head.setItemMeta(meta);
            inv.setItem(ROLE_SLOTS[i], head);
        }
        List<Component> aiLore = new ArrayList<>();
        aiLore.add(line("AI hunters that join the human seekers.", NamedTextColor.GRAY));
        aiLore.add(Component.empty());
        for (int n = 0; n <= maxSeekers; n++) {
            boolean selected = n == aiSeekers;
            aiLore.add(line((selected ? " ▶ " : "    ") + n, selected ? NamedTextColor.GREEN : NamedTextColor.DARK_GRAY));
        }
        aiLore.add(Component.empty());
        aiLore.add(hint("Left-click more • Right-click fewer"));
        inv.setItem(28, button("set:bots", Material.ZOMBIE_HEAD, "AI Seekers: " + aiSeekers, NamedTextColor.RED,
                aiSeekers > 0, aiLore));
        inv.setItem(30, lobby
                ? button("action:clearpicks", Material.HOPPER, "Clear Picks", NamedTextColor.AQUA, false,
                List.of(line("Go back to random humans from", NamedTextColor.GRAY),
                        line("the Starting Humans setting.", NamedTextColor.GRAY), Component.empty(),
                        hint("Click to clear")))
                : button("action:shuffle", Material.HOPPER, "Shuffle Humans", NamedTextColor.AQUA, false,
                List.of(line("Randomly pick the same number of humans.", NamedTextColor.GRAY), Component.empty(),
                        hint("Click to shuffle"))));
        inv.setItem(32, button("nav:main", Material.ARROW, "Back to Settings", NamedTextColor.WHITE, false,
                List.of(hint("Return to the host settings"))));
        return inv;
    }

    String tagOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        return item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    // ------------------------------------------------------------------ widgets

    private ItemStack header(RatSeekSettings s, View view, Preset preset) {
        List<Component> lore = new ArrayList<>();
        lore.add(line(view.status(), view.statusColor()));
        lore.add(Component.empty());
        lore.add(stat("Preset", preset.displayName, preset.color));
        lore.add(stat("Hide / Hunt", s.hideSeconds + "s / " + s.huntMinutes + " min", NamedTextColor.WHITE));
        lore.add(stat("Humans", s.humanCountName() + " at " + RatSeekSettings.speedName(s.humanSpeed), NamedTextColor.WHITE));
        lore.add(stat("AI seekers", Integer.toString(s.aiSeekers), NamedTextColor.RED));
        lore.add(stat("Rats", s.ratSize.displayName + ", respawn " + s.respawnMode.displayName, NamedTextColor.WHITE));
        lore.add(stat("Twists", s.twistRate == TwistRate.OFF || s.twists.isEmpty() ? "Off"
                : s.twistRate.displayName + " (" + s.twists.size() + " on)", NamedTextColor.WHITE));
        lore.add(Component.empty());
        lore.add(line("Left-click cycles forward, right-click back.", NamedTextColor.DARK_GRAY));
        return button("noop", Material.NETHER_STAR, "Crooked Manor Rules", NamedTextColor.GOLD, true, lore);
    }

    private ItemStack twistsButton(RatSeekSettings s, View view) {
        List<Component> lore = new ArrayList<>();
        lore.add(line("Random events that shake up the hunt.", NamedTextColor.GRAY));
        lore.add(Component.empty());
        lore.add(stat("Frequency", s.twistRate.displayName, NamedTextColor.LIGHT_PURPLE));
        for (Twist twist : Twist.values()) {
            boolean on = s.twists.contains(twist);
            lore.add(line((on ? " ✔ " : " ✘ ") + twist.displayName, on ? NamedTextColor.GREEN : NamedTextColor.DARK_GRAY));
        }
        lore.add(Component.empty());
        lore.add(hint("Click to choose twists"));
        return button("nav:twists", Material.FIREWORK_STAR, "House Twists", NamedTextColor.LIGHT_PURPLE,
                s.twistRate != TwistRate.OFF && !s.twists.isEmpty(), lore);
    }

    private ItemStack presetButton(View view, Preset preset, boolean selected) {
        List<Component> lore = new ArrayList<>();
        lore.add(line(preset.description + ".", NamedTextColor.GRAY));
        lore.add(line("Keeps timers, teams, rat size and abilities.", NamedTextColor.DARK_GRAY));
        lore.add(Component.empty());
        lore.add(selected ? line("✔ ACTIVE", NamedTextColor.GREEN)
                : hint(view.editable() ? "Click to apply" : lockText(view)));
        return button(view.editable() ? "preset:" + preset.name() : "noop", preset.icon,
                preset.displayName + " Preset", preset.color, selected, lore);
    }

    private ItemStack choice(View view, String tag, Material material, String name, NamedTextColor color,
                             String description, List<String> options, String current,
                             Function<String, String> label, String note) {
        List<Component> lore = new ArrayList<>();
        lore.add(line(description, NamedTextColor.GRAY));
        if (note != null) {
            lore.add(line(note + ".", NamedTextColor.DARK_GRAY));
        }
        lore.add(Component.empty());
        for (String option : options) {
            String shown = label.apply(option);
            boolean selected = shown.equals(current);
            lore.add(line((selected ? " ▶ " : "    ") + shown, selected ? NamedTextColor.GREEN : NamedTextColor.DARK_GRAY));
        }
        lore.add(Component.empty());
        lore.add(hint(view.editable() ? "Left-click next • Right-click previous" : lockText(view)));
        return button(view.editable() ? tag : "noop", material, name + ": " + current, color, false, lore);
    }

    private ItemStack toggle(View view, String tag, Material material, String name, boolean on, String description) {
        List<Component> lore = new ArrayList<>();
        lore.add(line(description, NamedTextColor.GRAY));
        lore.add(Component.empty());
        lore.add(line(on ? "✔ ON" : "✘ OFF", on ? NamedTextColor.GREEN : NamedTextColor.RED));
        lore.add(hint(view.editable() ? "Click to toggle" : lockText(view)));
        return button(view.editable() ? tag : "noop", material, name, on ? NamedTextColor.GREEN : NamedTextColor.RED,
                on, lore);
    }

    private ItemStack button(String tag, Material material, String name, NamedTextColor color, boolean glint,
                             List<Component> lore) {
        ItemStack item = ItemStack.of(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color, TextDecoration.BOLD).decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.addItemFlags(ItemFlag.values());
        if (glint) {
            meta.setEnchantmentGlintOverride(true);
        }
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private void section(Inventory inv, int left, int right, Material pane, String name, NamedTextColor color) {
        ItemStack marker = button("noop", pane, name, color, false, List.of());
        inv.setItem(left, marker);
        inv.setItem(right, marker);
    }

    private void frame(Inventory inv, int size, Preset preset) {
        Material pane = switch (preset) {
            case EASY -> Material.YELLOW_STAINED_GLASS_PANE;
            case NORMAL -> Material.GREEN_STAINED_GLASS_PANE;
            case HARD -> Material.RED_STAINED_GLASS_PANE;
            case CHAOS -> Material.PURPLE_STAINED_GLASS_PANE;
            case CUSTOM -> Material.BLACK_STAINED_GLASS_PANE;
        };
        ItemStack filler = button("noop", pane, " ", NamedTextColor.DARK_GRAY, false, List.of());
        for (int slot = 0; slot < size; slot++) {
            if (slot < 9 || slot >= size - 9 || slot % 9 == 0 || slot % 9 == 8) {
                inv.setItem(slot, filler);
            }
        }
    }

    private static Inventory create(Holder holder, int size, Component title) {
        Inventory inventory = Bukkit.createInventory(holder, size, title);
        holder.inventory = inventory;
        return inventory;
    }

    private static String lockText(View view) {
        return view.lobby() ? "Only the queue host can change this" : "Locked — only the host, during hiding";
    }

    private static Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private static Component hint(String text) {
        return line("» " + text, NamedTextColor.YELLOW);
    }

    private static Component stat(String label, String value, NamedTextColor color) {
        return Component.text(label + ": ", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(value, color));
    }

    private static List<String> ints(int[] values) {
        List<String> result = new ArrayList<>();
        for (int value : values) {
            result.add(Integer.toString(value));
        }
        return result;
    }

    private static List<String> doubles(double[] values) {
        List<String> result = new ArrayList<>();
        for (double value : values) {
            result.add(RatSeekSettings.speedName(value));
        }
        return result;
    }

    private static <E> List<String> names(E[] values, Function<E, String> name) {
        List<String> result = new ArrayList<>();
        for (E value : values) {
            result.add(name.apply(value));
        }
        return result;
    }
}
