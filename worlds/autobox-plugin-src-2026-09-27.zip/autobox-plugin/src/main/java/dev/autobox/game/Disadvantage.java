package dev.autobox.game;

import org.bukkit.Material;

public enum Disadvantage {

    HALF_HEARTS("Half Hearts", "You only have 5 hearts", Material.APPLE),
    SLOWNESS("Slowness", "Permanent Slowness II", Material.LEATHER_BOOTS),
    GLASS_CANNON("Glass Cannon", "You take double damage", Material.GLASS),
    HUNGER("Hunger", "Your food bar never fills", Material.ROTTEN_FLESH),
    NO_WOOL_REFILL("No Wool Refill", "Wool does not restock when placed", Material.WHITE_WOOL),
    NO_SPRINT("No Sprint", "You can never sprint", Material.SUGAR),
    WEAKNESS("Weakness", "Melee hits deal half a heart", Material.IRON_SWORD);

    private final String displayName;
    private final String description;
    private final Material icon;

    Disadvantage(String displayName, String description, Material icon) {
        this.displayName = displayName;
        this.description = description;
        this.icon = icon;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public Material getIcon() {
        return icon;
    }
}
