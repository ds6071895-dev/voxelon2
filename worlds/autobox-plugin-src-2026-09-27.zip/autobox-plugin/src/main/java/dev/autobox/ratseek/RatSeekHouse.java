package dev.autobox.ratseek;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Deterministic manor blueprint, kept independent of a live world for navigation checks. */
final class RatSeekHouse {
    static final int CELLAR = 74, GROUND = 80, UPSTAIRS = 86, ATTIC = 92;
    static final Pos RELEASE = new Pos(0, 81, 19);
    static final Pos WAITING = new Pos(0, 81, 29);
    static final Pos CAGE = new Pos(29, 81, 0);
    static final Pos KEEPER = new Pos(24, 81, 0);
    /** Standing spots on top of the garden podium steps, and the crowd in front of it. */
    static final Pos PODIUM_FIRST = new Pos(13, 83, 25);
    static final Pos PODIUM_SECOND = new Pos(10, 82, 25);
    static final Pos PODIUM_THIRD = new Pos(16, 82, 25);
    static final Pos PODIUM_CROWD = new Pos(13, 81, 28);
    record Pos(int x, int y, int z) {
        Pos offset(int dx, int dy, int dz) { return new Pos(x + dx, y + dy, z + dz); }
    }
    record Room(String name, int x1, int x2, int y1, int y2, int z1, int z2) { }
    record Passage(String name, int x, int y, int z1, int z2, Pos exitA, Pos exitB) { }
    record Hide(String name, Pos position) { }
    final Map<Pos, Material> blocks = new LinkedHashMap<>();
    final List<Room> rooms = new ArrayList<>();
    final List<Passage> passages = new ArrayList<>();
    final List<Hide> hides = new ArrayList<>();
    final List<Pos> spawns = new ArrayList<>();
    final List<Pos> cheese = new ArrayList<>();
    /** Floor levers in each central hall that drop the chandelier. */
    final List<Pos> chandelierLevers = new ArrayList<>();
    /** Where each hall's chandelier hangs (the ceiling cell above the drop zone). */
    final List<Pos> chandeliers = new ArrayList<>();
    RatSeekHouse() {
        shell();
        interiors();
        stairs();
        ducts();
        garden();
        cage();
    }

    Material at(Pos p) { return blocks.getOrDefault(p, Material.AIR); }
    private void block(int x, int y, int z, Material material) {
        blocks.put(new Pos(x, y, z), material);
    }
    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, Material material) {
        for (int x = x1; x <= x2; x++)
            for (int y = y1; y <= y2; y++)
                for (int z = z1; z <= z2; z++) block(x, y, z, material);
    }

    private void shell() {
        // Clear the previous arena, including its roof, after a plugin upgrade or unclean shutdown.
        fill(-25, CELLAR, -21, 34, 109, 34, Material.AIR);
        // A continuous foundation and tall perimeter keep every chase inside the estate.
        fill(-25, GROUND - 1, -21, 34, GROUND, 34, Material.GRASS_BLOCK);
        fill(-20, CELLAR, -16, 20, ATTIC + 2, 16, Material.AIR);
        for (int y : new int[]{CELLAR, GROUND, UPSTAIRS, ATTIC}) {
            fill(-20, y, -16, 20, y, 16,
                    y == CELLAR ? Material.DEEPSLATE_TILES : Material.SPRUCE_PLANKS);
            Material wall = y == CELLAR ? Material.STONE_BRICKS : Material.CALCITE;
            fill(-20, y + 1, -16, 20, y + 5, -16, wall);
            fill(-20, y + 1, 16, 20, y + 5, 16, wall);
            fill(-20, y + 1, -15, -20, y + 5, 15, wall);
            fill(20, y + 1, -15, 20, y + 5, 15, wall);
            for (int x = -20; x <= 20; x += 8) {
                for (int z : new int[]{-16, 16})
                    fill(x, y + 1, z, x, y + 5, z, Material.STRIPPED_DARK_OAK_LOG);
            }
            for (int z = -16; z <= 16; z += 8) {
                for (int x : new int[]{-20, 20})
                    fill(x, y + 1, z, x, y + 5, z, Material.STRIPPED_DARK_OAK_LOG);
            }
            if (y != CELLAR) {
                for (int x : new int[]{-16, -8, 6, 14}) {
                    for (int z : new int[]{-16, 16}) {
                        fill(x, y + 2, z, x + 2, y + 3, z, Material.LIGHT_BLUE_STAINED_GLASS);
                        fill(x, y + 1, z, x + 2, y + 1, z, Material.DARK_OAK_PLANKS);
                    }
                }
                for (int z : new int[]{-10, 6}) {
                    for (int x : new int[]{-20, 20})
                        fill(x, y + 2, z, x, y + 3, z + 3, Material.LIGHT_BLUE_STAINED_GLASS);
                }
            }
            for (int z : new int[]{-16, 16})
                fill(-20, y, z, 20, y, z, Material.DARK_OAK_PLANKS);
        }
        // Steep slate roof, closed gables, contrasting ridge and paired chimneys.
        for (int rise = 0; rise <= 8; rise++) {
            int edge = 17 - rise * 2;
            int y = 98 + rise;
            fill(-21, y, -edge, 21, y, -edge + 1, Material.DEEPSLATE_TILES);
            fill(-21, y, edge - 1, 21, y, edge, Material.DEEPSLATE_TILES);
            if (edge > 1) {
                fill(-20, y, -edge + 2, -20, y, edge - 2, Material.CALCITE);
                fill(20, y, -edge + 2, 20, y, edge - 2, Material.CALCITE);
            }
        }
        fill(-21, 107, 0, 21, 107, 0, Material.POLISHED_BLACKSTONE_BRICKS);
        for (int x : new int[]{-14, 14}) {
            fill(x, 99, -7, x + 1, 108, -6, Material.BRICKS);
            fill(x - 1, 109, -8, x + 2, 109, -5, Material.POLISHED_ANDESITE);
        }
        // The porch and service door connect to the same circulation loop.
        fill(-3, 81, 16, 3, 84, 16, Material.AIR);
        fill(20, 81, -2, 20, 83, 2, Material.AIR);
        fill(-4, 80, 17, 4, 80, 21, Material.STONE_BRICKS);
        fill(-4, 85, 16, 4, 85, 21, Material.DARK_OAK_PLANKS);
        for (int x : new int[]{-4, 4}) {
            fill(x, 81, 21, x, 84, 21, Material.STRIPPED_DARK_OAK_LOG);
            block(x, 84, 20, Material.LANTERN);
        }
    }

    private void interiors() {
        String[][] names = {
                {"wine cellar", "boiler workshop", "root pantry", "storage vault"},
                {"grand library", "country kitchen", "drawing room", "banquet room"},
                {"master bedroom", "toy room", "guest bedroom", "bath and laundry"},
                {"trunk loft", "artist studio", "clockwork attic", "music room"}
        };
        Material[][] colors = {
                {Material.RED_TERRACOTTA, Material.GRAY_TERRACOTTA, Material.GREEN_TERRACOTTA, Material.BROWN_TERRACOTTA},
                {Material.GREEN_WOOL, Material.YELLOW_TERRACOTTA, Material.RED_WOOL, Material.ORANGE_TERRACOTTA},
                {Material.BLUE_WOOL, Material.PINK_WOOL, Material.PURPLE_WOOL, Material.LIGHT_BLUE_TERRACOTTA},
                {Material.BROWN_WOOL, Material.CYAN_WOOL, Material.GRAY_WOOL, Material.MAGENTA_WOOL}
        };
        for (int level = 0; level < 4; level++) {
            int floor = CELLAR + level * 6;
            for (int wallX : new int[]{-4, 4}) {
                fill(wallX, floor + 1, -15, wallX, floor + 5, 15, Material.DARK_OAK_PLANKS);
                // Two doors per room allow the Human to cut off a chase.
                for (int z : new int[]{-13, -6, 4, 11})
                    fill(wallX, floor + 1, z, wallX, floor + 3, z + 1, Material.AIR);
                for (int z : new int[]{-9, 8}) mousehole(wallX, floor + 1, z);
            }
            for (int side : new int[]{-1, 1}) {
                int left = side < 0 ? -19 : 5;
                int right = side < 0 ? -5 : 19;
                fill(left, floor + 1, 0, right, floor + 5, 0, Material.DARK_OAK_PLANKS);
                for (int dx : new int[]{3, 10})
                    fill(left + dx, floor + 1, 0, left + dx + 1, floor + 3, 0, Material.AIR);
                mousehole(left + 1, floor + 1, 0);
                mousehole(right - 1, floor + 1, 0);
                for (int half = 0; half < 2; half++) {
                    int z = half == 0 ? -15 : 1;
                    int index = half * 2 + (side > 0 ? 1 : 0);
                    String name = names[level][index];
                    rooms.add(new Room(name, left, right, floor + 1, floor + 6, z, z + 14));
                    furnish(left, floor, z, colors[level][index], level, index, name);
                }
            }
            rooms.add(new Room(new String[]{"cellar passage", "entrance hall", "upper gallery", "attic landing"}[level],
                    -3, 3, floor + 1, floor + 6, -15, 15));
            // Inlaid runners don't reduce clearance in the one-block rat openings.
            fill(-3, floor, -15, -3, floor, 15, Material.RED_WOOL);
            fill(3, floor, -15, 3, floor, 15, Material.RED_WOOL);
            for (int z : new int[]{-14, -3, 3, 14}) block(0, floor + 5, z, Material.SEA_LANTERN);
            // Floor lever against the hall wall, clear of both staircases and every doorway.
            block(3, floor + 1, 0, Material.LEVER);
            chandelierLevers.add(new Pos(3, floor + 1, 0));
            chandeliers.add(new Pos(0, floor + 5, 0));
        }
    }

    private void furnish(int x, int floor, int z, Material accent, int level, int index, String name) {
        int y = floor + 1;
        fill(x + 3, floor, z + 3, x + 11, floor, z + 11, accent);
        // Four shallow, open-sided hides per room; none blocks the two door approaches.
        canopy(name + " table", x + 4, y, z + 4, accent);
        canopy(name + " bench", x + 9, y, z + 9, Material.SPRUCE_PLANKS);
        // Wardrobe: full-height side exit and an open front, with a dark recessed back.
        fill(x, y, z + 4, x + 1, y + 3, z + 7, Material.DARK_OAK_PLANKS);
        fill(x + 1, y, z + 5, x + 1, y + 1, z + 6, Material.AIR);
        hides.add(new Hide(name + " wardrobe", new Pos(x + 1, y, z + 5)));
        // Shelf island: a one-block channel behind it with exits at both ends.
        fill(x + 5, y, z + 12, x + 9, y + 2, z + 12,
                level == 0 ? Material.BARREL : level == 3 ? Material.CHISELED_BOOKSHELF : Material.BOOKSHELF);
        hides.add(new Hide(name + " shelf recess", new Pos(x + 7, y, z + 13)));
        block(x + 5, y + 3, z + 12, Material.LANTERN);
        // Room-specific silhouettes and props above the crawlable furniture.
        if (level == 1 && index == 1) {
            fill(x + 10, y, z + 1, x + 13, y + 2, z + 1, Material.SMOOTH_QUARTZ);
            block(x + 11, y + 1, z + 2, Material.SMOKER);
            block(x + 12, y + 3, z + 1, Material.FLOWER_POT);
        } else if (level == 2 && index != 3) {
            fill(x + 4, y + 2, z + 4, x + 4, y + 2, z + 6, Material.WHITE_WOOL);
            fill(x + 3, y + 1, z + 4, x + 3, y + 3, z + 6, Material.STRIPPED_DARK_OAK_LOG);
            block(x + 2, y, z + 3, Material.BARREL);
        } else if (level == 2) {
            fill(x + 10, y, z + 1, x + 13, y + 1, z + 2, Material.QUARTZ_BLOCK);
            block(x + 10, y + 2, z + 1, Material.CAULDRON);
            block(x + 12, y + 2, z + 1, Material.IRON_BLOCK);
        } else if (level == 0 && index == 1) {
            fill(x + 11, y, z + 1, x + 12, y + 3, z + 2, Material.WAXED_COPPER_BLOCK);
            block(x + 10, y, z + 1, Material.BLAST_FURNACE);
        } else if (level == 0) {
            for (int dx : new int[]{3, 6, 10}) {
                block(x + dx, y, z + 1, Material.BARREL);
                block(x + dx, y + 1, z + 1, index == 2 ? Material.HAY_BLOCK : Material.BARREL);
            }
        } else if (level == 3 && index == 3) {
            fill(x + 3, y, z + 1, x + 6, y + 1, z + 2, Material.BLACK_CONCRETE);
            fill(x + 3, y + 1, z + 3, x + 6, y + 1, z + 3, Material.QUARTZ_SLAB);
            block(x + 10, y, z + 1, Material.JUKEBOX);
        } else if (level == 3) {
            for (int dx : new int[]{3, 7, 11}) {
                block(x + dx, y, z + 1, Material.BARREL);
                block(x + dx, y + 1, z + 1, index == 1 ? Material.WHITE_WOOL : Material.NOTE_BLOCK);
            }
        } else {
            fill(x + 3, y, z + 1, x + 8, y + 3, z + 1, Material.BOOKSHELF);
            block(x + 10, y, z + 2, Material.FLOWER_POT);
        }
        block(x + 7, floor + 5, z + 7, Material.SEA_LANTERN);
        spawns.add(new Pos(x + 7, y, z + 7));
        cheese.add(new Pos(x + 2, y, z + 9));
        cheese.add(new Pos(x + 11, y, z + 5));
    }

    private void canopy(String name, int x, int y, int z, Material top) {
        fill(x, y + 1, z, x + 3, y + 1, z + 2, top);
        for (int dx : new int[]{0, 3}) for (int dz : new int[]{0, 2})
            block(x + dx, y, z + dz, Material.STRIPPED_SPRUCE_LOG);
        hides.add(new Hide(name, new Pos(x + 1, y, z + 1)));
    }

    private void mousehole(int x, int y, int z) {
        block(x, y, z, Material.AIR);
        hides.add(new Hide("mousehole", new Pos(x, y, z)));
    }

    private void stairs() {
        // Two independent three-wide stairways connect ALL floors. Directional stair
        // blocks let both player scales ascend without repeated jumping.
        for (int floor = CELLAR; floor < ATTIC; floor += 6) {
            for (int step = 1; step <= 6; step++) {
                int northZ = -14 + step;
                int southZ = 14 - step;
                fill(-2, floor + step, northZ, 0, floor + step + 3, northZ, Material.AIR);
                fill(0, floor + step, southZ, 2, floor + step + 3, southZ, Material.AIR);
                fill(-2, floor + step, northZ, 0, floor + step, northZ, Material.POLISHED_ANDESITE_STAIRS);
                fill(0, floor + step, southZ, 2, floor + step, southZ, Material.POLISHED_ANDESITE_STAIRS);
            }
        }
    }

    private void ducts() {
        // Four sealed service runs. Entry is at floor level and both flush destinations
        // are unobstructed inside a room. The existing noise/anti-camping rules apply.
        for (int floor : new int[]{GROUND, UPSTAIRS}) for (int side : new int[]{-1, 1}) {
            int x = side * 21;
            int y = floor + 1;
            fill(Math.min(x, side * 22), y - 1, -13, Math.max(x, side * 22), y + 1, 13,
                    Material.WAXED_OXIDIZED_COPPER);
            fill(x, y, -12, x, y, 12, Material.AIR);
            for (int z : new int[]{-12, 12}) block(side * 20, y, z, Material.AIR);
            passages.add(new Passage((side < 0 ? "west " : "east ")
                    + (floor == GROUND ? "skirting tunnel" : "linen duct"), x, y, -12, 12,
                    new Pos(side * 19, y, -12), new Pos(side * 19, y, 12)));
        }
    }

    private void garden() {
        rooms.add(new Room("greenhouse", -22, -10, 81, 87, 23, 32));
        rooms.add(new Room("hedge garden", -25, 20, 81, 91, 17, 34));
        rooms.add(new Room("rescue courtyard", 21, 34, 81, 91, -21, 34));
        for (int x : new int[]{-25, 34}) fill(x, 81, -21, x, 84, 34, Material.STONE_BRICKS);
        for (int z : new int[]{-21, 34}) fill(-25, 81, z, 34, 84, z, Material.STONE_BRICKS);
        fill(-2, 80, 17, 2, 80, 33, Material.POLISHED_ANDESITE);
        fill(21, 80, -2, 26, 80, 2, Material.POLISHED_ANDESITE);
        for (int x : new int[]{-8, 7, 15}) {
            for (int z : new int[]{22, 29}) {
                fill(x, 81, z, x + 3, 82, z, Material.AZALEA_LEAVES);
                hides.add(new Hide("hedge alcove", new Pos(x + 1, 81, z + 1)));
                cheese.add(new Pos(x + 1, 81, z + 2));
            }
        }
        // Walk-in greenhouse with two opposing doors and raised potting benches.
        fill(-22, 80, 23, -11, 80, 32, Material.MOSSY_STONE_BRICKS);
        fill(-22, 81, 23, -11, 85, 23, Material.GLASS);
        fill(-22, 81, 32, -11, 85, 32, Material.GLASS);
        fill(-22, 81, 24, -22, 85, 31, Material.GLASS);
        fill(-11, 81, 24, -11, 85, 31, Material.GLASS);
        fill(-22, 86, 23, -11, 86, 32, Material.WAXED_OXIDIZED_COPPER);
        fill(-17, 81, 23, -15, 83, 23, Material.AIR);
        fill(-11, 81, 27, -11, 83, 29, Material.AIR);
        // Benches stand a block off the glass so a seeker can reach under them from behind.
        canopy("greenhouse potting bench", -20, 81, 25, Material.MOSS_BLOCK);
        canopy("greenhouse seed bench", -16, 81, 28, Material.SPRUCE_PLANKS);
        block(-19, 83, 25, Material.FLOWER_POT);
        block(-15, 83, 28, Material.FLOWER_POT);
        block(-17, 85, 27, Material.SEA_LANTERN);
        spawns.add(new Pos(-15, 81, 26));
        cheese.add(new Pos(-20, 81, 30));
        for (int x : new int[]{-23, 5, 23, 32}) for (int z : new int[]{19, 32}) {
            fill(x, 81, z, x, 83, z, Material.STONE_BRICK_WALL);
            block(x, 84, z, Material.LANTERN);
        }
        // Winners' podium between the hedge rows; rats can scramble over it during play.
        fill(12, 81, 25, 14, 81, 26, Material.POLISHED_BLACKSTONE_BRICKS);
        fill(12, 82, 25, 14, 82, 26, Material.GOLD_BLOCK);
        fill(9, 81, 25, 11, 81, 26, Material.IRON_BLOCK);
        fill(15, 81, 25, 17, 81, 26, Material.WAXED_CUT_COPPER);
        // Glass waiting booth keeps the humans contained during the hide countdown.
        // Sized for up to 3 seekers with a 3x3 interior.
        fill(-2, 81, 27, 2, 83, 31, Material.GLASS);
        fill(-1, 81, 28, 1, 82, 30, Material.AIR);
    }

    private void cage() {
        fill(27, 80, -3, 32, 80, 3, Material.POLISHED_ANDESITE);
        fill(27, 81, -3, 32, 84, -3, Material.IRON_BARS);
        fill(27, 81, 3, 32, 84, 3, Material.IRON_BARS);
        fill(27, 81, -2, 27, 84, 2, Material.IRON_BARS);
        fill(32, 81, -2, 32, 84, 2, Material.IRON_BARS);
        fill(27, 85, -3, 32, 85, 3, Material.WAXED_COPPER_BLOCK);
        block(28, 84, 0, Material.SEA_LANTERN);
        block(31, 84, 0, Material.SEA_LANTERN);
        fill(23, 80, -1, 25, 80, 1, Material.GOLD_BLOCK);
    }
}
