package dev.autobox.splat;

import dev.autobox.splat.SplatRules.Team;

/**
 * Pure ranked-mode scoring shared by every objective: each team counts down from 100, the
 * lower count leads, zero is a knockout, and overtime runs while the trailing team holds the
 * objective. No world access, so SplatCheck can simulate whole matches.
 */
public final class RankedRules {
    public static final double START = 100;
    /** Overtime can't run forever. */
    public static final int OVERTIME_CAP = 2400;
    /** Splat Zones: share of zone turf needed to take control, and the penalty rules. */
    public static final double ZONE_CONTROL = 0.7, PENALTY_SHARE = 0.75, PENALTY_CAP = 25;
    /** Splat Zones count drop per tick while holding (one per second). */
    public static final double ZONE_RATE = 1 / 20.0;
    /** Clam Blitz scoring. */
    public static final double POWER_CLAM = 20, CLAM = 3;
    public static final int CLAMS_FOR_POWER = 10, MAX_CLAMS = 9, BARRIER_OPEN = 400;

    private RankedRules() {}

    /** Lower count leads; null when level. */
    public static Team leader(double orange, double blue) {
        if (Math.abs(orange - blue) < 1e-9) return null;
        return orange < blue ? Team.ORANGE : Team.BLUE;
    }

    public static Team winner(double orange, double blue) { return leader(orange, blue); }

    public static Team knockout(double orange, double blue) {
        if (orange <= 0 && blue <= 0) return null;
        return orange <= 0 ? Team.ORANGE : blue <= 0 ? Team.BLUE : null;
    }

    /** At the buzzer (and every overtime tick): keep playing while a non-leading team holds the objective. */
    public static boolean overtime(double orange, double blue, Team holder, int overtimeTicks) {
        if (holder == null || overtimeTicks >= OVERTIME_CAP) return false;
        return leader(orange, blue) != holder;
    }

    /** Overtime ends the instant the holder takes the lead. Losing the objective ends it after a short grace. */
    public static final int OVERTIME_GRACE = 40;

    public static boolean overtimeDecided(double orange, double blue, Team holder) {
        return holder != null && leader(orange, blue) == holder;
    }

    /**
     * A team that holds its count down by 'scored' points and then loses control owes a penalty
     * that has to burn off before its count moves again.
     */
    public static double penaltyAfterLoss(double scoredDuringHold) {
        return Math.min(PENALTY_CAP, Math.max(0, scoredDuringHold) * PENALTY_SHARE);
    }

    /** Zone control from painted shares: a team takes it at the threshold, otherwise the holder keeps it. */
    public static Team zoneControl(Team holder, int orange, int blue, int size) {
        if (size <= 0) return holder;
        if (orange >= size * ZONE_CONTROL) return Team.ORANGE;
        if (blue >= size * ZONE_CONTROL) return Team.BLUE;
        if (holder != null) {
            // Losing majority to the other side neutralises the zone.
            int own = holder == Team.ORANGE ? orange : blue, other = holder == Team.ORANGE ? blue : orange;
            if (other > own) return null;
        }
        return holder;
    }

    /** Count for a push-style mode (Tower, Rainmaker): 100 minus the best progress in percent. */
    public static double progressCount(double bestFraction) {
        return Math.max(0, Math.round(START - 100 * Math.max(0, Math.min(1, bestFraction))));
    }
}
