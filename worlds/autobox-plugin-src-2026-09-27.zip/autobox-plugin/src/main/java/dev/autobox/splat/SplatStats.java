package dev.autobox.splat;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.logging.Level;

/** Saved Splatoon progress in plugins/Worlds/splat-ranks.yml: level, per-mode rating and records, and the chosen kit. */
public final class SplatStats {
    public static final class ModeStats {
        public int rating = SplatRating.START, matches, wins, losses, splats, deaths, turf;
    }

    public static final class Record {
        public String name;
        public long xp;
        public Kit kit = Kit.SPLATTERSHOT;
        public final EnumMap<SplatMode, ModeStats> modes = new EnumMap<>(SplatMode.class);

        Record(String name) { this.name = name; }

        public ModeStats mode(SplatMode mode) { return modes.computeIfAbsent(mode, m -> new ModeStats()); }

        public int level() { return SplatRating.level(xp); }

        public int totalWins() { return modes.values().stream().mapToInt(m -> m.wins).sum(); }

        public int totalMatches() { return modes.values().stream().mapToInt(m -> m.matches).sum(); }
    }

    public record Entry(UUID id, Record record) {}

    private final Plugin plugin;
    private final File file;
    private final Map<UUID, Record> records = new HashMap<>();
    private final Object writeLock = new Object();

    public SplatStats(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "splat-ranks.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        for (String key : yaml.getKeys(false)) {
            UUID id;
            try { id = UUID.fromString(key); } catch (IllegalArgumentException bad) { continue; }
            ConfigurationSection section = yaml.getConfigurationSection(key);
            if (section == null) continue;
            Record record = new Record(section.getString("name", "?"));
            record.xp = section.getLong("xp");
            record.kit = Kit.byName(section.getString("kit", Kit.SPLATTERSHOT.name()));
            ConfigurationSection modes = section.getConfigurationSection("modes");
            if (modes != null) {
                for (String modeKey : modes.getKeys(false)) {
                    SplatMode mode = SplatMode.byKey(modeKey);
                    ConfigurationSection m = modes.getConfigurationSection(modeKey);
                    if (mode == null || m == null) continue;
                    ModeStats stats = record.mode(mode);
                    stats.rating = m.getInt("rating", SplatRating.START);
                    stats.matches = m.getInt("matches");
                    stats.wins = m.getInt("wins");
                    stats.losses = m.getInt("losses");
                    stats.splats = m.getInt("splats");
                    stats.deaths = m.getInt("deaths");
                    stats.turf = m.getInt("turf");
                }
            }
            records.put(id, record);
        }
    }

    /** Existing record (renamed to the current name) or a fresh one. */
    public Record get(UUID id, String name) {
        Record record = records.computeIfAbsent(id, k -> new Record(name));
        if (name != null) record.name = name;
        return record;
    }

    public Record find(UUID id) { return records.get(id); }

    public Map.Entry<UUID, Record> findByName(String name) {
        return records.entrySet().stream().filter(e -> e.getValue().name.equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public int rating(UUID id, SplatMode mode) {
        Record record = records.get(id);
        return record == null ? SplatRating.START : record.mode(mode).rating;
    }

    /** Top players by mode rating (with at least one match), or by level when mode is null. */
    public List<Entry> top(SplatMode mode, int limit) {
        Comparator<Map.Entry<UUID, Record>> order = mode == null
                ? Comparator.comparingLong((Map.Entry<UUID, Record> e) -> e.getValue().xp).reversed()
                : Comparator.comparingInt((Map.Entry<UUID, Record> e) -> e.getValue().mode(mode).rating).reversed();
        return records.entrySet().stream()
                .filter(e -> mode == null ? e.getValue().xp > 0 : e.getValue().modes.containsKey(mode) && e.getValue().mode(mode).matches > 0)
                .sorted(order.thenComparing(e -> e.getValue().name, String.CASE_INSENSITIVE_ORDER))
                .limit(limit).map(e -> new Entry(e.getKey(), e.getValue())).toList();
    }

    private boolean saveQueued;

    /** Batches bursts of small changes (locker clicks) into one save a few seconds later. */
    public void saveSoon() {
        if (saveQueued) return;
        if (!plugin.isEnabled()) { save(); return; }
        saveQueued = true;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            saveQueued = false;
            save();
        }, 100L);
    }

    /** Snapshot on the main thread, write off it; the temp-file rename keeps a crash from truncating the file. */
    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<UUID, Record> entry : records.entrySet()) {
            Record r = entry.getValue();
            String base = entry.getKey().toString();
            yaml.set(base + ".name", r.name);
            yaml.set(base + ".xp", r.xp);
            yaml.set(base + ".kit", r.kit.name());
            for (Map.Entry<SplatMode, ModeStats> mode : r.modes.entrySet()) {
                String m = base + ".modes." + mode.getKey().key;
                ModeStats s = mode.getValue();
                yaml.set(m + ".rating", s.rating);
                yaml.set(m + ".matches", s.matches);
                yaml.set(m + ".wins", s.wins);
                yaml.set(m + ".losses", s.losses);
                yaml.set(m + ".splats", s.splats);
                yaml.set(m + ".deaths", s.deaths);
                yaml.set(m + ".turf", s.turf);
            }
        }
        String text = yaml.saveToString();
        Runnable write = () -> {
            synchronized (writeLock) {
                try {
                    Files.createDirectories(file.getParentFile().toPath());
                    File temp = new File(file.getParentFile(), file.getName() + ".tmp");
                    Files.writeString(temp.toPath(), text, StandardCharsets.UTF_8);
                    Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (IOException failure) {
                    plugin.getLogger().log(Level.WARNING, "Could not save Splatoon ranks", failure);
                }
            }
        };
        if (plugin.isEnabled()) Bukkit.getScheduler().runTaskAsynchronously(plugin, write);
        else write.run();
    }
}
