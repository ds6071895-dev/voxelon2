package dev.autobox.splat;

import dev.autobox.splat.SplatArena.Pos;
import dev.autobox.splat.SplatRules.Team;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;

/** Every main, sub and special: firing, flight, hits, bombs, gadgets and explosions. */
final class SplatWeapons {
    /** An ink shot or thrown item; damage is the full-strength hit before falloff. */
    record Shot(UUID owner, Team team, Weapon weapon, int born, double damage) {}

    private record Bomb(UUID owner, Team team, Weapon weapon, Location at, Entity display, int burstAt) {}

    /** Placed gadgets and specials that live on the map for a while. */
    static final class Device {
        final Weapon kind;
        final UUID owner;
        final Team team;
        final Location at;
        final Entity visual;
        final int until;
        final Vector drift;

        Device(Weapon kind, UUID owner, Team team, Location at, Entity visual, int until, Vector drift) {
            this.kind = kind; this.owner = owner; this.team = team; this.at = at; this.visual = visual; this.until = until; this.drift = drift;
        }
    }

    private static final Vector DOWN = new Vector(0, -1, 0);

    private final SplatGame g;
    final Map<Entity, Shot> shots = new HashMap<>();
    private final List<Bomb> bombs = new ArrayList<>();
    final List<Device> devices = new ArrayList<>();

    SplatWeapons(SplatGame g) { this.g = g; }

    void clear() {
        shots.clear();
        bombs.clear();
        devices.clear();
    }

    void tick() {
        sweepShots();
        bombsTick();
        devicesTick();
    }

    // ------------------------------------------------------------------ firing

    void fire(Player p, Inkling in, Weapon weapon) {
        if (in.busy()) return;
        int now = g.elapsed;
        if (weapon == Weapon.TRIZOOKA && in.trizookaShots > 0) { trizookaShot(p, in); return; }
        if (weapon.kind == Weapon.Kind.SPECIAL) { activateSpecial(p, in); return; }
        if (weapon == Weapon.CLAM || weapon == Weapon.POWER_CLAM) {
            if (now < in.ready[weapon.ordinal()]) return;
            in.ready[weapon.ordinal()] = now + weapon.cooldown;
            g.objective.throwClam(p, in);
            return;
        }
        if (weapon.kind == Weapon.Kind.UTILITY) return;
        // Stale items (e.g. a sub after picking up the Rainmaker) do nothing.
        if (weapon != in.main() && !(weapon == in.kit.sub && !in.rainmaker && in.clams == 0 && !in.powerClam)) return;
        if (weapon.charges()) { beginCharge(p, in, weapon); return; }
        if (now < in.ready[weapon.ordinal()]) return;
        if (in.ink < weapon.ink) { noInk(p, in, weapon); return; }
        in.ink -= weapon.ink;
        in.lastFire = now;
        in.ready[weapon.ordinal()] = now + weapon.cooldown;
        Location at = p.getLocation();
        World world = g.world;
        switch (weapon) {
            case SPLATTERSHOT -> {
                shoot(p, in, weapon, 0, 0, 1, weapon.damage, 1);
                world.playSound(at, Sound.ENTITY_SNOWBALL_THROW, 0.45f, 1.9f);
                world.playSound(at, Sound.ENTITY_SLIME_SQUISH_SMALL, 0.3f, 1.8f);
            }
            case DUALIES -> {
                boolean turret = now < in.turretUntil;
                shoot(p, in, weapon, now % 4 < 2 ? -1.5 : 1.5, 0, 1, weapon.damage, turret ? 0.35 : 1);
                world.playSound(at, Sound.ENTITY_SNOWBALL_THROW, 0.35f, 2f);
                world.playSound(at, Sound.BLOCK_NOTE_BLOCK_HAT, 0.2f, 2f);
            }
            case ROLLER, INKBRUSH -> {
                Weapon.Ballistics b = weapon.ballistics;
                for (int i = 0; i < b.pellets(); i++) shoot(p, in, weapon, (i - (b.pellets() - 1) / 2.0) * b.pelletAngle(), 0, 1, weapon.damage, 1);
                p.swingMainHand();
                world.playSound(at, Sound.ENTITY_PLAYER_SPLASH, weapon == Weapon.ROLLER ? 0.6f : 0.35f, weapon == Weapon.ROLLER ? 1.5f : 1.9f);
                if (weapon == Weapon.ROLLER) world.playSound(at, Sound.ENTITY_SLIME_SQUISH, 0.8f, 0.8f);
            }
            case SLOSHER -> {
                // A heavy lead blob and two trailing ones, lobbed upward so they arc over cover.
                for (int i = 0; i < 3; i++)
                    shoot(p, in, weapon, 0, -8 + i * 1.5, 1 - i * 0.14, i == 0 ? weapon.damage : Weapon.SLOSH_TRAIL_DAMAGE, 1);
                p.swingMainHand();
                world.playSound(at, Sound.ITEM_BUCKET_EMPTY, 0.8f, 1.4f);
            }
            case BLASTER -> {
                shoot(p, in, weapon, 0, 0, 1, weapon.damage, 1);
                world.playSound(at, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.7f, 1.3f);
                world.playSound(at, Sound.ENTITY_SLIME_SQUISH, 0.5f, 1.4f);
            }
            case BOMB, BURST_BOMB, SUCTION_BOMB, SPRINKLER, BEAKON -> {
                shoot(p, in, weapon, 0, -4, 1, weapon.damage, 1);
                world.playSound(at, Sound.ENTITY_SNOWBALL_THROW, 1f, weapon == Weapon.BURST_BOMB ? 1.2f : 0.6f);
            }
            default -> {}
        }
    }

    private void noInk(Player p, Inkling in, Weapon weapon) {
        in.ready[weapon.ordinal()] = g.elapsed + 10;
        in.notice = Component.text("Not enough ink! Sneak on your own ink to refill.", NamedTextColor.RED);
        in.noticeUntil = g.elapsed + 30;
        p.playSound(p, Sound.BLOCK_NOTE_BLOCK_BASS, 0.6f, 0.6f);
    }

    private static boolean thrownItem(Weapon weapon) {
        return weapon.kind == Weapon.Kind.SUB || weapon == Weapon.BOOYAH || weapon == Weapon.CLAM || weapon == Weapon.POWER_CLAM;
    }

    Snowball shoot(Player p, Inkling in, Weapon weapon, double yawOffset, double pitchOffset, double speedFactor, double damage, double spreadFactor) {
        Weapon.Ballistics b = weapon.ballistics;
        Location eye = p.getEyeLocation();
        eye.setYaw(eye.getYaw() + (float) (yawOffset + g.random.nextGaussian() * b.spread() * spreadFactor));
        eye.setPitch(eye.getPitch() + (float) (pitchOffset + g.random.nextGaussian() * b.spread() * 0.6 * spreadFactor));
        Snowball ball = p.launchProjectile(Snowball.class, eye.getDirection().multiply(b.speed() * speedFactor));
        ball.setItem(thrownItem(weapon) ? g.weaponItem(weapon, false) : SplatGame.inkItem(in.team));
        // Shots fly straight, then drop; the no-gravity flag is synced so clients draw the same path.
        if (b.straightTicks() > 0) ball.setGravity(false);
        g.track(ball);
        shots.put(ball, new Shot(p.getUniqueId(), in.team, weapon, g.elapsed, damage));
        return ball;
    }

    /**
     * Players are non-collidable (so teammates never block ink or shove each other), which also
     * makes vanilla projectiles pass through them. Ink shots therefore test padded enemy
     * hitboxes along the path they are about to travel this tick.
     */
    private void sweepShots() {
        World world = g.world;
        for (Map.Entry<Entity, Shot> entry : new ArrayList<>(shots.entrySet())) {
            Entity ball = entry.getKey();
            Shot shot = entry.getValue();
            if (!ball.isValid()) { forget(ball); continue; }
            Weapon w = shot.weapon();
            Weapon.Ballistics b = w.ballistics;
            int age = g.elapsed - shot.born();
            if (b != null && !ball.hasGravity() && age >= b.straightTicks()) ball.setGravity(true);
            Location at = ball.getLocation();
            if (w == Weapon.CLAM || w == Weapon.POWER_CLAM) {
                if (g.objective.flying(ball, shot)) remove(ball);
                continue;
            }
            if (inEnemyBubble(shot.team(), at)) {
                world.spawnParticle(Particle.BLOCK, at, 6, 0.1, 0.1, 0.1, 0, g.inkData.get(shot.team()));
                world.playSound(at, Sound.BLOCK_GLASS_HIT, 0.4f, 1.8f);
                remove(ball);
                continue;
            }
            if (w == Weapon.BURST_BOMB) {
                for (Player v : g.online()) {
                    Inkling vi = g.players.get(v.getUniqueId());
                    if (vi.team == shot.team() || !vi.alive()) continue;
                    if (v.getBoundingBox().expand(0.4).contains(at.toVector())) { remove(ball); burst(shot, at); break; }
                }
                continue;
            }
            if (thrownItem(w)) continue;

            boolean heavy = w == Weapon.TRIZOOKA || w == Weapon.RAINMAKER || w == Weapon.BLASTER;
            // Light shots leave a trail puff every other tick: dozens of shots in flight each sent a
            // particle packet to every player every tick. The ink item itself is still drawn every tick.
            if (heavy || (age & 1) == 0) {
                world.spawnParticle(Particle.DUST, at, heavy ? 3 : 1, 0.03, 0.03, 0.03, 0, heavy ? SplatGame.dust(shot.team()) : SplatGame.trail(shot.team()));
            }
            if (g.elapsed % 3 == 0 && g.random.nextInt(3) == 0) {
                RayTraceResult drip = world.rayTraceBlocks(at, DOWN, 5, FluidCollisionMode.NEVER, true);
                if (drip != null && drip.getHitBlock() != null) g.paint(SplatGame.pos(drip.getHitBlock()), shot.team(), g.players.get(shot.owner()));
            }
            if (w == Weapon.BLASTER && age >= Weapon.BLASTER_BURST_AGE) {
                remove(ball);
                explode(at, shot, 1.1, 12, Weapon.BLASTER_RADIUS, Weapon.BLASTER_SPLASH, 2);
                continue;
            }

            Vector start = at.toVector(), velocity = ball.getVelocity();
            double length = velocity.length();
            Player shooter = Bukkit.getPlayer(shot.owner());
            double padding = SplatRules.HIT_FORGIVENESS + (shooter == null ? 0 : Math.min(0.2, shooter.getPing() / 1000.0));
            Player victim = null;
            double nearest = Double.MAX_VALUE;
            for (Player v : g.online()) {
                Inkling vi = g.players.get(v.getUniqueId());
                if (vi.team == shot.team() || vi.respawnAt >= 0) continue;
                BoundingBox box = v.getBoundingBox().expand(padding);
                double distance;
                if (box.contains(start)) distance = 0;
                else if (length < 1e-4) continue;
                else {
                    RayTraceResult hit = box.rayTrace(start, velocity.clone().multiply(1 / length), length);
                    if (hit == null) continue;
                    distance = hit.getHitPosition().distance(start);
                }
                if (distance < nearest) { nearest = distance; victim = v; }
            }
            if (victim == null) continue;
            if (nearest > 0.05) {
                RayTraceResult wall = world.rayTraceBlocks(at, velocity.clone().multiply(1 / length), nearest, FluidCollisionMode.NEVER, true);
                if (wall != null && wall.getHitBlock() != null) continue;
            }
            remove(ball);
            switch (w) {
                case TRIZOOKA -> explode(victim.getLocation().add(0, 1, 0), shot, 1.6, 20, Weapon.TRIZOOKA_RADIUS, 12, 2);
                case RAINMAKER -> explode(victim.getLocation().add(0, 1, 0), shot, 1.8, 20, Weapon.RAINMAKER_RADIUS, 10, 3);
                case BLASTER -> {
                    inkPlayer(victim, shot, at);
                    explode(at, shot, 0, 0, Weapon.BLASTER_RADIUS, Weapon.BLASTER_SPLASH, 1);
                }
                default -> inkPlayer(victim, shot, at);
            }
        }
    }

    private void forget(Entity ball) {
        shots.remove(ball);
        g.entities.remove(ball);
    }

    private void remove(Entity ball) {
        forget(ball);
        ball.remove();
    }

    private void inkPlayer(Player v, Shot shot, Location at) {
        Inkling vi = g.players.get(v.getUniqueId());
        Player shooter = Bukkit.getPlayer(shot.owner());
        Weapon.Ballistics b = shot.weapon().ballistics;
        double damage = SplatRules.falloff(shot.damage(), g.elapsed - shot.born(), b.fullUntil(), b.fadeUntil(), b.minFactor());
        g.hurt(v, vi, damage, shooter, shot.weapon());
        Location l = v.getLocation();
        g.paint(new Pos(l.getBlockX(), (int) Math.floor(l.getY() - 0.05), l.getBlockZ()), shot.team(), g.players.get(shot.owner()));
        g.world.spawnParticle(Particle.BLOCK, at, 6, 0.15, 0.15, 0.15, 0, g.inkData.get(shot.team()));
    }

    public void projectileHit(ProjectileHitEvent event) {
        Entity entity = event.getEntity();
        Shot shot = shots.remove(entity);
        g.entities.remove(entity);
        entity.remove();
        if (shot == null || g.phase != SplatGame.Phase.PLAY) return;
        Inkling owner = g.players.get(shot.owner());
        Location land = entity.getLocation();
        if (event.getHitBlock() != null) {
            BlockFace face = event.getHitBlockFace() == null ? BlockFace.UP : event.getHitBlockFace();
            land = event.getHitBlock().getRelative(face).getLocation().add(0.5, 0.1, 0.5);
        }
        World world = g.world;
        Weapon w = shot.weapon();
        switch (w) {
            case CLAM, POWER_CLAM -> g.objective.landed(land, shot);
            case BOMB -> bomb(shot, land, Weapon.BOMB_FUSE);
            case SUCTION_BOMB -> bomb(shot, land, Weapon.SUCTION_FUSE);
            case BOOYAH -> bomb(shot, land, 40);
            case BURST_BOMB -> burst(shot, entity.getLocation());
            case SPRINKLER -> placeSprinkler(shot, land);
            case BEAKON -> placeBeakon(shot, land);
            case BLASTER -> explode(entity.getLocation(), shot, 1.1, 12, Weapon.BLASTER_RADIUS, Weapon.BLASTER_SPLASH, 2);
            case TRIZOOKA -> explode(entity.getLocation(), shot, 1.6, 20, Weapon.TRIZOOKA_RADIUS, 12, 2);
            case RAINMAKER -> explode(entity.getLocation(), shot, 1.8, 20, Weapon.RAINMAKER_RADIUS, 10, 3);
            default -> {
                if (event.getHitBlock() == null) return;
                Pos hit = SplatGame.pos(event.getHitBlock());
                Location at = entity.getLocation();
                if (g.objective.hitBlock(hit, shot.team(), shot.damage())) {
                    world.spawnParticle(Particle.DUST, at, 4, 0.15, 0.15, 0.15, 0, SplatGame.dust(shot.team()));
                    return;
                }
                g.splash(hit, shot.team(), w.ballistics.splash(), owner);
                world.spawnParticle(Particle.BLOCK, at, 5, 0.15, 0.15, 0.15, 0, g.inkData.get(shot.team()));
                world.spawnParticle(Particle.DUST, at, 5, 0.2, 0.2, 0.2, 0, SplatGame.dust(shot.team()));
                if (g.random.nextInt(3) == 0) world.playSound(at, Sound.ENTITY_SLIME_SQUISH_SMALL, 0.3f, 1.3f + g.random.nextFloat() * 0.5f);
            }
        }
    }

    // ------------------------------------------------------------------ explosions and bombs

    /** Paints, damages by distance from the centre (inner ring hits harder) and hurts objectives like the Rainmaker shield. */
    void explode(Location at, Shot shot, double innerRadius, double innerDamage, double outerRadius, double outerDamage, int paintRadius) {
        explode(at, shot.team(), shot.owner(), shot.weapon(), innerRadius, innerDamage, outerRadius, outerDamage, paintRadius);
    }

    void explode(Location at, Team team, UUID ownerId, Weapon weapon, double innerRadius, double innerDamage,
                 double outerRadius, double outerDamage, int paintRadius) {
        World world = g.world;
        Inkling owner = ownerId == null ? null : g.players.get(ownerId);
        Player thrower = ownerId == null ? null : Bukkit.getPlayer(ownerId);
        RayTraceResult ground = world.rayTraceBlocks(at, DOWN, 5, FluidCollisionMode.NEVER, true);
        Pos centre = ground != null && ground.getHitBlock() != null ? SplatGame.pos(ground.getHitBlock())
                : new Pos(at.getBlockX(), (int) Math.floor(at.getY() - 0.2), at.getBlockZ());
        if (paintRadius > 0) g.splash(centre, team, paintRadius, owner);
        if (outerRadius >= 2.5) world.spawnParticle(Particle.EXPLOSION, at, 1);
        world.spawnParticle(Particle.DUST, at, (int) (15 * outerRadius), outerRadius * 0.5, 0.5, outerRadius * 0.5, 0, SplatGame.dust(team));
        world.spawnParticle(Particle.BLOCK, at, (int) (10 * outerRadius), outerRadius * 0.4, 0.4, outerRadius * 0.4, 0, g.inkData.get(team));
        world.playSound(at, Sound.ENTITY_GENERIC_EXPLODE, (float) Math.min(1.5, 0.3 + outerRadius * 0.15), 1.6f);
        world.playSound(at, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 0.8f, 1.2f);
        for (Player v : g.online()) {
            Inkling vi = g.players.get(v.getUniqueId());
            if (vi.team == team || !vi.alive() || shieldedFrom(vi.team, v.getLocation(), at)) continue;
            double d = v.getLocation().add(0, 0.9, 0).distance(at);
            if (d < innerRadius) g.hurt(v, vi, innerDamage, thrower, weapon);
            else if (d < outerRadius) g.hurt(v, vi, outerDamage, thrower, weapon);
        }
        g.objective.blast(at, team, outerRadius, Math.max(innerDamage, outerDamage));
    }

    private void burst(Shot shot, Location at) { explode(at, shot, 1.5, 12, 2.6, 6, 2); }

    private void bomb(Shot shot, Location land, int fuse) {
        Entity display = g.dropStill(land, g.uniqueItem(shot.weapon()), false);
        bombs.add(new Bomb(shot.owner(), shot.team(), shot.weapon(), land, display, g.elapsed + fuse));
        g.world.playSound(land, Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1.2f);
    }

    private void bombsTick() {
        World world = g.world;
        for (Iterator<Bomb> it = bombs.iterator(); it.hasNext(); ) {
            Bomb bomb = it.next();
            int left = bomb.burstAt() - g.elapsed;
            if (left <= 0) {
                it.remove();
                bomb.display().remove();
                g.entities.remove(bomb.display());
                Location at = bomb.at().clone().add(0, 0.3, 0);
                switch (bomb.weapon()) {
                    case SUCTION_BOMB -> explode(at, bomb.team(), bomb.owner(), bomb.weapon(), 2.2, 20, 4, 10, 4);
                    case BOOYAH -> explode(at, bomb.team(), bomb.owner(), bomb.weapon(), 3.5, 20, Weapon.BOOYAH_RADIUS, 10, 5);
                    default -> explode(at, bomb.team(), bomb.owner(), bomb.weapon(), 1.8, Weapon.BOMB.damage, 3.2, 8, 3);
                }
            } else {
                if (left % (left < 12 ? 3 : 6) == 0) world.playSound(bomb.at(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 2f);
                if (left % 4 == 0) world.spawnParticle(Particle.DUST, bomb.at().clone().add(0, 0.3, 0), 3, 0.15, 0.15, 0.15, 0, SplatGame.dust(bomb.team()));
                if (bomb.weapon() == Weapon.BOOYAH && left % 2 == 0) {
                    double r = Weapon.BOOYAH_RADIUS * (1 - left / 40.0);
                    for (int i = 0; i < 16; i++) {
                        double a = i * Math.PI / 8;
                        world.spawnParticle(Particle.DUST, bomb.at().clone().add(Math.cos(a) * r, 0.2, Math.sin(a) * r), 1, 0, 0, 0, 0, SplatGame.dust(bomb.team()));
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ gadgets

    private void placeSprinkler(Shot shot, Location land) {
        devices.removeIf(d -> {
            boolean mine = d.kind == Weapon.SPRINKLER && d.owner.equals(shot.owner());
            if (mine && d.visual != null) { d.visual.remove(); g.entities.remove(d.visual); }
            return mine;
        });
        Entity visual = g.dropStill(land, g.uniqueItem(Weapon.SPRINKLER), false);
        devices.add(new Device(Weapon.SPRINKLER, shot.owner(), shot.team(), land, visual, g.elapsed + Weapon.SPRINKLER_TICKS, null));
        g.world.playSound(land, Sound.BLOCK_BUBBLE_COLUMN_UPWARDS_INSIDE, 1f, 1.4f);
    }

    private void placeBeakon(Shot shot, Location land) {
        List<Device> mine = devices.stream().filter(d -> d.kind == Weapon.BEAKON && d.owner.equals(shot.owner())).toList();
        if (mine.size() >= Weapon.BEAKONS) removeDevice(mine.getFirst());
        Entity visual = g.dropStill(land, g.uniqueItem(Weapon.BEAKON), false);
        visual.setGlowing(true);
        devices.add(new Device(Weapon.BEAKON, shot.owner(), shot.team(), land, visual, g.elapsed + Weapon.BEAKON_TICKS, null));
        g.world.playSound(land, Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 1.6f);
    }

    private void removeDevice(Device d) {
        devices.remove(d);
        if (d.visual != null) { d.visual.remove(); g.entities.remove(d.visual); }
    }

    List<Device> beakons(Team team) { return devices.stream().filter(d -> d.kind == Weapon.BEAKON && d.team == team).toList(); }

    private boolean inEnemyBubble(Team shotTeam, Location at) {
        for (Device d : devices)
            if (d.kind == Weapon.BUBBLER && d.team != shotTeam && d.at.getWorld() == at.getWorld()
                    && d.at.distanceSquared(at) <= Weapon.BUBBLER_RADIUS * Weapon.BUBBLER_RADIUS) return true;
        return false;
    }

    /** A player inside their own team's bubble ignores explosions that go off outside it. */
    private boolean shieldedFrom(Team victimTeam, Location victim, Location blast) {
        double r2 = Weapon.BUBBLER_RADIUS * Weapon.BUBBLER_RADIUS;
        for (Device d : devices)
            if (d.kind == Weapon.BUBBLER && d.team == victimTeam && d.at.distanceSquared(victim) <= r2 && d.at.distanceSquared(blast) > r2) return true;
        return false;
    }

    private void devicesTick() {
        World world = g.world;
        for (Device d : new ArrayList<>(devices)) {
            if (g.elapsed >= d.until || (d.visual != null && !d.visual.isValid())) { removeDevice(d); continue; }
            Player owner = Bukkit.getPlayer(d.owner);
            Inkling in = g.players.get(d.owner);
            switch (d.kind) {
                case SPRINKLER -> {
                    if (g.elapsed % 5 == 0) {
                        double angle = g.random.nextDouble() * Math.PI * 2, r = 0.8 + g.random.nextDouble() * 2.6;
                        Location drop = d.at.clone().add(Math.cos(angle) * r, 1.2, Math.sin(angle) * r);
                        RayTraceResult hit = world.rayTraceBlocks(drop, DOWN, 4, FluidCollisionMode.NEVER, true);
                        if (hit != null && hit.getHitBlock() != null) g.paint(SplatGame.pos(hit.getHitBlock()), d.team, in);
                        world.spawnParticle(Particle.DUST, d.at.clone().add(0, 0.5, 0), 3, 0.6, 0.3, 0.6, 0, SplatGame.trail(d.team));
                    }
                    if (g.elapsed % 10 == 0) hurtNear(d, 2.2, 1, owner, false);
                }
                case BEAKON -> {
                    if (g.elapsed % 10 == 0)
                        for (int i = 0; i < 6; i++) world.spawnParticle(Particle.DUST, d.at.clone().add(0, 0.4 + i * 0.5, 0), 1, 0.02, 0, 0.02, 0, SplatGame.trail(d.team));
                    for (Player v : g.online()) {
                        Inkling vi = g.players.get(v.getUniqueId());
                        if (vi.team != d.team && vi.alive() && v.getLocation().distanceSquared(d.at) < 1.5) {
                            world.playSound(d.at, Sound.BLOCK_GLASS_BREAK, 1f, 1.4f);
                            removeDevice(d);
                            break;
                        }
                    }
                }
                case BUBBLER -> {
                    if (g.elapsed % 4 == 0) {
                        Particle.DustOptions dust = new Particle.DustOptions(d.team.color, 0.9f);
                        // 20 random points every 4 ticks still reads as a shimmering sphere at a third fewer packets.
                        for (int i = 0; i < 20; i++) {
                            double u = g.random.nextDouble() * 2 - 1, a = g.random.nextDouble() * Math.PI * 2, s = Math.sqrt(1 - u * u);
                            Vector v = new Vector(s * Math.cos(a), Math.abs(u), s * Math.sin(a)).multiply(Weapon.BUBBLER_RADIUS);
                            world.spawnParticle(Particle.DUST, d.at.clone().add(v), 1, 0, 0, 0, 0, dust);
                        }
                    }
                    if (d.until - g.elapsed == 20) world.playSound(d.at, Sound.BLOCK_BEACON_DEACTIVATE, 1f, 1.6f);
                }
                case INK_STORM -> {
                    d.at.add(d.drift);
                    Particle.DustOptions cloud = new Particle.DustOptions(d.team.color, 2.2f);
                    world.spawnParticle(Particle.DUST, d.at, 8, Weapon.STORM_RADIUS * 0.5, 0.3, Weapon.STORM_RADIUS * 0.5, 0, cloud);
                    if (g.elapsed % 2 == 0) {
                        double angle = g.random.nextDouble() * Math.PI * 2, r = g.random.nextDouble() * Weapon.STORM_RADIUS;
                        Location drop = d.at.clone().add(Math.cos(angle) * r, 0, Math.sin(angle) * r);
                        world.spawnParticle(Particle.FALLING_WATER, drop, 2, 0.1, 0, 0.1, 0);
                        RayTraceResult hit = world.rayTraceBlocks(drop, DOWN, 16, FluidCollisionMode.NEVER, true);
                        if (hit != null && hit.getHitBlock() != null) g.splash(SplatGame.pos(hit.getHitBlock()), d.team, g.random.nextInt(4) == 0 ? 1 : 0, in);
                    }
                    if (g.elapsed % 10 == 0) hurtNear(d, Weapon.STORM_RADIUS, 1.5, owner, true);
                    if (g.elapsed % 20 == 0) world.playSound(d.at, Sound.WEATHER_RAIN, 1f, 1.2f);
                }
                default -> {}
            }
        }
    }

    private void hurtNear(Device d, double radius, double damage, Player owner, boolean below) {
        for (Player v : g.online()) {
            Inkling vi = g.players.get(v.getUniqueId());
            if (vi.team == d.team || !vi.alive()) continue;
            Location l = v.getLocation();
            double dx = l.getX() - d.at.getX(), dz = l.getZ() - d.at.getZ();
            boolean vertical = below ? l.getY() < d.at.getY() && l.getY() > d.at.getY() - 16 : Math.abs(l.getY() - d.at.getY()) < 2;
            if (dx * dx + dz * dz < radius * radius && vertical) g.hurt(v, vi, damage, owner, d.kind);
        }
    }

    // ------------------------------------------------------------------ specials

    void activateSpecial(Player p, Inkling in) {
        if (in.special < SplatRules.SPECIAL_MAX || in.rainmaker || in.busy()) return;
        cancelCharge(p, in);
        Weapon special = in.kit.special;
        in.special = 0;
        in.specialAnnounced = false;
        in.specials++;
        Location l = p.getLocation();
        World world = g.world;
        for (Player other : g.world.getPlayers())
            other.sendMessage(Component.text("★ ", NamedTextColor.GOLD).append(Component.text(in.name, in.team.text))
                    .append(Component.text(" used " + special.title + "!", NamedTextColor.GRAY)));
        switch (special) {
            case SPLASHDOWN -> {
                in.splashdownAt = g.elapsed + Weapon.SPLASHDOWN_RISE;
                in.slamming = false;
                p.setVelocity(new Vector(0, 1.05, 0));
                world.playSound(l, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1f, 1.5f);
                world.playSound(l, Sound.ENTITY_WARDEN_SONIC_CHARGE, 0.7f, 1.8f);
                world.spawnParticle(Particle.BLOCK, l, 30, 0.6, 0.2, 0.6, 0, g.inkData.get(in.team));
            }
            case TRIZOOKA -> {
                in.trizookaShots = Weapon.TRIZOOKA_SHOTS;
                in.trizookaUntil = g.elapsed + Weapon.TRIZOOKA_TICKS;
                in.ready[Weapon.TRIZOOKA.ordinal()] = g.elapsed + 6;
                p.getInventory().setHeldItemSlot(SplatGame.MAIN_SLOT);
                world.playSound(l, Sound.ITEM_CROSSBOW_LOADING_END, 1f, 0.6f);
            }
            case BUBBLER -> {
                devices.add(new Device(Weapon.BUBBLER, in.id, in.team, l.clone().add(0, 0.2, 0), null, g.elapsed + Weapon.BUBBLER_TICKS, null));
                world.playSound(l, Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.8f);
                world.playSound(l, Sound.ENTITY_PLAYER_SPLASH, 1f, 0.6f);
            }
            case INK_STORM -> {
                Location eye = p.getEyeLocation();
                Vector look = eye.getDirection();
                RayTraceResult hit = world.rayTraceBlocks(eye, look, 12, FluidCollisionMode.NEVER, true);
                Location target = hit == null ? eye.clone().add(look.clone().multiply(12)) : hit.getHitPosition().toLocation(world);
                target.setY(Math.min(SplatArena.FLOOR + 12, target.getY() + 6));
                Vector drift = look.clone().setY(0);
                drift = drift.lengthSquared() < 1e-4 ? new Vector() : drift.normalize().multiply(0.045);
                devices.add(new Device(Weapon.INK_STORM, in.id, in.team, target, null, g.elapsed + Weapon.STORM_TICKS, drift));
                world.playSound(l, Sound.ENTITY_SNOWBALL_THROW, 1f, 0.5f);
                world.playSound(target, Sound.ITEM_TRIDENT_THUNDER, 0.5f, 1.6f);
            }
            case BOOYAH -> {
                in.booyahAt = g.elapsed + Weapon.BOOYAH_RISE;
                g.floating(p, true);
                p.setVelocity(new Vector(0, 0.55, 0));
                world.playSound(l, Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.4f);
            }
            default -> {}
        }
        g.refreshHotbar(p, in);
    }

    private void trizookaShot(Player p, Inkling in) {
        if (g.elapsed < in.ready[Weapon.TRIZOOKA.ordinal()]) return;
        in.ready[Weapon.TRIZOOKA.ordinal()] = g.elapsed + Weapon.TRIZOOKA.cooldown;
        shoot(p, in, Weapon.TRIZOOKA, 0, 0, 1, Weapon.TRIZOOKA.damage, 1);
        Vector back = p.getLocation().getDirection().multiply(-0.3).setY(0.08);
        p.setVelocity(p.getVelocity().add(back));
        g.world.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1f, 0.8f);
        if (--in.trizookaShots <= 0) endTrizooka(p, in);
    }

    void endTrizooka(Player p, Inkling in) {
        in.trizookaShots = 0;
        g.refreshHotbar(p, in);
    }

    void splashdownTick(Player p, Inkling in) {
        Location l = p.getLocation();
        if (!in.slamming) {
            for (int i = 0; i < 8; i++) {
                double angle = g.elapsed * 0.6 + i * Math.PI / 4;
                g.world.spawnParticle(Particle.DUST, l.clone().add(Math.cos(angle) * 1.2, 0.5, Math.sin(angle) * 1.2), 1, 0, 0, 0, 0, SplatGame.dust(in.team));
            }
            if (g.elapsed >= in.splashdownAt) {
                in.slamming = true;
                p.setVelocity(new Vector(0, -2.2, 0));
            }
        } else if (p.isOnGround() || g.elapsed >= in.splashdownAt + 20) {
            slam(p, in);
        }
    }

    private void slam(Player p, Inkling in) {
        in.splashdownAt = -1;
        in.slamming = false;
        Location at = p.getLocation();
        World world = g.world;
        g.splash(new Pos(at.getBlockX(), (int) Math.floor(at.getY() - 0.05), at.getBlockZ()), in.team, Weapon.SPLASHDOWN_PAINT, in);
        world.spawnParticle(Particle.EXPLOSION, at, 4, 1.5, 0.3, 1.5);
        world.spawnParticle(Particle.DUST, at.clone().add(0, 0.5, 0), 120, 2.5, 0.8, 2.5, 0, SplatGame.dust(in.team));
        world.spawnParticle(Particle.BLOCK, at, 80, 2.5, 0.6, 2.5, 0, g.inkData.get(in.team));
        for (int i = 0; i < 32; i++) {
            double angle = i * Math.PI / 16;
            world.spawnParticle(Particle.DUST, at.clone().add(Math.cos(angle) * Weapon.SPLASHDOWN_OUTER, 0.3, Math.sin(angle) * Weapon.SPLASHDOWN_OUTER),
                    1, 0, 0, 0, 0, SplatGame.dust(in.team));
        }
        world.playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 1.1f);
        world.playSound(at, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1.5f, 0.7f);
        world.playSound(at, Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 0.7f, 1.4f);
        for (Player v : g.online()) {
            if (!g.enemy(in, v)) continue;
            double d = v.getLocation().distance(at);
            if (d < Weapon.SPLASHDOWN_INNER) g.hurt(v, g.players.get(v.getUniqueId()), Weapon.SPLASHDOWN.damage, p, Weapon.SPLASHDOWN);
            else if (d < Weapon.SPLASHDOWN_OUTER) g.hurt(v, g.players.get(v.getUniqueId()), Weapon.SPLASHDOWN_CHIP, p, Weapon.SPLASHDOWN);
        }
        g.objective.blast(at, in.team, Weapon.SPLASHDOWN_OUTER, Weapon.SPLASHDOWN.damage);
    }

    void booyahTick(Player p, Inkling in) {
        Location l = p.getLocation();
        int left = in.booyahAt - g.elapsed;
        if (left > Weapon.BOOYAH_RISE - 8) return;
        if (p.getVelocity().getY() > 0.05) p.setVelocity(p.getVelocity().setY(0));
        double r = 0.6 + (Weapon.BOOYAH_RISE - left) * 0.05;
        for (int i = 0; i < 10; i++) {
            double a = i * Math.PI / 5 + g.elapsed * 0.4;
            g.world.spawnParticle(Particle.DUST, l.clone().add(Math.cos(a) * r, 1, Math.sin(a) * r), 1, 0, 0, 0, 0, SplatGame.dust(in.team));
        }
        if (left % 5 == 0) g.world.playSound(l, Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 0.8f + (Weapon.BOOYAH_RISE - left) * 0.04f);
        if (left <= 0) {
            in.booyahAt = -1;
            g.floating(p, false);
            shoot(p, in, Weapon.BOOYAH, 0, -6, 1, Weapon.BOOYAH.damage, 0);
            g.world.playSound(l, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.6f);
            g.world.playSound(l, Sound.ENTITY_GENERIC_EXPLODE, 0.4f, 1.9f);
        }
    }

    // ------------------------------------------------------------------ charging (Charger and Rainmaker)

    void beginCharge(Player p, Inkling in, Weapon weapon) {
        in.lastClick = g.elapsed;
        if (in.chargeStart >= 0 || g.elapsed < in.ready[weapon.ordinal()]) return;
        if (weapon == Weapon.CHARGER && in.ink < Weapon.CHARGER_MIN_INK) { noInk(p, in, weapon); return; }
        in.chargeStart = g.elapsed;
        in.chargeFull = false;
        in.chargeWeapon = weapon;
        p.playSound(p, Sound.ITEM_CROSSBOW_LOADING_START, 0.7f, weapon == Weapon.RAINMAKER ? 0.7f : 1.3f);
    }

    void cancelCharge(Player p, Inkling in) {
        if (in.chargeStart < 0) return;
        in.chargeStart = -1;
        in.chargeFull = false;
        if (p.hasActiveItem()) p.clearActiveItem();
    }

    double chargeLevel(Inkling in) {
        if (in.chargeStart < 0) return 0;
        int held = g.elapsed - in.chargeStart;
        return in.chargeWeapon == Weapon.RAINMAKER ? Math.min(1, held / (double) Weapon.RAINMAKER_CHARGE) : SplatRules.charge(held, in.ink);
    }

    void chargeTick(Player p, Inkling in) {
        if (g.weaponOf(p.getInventory().getItemInMainHand()) != in.chargeWeapon || in.main() != in.chargeWeapon) { cancelCharge(p, in); return; }
        int held = g.elapsed - in.chargeStart;
        double charge = chargeLevel(in);
        if (held % 3 == 0) {
            if (in.chargeWeapon == Weapon.CHARGER) laser(p, in, charge);
            else g.world.spawnParticle(Particle.DUST, p.getEyeLocation().add(p.getLocation().getDirection()), 4, 0.25, 0.25, 0.25, 0,
                    new Particle.DustOptions(Color.fromRGB(0xFFD23F), (float) (0.6 + charge)));
        }
        if (charge >= 1 && !in.chargeFull) {
            in.chargeFull = true;
            p.playSound(p, Sound.ITEM_CROSSBOW_LOADING_END, 0.9f, 1.2f);
            p.playSound(p, Sound.BLOCK_NOTE_BLOCK_PLING, 0.7f, 2f);
            g.world.spawnParticle(Particle.DUST, p.getEyeLocation(), 8, 0.3, 0.3, 0.3, 0, SplatGame.dust(in.team));
        } else if (charge < 1 && held % 4 == 0) {
            p.playSound(p, Sound.ITEM_CROSSBOW_LOADING_MIDDLE, 0.35f, (float) (0.8 + charge));
        }
        // Java holds the item in use until release; Bedrock and left-click taps count as holding while they keep coming.
        boolean holding = p.hasActiveItem() || g.elapsed - in.lastClick <= Weapon.CHARGE_RELEASE;
        if (!holding || (in.chargeFull && held >= Weapon.CHARGE_TICKS + Weapon.CHARGE_HOLD)) releaseCharge(p, in);
    }

    void releaseCharge(Player p, Inkling in) {
        double charge = chargeLevel(in);
        if (in.chargeWeapon == Weapon.RAINMAKER) shootRainmaker(p, in, charge);
        else shootCharger(p, in, charge);
    }

    /** Team-coloured sight line, visible to everyone like a real charger's laser. */
    private void laser(Player p, Inkling in, double charge) {
        Location eye = p.getEyeLocation();
        Vector direction = eye.getDirection();
        double range = SplatRules.chargerRange(charge);
        RayTraceResult ray = g.world.rayTraceBlocks(eye, direction, range, FluidCollisionMode.NEVER, true);
        double length = ray == null ? range : ray.getHitPosition().distance(eye.toVector());
        Particle.DustOptions dot = new Particle.DustOptions(in.team.color, charge >= 1 ? 0.7f : 0.45f);
        for (double d = 1.5; d < length; d += 2) g.world.spawnParticle(Particle.DUST, eye.clone().add(direction.clone().multiply(d)), 1, 0, 0, 0, 0, dot);
        g.world.spawnParticle(Particle.DUST, eye.clone().add(direction.clone().multiply(length)), 2, 0.05, 0.05, 0.05, 0, SplatGame.dust(in.team));
    }

    private void shootCharger(Player p, Inkling in, double charge) {
        cancelCharge(p, in);
        World world = g.world;
        boolean full = charge >= 1;
        double cost = Math.min(in.ink, SplatRules.chargerInk(charge));
        in.ink -= cost;
        in.lastFire = g.elapsed;
        in.ready[Weapon.CHARGER.ordinal()] = g.elapsed + Weapon.CHARGER.cooldown;
        double range = SplatRules.chargerRange(charge), damage = SplatRules.chargerDamage(charge);
        Location eye = p.getEyeLocation();
        Vector direction = eye.getDirection();
        double padding = (full ? 0.3 : 0.15) + Math.min(0.15, p.getPing() / 1000.0);
        RayTraceResult hit = world.rayTrace(eye, direction, range, FluidCollisionMode.NEVER, true, padding,
                e -> e instanceof Player v && !v.equals(p) && g.enemy(in, v));
        double distance = hit == null ? range : hit.getHitPosition().distance(eye.toVector());
        // Enemy bubbles stop the beam.
        for (Device d : devices) {
            if (d.kind != Weapon.BUBBLER || d.team == in.team) continue;
            double t = d.at.toVector().subtract(eye.toVector()).dot(direction);
            if (t <= 0 || t >= distance) continue;
            Vector closest = eye.toVector().add(direction.clone().multiply(t));
            if (closest.distanceSquared(d.at.toVector()) <= Weapon.BUBBLER_RADIUS * Weapon.BUBBLER_RADIUS) { distance = t; hit = null; }
        }
        Particle.DustOptions beam = new Particle.DustOptions(in.team.color, full ? 1.6f : 1f);
        for (double d = 1; d < distance; d += full ? 0.6 : 1) {
            Location point = eye.clone().add(direction.clone().multiply(d));
            world.spawnParticle(Particle.DUST, point, 1, 0, 0, 0, 0, beam);
            if (d % (full ? 1.2 : 2) > (full ? 0.6 : 1)) continue;
            RayTraceResult below = world.rayTraceBlocks(point, DOWN, 4, FluidCollisionMode.NEVER, true);
            if (below != null && below.getHitBlock() != null) g.paint(SplatGame.pos(below.getHitBlock()), in.team, in);
        }
        Location end = eye.clone().add(direction.clone().multiply(distance));
        world.spawnParticle(Particle.BLOCK, end, full ? 16 : 6, 0.25, 0.25, 0.25, 0, g.inkData.get(in.team));
        if (hit != null && hit.getHitEntity() instanceof Player v) g.hurt(v, g.players.get(v.getUniqueId()), damage, p, Weapon.CHARGER);
        else if (hit != null && hit.getHitBlock() != null) {
            Pos block = SplatGame.pos(hit.getHitBlock());
            if (!g.objective.hitBlock(block, in.team, damage)) g.splash(block, in.team, full ? 1 : 0, in);
        }
        world.playSound(p.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1f, full ? 1.3f : 1.8f);
        if (full) world.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.9f, 1.5f);
    }

    private void shootRainmaker(Player p, Inkling in, double charge) {
        cancelCharge(p, in);
        in.lastFire = g.elapsed;
        in.ready[Weapon.RAINMAKER.ordinal()] = g.elapsed + Weapon.RAINMAKER.cooldown;
        shoot(p, in, Weapon.RAINMAKER, 0, -3, 0.45 + 0.65 * charge, Weapon.RAINMAKER.damage, 1);
        g.world.playSound(p.getLocation(), Sound.ENTITY_BREEZE_SHOOT, 1f, 0.7f);
    }

    // ------------------------------------------------------------------ rolling, brushing and dodging

    void roll(Player p, Inkling in, Vector moved) {
        boolean brush = in.main() == Weapon.INKBRUSH;
        double distance = moved.length(), cost = (brush ? Weapon.BRUSH_INK : Weapon.ROLL_INK) * distance;
        if (in.ink < cost) {
            if (g.elapsed % 20 == 0) noInk(p, in, in.main());
            return;
        }
        in.ink -= cost;
        in.lastFire = g.elapsed;
        Location l = p.getLocation();
        Vector forward = moved.clone().multiply(1 / distance);
        Vector side = new Vector(-forward.getZ(), 0, forward.getX());
        int y = (int) Math.floor(l.getY() - 0.05);
        double[] widths = brush ? new double[]{-0.35, 0.35} : new double[]{-1.2, -0.6, 0, 0.6, 1.2};
        for (double s : widths) {
            for (double f : new double[]{0, 0.7}) {
                g.paint(new Pos((int) Math.floor(l.getX() + forward.getX() * f + side.getX() * s), y,
                        (int) Math.floor(l.getZ() + forward.getZ() * f + side.getZ() * s)), in.team, in);
            }
        }
        Location front = l.clone().add(forward.clone().multiply(0.9));
        if (g.elapsed % 2 == 0) g.world.spawnParticle(Particle.BLOCK, front.clone().add(0, 0.15, 0), brush ? 2 : 3, brush ? 0.2 : 0.6, 0.05, brush ? 0.2 : 0.6, 0, g.inkData.get(in.team));
        if (g.elapsed % 5 == 0) {
            if (brush) g.world.playSound(l, Sound.ITEM_BRUSH_BRUSHING_GENERIC, 0.4f, 1.6f);
            else g.world.playSound(l, Sound.BLOCK_HONEY_BLOCK_SLIDE, 0.45f, 1.4f);
        }
        if (brush || distance < Weapon.FLATTEN_SPEED) return;
        for (Player v : g.online()) {
            if (!g.enemy(in, v)) continue;
            Location vl = v.getLocation();
            double dx = vl.getX() - front.getX(), dz = vl.getZ() - front.getZ();
            if (dx * dx + dz * dz < 1.2 && Math.abs(vl.getY() - l.getY()) < 1.2)
                g.hurt(v, g.players.get(v.getUniqueId()), Weapon.ROLL_DAMAGE, p, Weapon.ROLLER);
        }
    }

    void dodge(Player p, Inkling in) {
        if (in.main() != Weapon.DUALIES || !p.isOnGround()) return;
        int now = g.elapsed;
        if (now > in.rollReadyAt + 30) in.rolls = 0;
        if (now < in.rollReadyAt) return;
        if (in.ink < Weapon.DODGE_INK) { noInk(p, in, Weapon.DUALIES); return; }
        Vector direction = in.lastMove.clone().setY(0);
        if (direction.lengthSquared() < 0.002) direction = p.getLocation().getDirection().setY(0);
        if (direction.lengthSquared() < 1e-4) return;
        direction.normalize();
        in.ink -= Weapon.DODGE_INK;
        in.lastFire = now;
        p.setVelocity(direction.multiply(Weapon.DODGE_SPEED).setY(0.16));
        if (++in.rolls >= Weapon.DODGE_ROLLS) { in.rolls = 0; in.rollReadyAt = now + Weapon.DODGE_COOLDOWN; }
        else in.rollReadyAt = now + 7;
        in.turretUntil = now + 7 + Weapon.DODGE_TURRET;
        Location l = p.getLocation();
        g.splash(new Pos(l.getBlockX(), (int) Math.floor(l.getY() - 0.05), l.getBlockZ()), in.team, 1, in);
        g.world.spawnParticle(Particle.BLOCK, l.clone().add(0, 0.2, 0), 14, 0.4, 0.1, 0.4, 0, g.inkData.get(in.team));
        g.world.playSound(l, Sound.ENTITY_PLAYER_SPLASH, 0.6f, 1.7f);
        g.world.playSound(l, Sound.ITEM_ARMOR_EQUIP_LEATHER, 0.5f, 1.5f);
    }
}
