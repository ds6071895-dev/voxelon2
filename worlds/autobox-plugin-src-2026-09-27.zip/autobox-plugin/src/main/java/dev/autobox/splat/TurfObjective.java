package dev.autobox.splat;

import dev.autobox.splat.SplatRules.Team;

import java.util.List;

/** Turf War: the team covering the most turf at the buzzer wins. */
final class TurfObjective implements Objective {
    private final SplatGame g;

    TurfObjective(SplatGame g) { this.g = g; }

    private int total() { return g.map.blueprint().turf().size(); }

    @Override
    public double count(Team team) { return SplatRules.percent(g.turf.get(team), total()); }

    @Override
    public Team knockout() { return null; }

    @Override
    public Team winner() { return SplatRules.winner(g.turf.get(Team.ORANGE), g.turf.get(Team.BLUE)); }

    @Override
    public void sidebar(List<String> lines) {
        int total = total(), orange = g.turf.get(Team.ORANGE), blue = g.turf.get(Team.BLUE);
        lines.add("§6■ Orange §f" + SplatRules.format(SplatRules.percent(orange, total)));
        lines.add("§9■ Blue §f" + SplatRules.format(SplatRules.percent(blue, total)));
        lines.add("§7□ Unpainted §f" + SplatRules.format(SplatRules.percent(total - orange - blue, total)));
    }
}
