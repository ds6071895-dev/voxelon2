package dev.autobox.splat;

import dev.autobox.AutoBoxPlugin;
import dev.autobox.lobby.GameType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Stream;

/** Player commands (music, ranks, leaderboards, locker, menu, super jump) and operator testing. */
public final class SplatCommand implements CommandExecutor, TabCompleter {
    private static final List<String> PLAYER = List.of("music", "rank", "top", "locker", "menu", "jump", "again");
    private final AutoBoxPlugin plugin;
    private final SplatGame game;

    public SplatCommand(AutoBoxPlugin plugin, SplatGame game) { this.plugin = plugin; this.game = game; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "music" -> {
                if (!(sender instanceof Player p)) sender.sendMessage(SplatGame.text("Only players can toggle their music."));
                else sender.sendMessage(SplatGame.text(game.toggleMusic(p) ? "♪ Splatoon music on." : "Splatoon music off. /splat music turns it back on."));
                return true;
            }
            case "rank", "stats" -> { rank(sender, args.length > 1 ? args[1] : null); return true; }
            case "top" -> { top(sender, args.length > 1 ? args[1] : "level"); return true; }
            case "locker", "kit" -> {
                if (sender instanceof Player p) game.openLocker(p);
                return true;
            }
            case "menu" -> {
                if (sender instanceof Player p) game.openHostMenu(p);
                return true;
            }
            case "jump" -> {
                if (sender instanceof Player p) game.openJump(p);
                return true;
            }
            case "again" -> {
                if (sender instanceof Player p) game.playAgain(p);
                return true;
            }
            case "test" -> { if (test(sender, args)) return true; }
            default -> {}
        }
        sender.sendMessage(SplatGame.text("/splat music · rank [player] · top [level|turf|zones|tower|rainmaker|clams] · locker · menu · jump · again"));
        if (sender.hasPermission("splat.test"))
            sender.sendMessage(SplatGame.text("/splat test start|solo [mode] [map#] · skip · stop"));
        return true;
    }

    private boolean test(CommandSender sender, String[] args) {
        if (!sender.hasPermission("splat.test")) { sender.sendMessage(SplatGame.text("Only operators can run Splatoon tests.")); return true; }
        if (args.length < 2) return false;
        SplatMode mode = args.length > 2 ? SplatMode.byKey(args[2]) : null;
        Integer map = null;
        if (args.length > 3) {
            try { map = Math.max(0, Math.min(SplatArena.MAPS.size() - 1, Integer.parseInt(args[3]) - 1)); } catch (NumberFormatException ignored) {}
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "start" -> game.testStart(sender, plugin.getLobbyManager().queuedPlayers(GameType.SPLAT), false, mode, map);
            case "solo" -> {
                if (!(sender instanceof Player p)) sender.sendMessage(SplatGame.text("Solo testing requires a player in the lobby."));
                else if (!p.getWorld().equals(plugin.getLobbySpawn().getWorld())) sender.sendMessage(SplatGame.text("Return to the lobby before solo testing."));
                else game.testStart(sender, List.of(p), true, mode, map);
            }
            case "skip" -> game.skip();
            case "stop" -> game.stop();
            default -> { return false; }
        }
        return true;
    }

    private void rank(CommandSender sender, String name) {
        UUID id;
        SplatStats.Record record;
        if (name == null) {
            if (!(sender instanceof Player p)) { sender.sendMessage(SplatGame.text("Usage: /splat rank <player>")); return; }
            id = p.getUniqueId();
            record = game.stats().get(id, p.getName());
        } else {
            Map.Entry<UUID, SplatStats.Record> found = game.stats().findByName(name);
            if (found == null) { sender.sendMessage(SplatGame.text(name + " hasn't played Splatoon yet.")); return; }
            id = found.getKey();
            record = found.getValue();
        }
        long into = SplatRating.xpIntoLevel(record.xp), need = SplatRating.xpToNext(record.level());
        sender.sendMessage(Component.text("━━━ " + record.name + " · Splatoon ━━━", NamedTextColor.GOLD, TextDecoration.BOLD));
        sender.sendMessage(Component.text(" Level " + record.level(), NamedTextColor.AQUA, TextDecoration.BOLD)
                .append(Component.text("  " + into + "/" + need + " XP  ·  kit: " + record.kit.main.title, NamedTextColor.GRAY)));
        for (SplatMode mode : SplatMode.values()) {
            SplatStats.ModeStats m = record.modes.get(mode);
            if (m == null || m.matches == 0) {
                sender.sendMessage(Component.text(" " + mode.title + ": ", mode.color).append(Component.text("not played yet", NamedTextColor.DARK_GRAY)));
                continue;
            }
            SplatRating.Rank rank = SplatRating.rank(m.rating);
            double kd = m.deaths == 0 ? m.splats : m.splats / (double) m.deaths;
            sender.sendMessage(Component.text(" " + mode.title + ": ", mode.color)
                    .append(Component.text(SplatRating.label(m.rating, m.matches) + " " + m.rating, rank.color, TextDecoration.BOLD))
                    .append(Component.text("  " + m.wins + "W " + m.losses + "L  ·  " + m.splats + " splats (" + String.format(Locale.ROOT, "%.2f", kd)
                            + " K/D)  ·  " + m.turf + " turf", NamedTextColor.GRAY)));
        }
    }

    private void top(CommandSender sender, String which) {
        SplatMode mode = which.equalsIgnoreCase("level") ? null : SplatMode.byKey(which);
        if (mode == null && !which.equalsIgnoreCase("level")) { sender.sendMessage(SplatGame.text("Try /splat top level|turf|zones|tower|rainmaker|clams")); return; }
        List<SplatStats.Entry> top = game.stats().top(mode, 10);
        sender.sendMessage(Component.text("━━━ Top 10 · " + (mode == null ? "Level" : mode.title) + " ━━━", NamedTextColor.GOLD, TextDecoration.BOLD));
        if (top.isEmpty()) sender.sendMessage(Component.text(" Nobody yet — go play!", NamedTextColor.GRAY));
        for (int i = 0; i < top.size(); i++) {
            SplatStats.Record r = top.get(i).record();
            Component line = Component.text(" #" + (i + 1) + " ", i < 3 ? NamedTextColor.YELLOW : NamedTextColor.GRAY).append(Component.text(r.name, NamedTextColor.WHITE));
            if (mode == null) line = line.append(Component.text("  Lv " + r.level() + "  (" + r.totalMatches() + " matches)", NamedTextColor.AQUA));
            else {
                SplatStats.ModeStats m = r.mode(mode);
                line = line.append(Component.text("  " + SplatRating.label(m.rating, m.matches) + " " + m.rating, SplatRating.rank(m.rating).color, TextDecoration.BOLD))
                        .append(Component.text("  " + m.wins + "-" + m.losses, NamedTextColor.GRAY));
            }
            sender.sendMessage(line);
        }
        if (sender instanceof Player player) SplatWebLink.sendLink(player);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        boolean op = sender.hasPermission("splat.test");
        List<String> modes = Arrays.stream(SplatMode.values()).map(m -> m.key).toList();
        List<String> options;
        if (args.length == 1) options = op ? Stream.concat(PLAYER.stream(), Stream.of("test")).toList() : PLAYER;
        else if (args.length == 2 && args[0].equalsIgnoreCase("top")) options = Stream.concat(Stream.of("level"), modes.stream()).toList();
        else if (args.length == 2 && args[0].equalsIgnoreCase("rank")) options = org.bukkit.Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        else if (args.length == 2 && op && args[0].equalsIgnoreCase("test")) options = List.of("start", "solo", "skip", "stop");
        else if (args.length == 3 && op && args[0].equalsIgnoreCase("test")) options = modes;
        else if (args.length == 4 && op && args[0].equalsIgnoreCase("test")) options = List.of("1", "2");
        else options = List.of();
        String prefix = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        return options.stream().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(prefix)).toList();
    }
}
