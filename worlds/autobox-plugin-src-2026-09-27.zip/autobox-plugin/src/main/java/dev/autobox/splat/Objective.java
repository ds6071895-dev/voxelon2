package dev.autobox.splat;

import dev.autobox.splat.SplatArena.Pos;
import dev.autobox.splat.SplatRules.Team;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.List;

/** Mode rules plugged into SplatGame. Turf War is an objective too, so the match loop has one code path. */
interface Objective {
    default void start() {}

    /** Every PLAY tick, after players, shots and bombs. */
    default void tick() {}

    /** A paintable block changed from 'before' (maybe null) to 'after'. */
    default void onPaint(Pos pos, Team before, Team after) {}

    /** Called before the victim's inventory is cleared. */
    default void onSplat(Player victim, Inkling in, Location at) {}

    /** Ink from a team touched a block; return true to absorb it (no paint). */
    default boolean hitBlock(Pos pos, Team team, double damage) { return false; }

    /** An explosion from a team went off. */
    default void blast(Location at, Team team, double radius, double damage) {}

    /** Every tick for thrown objective projectiles (clams); return true once it has been used up. */
    default boolean flying(Entity ball, SplatWeapons.Shot shot) { return false; }

    /** A thrown objective projectile hit the ground. */
    default void landed(Location at, SplatWeapons.Shot shot) {}

    /** Click with a clam in hand. */
    default void throwClam(Player p, Inkling in) {}

    default boolean allowSquid(Inkling in) { return true; }

    default boolean allowSuperJump(Inkling in) { return true; }

    /** Turf War: percentage painted. Ranked: the count down from 100. */
    double count(Team team);

    /** Ranked count penalty still owed, for the HUD. */
    default double penalty(Team team) { return 0; }

    /** The team that just knocked out the other, if any. */
    default Team knockout() { return RankedRules.knockout(count(Team.ORANGE), count(Team.BLUE)); }

    /** The team holding the objective (overtime), or null. */
    default Team advantage() { return null; }

    Team winner();

    /** Extra sidebar lines describing the objective. */
    default void sidebar(List<String> lines) {}

    /** Short action-bar hint for one player, or null. */
    default String hint(Inkling in) { return null; }

    default void cleanup() {}
}
