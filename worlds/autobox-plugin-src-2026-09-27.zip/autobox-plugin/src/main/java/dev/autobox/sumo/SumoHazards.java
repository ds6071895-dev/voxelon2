package dev.autobox.sumo;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Map-specific moving parts: the Sweeper's arms, Hex Layers' crumbling tiles and Bounce House pads. */
final class SumoHazards {
    private static final float ARM_HEIGHT = 0.7f;
    private static final float ARM_WIDTH = 0.6f;
    private static final int ARM_UPDATE_TICKS = 2;

    private final BlockSumoGame game;
    private final List<BlockDisplay> arms = new ArrayList<>();
    private final Map<Location, Integer> crumbling = new HashMap<>();
    private final Set<Location> hexTiles = new HashSet<>();
    /** Marathon only: crumbled tiles grow back, or a twelve-minute match would run out of floor. */
    private final Map<Location, Integer> regrowAt = new HashMap<>();
    private final Map<Location, Material> hexOriginal = new HashMap<>();
    private final Map<UUID, Integer> padReady = new HashMap<>();
    private final Map<UUID, Integer> sweptAt = new HashMap<>();
    private double armAngle;

    SumoHazards(BlockSumoGame game) {
        this.game = game;
    }

    /** Called once the arena for a round is fully built. */
    void begin(SumoArena arena) {
        clear();
        World world = game.world();
        if (arena.kind() == SumoArena.Kind.HEX) {
            for (SumoArena.Block block : arena.blocks()) {
                Location tile = new Location(world, block.x(), block.y(), block.z());
                hexTiles.add(tile);
                hexOriginal.put(tile, block.material());
            }
        }
        if (arena.kind() == SumoArena.Kind.SWEEPER) {
            armAngle = game.random().nextDouble() * Math.PI * 2;
            for (int i = 0; i < 2; i++) {
                arms.add(world.spawn(pivot(), BlockDisplay.class, arm -> {
                    arm.setBlock(Material.RED_CONCRETE.createBlockData());
                    arm.setGlowing(true);
                    arm.setGlowColorOverride(Color.fromRGB(255, 60, 40));
                    arm.setBrightness(new Display.Brightness(15, 15));
                    arm.setPersistent(false);
                    arm.addScoreboardTag(BlockSumoGame.FX_TAG);
                }));
            }
            updateArms(0);
        }
    }

    void clear() {
        arms.forEach(BlockDisplay::remove);
        arms.clear();
        crumbling.clear();
        hexTiles.clear();
        regrowAt.clear();
        hexOriginal.clear();
        padReady.clear();
        sweptAt.clear();
    }

    void tick() {
        SumoArena.Kind kind = game.arena().kind();
        if (game.roundTicks() < 0) return;
        switch (kind) {
            case SWEEPER -> tickSweeper();
            case HEX -> {
                tickHex();
                if (game.ticks() % 5 == 0) regrowHex(game.ticks());
            }
            case BOUNCE -> tickPads();
            default -> { }
        }
    }

    private Location pivot() {
        return new Location(game.world(), 0.5, SumoArenas.SWEEPER_PLATE_Y + 1.02, 0.5);
    }

    private double armLength() {
        return Math.max(0.8, game.arenaRadius() - 0.4 - SumoArenas.SWEEPER_ARM_START);
    }

    private void tickSweeper() {
        armAngle += Math.toRadians(SumoRules.sweeperSpeed(game.mode(), game.roundTicks()));
        if (game.ticks() % ARM_UPDATE_TICKS == 0) updateArms(ARM_UPDATE_TICKS);
        double length = armLength();
        double feetMin = SumoArenas.SWEEPER_PLATE_Y + 0.5;
        double feetMax = SumoArenas.SWEEPER_PLATE_Y + 1 + ARM_HEIGHT;
        Location pivot = pivot();
        int ticks = game.ticks();
        game.forEachPlayer(player -> {
            Location feet = player.getLocation();
            if (feet.getY() < feetMin || feet.getY() > feetMax) return;
            double px = feet.getX() - pivot.getX();
            double pz = feet.getZ() - pivot.getZ();
            double halfWidth = player.getBoundingBox().getWidthX() / 2;
            for (int i = 0; i < 2; i++) {
                double angle = armAngle + i * Math.PI;
                // Matches JOML's rotateY: the arm points along (cos, 0, -sin).
                double dx = Math.cos(angle);
                double dz = -Math.sin(angle);
                double along = px * dx + pz * dz;
                double across = Math.abs(px * -dz + pz * dx);
                if (along < SumoArenas.SWEEPER_ARM_START - halfWidth
                        || along > SumoArenas.SWEEPER_ARM_START + length + halfWidth
                        || across > ARM_WIDTH / 2 + halfWidth + 0.15) continue;
                if (sweptAt.getOrDefault(player.getUniqueId(), -100) > ticks - 10) return;
                // Rotation direction (increasing angle) plus a little outward shove.
                Vector tangent = new Vector(-Math.sin(angle), 0, -Math.cos(angle));
                Vector push = tangent.multiply(1.25).add(new Vector(dx, 0, dz).multiply(0.35)).setY(0.5);
                if (game.knock(player, push, null)) {
                    sweptAt.put(player.getUniqueId(), ticks);
                    game.world().playSound(feet, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.7f);
                    Particle.SWEEP_ATTACK.builder().location(feet.clone().add(0, 0.6, 0)).count(1)
                            .receivers(48, true).spawn();
                }
                return;
            }
        });
    }

    private void updateArms(int interpolation) {
        float length = (float) armLength();
        for (int i = 0; i < arms.size(); i++) {
            BlockDisplay arm = arms.get(i);
            if (!arm.isValid()) continue;
            float angle = (float) (armAngle + i * Math.PI);
            Quaternionf rotation = new Quaternionf().rotateY(angle);
            Vector3f offset = rotation.transform(new Vector3f((float) SumoArenas.SWEEPER_ARM_START, 0, -ARM_WIDTH / 2));
            arm.setInterpolationDelay(0);
            arm.setInterpolationDuration(interpolation);
            arm.setTransformation(new Transformation(offset, rotation,
                    new Vector3f(length, ARM_HEIGHT, ARM_WIDTH), new Quaternionf()));
        }
    }

    private void tickHex() {
        int ticks = game.ticks();
        game.forEachPlayer(player -> {
            if (!player.isOnGround()) return;
            BoundingBox box = player.getBoundingBox();
            int y = (int) Math.floor(box.getMinY() - 0.05);
            for (double x : new double[]{box.getMinX() + 0.01, box.getMaxX() - 0.01}) {
                for (double z : new double[]{box.getMinZ() + 0.01, box.getMaxZ() - 0.01}) {
                    Location tile = new Location(game.world(), Math.floor(x), y, Math.floor(z));
                    if (hexTiles.contains(tile) && !crumbling.containsKey(tile)) {
                        crumbling.put(tile, ticks + SumoRules.HEX_CRUMBLE_TICKS);
                    }
                }
            }
        });
        for (Iterator<Map.Entry<Location, Integer>> iterator = crumbling.entrySet().iterator(); iterator.hasNext(); ) {
            Map.Entry<Location, Integer> entry = iterator.next();
            Block block = entry.getKey().getBlock();
            int left = entry.getValue() - ticks;
            Location center = entry.getKey().clone().add(0.5, 0.9, 0.5);
            if (left > 0) {
                if (left % 4 == 0 && !block.getType().isAir()) {
                    Particle.BLOCK.builder().location(center).count(2).offset(0.3, 0.05, 0.3)
                            .data(block.getBlockData()).receivers(32, true).spawn();
                }
                continue;
            }
            iterator.remove();
            hexTiles.remove(entry.getKey());
            if (game.mode() == SumoRules.Mode.MARATHON) regrowAt.put(entry.getKey(), ticks + SumoRules.HEX_REGROW_TICKS);
            if (block.getType().isAir()) continue;
            Particle.BLOCK.builder().location(center).count(6).offset(0.3, 0.1, 0.3)
                    .data(block.getBlockData()).receivers(32, true).spawn();
            if (game.random().nextInt(3) == 0) game.world().playSound(center, Sound.BLOCK_GLASS_BREAK, 0.4f, 1.4f);
            game.removeArenaBlock(entry.getKey());
        }
    }

    private void regrowHex(int ticks) {
        List<Location> blocked = new ArrayList<>();
        for (Iterator<Map.Entry<Location, Integer>> iterator = regrowAt.entrySet().iterator(); iterator.hasNext(); ) {
            Map.Entry<Location, Integer> entry = iterator.next();
            if (entry.getValue() > ticks) continue;
            iterator.remove();
            Location tile = entry.getKey();
            Block block = tile.getBlock();
            // Collapsed rings stay gone, and a tile never grows back into a player.
            if (!block.getType().isAir() || Math.hypot(tile.getBlockX(), tile.getBlockZ()) > game.arenaRadius() + 0.4) continue;
            BoundingBox cell = BoundingBox.of(block);
            if (game.alivePlayers().stream().anyMatch(player -> player.getBoundingBox().overlaps(cell))) {
                blocked.add(tile);
                continue;
            }
            block.setType(hexOriginal.getOrDefault(tile, Material.GLASS), false);
            game.arenaBlocks().add(tile);
            hexTiles.add(tile);
            Particle.WAX_ON.builder().location(tile.clone().add(0.5, 1.0, 0.5)).count(3).offset(0.3, 0.05, 0.3)
                    .receivers(32, true).spawn();
        }
        blocked.forEach(tile -> regrowAt.put(tile, ticks + 20));
    }

    private void tickPads() {
        int ticks = game.ticks();
        game.forEachPlayer(player -> {
            if (!player.isOnGround() || padReady.getOrDefault(player.getUniqueId(), 0) > ticks) return;
            Location feet = player.getLocation();
            Block below = feet.clone().subtract(0, 0.2, 0).getBlock();
            if (below.getType() != Material.SLIME_BLOCK || !game.isArenaBlock(below.getLocation())) return;
            int[] target = SumoArenas.BOUNCE_TARGET;
            double[] launch = SumoRules.padLaunch(target[0] + 0.5 - feet.getX(), target[1] - feet.getY(),
                    target[2] + 0.5 - feet.getZ());
            // Pads work through shields: they are transport, not an attack.
            player.setVelocity(new Vector(launch[0], launch[1], launch[2]));
            player.setFallDistance(0);
            padReady.put(player.getUniqueId(), ticks + 20);
            game.world().playSound(feet, Sound.BLOCK_SLIME_BLOCK_FALL, 1f, 0.6f);
            game.world().playSound(feet, Sound.ENTITY_BREEZE_JUMP, 0.8f, 1.2f);
            Particle.ITEM_SLIME.builder().location(feet).count(16).offset(0.4, 0.1, 0.4)
                    .receivers(48, true).spawn();
        });
    }
}
