package dev.autobox.zombie;

import dev.autobox.util.AsyncFiles;
import dev.autobox.util.Sidebar;
import dev.autobox.AutoBoxPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.*;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.*;
import org.bukkit.scheduler.*;
import org.bukkit.scoreboard.*;
import org.bukkit.util.Vector;

import java.io.File;
import java.util.*;

public final class ZombieApocalypseGame implements Listener {
    public static final String WORLD_NAME = "zombie_apocalypse_city";
    private enum Phase { IDLE, BREAK, FIGHT, RESULTS }
    private enum Mutation { HORDE, RUNNERS, ARMORED, ARCHERS, SWARM }
    private static final String[] BOSSES = {"The Gatebreaker", "Broodmother", "The Frost Warden",
            "Gravecaller", "The Plague Doctor", "The Apocalypse King"};
    private static final EntityType[] BOSS_TYPES = {EntityType.HUSK,EntityType.SPIDER,EntityType.STRAY,
            EntityType.WITHER_SKELETON,EntityType.HUSK,EntityType.ZOMBIE};
    private static final String[] UPGRADES = {"Sword", "Bow", "Armour", "Vitality"};
    private static final Material[] ICONS = {Material.IRON_SWORD,Material.BOW,Material.IRON_CHESTPLATE,Material.GOLDEN_APPLE};
    private static final class Survivor {
        int credits=40, kills, healsAt, dashAt;
        int[] tiers = new int[4];
        boolean down;
        final double originalMax, originalSpeed;
        Survivor(Player p) { originalMax=p.getAttribute(Attribute.MAX_HEALTH).getBaseValue();
            originalSpeed=p.getAttribute(Attribute.ATTACK_SPEED).getBaseValue(); }
    }
    private static final class Shop implements InventoryHolder {
        final UUID owner; final Inventory inventory;
        Shop(UUID owner) { this.owner=owner; inventory=Bukkit.createInventory(this,9,Component.text("Survivor Upgrades")); }
        public Inventory getInventory() { return inventory; }
    }
    private record Hazard(Location location, double radius, int due, int kind) {}
    private final AutoBoxPlugin plugin;
    private final World world;
    private final NamespacedKey itemKey;
    private final Random random = new Random();
    private final Map<UUID,Survivor> players = new LinkedHashMap<>();
    private final Map<UUID,Sidebar> sidebars = new HashMap<>();
    private static final Particle.DustOptions HAZARD_DUST = new Particle.DustOptions(Color.RED,1.3f);
    private final Map<UUID,Mob> enemies = new LinkedHashMap<>();
    private final List<Hazard> hazards = new ArrayList<>();
    private final File recordsFile;
    private final YamlConfiguration records;
    private final BossBar waveBar = Bukkit.createBossBar("Zombie Apocalypse",BarColor.GREEN,BarStyle.SEGMENTED_10);
    private final BossBar bossBar = Bukkit.createBossBar("Boss",BarColor.RED,BarStyle.SOLID);
    private BukkitTask builder, ticker;
    private boolean ready;
    private Phase phase = Phase.IDLE;
    private Mutation mutation;
    private int wave, remaining, elapsed, seconds, budget, spawned, partySize, cleared;
    private Mob boss;
    private boolean enraged;

    public ZombieApocalypseGame(AutoBoxPlugin plugin, World world) {
        this.plugin=plugin; this.world=world; itemKey=new NamespacedKey(plugin,"zombie_item");
        recordsFile=new File(plugin.getDataFolder(),"zombie-records.yml");
        records=YamlConfiguration.loadConfiguration(recordsFile);
        // This dedicated arena never contains persistent gameplay entities.
        for(Entity e:world.getEntities()) if(!(e instanceof Player)) e.remove();
        ZombieCity city=new ZombieCity();
        var blocks=city.blocks().entrySet().iterator();
        builder=new BukkitRunnable() {
            public void run() {
                for(int i=0;i<1200 && blocks.hasNext();i++) {
                    var e=blocks.next(); var p=e.getKey(); world.getBlockAt(p.x(),p.y(),p.z()).setType(e.getValue(),false);
                }
                if(!blocks.hasNext()) { ready=true; cancel(); plugin.getLogger().info("Zombie Apocalypse: Quarantine City ready."); }
            }
        }.runTaskTimer(plugin,1,1);
        world.setSpawnLocation(new Location(world,0.5,81,0.5));
        ticker=Bukkit.getScheduler().runTaskTimer(plugin,this::tick,20,20);
    }
    public boolean isWorld(World w) { return world.equals(w); }
    public boolean isWorld(Player p) { return isWorld(p.getWorld()); }
    public boolean isRunning() { return phase!=Phase.IDLE; }
    public boolean isPlaying(Player p) { return isRunning() && players.containsKey(p.getUniqueId()); }
    public Location getSpectateLocation() { return new Location(world,0.5,91,0.5); }
    private Location spawn() { return new Location(world,random.nextInt(7)-3+0.5,81,random.nextInt(5)-1+0.5); }
    private List<Player> roster() { return players.keySet().stream().map(Bukkit::getPlayer).filter(Objects::nonNull).filter(Player::isOnline).toList(); }
    private List<Player> alive() { return roster().stream().filter(p->isWorld(p)&&!players.get(p.getUniqueId()).down).toList(); }
    public void start(CommandSender sender,List<Player> party) {
        if(isRunning()) { sender.sendMessage("Zombie Apocalypse is already running."); return; }
        List<Player> online=party.stream().filter(Player::isOnline).distinct().toList();
        if(!ZombieRules.validParty(online.size())) { sender.sendMessage("Zombie Apocalypse needs 2–6 players."); return; }
        if(!ready) { sender.sendMessage("Quarantine City is being built. Click again in a moment; your queue is saved."); return; }
        cleanEnemies(); players.clear(); wave=0; cleared=0; seconds=0; partySize=online.size();
        phase=Phase.BREAK; remaining=15;
        for(Player p:online) {
            players.put(p.getUniqueId(),new Survivor(p)); p.closeInventory(); clearEffects(p);
            p.setGameMode(GameMode.ADVENTURE); p.teleport(spawn()); p.getInventory().clear();
            p.getAttribute(Attribute.ATTACK_SPEED).setBaseValue(4); equip(p); heal(p); waveBar.addPlayer(p);
            p.sendTitle("§2§lZOMBIE APOCALYPSE","§f30 waves · Stay together. Survive.",10,70,10);
            p.sendMessage(Component.text("Swords + bows • No friendly fire • Slot 7: medkit • Slot 8: dodge • Slot 9: upgrades",NamedTextColor.GREEN));
            p.sendMessage(Component.text("Survive each wave. Defeat every boss before its timer ends. Fallen teammates return between waves.",NamedTextColor.YELLOW));
            p.sendMessage(Component.text("Best wave: "+records.getInt(p.getUniqueId()+".best")+" | Victories: "+records.getInt(p.getUniqueId()+".wins"),NamedTextColor.AQUA));
        }
        updateHud();
    }
    private void tick() {
        if(!isRunning()) return;
        seconds++;
        for(Player p:roster()) if(!isWorld(p)) handleQuit(p);
        if(!isRunning()) return;
        if(phase==Phase.RESULTS) { if(--remaining<=0) reset(); return; }
        if(players.isEmpty() || alive().isEmpty()) { finish(false,"The team was overwhelmed."); return; }
        if(phase==Phase.BREAK) { if(--remaining<=0) beginWave(); updateHud(); return; }
        elapsed++;
        List<Player> living=alive();
        for(Player p:living) {
            p.setFoodLevel(20); p.setSaturation(0);
            if(p.getLocation().getY()<80 || Math.abs(p.getLocation().getX())>39 || Math.abs(p.getLocation().getZ())>39) p.teleport(spawn());
            if(seconds%5==0) p.getInventory().setItem(9,new ItemStack(Material.ARROW,64));
        }
        enemies.values().removeIf(e->!e.isValid() || e.isDead());
        // Retarget towards living teammates; spectators and downed players never draw aggro.
        for(Mob mob:enemies.values()) {
            Player target=living.stream().min(Comparator.comparingDouble(p->p.getLocation().distanceSquared(mob.getLocation()))).orElse(null);
            mob.setTarget(target);
            if(mob.getLocation().getY()<79) mob.teleport(gate());
            if(target!=null && seconds%12==0 && mob.getLocation().distanceSquared(target.getLocation())>900) mob.teleport(gate());
        }
        if(elapsed<=40 && spawned<budget) {
            int batch=Math.min(5,Math.max(1,(budget+19)/20));
            if(elapsed%2==0) for(int i=0;i<batch && spawned<budget && enemies.size()<ZombieRules.MOB_CAP;i++) { spawnEnemy(false); spawned++; }
        }
        if(boss!=null && boss.isValid() && !boss.isDead()) {
            double ratio=boss.getHealth()/boss.getAttribute(Attribute.MAX_HEALTH).getValue();
            bossBar.setProgress(Math.clamp(ratio,0,1));
            if(ratio<0.4 && !enraged) { enraged=true; announce("§cBOSS ENRAGED! Attacks speed up!"); }
            if(elapsed%(enraged?5:8)==0) bossAttack();
        }
        resolveHazards();
        switch(ZombieRules.outcome(wave,elapsed,boss!=null && boss.isValid() && !boss.isDead(),alive().size())) {
            case DEFEAT -> finish(false,alive().isEmpty()?"The team was overwhelmed.":"The boss overran the city.");
            case CLEAR -> clearWave();
            case VICTORY -> { cleared=wave; finish(true,"All 30 waves survived. The city is saved!"); }
            default -> { }
        }
        updateHud();
    }
    private void beginWave() {
        wave++; phase=Phase.FIGHT; elapsed=0; spawned=0; enraged=false;
        partySize=Math.max(2,players.size()); budget=ZombieRules.enemies(wave,partySize);
        mutation=Mutation.values()[random.nextInt(Mutation.values().length)];
        if(mutation==Mutation.HORDE) budget=budget*5/4;
        for(Player p:roster()) { p.closeInventory(); p.sendTitle("§aWAVE "+wave+" / 30",ZombieRules.bossWave(wave)?"§cBOSS: "+BOSSES[wave/5-1]:"§f"+mutation.name().replace('_',' '),5,40,5); }
        if(ZombieRules.bossWave(wave)) {
            boss=spawnMob(BOSS_TYPES[wave/5-1],gate(),ZombieRules.bossHealth(wave,partySize),4+wave*0.12);
            boss.customName(Component.text(BOSSES[wave/5-1],NamedTextColor.RED)); boss.setCustomNameVisible(true);
            boss.setGlowing(true); boss.getAttribute(Attribute.KNOCKBACK_RESISTANCE).setBaseValue(0.8);
            if(boss.getAttribute(Attribute.SCALE)!=null) boss.getAttribute(Attribute.SCALE).setBaseValue(wave==30?1.8:1.4);
            bossBar.setTitle(BOSSES[wave/5-1]); bossBar.setProgress(1); roster().forEach(bossBar::addPlayer);
            announce("§cDefeat the boss! 50 seconds + up to 40 seconds of overtime.");
            world.playSound(spawn(),Sound.ENTITY_WITHER_SPAWN,1,0.7f);
        }
    }
    private void clearWave() {
        cleared=wave;
        boolean cleanSweep=enemies.isEmpty();
        int reward=ZombieRules.reward(wave)+(cleanSweep?15:0);
        cleanEnemies(); phase=Phase.BREAK; remaining=ZombieRules.BREAK_SECONDS;
        for(Player p:roster()) {
            Survivor s=players.get(p.getUniqueId()); s.credits+=reward; s.down=false;
            clearEffects(p); p.setGameMode(GameMode.ADVENTURE); p.teleport(spawn()); equip(p); heal(p);
            p.sendTitle("§aWAVE COMPLETE","§e+"+reward+" scrap · Upgrade! Next wave in 10s",5,45,5);
            p.playSound(p.getLocation(),Sound.ENTITY_PLAYER_LEVELUP,0.7f,1.4f);
        }
    }
    private Location gate() {
        List<ZombieCity.Pos> choices=new ArrayList<>(ZombieCity.GATES); Collections.shuffle(choices,random);
        var living=alive();
        for(var p:choices) {
            Location at=new Location(world,p.x()+0.5,p.y(),p.z()+0.5);
            if(living.stream().noneMatch(a->a.getLocation().distanceSquared(at)<64)) return at;
        }
        var p=choices.getFirst(); return new Location(world,p.x()+0.5,p.y(),p.z()+0.5);
    }
    private void spawnEnemy(boolean minion) {
        if(enemies.size()>=ZombieRules.MOB_CAP) return;
        int roll=random.nextInt(100);
        EntityType type=EntityType.ZOMBIE;
        if(wave>=3 && roll<18 || mutation==Mutation.ARCHERS && roll<35) type=EntityType.SKELETON;
        else if(wave>=4 && roll<35 || mutation==Mutation.SWARM && roll<50) type=EntityType.SPIDER;
        else if(wave>=8 && roll>85) type=EntityType.HUSK;
        boolean runner=mutation==Mutation.RUNNERS || random.nextInt(6)==0;
        Mob mob=spawnMob(type,gate(),ZombieRules.health(wave,runner),2+wave*0.085);
        if(mob instanceof Zombie zombie) zombie.setBaby(runner);
        if(mob.getAttribute(Attribute.MOVEMENT_SPEED)!=null) mob.getAttribute(Attribute.MOVEMENT_SPEED).setBaseValue(runner?0.29:0.23);
        if(mutation==Mutation.ARMORED && mob.getEquipment()!=null && !(mob instanceof Spider))
            mob.getEquipment().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
        mob.customName(Component.text(minion?"Summoned Horror":runner?"Infected Runner":type.name().replace('_',' '),NamedTextColor.GREEN));
    }
    private Mob spawnMob(EntityType type,Location at,double health,double damage) {
        Mob mob=(Mob)world.spawnEntity(at,type);
        mob.setPersistent(false); mob.setRemoveWhenFarAway(false); mob.setCanPickupItems(false);
        mob.getAttribute(Attribute.MAX_HEALTH).setBaseValue(health); mob.setHealth(health);
        if(mob.getAttribute(Attribute.ATTACK_DAMAGE)!=null) mob.getAttribute(Attribute.ATTACK_DAMAGE).setBaseValue(damage);
        if(mob instanceof Zombie z) { z.setShouldBurnInDay(false); z.setCanBreakDoors(false); }
        if(mob.getEquipment()!=null) {
            mob.getEquipment().setHelmetDropChance(0); mob.getEquipment().setChestplateDropChance(0);
            mob.getEquipment().setLeggingsDropChance(0); mob.getEquipment().setBootsDropChance(0);
            mob.getEquipment().setItemInMainHandDropChance(0); mob.getEquipment().setItemInOffHandDropChance(0);
        }
        enemies.put(mob.getUniqueId(),mob); return mob;
    }
    private void bossAttack() {
        int kind=wave/5;
        if(kind==4) { for(int i=0;i<partySize+1;i++) spawnEnemy(true); announce("§5Gravecaller summons reinforcements!"); }
        if(kind==1 || kind==6) {
            hazards.add(new Hazard(boss.getLocation().clone(),kind==6?7:6,seconds+2,1));
            announce("§cGROUND SLAM! Leave the red ring!");
        }
        if(kind!=1) {
            for(Player p:alive()) hazards.add(new Hazard(p.getLocation().clone(),kind==6?3.5:3,seconds+2,kind));
            announce(switch(kind) { case 2 -> "§dBroodmother: escape the web circles!"; case 3 -> "§bFrost Warden: dodge the ice strikes!";
                case 4 -> "§5Gravecaller: dodge the soul eruptions!"; case 5 -> "§2Plague Doctor: leave the poison circles!";
                default -> "§cApocalypse King: meteor storm! Keep moving!"; });
        }
    }
    private void resolveHazards() {
        for(Hazard h:new ArrayList<>(hazards)) {
            // 24 points still draw a solid warning circle; the King can have 7 of these up at once.
            for(int i=0;i<24;i++) {
                double angle=i*Math.PI/12;
                world.spawnParticle(Particle.DUST,h.location.clone().add(Math.cos(angle)*h.radius,0.15,Math.sin(angle)*h.radius),
                        1,0,0,0,0,HAZARD_DUST);
            }
            if(seconds<h.due) continue;
            hazards.remove(h);
            world.spawnParticle(Particle.SOUL_FIRE_FLAME,h.location.clone().add(0,0.5,0),40,h.radius/2,0.5,h.radius/2,0.02);
            world.playSound(h.location,Sound.ENTITY_GENERIC_EXPLODE,0.7f,0.6f);
            for(Player p:alive()) if(p.getLocation().distanceSquared(h.location)<=h.radius*h.radius) {
                p.damage(h.kind==6?7:5,boss);
                if(!players.get(p.getUniqueId()).down && (h.kind==2 || h.kind==3))
                    p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,60,1));
                if(!players.get(p.getUniqueId()).down && h.kind==5) p.addPotionEffect(new PotionEffect(PotionEffectType.POISON,60,0));
            }
        }
    }
    private ItemStack item(Material material,String name,String action,String... lore) {
        ItemStack item=new ItemStack(material); ItemMeta meta=item.getItemMeta();
        meta.displayName(Component.text(name,NamedTextColor.GREEN)); meta.setUnbreakable(true);
        meta.lore(Arrays.stream(lore).map(s->Component.text(s,NamedTextColor.GRAY)).toList());
        if(action!=null) meta.getPersistentDataContainer().set(itemKey,PersistentDataType.STRING,action);
        item.setItemMeta(meta); return item;
    }
    private void equip(Player p) {
        Survivor s=players.get(p.getUniqueId()); int sword=s.tiers[0], bow=s.tiers[1], armour=s.tiers[2];
        p.getInventory().clear();
        ItemStack blade=item(sword>=4?Material.NETHERITE_SWORD:sword>=2?Material.DIAMOND_SWORD:Material.IRON_SWORD,"Survivor Sword "+sword,null);
        if(sword>0) blade.addUnsafeEnchantment(Enchantment.SHARPNESS,sword);
        p.getInventory().setItem(0,blade);
        ItemStack ranged=item(Material.BOW,"Survivor Bow "+bow,null);
        ranged.addEnchantment(Enchantment.INFINITY,1);
        if(bow>0) ranged.addEnchantment(Enchantment.POWER,bow);
        if(bow>=4) ranged.addEnchantment(Enchantment.PUNCH,1);
        p.getInventory().setItem(1,ranged);
        p.getInventory().setItemInOffHand(item(Material.SHIELD,"Riot Shield",null));
        p.getInventory().setItem(6,item(Material.HONEY_BOTTLE,"Field Medkit","heal","Right-click: heal 4 hearts","25-second cooldown; unlimited uses"));
        p.getInventory().setItem(7,item(Material.FEATHER,"Combat Dodge","dash","Right-click to dash forward","6-second cooldown"));
        p.getInventory().setItem(8,item(Material.EMERALD,"Survivor Upgrades","shop","Right-click between waves","Shared kill rewards; your own purchases"));
        p.getInventory().setItem(9,new ItemStack(Material.ARROW,64));
        String prefix=armour>=4?"DIAMOND":armour>=2?"IRON":"CHAINMAIL";
        String[] pieces={"BOOTS","LEGGINGS","CHESTPLATE","HELMET"};
        ItemStack[] gear=new ItemStack[4];
        for(int i=0;i<4;i++) { gear[i]=item(Material.valueOf(prefix+"_"+pieces[i]),"Survivor Armour",null);
            if(armour>0) gear[i].addEnchantment(Enchantment.PROTECTION,Math.min(4,armour)); }
        p.getInventory().setArmorContents(gear);
        p.getAttribute(Attribute.MAX_HEALTH).setBaseValue(20+s.tiers[3]*4);
        p.setHealth(Math.min(p.getHealth(),p.getAttribute(Attribute.MAX_HEALTH).getValue()));
    }
    private void heal(Player p) {
        p.setHealth(p.getAttribute(Attribute.MAX_HEALTH).getValue()); p.setFoodLevel(20); p.setSaturation(0);
        p.setFireTicks(0); p.setFallDistance(0); p.setNoDamageTicks(40);
    }
    private void clearEffects(Player p) { for(var effect:p.getActivePotionEffects()) p.removePotionEffect(effect.getType()); }
    private void openShop(Player p) {
        if(!isPlaying(p) || phase!=Phase.BREAK) { p.sendActionBar(Component.text("Upgrades open between waves",NamedTextColor.YELLOW)); return; }
        Survivor s=players.get(p.getUniqueId()); Shop shop=new Shop(p.getUniqueId());
        for(int i=0;i<4;i++) {
            int tier=s.tiers[i];
            shop.inventory.setItem(i,item(ICONS[i],UPGRADES[i]+" "+tier+" / 5",null,
                    tier==5?"MAXED": "Next tier: "+ZombieRules.upgradeCost(tier)+" scrap",
                    switch(i) { case 0 -> "Sharper blades; diamond / netherite"; case 1 -> "More arrow damage; knockback at tier 4";
                        case 2 -> "Protection; iron / diamond armour"; default -> "+2 permanent hearts per tier this match"; },
                    "Your scrap: "+s.credits));
        }
        shop.inventory.setItem(8,item(Material.BARRIER,"Close",null)); p.openInventory(shop.inventory);
    }
    @EventHandler public void interact(PlayerInteractEvent event) {
        Player p=event.getPlayer(); if(!isWorld(p)) return;
        if(event.getClickedBlock()!=null && (event.getClickedBlock().getType()==Material.BARREL
                || event.getClickedBlock().getType()==Material.SMITHING_TABLE)) { event.setCancelled(true); openShop(p); return; }
        ItemStack held=event.getItem(); if(held==null || !held.hasItemMeta()) return;
        String action=held.getItemMeta().getPersistentDataContainer().get(itemKey,PersistentDataType.STRING);
        if(action==null) return;
        event.setCancelled(true);
        if(event.getHand()!=EquipmentSlot.HAND || !event.getAction().isRightClick() || !isPlaying(p)) return;
        Survivor s=players.get(p.getUniqueId()); if(s.down || phase==Phase.RESULTS) return;
        if(action.equals("shop")) { openShop(p); return; }
        if(action.equals("heal")) {
            if(seconds<s.healsAt) { p.sendActionBar(Component.text("Medkit ready in "+(s.healsAt-seconds)+"s")); return; }
            if(p.getHealth()>=p.getAttribute(Attribute.MAX_HEALTH).getValue()) return;
            p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(),p.getHealth()+8)); s.healsAt=seconds+25;
            p.playSound(p.getLocation(),Sound.ENTITY_GENERIC_DRINK,1,1); world.spawnParticle(Particle.HEART,p.getLocation().add(0,2,0),6,0.4,0.4,0.4);
        }
        if(action.equals("dash")) {
            if(seconds<s.dashAt) { p.sendActionBar(Component.text("Dodge ready in "+(s.dashAt-seconds)+"s")); return; }
            Vector direction=p.getLocation().getDirection().setY(0);
            if(direction.lengthSquared()<0.01) direction=new Vector(0,0,1);
            p.setVelocity(direction.normalize().multiply(1.15).setY(0.25)); p.setNoDamageTicks(12); s.dashAt=seconds+6;
            p.playSound(p.getLocation(),Sound.ENTITY_ENDER_DRAGON_FLAP,0.5f,1.7f);
        }
    }
    @EventHandler public void shopClick(InventoryClickEvent event) {
        if(!(event.getWhoClicked() instanceof Player p) || !isWorld(p)) return;
        if(event.getView().getTopInventory().getHolder() instanceof Shop shop) {
            event.setCancelled(true);
            if(!isPlaying(p) || !shop.owner.equals(p.getUniqueId()) || phase!=Phase.BREAK) { p.closeInventory(); return; }
            int slot=event.getRawSlot(); if(slot==8) { p.closeInventory(); return; }
            if(slot<0 || slot>=4) return;
            Survivor s=players.get(p.getUniqueId()); int cost=ZombieRules.upgradeCost(s.tiers[slot]);
            if(s.credits<cost) { p.sendMessage("§eNot enough scrap (or already maxed)."); return; }
            s.credits-=cost; s.tiers[slot]++; equip(p); heal(p); openShop(p);
            p.playSound(p.getLocation(),Sound.BLOCK_ANVIL_USE,0.5f,1.4f);
        } else event.setCancelled(true); // Fixed kit: no dropping/rearranging its ability slots.
    }
    @EventHandler public void drag(InventoryDragEvent e) { if(isWorld(e.getWhoClicked().getWorld())) e.setCancelled(true); }
    @EventHandler public void swap(PlayerSwapHandItemsEvent e) { if(isWorld(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void place(BlockPlaceEvent e) { if(isWorld(e.getBlock().getWorld())) e.setCancelled(true); }
    @EventHandler public void breakBlock(BlockBreakEvent e) { if(isWorld(e.getBlock().getWorld())) e.setCancelled(true); }
    @EventHandler public void explode(EntityExplodeEvent e) { if(isWorld(e.getLocation().getWorld())) e.blockList().clear(); }
    @EventHandler public void changeBlock(EntityChangeBlockEvent e) { if(isWorld(e.getBlock().getWorld())) e.setCancelled(true); }
    @EventHandler public void transform(EntityTransformEvent e) { if(isWorld(e.getEntity().getWorld())) e.setCancelled(true); }
    @EventHandler public void spawn(CreatureSpawnEvent e) {
        if(isWorld(e.getLocation().getWorld()) && e.getSpawnReason()!=CreatureSpawnEvent.SpawnReason.CUSTOM) e.setCancelled(true);
    }
    @EventHandler public void target(EntityTargetLivingEntityEvent e) {
        if(isWorld(e.getEntity().getWorld()) && e.getTarget()!=null
                && (!(e.getTarget() instanceof Player p) || !isPlaying(p) || players.get(p.getUniqueId()).down)) e.setCancelled(true);
    }
    private Player attacker(Entity entity) {
        if(entity instanceof Player p) return p;
        if(entity instanceof Projectile arrow && arrow.getShooter() instanceof Player p) return p;
        return null;
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void damage(EntityDamageEvent event) {
        if(!isWorld(event.getEntity().getWorld())) return;
        if(phase!=Phase.FIGHT) { event.setCancelled(true); return; }
        if(event.getEntity() instanceof Player p) {
            Survivor s=players.get(p.getUniqueId());
            if(s==null || s.down) { event.setCancelled(true); return; }
            if(event instanceof EntityDamageByEntityEvent hit && attacker(hit.getDamager())!=null) { event.setCancelled(true); return; }
            if(event instanceof EntityDamageByEntityEvent ranged && ranged.getDamager() instanceof AbstractArrow arrow
                    && arrow.getShooter() instanceof Mob mob && enemies.containsKey(mob.getUniqueId()))
                event.setDamage(3 + wave * 0.12);
            if(event.getCause()==EntityDamageEvent.DamageCause.FALL) { event.setCancelled(true); return; }
            if(event.getFinalDamage()>=p.getHealth()) {
                event.setCancelled(true); down(p);
            }
        } else if(event instanceof EntityDamageByEntityEvent hit) {
            Player p=attacker(hit.getDamager());
            if(p==null || !isPlaying(p) || players.get(p.getUniqueId()).down || !enemies.containsKey(event.getEntity().getUniqueId()))
                event.setCancelled(true);
        }
    }
    private void down(Player p) {
        Survivor s=players.get(p.getUniqueId()); if(s==null || s.down) return;
        s.down=true; p.closeInventory(); clearEffects(p); p.setFireTicks(0); p.setHealth(p.getAttribute(Attribute.MAX_HEALTH).getValue());
        p.setGameMode(GameMode.SPECTATOR); p.teleport(getSpectateLocation());
        announce("§e"+p.getName()+" fell! Survive this wave to bring them back.");
        p.sendTitle("§cYOU'RE DOWN","§fReturning next wave if your team survives",5,60,5);
        if(alive().isEmpty()) finish(false,"The team was overwhelmed.");
    }
    @EventHandler public void death(EntityDeathEvent event) {
        if(!isWorld(event.getEntity().getWorld())) return;
        event.getDrops().clear(); event.setDroppedExp(0);
        if(enemies.remove(event.getEntity().getUniqueId())==null) return;
        boolean isBoss=event.getEntity().equals(boss);
        for(Survivor s:players.values()) s.credits+=isBoss?30:2;
        Player killer=event.getEntity().getKiller();
        if(killer!=null && players.containsKey(killer.getUniqueId())) players.get(killer.getUniqueId()).kills++;
        if(isBoss) { boss=null; hazards.clear(); bossBar.removeAll(); announce("§6BOSS DEFEATED! +30 scrap each!");
            for(Player p:alive()) { p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(),p.getHealth()+6)); p.playSound(p.getLocation(),Sound.UI_TOAST_CHALLENGE_COMPLETE,0.6f,1); } }
    }
    @EventHandler public void playerDeath(PlayerDeathEvent e) {
        if(!isWorld(e.getEntity())) return;
        e.deathMessage(null); e.setKeepInventory(true); e.getDrops().clear();
        Survivor s=players.get(e.getEntity().getUniqueId()); if(s!=null) s.down=true;
    }
    @EventHandler public void respawn(PlayerRespawnEvent e) {
        if(!isPlaying(e.getPlayer())) return;
        e.setRespawnLocation(getSpectateLocation()); e.getPlayer().setGameMode(GameMode.SPECTATOR);
    }
    @EventHandler public void projectile(ProjectileHitEvent e) {
        if(!isWorld(e.getEntity().getWorld())) return;
        // Remove embedded arrows; never accumulate 30 waves of entities.
        Bukkit.getScheduler().runTask(plugin,()->e.getEntity().remove());
    }
    @EventHandler public void shoot(EntityShootBowEvent e) {
        if(!isWorld(e.getEntity().getWorld())) return;
        if(phase!=Phase.FIGHT) { e.setCancelled(true); return; }
        if(e.getProjectile() instanceof AbstractArrow a) a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
    }
    private void announce(String text) { roster().forEach(p->p.sendMessage(text)); }
    private void updateHud() {
        if(!isRunning() || phase==Phase.RESULTS) return;
        int left=phase==Phase.BREAK?remaining:Math.max(0,ZombieRules.COMBAT_SECONDS-elapsed);
        boolean overtime=phase==Phase.FIGHT && elapsed>=ZombieRules.COMBAT_SECONDS && boss!=null;
        if(overtime) left=ZombieRules.COMBAT_SECONDS+ZombieRules.BOSS_OVERTIME-elapsed;
        String title=phase==Phase.BREAK?"UPGRADES · Wave "+(wave+1)+" in "+left+"s":
                "Wave "+wave+" / 30 · "+(overtime?"BOSS OVERTIME ":"")+left+"s · "+enemies.size()+" enemies";
        waveBar.setTitle(title); waveBar.setColor(phase==Phase.BREAK?BarColor.BLUE:overtime?BarColor.RED:BarColor.GREEN);
        waveBar.setProgress(Math.clamp((double)left/(phase==Phase.BREAK?15:overtime?40:50),0,1));
        for(Player p:roster()) {
            Survivor s=players.get(p.getUniqueId());
            // One board per survivor, updated in place (a new board each second re-sent every line).
            Sidebar sidebar=sidebars.computeIfAbsent(p.getUniqueId(),id->new Sidebar("zombie",Component.text("ZOMBIE APOCALYPSE",NamedTextColor.GREEN)));
            String[] lines={"§fWave: §a"+wave+" / 30","§fTeam standing: §a"+alive().size()+" / "+players.size(),
                    "§fScrap: §e"+s.credits,"§fKills: §c"+s.kills,"§fEnemies: §c"+enemies.size(),
                    "§fNext boss: §d"+Math.min(30,((wave/5)+1)*5),"§7Medkit / Dodge / Upgrades","§7Use /lobby to leave"};
            sidebar.lines(List.of(lines)); sidebar.show(p);
            p.sendActionBar(Component.text(s.down?"Down · Your team can bring you back next wave":
                    phase==Phase.BREAK?"UPGRADE NOW · "+s.credits+" scrap · Right-click emerald":
                            "Medkit "+(seconds>=s.healsAt?"READY":(s.healsAt-seconds)+"s")+" | Dodge "+(seconds>=s.dashAt?"READY":(s.dashAt-seconds)+"s"),NamedTextColor.GREEN));
        }
    }
    private void finish(boolean win,String reason) {
        if(phase==Phase.RESULTS || phase==Phase.IDLE) return;
        phase=Phase.RESULTS; remaining=12; cleanEnemies(); waveBar.setProgress(1); waveBar.setTitle(win?"VICTORY · City saved!":"DEFEAT · Requeue for another run");
        for(Player p:roster()) {
            p.closeInventory(); clearEffects(p); p.setGameMode(GameMode.ADVENTURE); p.teleport(spawn()); heal(p);
            p.sendTitle(win?"§6§lCITY SAVED!":"§c§lTEAM OVERWHELMED","§f"+cleared+" / 30 waves cleared",10,100,10);
            p.sendMessage("§e"+reason+" §fReturning to lobby in 12s. Requeue for fresh hordes and upgrades!");
            String key=p.getUniqueId().toString(); records.set(key+".best",Math.max(cleared,records.getInt(key+".best")));
            if(win) records.set(key+".wins",records.getInt(key+".wins")+1);
            records.set(key+".name",p.getName());
            if(win) { world.spawnParticle(Particle.TOTEM_OF_UNDYING,p.getLocation().add(0,2,0),80,1,1,1,0.2); p.playSound(p.getLocation(),Sound.UI_TOAST_CHALLENGE_COMPLETE,1,1); }
        }
        saveRecords();
    }
    private void saveRecords() {
        AsyncFiles.writeYaml(plugin, records, recordsFile);
    }
    private void restore(Player p,Survivor s) {
        p.closeInventory(); clearEffects(p); p.setFireTicks(0); p.setAbsorptionAmount(0);
        p.getAttribute(Attribute.MAX_HEALTH).setBaseValue(s.originalMax);
        p.setHealth(Math.min(p.getHealth(),p.getAttribute(Attribute.MAX_HEALTH).getValue()));
        p.getAttribute(Attribute.ATTACK_SPEED).setBaseValue(s.originalSpeed);
        waveBar.removePlayer(p); bossBar.removePlayer(p);
    }
    public void handleQuit(Player p) {
        sidebars.remove(p.getUniqueId());
        Survivor s=players.remove(p.getUniqueId()); if(s==null) return;
        restore(p,s);
        String key=p.getUniqueId().toString(); records.set(key+".best",Math.max(cleared,records.getInt(key+".best"))); saveRecords();
        if(phase!=Phase.RESULTS && isRunning() && alive().isEmpty()) finish(false,"No survivors remain.");
    }
    private void cleanEnemies() {
        hazards.clear(); boss=null; bossBar.removeAll();
        enemies.values().forEach(Entity::remove); enemies.clear();
        for(Entity e:world.getEntities()) if(e instanceof Projectile || e instanceof Item || e instanceof ExperienceOrb) e.remove();
    }
    private void reset() {
        List<Player> old=roster(); Map<UUID,Survivor> states=new HashMap<>(players);
        phase=Phase.IDLE; players.clear(); cleanEnemies(); waveBar.removeAll();
        for(Player p:old) { restore(p,states.get(p.getUniqueId())); plugin.getLobbyManager().returnToLobby(p); }
    }
    public void shutdown() {
        if(builder!=null) builder.cancel(); if(ticker!=null) ticker.cancel();
        if(isRunning()) reset(); else cleanEnemies();
    }
}
