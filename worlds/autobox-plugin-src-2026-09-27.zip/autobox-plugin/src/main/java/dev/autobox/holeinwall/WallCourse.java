package dev.autobox.holeinwall;

import java.util.Arrays;
import java.util.Random;

/** Deterministic course geometry; coordinates rotate about the deck's centre block. */
public final class WallCourse {
    public static final int WIDTH = 13;
    public static final int HEIGHT = 4;
    public static final int FINAL_WAVE = 24;
    public record Pattern(String name, boolean[][] solid) { }

    public static int x(int direction, int across, int along) {
        return switch (direction) { case 0 -> across; case 1 -> -along; case 2 -> -across; default -> along; };
    }
    public static int z(int direction, int across, int along) {
        return switch (direction) { case 0 -> along; case 1 -> across; case 2 -> -along; default -> -across; };
    }
    public static int moveInterval(int cleared, boolean rush) {
        return Math.max(3, 6 - cleared / 6 - (rush ? 1 : 0));
    }
    public static Pattern pattern(Random random, int wave, boolean tiny) {
        boolean[][] solid = new boolean[WIDTH][HEIGHT];
        for (boolean[] column : solid) Arrays.fill(column, true);
        int style = wave <= 2 ? 0 : (wave - 3) % 5;
        String name;
        switch (style) {
            case 0 -> {
                name = tiny ? "NEEDLE THREAD" : "BIG DOOR";
                int width = tiny ? 1 : 3;
                carve(solid, 2 + random.nextInt(7 - width), 0, width, 3);
            }
            case 1 -> {
                name = "PICK A SIDE";
                carve(solid, 2, 0, tiny ? 1 : 2, 3);
                carve(solid, 9, 0, tiny ? 1 : 2, 3);
            }
            case 2 -> {
                name = "JUMP GATE";
                carve(solid, 3, 1, 7, 3);
            }
            case 3 -> {
                name = "SLALOM";
                carve(solid, random.nextBoolean() ? 2 : 8, 0, tiny ? 1 : 3, 2);
            }
            default -> {
                name = "TRIPLE CHOICE";
                for (int left : new int[]{2, 5, 8}) carve(solid, left, 0, tiny ? 1 : 2, 2);
            }
        }
        return new Pattern(name, solid);
    }
    private static void carve(boolean[][] solid, int x, int y, int width, int height) {
        for (int dx = 0; dx < width; dx++) for (int dy = 0; dy < height; dy++) solid[x + dx][y + dy] = false;
    }
    private WallCourse() { }
}
