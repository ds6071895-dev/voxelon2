package dev.autobox.game;

import dev.autobox.AutoBoxPlugin;
import dev.autobox.chicken.ChickenRunGame;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.entity.Chicken;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import dev.autobox.sumo.BlockSumoGame;

public class GameListener implements Listener {

    private static final double SNOWBALL_KNOCKBACK = 0.35;

    private final AutoBoxPlugin plugin;
    private final AutoBoxGame game;

    public GameListener(AutoBoxPlugin plugin, AutoBoxGame game) {
        this.plugin = plugin;
        this.game = game;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (plugin.getBlockSumo().isWorld(player)) {
            plugin.getBlockSumo().handleInteract(event);
            return;
        }
        if (plugin.getChickenRun().isWorld(player) || plugin.getHoleInWall().isWorld(player) || plugin.getSplat().isWorld(player)
                || plugin.getZombieApocalypse().isWorld(player) || plugin.getRatSeek().isWorld(player)
                || plugin.getLuckyPillars().isWorld(player)) {
            // Lucky Pillars needs vanilla right-clicks: buckets, spawn eggs, pearls, crystals.
            return;
        }
        if (game.isInArenaWorld(player)) {
            if (event.getAction() == Action.RIGHT_CLICK_AIR) {
                return;
            }
            if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                Block block = event.getClickedBlock();
                if (block != null && block.getType() == Material.CHEST) {
                    event.setCancelled(true);
                    game.openChest(player, block.getLocation());
                }
                return;
            }
            event.setCancelled(true);
            return;
        }
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.LEFT_CLICK_BLOCK) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlace(BlockPlaceEvent event) {
        if (plugin.getZombieApocalypse().isWorld(event.getPlayer())) return;
        Player player = event.getPlayer();
        if (plugin.getLuckyPillars().isWorld(player)) {
            // LuckyPillarsGame decides who may build or break.
            return;
        }
        if (plugin.getSplat().isWorld(player)) {
            return;
        }
        if (plugin.getBlockSumo().isWorld(player)) {
            if (!plugin.getBlockSumo().onWoolPlace(player, event.getBlockPlaced())) {
                event.setCancelled(true);
            } else {
                event.setBuild(true);
                event.setCancelled(false);
            }
            return;
        }
        if (plugin.getChickenRun().isWorld(player)) {
            if (!plugin.getChickenRun().onPlace(player, event.getBlockPlaced())) {
                event.setCancelled(true);
            } else {
                event.setBuild(true);
                event.setCancelled(false);
            }
            return;
        }
        if (plugin.getHoleInWall().isWorld(player)) {
            event.setCancelled(true);
            return;
        }

        if (plugin.getRatSeek().isWorld(player)) {
            event.setCancelled(true);
            return;
        }
        if (game.isInArenaWorld(player)) {
            if (!game.onWoolPlace(player, event.getBlockPlaced().getLocation(), event.getBlock().getType())) {
                event.setCancelled(true);
            } else {
                event.setBuild(true);
                event.setCancelled(false);
            }
        } else {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent event) {
        if (plugin.getZombieApocalypse().isWorld(event.getPlayer())) return;
        Player player = event.getPlayer();
        if (plugin.getLuckyPillars().isWorld(player)) {
            // LuckyPillarsGame decides who may build or break.
            return;
        }
        if (plugin.getSplat().isWorld(player)) {
            return;
        }
        if (plugin.getBlockSumo().isWorld(player)) {
            if (!plugin.getBlockSumo().onBreak(player, event.getBlock())) {
                event.setCancelled(true);
            } else {
                event.setCancelled(false);
            }
            return;
        }
        if (plugin.getChickenRun().isWorld(player)) {
            if (!plugin.getChickenRun().onBreak(player, event.getBlock())) {
                event.setCancelled(true);
            } else {
                event.setDropItems(false);
                event.setCancelled(false);
            }
            return;
        }
        if (plugin.getHoleInWall().isWorld(player)) {
            event.setCancelled(true);
            return;
        }

        if (plugin.getRatSeek().isWorld(player)) {
            event.setCancelled(true);
            return;
        }
        if (game.isInArenaWorld(player)) {
            if (event.getBlock().getType().name().endsWith("_WOOL")) {
                game.onWoolBreak(event.getBlock().getLocation());
                event.setCancelled(false);
                return;
            }
            event.setCancelled(true);
            return;
        }
        if (plugin.getLobbySpawn().getWorld().equals(event.getBlock().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onSettingsClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (!event.getView().title().equals(AutoBoxPlugin.SETTINGS_TITLE)) {
            return;
        }
        event.setCancelled(true);
        ItemStack current = event.getCurrentItem();
        if (current == null || current.getType() == Material.AIR) {
            return;
        }
        int slot = event.getSlot();
        if (slot == 8) {
            player.closeInventory();
            return;
        }
        Disadvantage[] values = Disadvantage.values();
        if (slot >= 0 && slot < values.length) {
            plugin.toggleDisadvantage(player, values[slot]);
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1.2f);
            plugin.refreshSettingsInventory(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        if (plugin.getZombieApocalypse().isWorld(event.getEntity().getWorld())) return;
        if (plugin.getLuckyPillars().isWorld(event.getEntity().getWorld())) return;
        if (event.getEntity() instanceof Chicken chicken
                && plugin.getChickenRun().isWorld(chicken.getWorld())
                && chicken.getScoreboardTags().contains(ChickenRunGame.FINISH_TAG)
                && event.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK
                && event.getCause() != EntityDamageEvent.DamageCause.PROJECTILE) {
            event.setCancelled(true);
            return;
        }
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        World world = player.getWorld();
        if (plugin.getSplat().isWorld(player)) {
            return;
        }
        if (plugin.getBlockSumo().isWorld(player)) {
            event.setCancelled(true);
            return;
        }
        if (plugin.getChickenRun().isWorld(player)) {
            event.setCancelled(true);
            return;
        }
        if (plugin.getHoleInWall().isWorld(player)) {
            event.setCancelled(true);
            return;
        }
        if (plugin.getRatSeek().isWorld(player)) {
            // Hits are handled as catches; every other source is harmless.
            event.setCancelled(true);
            return;
        }

        if (game.isInArenaWorld(player)) {
            EntityDamageEvent.DamageCause cause = event.getCause();
            if (cause == EntityDamageEvent.DamageCause.PROJECTILE
                    || cause == EntityDamageEvent.DamageCause.ENTITY_ATTACK
                    || cause == EntityDamageEvent.DamageCause.VOID) {
                if (plugin.getDisadvantages(player).contains(Disadvantage.GLASS_CANNON)) {
                    event.setDamage(event.getDamage() * 2);
                }
                return;
            }
            event.setCancelled(true);
            return;
        }
        if (world.equals(plugin.getLobbySpawn().getWorld())) {
            if (event.getCause() == EntityDamageEvent.DamageCause.VOID) {
                event.setCancelled(true);
                player.teleport(plugin.getLobbySpawn());
                return;
            }
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (plugin.getZombieApocalypse().isWorld(event.getEntity().getWorld())) return;
        if (plugin.getLuckyPillars().isWorld(event.getEntity().getWorld())) return;
        if ((event.getEntity() instanceof Player partyVictim && plugin.getSplat().isWorld(partyVictim))
                || (event.getDamager() instanceof Player partyAttacker && plugin.getSplat().isWorld(partyAttacker))) {
            return;
        }
        if (event.getEntity() instanceof Player victim && plugin.getHoleInWall().isWorld(victim)) {
            event.setCancelled(true);
            return;
        }
        if (event.getDamager() instanceof Player player && event.getEntity() instanceof Chicken chicken
                && plugin.getChickenRun().handleChickenHit(event, player, chicken)) {
            return;
        }
        if (event.getDamager() instanceof Player attacker
                && event.getEntity() instanceof Player victim
                && plugin.getChickenRun().isWorld(victim)) {
            plugin.getChickenRun().handleMelee(event, attacker, victim);
            return;
        }
        if (event.getDamager() instanceof Player attacker
                && event.getEntity() instanceof Player victim
                && plugin.getBlockSumo().isWorld(victim)) {
            plugin.getBlockSumo().handleMelee(event, attacker, victim);
            return;
        }
        if (event.getDamager() instanceof Player attacker
                && event.getEntity() instanceof Player victim
                && plugin.getRatSeek().isWorld(victim)) {
            plugin.getRatSeek().handleHit(event, attacker, victim);
            return;
        }

        if (event.getDamager() instanceof Player attacker
                && plugin.getChickenRun().handleBossHit(event, attacker)) {
            return;
        }
        if (event.getEntity() instanceof Player victim && !game.isInArenaWorld(victim)) {
            return;
        }
        if (event.getDamager() instanceof Player attacker
                && event.getEntity() instanceof Player victim
                && game.isPlaying(attacker) && game.isPlaying(victim)) {
            event.setDamage(plugin.getDisadvantages(attacker).contains(Disadvantage.WEAKNESS) ? 0.5 : 1.0);
            attacker.resetCooldown();
            boolean sprinting = attacker.isSprinting();
            Vector knockback = victim.getLocation().toVector().subtract(attacker.getLocation().toVector());
            knockback.setY(0);
            if (knockback.lengthSquared() < 0.01) {
                knockback.setX(randomSign());
                knockback.setZ(0);
            }
            knockback.normalize();
            knockback.multiply(sprinting ? 0.9 : 0.6);
            knockback.setY(sprinting ? 0.45 : 0.3);
            victim.setVelocity(knockback);
            victim.getWorld().playSound(victim.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1f, 1.2f);
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        if (plugin.getZombieApocalypse().isWorld(event.getEntity().getWorld())) return;
        if (plugin.getLuckyPillars().isWorld(event.getEntity().getWorld())) return;
        if (event.getEntity().getWorld().getName().equals(dev.autobox.splat.SplatGame.WORLD_NAME)) {
            return;
        }
        if (plugin.getChickenRun().isWorld(event.getEntity().getWorld())) {
            plugin.getChickenRun().handleProjectileHit(event);
            return;
        }
        if (plugin.getBlockSumo().isWorld(event.getEntity().getWorld())) {
            plugin.getBlockSumo().handleProjectileHit(event);
            return;
        }

        if (!(event.getEntity() instanceof Snowball snowball)
                || !(event.getHitEntity() instanceof Player hit)
                || !(snowball.getShooter() instanceof Player shooter)
                || !game.isPlaying(shooter) || !game.isPlaying(hit)) {
            return;
        }
        hit.damage(5.0, shooter);
        Vector dir = snowball.getVelocity();
        double speed = Math.hypot(dir.getX(), dir.getZ());
        if (speed > 0.01) {
            Vector knockback = new Vector(dir.getX() / speed, 0, dir.getZ() / speed)
                    .multiply(SNOWBALL_KNOCKBACK);
            knockback.setY(0.22);
            hit.setVelocity(knockback);
        }
        hit.getWorld().playSound(hit.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 0.7f);
        Particle.POOF.builder()
                .location(hit.getLocation().add(0, 1, 0))
                .count(15)
                .offset(0.5, 0.5, 0.5)
                .extra(0.05)
                .receivers(32, true)
                .spawn();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        if (plugin.getZombieApocalypse().isWorld(event.getEntity().getWorld())) return;
        if (plugin.getLuckyPillars().isWorld(event.getEntity().getWorld())) return;
        Player player = event.getEntity();
        if (plugin.getHoleInWall().isWorld(player)) {
            event.deathMessage(null);
            event.setKeepInventory(true);
            return;
        }
        if (plugin.getSplat().isWorld(player)) {
            event.deathMessage(null);
            event.setKeepInventory(true);
            return;
        }

        if (plugin.getRatSeek().isWorld(player)) {
            event.deathMessage(null);
            event.setKeepInventory(true);
            plugin.getRatSeek().handleDeath(player);
            return;
        }
        if (game.isInArenaWorld(player)) {
            event.deathMessage(null);
            event.setKeepInventory(true);
            game.handleDeath(player);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        if (plugin.getZombieApocalypse().isPlaying(event.getPlayer())) return;
        if (plugin.getLuckyPillars().isPlaying(event.getPlayer())) return;
        Player player = event.getPlayer();
        player.setBedSpawnLocation(plugin.getLobbySpawn(), true);
        if (plugin.getHoleInWall().isRunning() && plugin.getHoleInWall().isPlaying(player)) {
            event.setRespawnLocation(plugin.getHoleInWall().getSpectateLocation());
            player.setGameMode(GameMode.SPECTATOR);
            return;
        }
        if (plugin.getChickenRun().isRunning() && plugin.getChickenRun().isPlaying(player)) {
            event.setRespawnLocation(plugin.getChickenRun().getRespawnLocation(player));
            player.setGameMode(GameMode.SURVIVAL);
            return;
        }
        if (game.isRunning() && game.isPlaying(player)) {
            event.setRespawnLocation(game.respawnSpotFor(player));
            player.setGameMode(GameMode.SPECTATOR);
            game.startRespawnCountdown(player, event.getRespawnLocation());
        } else if (plugin.getSplat().isRunning() && plugin.getSplat().isPlaying(player)) {
            event.setRespawnLocation(plugin.getSplat().getSpectateLocation());
            player.setGameMode(GameMode.SPECTATOR);
        } else {
            event.setRespawnLocation(plugin.getLobbySpawn());
            player.setGameMode(GameMode.ADVENTURE);
            player.getInventory().clear();
            Bukkit.getScheduler().runTask(plugin, () -> plugin.getLobbyManager().returnToLobby(player));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        player.getInventory().clear();
        player.setGameMode(GameMode.ADVENTURE);
        player.setBedSpawnLocation(plugin.getLobbySpawn(), true);
        player.teleport(plugin.getLobbySpawn());
        player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        AttributeInstance attackSpeed = player.getAttribute(Attribute.ATTACK_SPEED);
        if (attackSpeed != null) {
            attackSpeed.setBaseValue(64.0);
        }
        player.sendMessage(Component.text("[Worlds] ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text("Welcome! Type ", NamedTextColor.AQUA))
                .append(Component.text("the NPCs", NamedTextColor.WHITE))
                .append(Component.text(" to choose a minigame.", NamedTextColor.AQUA)));
        plugin.getLobbyManager().onJoin(player);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        World lobby = plugin.getLobbySpawn().getWorld();
        if (player.getWorld().equals(lobby)
                && player.getLocation().getY() < plugin.getLobbySpawn().getY() - 40) {
            player.teleport(plugin.getLobbySpawn());
        }
    }

    @EventHandler
    public void onFish(org.bukkit.event.player.PlayerFishEvent event) {
        if (plugin.getBlockSumo().isWorld(event.getPlayer())) {
            plugin.getBlockSumo().handleFish(event);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getLobbyManager().onQuit(event.getPlayer());
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (game.isInArenaWorld(event.getPlayer())
                || plugin.getBlockSumo().isWorld(event.getPlayer())
                || plugin.getChickenRun().isWorld(event.getPlayer()) || plugin.getSplat().isWorld(event.getPlayer())
                || plugin.getZombieApocalypse().isWorld(event.getPlayer())
                || plugin.getHoleInWall().isWorld(event.getPlayer())
                || plugin.getRatSeek().isWorld(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onFoodChange(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player player && game.isInArenaWorld(player)) {
            if (plugin.getDisadvantages(player).contains(Disadvantage.HUNGER)) {
                return;
            }
            event.setCancelled(true);
            player.setFoodLevel(20);
        }
        if (event.getEntity() instanceof Player player && plugin.getBlockSumo().isWorld(player)) {
            event.setCancelled(true);
            player.setFoodLevel(20);
        }
        if (event.getEntity() instanceof Player player && plugin.getChickenRun().isWorld(player)) {
            event.setCancelled(true);
            player.setFoodLevel(20);
        }
        if (event.getEntity() instanceof Player player && plugin.getZombieApocalypse().isWorld(player)) {
            event.setCancelled(true);
            player.setFoodLevel(20);
        }
        if (event.getEntity() instanceof Player player && plugin.getRatSeek().isWorld(player)) {
            event.setCancelled(true);
            player.setFoodLevel(20);
        }
        if (event.getEntity() instanceof Player player && plugin.getHoleInWall().isWorld(player)) {
            event.setCancelled(true);
            player.setFoodLevel(20);
        }
    }

    private static int randomSign() {
        return Math.random() < 0.5 ? 1 : -1;
    }
}
