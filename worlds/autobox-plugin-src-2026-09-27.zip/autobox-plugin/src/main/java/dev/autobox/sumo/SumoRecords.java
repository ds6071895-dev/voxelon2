package dev.autobox.sumo;

import dev.autobox.util.AsyncFiles;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.util.UUID;

/** Lifetime Block Sumo stats per player, kept in {@code sumo-records.yml} (read by the leaderboard site). */
final class SumoRecords {
    private final Plugin plugin;
    private final File file;
    private final YamlConfiguration records;

    SumoRecords(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "sumo-records.yml");
        this.records = YamlConfiguration.loadConfiguration(file);
    }

    /** A Gauntlet round win. Returns true when it beat this player's fastest round win. */
    boolean roundWin(UUID id, String name, SumoArena.Kind arena, int roundTicks) {
        String key = id.toString();
        records.set(key + ".name", name);
        add(key + ".roundWins", 1);
        add(key + ".arenaWins." + arena.name(), 1);
        int best = records.getInt(key + ".fastestRound", 0);
        if (best == 0 || roundTicks < best) {
            records.set(key + ".fastestRound", roundTicks);
            return best != 0;
        }
        return false;
    }

    /** Adds one finished match. Returns true when the knockouts are a new personal best. */
    boolean match(UUID id, String name, SumoRules.Mode mode, boolean won, int knockouts, int falls, int bestStreak,
                  int crates) {
        String key = id.toString();
        records.set(key + ".name", name);
        add(key + ".games", 1);
        add(key + ".wins", won ? 1 : 0);
        add(key + "." + (mode == SumoRules.Mode.GAUNTLET ? "gauntletWins" : "marathonWins"), won ? 1 : 0);
        add(key + ".knockouts", knockouts);
        add(key + ".falls", falls);
        add(key + ".crates", crates);
        if (bestStreak > records.getInt(key + ".bestStreak")) records.set(key + ".bestStreak", bestStreak);
        boolean best = records.contains(key + ".bestKnockouts") && knockouts > records.getInt(key + ".bestKnockouts");
        if (knockouts > records.getInt(key + ".bestKnockouts")) records.set(key + ".bestKnockouts", knockouts);
        return best;
    }

    String summary(UUID id) {
        String key = id.toString();
        return records.getInt(key + ".wins") + " wins · " + records.getInt(key + ".knockouts") + " knockouts · "
                + records.getInt(key + ".games") + " games";
    }

    void save() {
        AsyncFiles.writeYaml(plugin, records, file);
    }

    private void add(String path, int amount) {
        if (amount != 0) records.set(path, records.getInt(path) + amount);
    }
}
