package dev.autobox.splat;

import java.util.*;

/**
 * Note-block soundtrack sequenced in code, so Java and Bedrock players hear it without the
 * resource pack. One step is a sixteenth note of 2 ticks (150 BPM). Pure data so SplatCheck
 * can verify every pitch stays inside the note-block range.
 */
public final class SplatMusic {
    public static final int STEP_TICKS = 2, BAR = 16;

    /** lowest is the MIDI note a voice plays at pitch 0.5; melodic notes are folded into its two octaves. */
    public enum Voice {
        BASS(30), GUITAR(42), BIT(54), PLING(54), FLUTE(66), BELL(78), CHIME(78), KICK(54), SNARE(54), HAT(54);

        public final int lowest;

        Voice(int lowest) { this.lowest = lowest; }

        public boolean drum() { return this == KICK || this == SNARE || this == HAT; }
    }

    public record Note(Voice voice, float pitch, float volume) {}

    public enum Track {
        COUNTDOWN(false), BATTLE(true), RANKED_BATTLE(true), FINAL_MINUTE(true), OVERTIME(true), JUDGING(false), VICTORY(false), DEFEAT(false), DRAW(false);

        public final boolean loops;

        Track(boolean loops) { this.loops = loops; }
    }

    private record Chord(int root, int... stab) {}

    private static final Map<String, Chord> CHORDS = Map.of(
            "G", new Chord(31, 55, 59, 62),
            "D", new Chord(38, 54, 57, 62),
            "Em", new Chord(40, 55, 59, 64),
            "C", new Chord(36, 55, 60, 64),
            "Bm", new Chord(35, 54, 59, 62));

    private static final String[] A_CHORDS = {"G", "D", "Em", "C", "G", "D", "C", "D"};
    private static final String[] A_LEAD = {
            "G4 . B4 . D5 . B4 . D5 . E5 D5 . B4 . .",
            "A4 . . F#4 A4 . D5 . E5 . D5 . A4 . F#4 .",
            "G4 . B4 . E5 . . D5 E5 . F#5 . E5 . D5 .",
            "E5 . D5 . C5 . . B4 C5 . D5 . . . . .",
            "G4 . B4 . D5 . B4 . D5 . E5 D5 . B4 . .",
            "A4 . . F#4 A4 . D5 . E5 . D5 . A4 . F#4 .",
            "G4 . B4 . E5 . . D5 E5 . G4 . B4 . E5 .",
            "E5 . D5 . C5 . B4 . A4 . B4 . D5 . . ."};
    private static final String[] B_CHORDS = {"C", "D", "Bm", "Em", "C", "D", "G", "G"};
    private static final String[] B_LEAD = {
            "E4 . G4 . C5 . G4 . E5 . D5 . C5 . G4 .",
            "F#4 . A4 . D5 . A4 . F#5 . E5 . D5 . A4 .",
            "B4 . . D5 . . F#5 . . E5 . . D5 . B4 .",
            "E5 . . D5 . . B4 . . G4 . . A4 . B4 .",
            "C5 . C5 . E5 . C5 . D5 . D5 . B4 . G4 .",
            "A4 . A4 . D5 . A4 . F#5 . E5 . D5 . C5 .",
            "B4 . D5 . G4 . B4 . D5 . . . E5 . F#5 .",
            "D5 . . B4 . . G4 . A4 . B4 . D5 . . ."};

    private static final EnumMap<Track, List<List<Note>>> SONGS = new EnumMap<>(Track.class);

    static {
        Song battle = new Song();
        section(battle, 0, A_CHORDS, A_LEAD, false, false);
        section(battle, 8, B_CHORDS, B_LEAD, false, false);
        section(battle, 16, A_CHORDS, A_LEAD, true, false);
        section(battle, 24, B_CHORDS, B_LEAD, true, false);
        SONGS.put(Track.BATTLE, battle.done(32 * BAR));

        Song last = new Song();
        section(last, 0, B_CHORDS, B_LEAD, true, true);
        section(last, 8, A_CHORDS, A_LEAD, true, true);
        SONGS.put(Track.FINAL_MINUTE, last.done(16 * BAR));

        // Ranked: the B section leads, with bells from the start for a tenser feel.
        Song ranked = new Song();
        section(ranked, 0, B_CHORDS, B_LEAD, true, false);
        section(ranked, 8, A_CHORDS, A_LEAD, false, false);
        section(ranked, 16, B_CHORDS, B_LEAD, true, true);
        section(ranked, 24, A_CHORDS, A_LEAD, true, false);
        SONGS.put(Track.RANKED_BATTLE, ranked.done(32 * BAR));

        // Overtime: the driving groove over the B section only, looping every eight bars.
        Song overtime = new Song();
        section(overtime, 0, B_CHORDS, B_LEAD, true, true);
        for (int bar = 0; bar < 8; bar++) for (int step = 2; step < 16; step += 4) overtime.at(bar * BAR + step, Voice.PLING, 74, 0.18);
        SONGS.put(Track.OVERTIME, overtime.done(8 * BAR));

        SONGS.put(Track.COUNTDOWN, countdown());
        SONGS.put(Track.JUDGING, judging());
        SONGS.put(Track.VICTORY, victory());
        SONGS.put(Track.DEFEAT, defeat());
        SONGS.put(Track.DRAW, draw());
    }

    private SplatMusic() {}

    public static int length(Track track) { return SONGS.get(track).size(); }

    /** Notes on a step; looping tracks wrap, one-shot tracks go silent past their end. */
    public static List<Note> step(Track track, int step) {
        List<List<Note>> song = SONGS.get(track);
        if (track.loops) step = Math.floorMod(step, song.size());
        return step >= 0 && step < song.size() ? song.get(step) : List.of();
    }

    public static float pitch(Voice voice, int midi) {
        if (!voice.drum()) {
            while (midi < voice.lowest) midi += 12;
            while (midi > voice.lowest + 24) midi -= 12;
        }
        return (float) Math.pow(2, (midi - voice.lowest - 12) / 12.0);
    }

    static int midi(String name) {
        int semitone = switch (name.charAt(0)) {
            case 'C' -> 0; case 'D' -> 2; case 'E' -> 4; case 'F' -> 5; case 'G' -> 7; case 'A' -> 9; case 'B' -> 11;
            default -> throw new IllegalArgumentException("Bad note " + name);
        };
        int i = 1;
        if (name.charAt(i) == '#') { semitone++; i++; } else if (name.charAt(i) == 'b') { semitone--; i++; }
        return (Integer.parseInt(name.substring(i)) + 1) * 12 + semitone;
    }

    // ------------------------------------------------------------------ arrangement

    private static final int KICK = 60, SNARE = 66, HAT = 72;

    /** Eight bars of lead over off-beat guitar stabs, driving bass and drums; intense is the last-minute groove. */
    private static void section(Song s, int startBar, String[] chords, String[] lead, boolean bells, boolean intense) {
        for (int bar = 0; bar < 8; bar++) {
            int at = (startBar + bar) * BAR;
            Chord chord = CHORDS.get(chords[bar]);
            s.bar(at, Voice.BIT, 0.5, lead[bar], 0);
            if (bells) s.bar(at, Voice.BELL, 0.26, lead[bar], 12);
            int[] bass = intense ? new int[]{0, 12, 0, 12, 0, 12, 0, 12} : new int[]{0, 0, 7, 0, 0, 0, 7, 12};
            for (int i = 0; i < 8; i++) s.at(at + i * 2, Voice.BASS, chord.root() + bass[i], i % 4 == 0 ? 0.75 : 0.55);
            for (int step : new int[]{2, 6, 10, 14}) for (int n : chord.stab()) s.at(at + step, Voice.GUITAR, n, 0.26);
            boolean fill = bar == 7;
            if (intense) {
                for (int step = 0; step < 16; step += 4) s.at(at + step, Voice.KICK, KICK, 0.7);
                for (int step = 0; step < (fill ? 8 : 16); step++) s.at(at + step, Voice.HAT, HAT, step % 2 == 0 ? 0.26 : 0.14);
            } else {
                s.at(at, Voice.KICK, KICK, 0.75);
                s.at(at + 8, Voice.KICK, KICK, 0.7);
                s.at(at + 10, Voice.KICK, KICK, 0.4);
                for (int step = 0; step < (fill ? 8 : 16); step += 2) s.at(at + step, Voice.HAT, HAT, 0.2);
            }
            s.at(at + 4, Voice.SNARE, SNARE, 0.55);
            s.at(at + 12, Voice.SNARE, SNARE, 0.55);
            if (fill) for (int i = 8; i < 16; i++) s.at(at + i, Voice.SNARE, SNARE + i - 8, 0.25 + 0.05 * (i - 8));
        }
    }

    /** Ten-second riser on the dominant that lands exactly on "GO!". */
    private static List<List<Note>> countdown() {
        Song s = new Song();
        int[] arpeggio = {62, 66, 69, 74};
        for (int bar = 0; bar < 6; bar++) {
            int at = bar * BAR;
            for (int step = 0; step < 16; step += 4) s.at(at + step, Voice.BASS, 38, 0.6 + bar * 0.04);
            for (int step = 0; step < 16; step += 2) s.at(at + step, Voice.HAT, HAT, 0.12 + bar * 0.02);
            if (bar >= 2) {
                for (int step = 0; step < 16; step += 4) s.at(at + step, Voice.KICK, KICK, 0.6);
                int every = bar >= 4 ? 1 : 2;
                for (int step = 0, n = 0; step < 16; step += every, n++) s.at(at + step, Voice.PLING, arpeggio[n % 4], 0.22 + bar * 0.03);
            }
            if (bar == 4) for (int step = 0; step < 16; step += 2) s.at(at + step, Voice.SNARE, SNARE, 0.2 + step * 0.02);
            if (bar == 5) for (int step = 0; step < 16; step++) s.at(at + step, Voice.SNARE, SNARE + step / 2, 0.3 + step * 0.03);
        }
        s.bar(5 * BAR, Voice.BIT, 0.45, "A4 . B4 . C#5 . D5 . E5 . F#5 . . . . .", 0);
        return s.done(100);
    }

    private static List<List<Note>> judging() {
        Song s = new Song();
        int steps = SplatRules.JUDGING / STEP_TICKS;
        s.at(0, Voice.KICK, KICK, 0.8);
        for (int step = 0; step < steps - 2; step++) s.at(step, Voice.SNARE, SNARE, 0.15 + 0.65 * step / steps);
        for (int step = 0; step < steps - 2; step += 8) s.at(step, Voice.BASS, 38, 0.5);
        return s.done(steps);
    }

    private static List<List<Note>> victory() {
        Song s = new Song();
        s.bar(0, Voice.BIT, 0.55, "G4 . . G4 B4 . D5 . . . B4 . D5 . . .", 0);
        s.bar(0, Voice.BELL, 0.35, "G4 . . G4 B4 . D5 . . . B4 . D5 . . .", 12);
        s.bar(BAR, Voice.BIT, 0.55, "E5 . . E5 D5 . C5 . D5 . . . F#5 . . .", 0);
        s.bar(BAR, Voice.BELL, 0.35, "E5 . . E5 D5 . C5 . D5 . . . F#5 . . .", 12);
        s.bar(2 * BAR, Voice.BIT, 0.6, "G4+B4+D5 . . . . . . . . . . . . . . .", 0);
        s.bar(2 * BAR, Voice.CHIME, 0.4, "D6 B5 G5 D6 B5 G5 G6 . . . . . . . . .", 0);
        chordHit(s, 0, "G", 0.8);
        chordHit(s, 8, "G", 0.6);
        chordHit(s, BAR, "C", 0.7);
        chordHit(s, BAR + 8, "D", 0.7);
        chordHit(s, 2 * BAR, "G", 0.9);
        for (int step : new int[]{4, 12}) s.at(step, Voice.SNARE, SNARE, 0.5);
        for (int step = 8; step < 16; step++) s.at(BAR + step, Voice.SNARE, SNARE + step - 8, 0.3 + 0.05 * (step - 8));
        return s.done(3 * BAR);
    }

    private static List<List<Note>> defeat() {
        Song s = new Song();
        s.bar(0, Voice.BIT, 0.45, "D5 . . . . . C5 . . . . . Bb4 . . .", 0);
        s.bar(BAR, Voice.BIT, 0.45, "A4 . . . . . Bb4 . A4 . G4 . . . . .", 0);
        s.bar(2 * BAR, Voice.FLUTE, 0.4, "G4 . . . . . . . . . . . . . . .", 0);
        int[][] harmony = {{0, 31, 55, 58, 62}, {8, 39, 55, 58, 63}, {BAR, 36, 55, 60, 63}, {BAR + 8, 38, 54, 57, 62}, {2 * BAR, 31, 55, 58, 62}};
        for (int[] h : harmony) {
            s.at(h[0], Voice.BASS, h[1], 0.6);
            for (int i = 2; i < h.length; i++) s.at(h[0], Voice.GUITAR, h[i], 0.22);
            s.at(h[0], Voice.KICK, KICK, 0.4);
        }
        return s.done(3 * BAR);
    }

    private static List<List<Note>> draw() {
        Song s = new Song();
        s.bar(0, Voice.PLING, 0.45, "D5 . . . A4 . . . D5 . . . E5 . . .", 0);
        s.bar(BAR, Voice.PLING, 0.45, "D5 . . . . . . . . . . . . . . .", 0);
        chordHit(s, 0, "D", 0.6);
        chordHit(s, 8, "C", 0.6);
        chordHit(s, BAR, "D", 0.6);
        return s.done(2 * BAR);
    }

    private static void chordHit(Song s, int step, String name, double volume) {
        Chord chord = CHORDS.get(name);
        s.at(step, Voice.KICK, KICK, volume);
        s.at(step, Voice.BASS, chord.root(), volume);
        for (int n : chord.stab()) s.at(step, Voice.GUITAR, n, volume * 0.4);
    }

    private static final class Song {
        final List<List<Note>> steps = new ArrayList<>();

        void at(int step, Voice voice, int midi, double volume) {
            while (steps.size() <= step) steps.add(new ArrayList<>());
            steps.get(step).add(new Note(voice, pitch(voice, midi), (float) Math.min(1, volume)));
        }

        /** One bar of sixteenths: "." rests, "G4" notes and "G4+B4+D5" chords. */
        void bar(int start, Voice voice, double volume, String tokens, int transpose) {
            String[] parts = tokens.trim().split("\\s+");
            if (parts.length != BAR) throw new IllegalArgumentException("Bar needs " + BAR + " steps: " + tokens);
            for (int i = 0; i < parts.length; i++) {
                if (parts[i].equals(".")) continue;
                for (String note : parts[i].split("\\+")) at(start + i, voice, midi(note) + transpose, volume);
            }
        }

        List<List<Note>> done(int length) {
            if (steps.size() > length) throw new IllegalStateException("Song overruns " + length + " steps");
            while (steps.size() < length) steps.add(new ArrayList<>());
            return steps.stream().map(List::copyOf).toList();
        }
    }
}
