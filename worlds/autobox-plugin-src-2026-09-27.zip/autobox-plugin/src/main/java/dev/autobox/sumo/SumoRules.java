package dev.autobox.sumo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

/** Match timing and combat rules, shared with the headless gameplay checks. */
public final class SumoRules {
    public enum Mode {
        GAUNTLET("Gauntlet", "First to 3 rounds · new arena every round"),
        MARATHON("Marathon", "12 minutes · five lives · one arena");
        public final String label;
        public final String description;
        Mode(String label, String description) {
            this.label = label;
            this.description = description;
        }
    }

    // Marathon: the long single-arena match.
    public static final int MATCH_TICKS = 12 * 60 * 20;
    public static final int SUDDEN_DEATH_TICKS = 60 * 20;
    public static final int MAX_LIVES = 5;
    public static final int LIFE_CAP = 6;
    public static final int MAX_LEVEL = 5;
    // Gauntlet: short rounds, a new arena and twist each time.
    public static final int ROUND_WINS = 3;
    public static final int ROUND_LIVES = 2;
    public static final int ROUND_TICKS = 90 * 20;
    public static final int ROUND_SUDDEN_DEATH_TICKS = 30 * 20;
    public static final int MAX_ROUNDS = 9;
    public static final int INTERMISSION_TICKS = 130;
    public static final int VOTE_TICKS = 10 * 20;
    public static final int ROUND_COUNTDOWN_TICKS = 3 * 20;

    public static final int BOUNTY_STREAK = 3;
    public static final int WOOL_LIFETIME = 45 * 20;
    public static final int WOOL_WARNING = 5 * 20;
    public static final int METEOR_RADIUS_TENTHS = 32;
    public static final int ANVIL_RADIUS_TENTHS = 22;
    public static final int EVENT_LENGTH = 12 * 20;
    public static final int HEX_CRUMBLE_TICKS = 16;
    public static final int HEX_REGROW_TICKS = 25 * 20;
    public static final int CRATE_FALL_TICKS = 30;
    public static final int CRATE_LIFETIME = 15 * 20;
    private static final int EVENT_WARMUP = 30 * 20;
    private static final int EVENT_PERIOD = 40 * 20;
    private static final int GAUNTLET_EVENT_TICK = 30 * 20;
    private static final int[] MARATHON_COLLAPSES = {270 * 20, 450 * 20, 630 * 20};
    private static final int[] GAUNTLET_COLLAPSES = {40 * 20, 60 * 20, 75 * 20};
    private static final int[] HEART_TICKS = {180 * 20, 360 * 20, 540 * 20};

    public enum Event {
        CALM("Calm"), DOUBLE_CHARGE("DOUBLE CHARGE"), GALE("RIFT GALE"),
        SKY_RUSH("SKY RUSH"), METEOR_SHOWER("METEOR SHOWER"), POWER_SURGE("POWER SURGE"),
        LOW_GRAVITY("LOW GRAVITY"), ICE_AGE("ICE AGE"), ANVIL_RAIN("ANVIL RAIN"),
        SHUFFLE("SHUFFLE"), TORNADO("TORNADO");
        public final String label;
        Event(String label) { this.label = label; }
    }

    /** The mystery crate loot table; weights add up to 100. */
    public enum CrateItem {
        WIND_CHARGES("Wind Charges", 18), KNOCKBACK_FISH("Knockback Fish", 16), GRAPPLE("Grapple", 12),
        BRIDGE_EGG("Bridge Egg", 12), SWAP_ORB("Swap Orb", 10), BUBBLE_SHIELD("Bubble Shield", 12),
        BOOM_STICK("Boom Stick", 8), SECOND_WIND("Second Wind", 12);
        public final String label;
        public final int weight;
        CrateItem(String label, int weight) {
            this.label = label;
            this.weight = weight;
        }
    }

    public static int matchTicks(Mode mode) {
        return mode == Mode.GAUNTLET ? ROUND_TICKS : MATCH_TICKS;
    }
    public static int suddenDeathTicks(Mode mode) {
        return mode == Mode.GAUNTLET ? ROUND_SUDDEN_DEATH_TICKS : SUDDEN_DEATH_TICKS;
    }
    public static int startLives(Mode mode) {
        return mode == Mode.GAUNTLET ? ROUND_LIVES : MAX_LIVES;
    }
    private static int[] collapses(Mode mode) {
        return mode == Mode.GAUNTLET ? GAUNTLET_COLLAPSES : MARATHON_COLLAPSES;
    }

    /** True on the tick an arena event window opens; the window lasts {@link #EVENT_LENGTH}. */
    public static boolean eventStarts(Mode mode, int roundTicks) {
        if (mode == Mode.GAUNTLET) return roundTicks == GAUNTLET_EVENT_TICK;
        if (roundTicks < EVENT_WARMUP || (roundTicks - EVENT_WARMUP) % EVENT_PERIOD != 0) return false;
        // Never start an event that would be cut off by time-up.
        return roundTicks + EVENT_LENGTH <= MATCH_TICKS;
    }
    /** Which events make sense for this mode, arena and twist. */
    public static boolean eventAllowed(Event event, Mode mode, SumoArena.Kind arena, SumoMutator mutator) {
        return switch (event) {
            case CALM -> false;
            case DOUBLE_CHARGE -> mode == Mode.MARATHON;
            case LOW_GRAVITY -> mutator != SumoMutator.LOW_GRAVITY && mutator != SumoMutator.MOON_SHOES
                    && arena != SumoArena.Kind.BOUNCE;
            case ICE_AGE -> arena != SumoArena.Kind.FROSTBITE;
            default -> true;
        };
    }
    public static int vaultCooldown(int level, Event event) {
        return event == Event.SKY_RUSH ? 80 : level >= 2 ? 120 : 200;
    }
    public static boolean recentHit(int now, int hitTick) {
        return hitTick >= 0 && now >= hitTick && now - hitTick <= 160;
    }
    public static int comebackLevel(int level, int leader) {
        return leader - level >= 2 ? Math.min(4, level + 1) : level;
    }
    /** Index of the collapse that happens exactly on this tick, or -1. */
    public static int collapseIndex(Mode mode, int tick) {
        int[] ticks = collapses(mode);
        for (int i = 0; i < ticks.length; i++) if (ticks[i] == tick) return i;
        return -1;
    }
    public static int nextCollapseIndex(Mode mode, int tick) {
        int[] ticks = collapses(mode);
        for (int i = 0; i < ticks.length; i++) if (tick < ticks[i]) return i;
        return -1;
    }
    public static int nextCollapseTick(Mode mode, int tick) {
        int index = nextCollapseIndex(mode, tick);
        return index < 0 ? -1 : collapses(mode)[index];
    }
    public static int collapseCount() {
        return MARATHON_COLLAPSES.length;
    }
    /** Knockback bonus starts with the final collapse. */
    public static boolean isOverdrive(Mode mode, int roundTicks) {
        int[] ticks = collapses(mode);
        return roundTicks >= ticks[ticks.length - 1];
    }
    public static boolean isHeartTick(Mode mode, int roundTicks) {
        if (mode != Mode.MARATHON) return false;
        for (int heart : HEART_TICKS) if (heart == roundTicks) return true;
        return false;
    }
    public static int nextHeartTick(Mode mode, int roundTicks) {
        if (mode != Mode.MARATHON) return -1;
        for (int heart : HEART_TICKS) if (roundTicks < heart) return heart;
        return -1;
    }
    /** Energy spheres belong to the long match; Gauntlet rounds run on crates. */
    public static boolean isSphereTick(Mode mode, int roundTicks) {
        return mode == Mode.MARATHON && roundTicks >= 10 * 20 && (roundTicks - 10 * 20) % (15 * 20) == 0;
    }
    public static boolean isCrateTick(Mode mode, int roundTicks) {
        int first = mode == Mode.GAUNTLET ? 12 * 20 : 15 * 20;
        return roundTicks >= first && (roundTicks - first) % (20 * 20) == 0 && roundTicks < matchTicks(mode);
    }
    public static CrateItem crateRoll(int roll) {
        int left = Math.floorMod(roll, 100);
        for (CrateItem item : CrateItem.values()) {
            if (left < item.weight) return item;
            left -= item.weight;
        }
        return CrateItem.WIND_CHARGES;
    }
    /** Later upgrades take longer to hold, so a long match does not max everyone out early. */
    public static int captureTicks(int level) {
        return 50 + 10 * Math.max(0, Math.min(level, MAX_LEVEL));
    }
    public static String streakCallout(int streak) {
        return switch (streak) {
            case 2 -> "DOUBLE KNOCKOUT";
            case BOUNTY_STREAK -> "RAMPAGE";
            case 5 -> "UNSTOPPABLE";
            case 7 -> "GODLIKE";
            default -> null;
        };
    }
    /** Blast push strength at a horizontal distance from impact; zero outside the blast. */
    public static double meteorPush(double distance, int radiusTenths) {
        double radius = radiusTenths / 10.0;
        if (distance > radius) return 0;
        return 0.75 + 0.6 * (1 - distance / radius);
    }
    public static double meteorPush(double distance) {
        return meteorPush(distance, METEOR_RADIUS_TENTHS);
    }
    /** Sweeper arm speed in degrees per tick: it spins up across the round. */
    public static double sweeperSpeed(Mode mode, int roundTicks) {
        double progress = Math.max(0, Math.min(1, roundTicks / (double) matchTicks(mode)));
        return 1.4 + 1.6 * progress;
    }
    public static Mode resolveVote(int gauntletVotes, int marathonVotes, int players) {
        if (gauntletVotes > marathonVotes) return Mode.GAUNTLET;
        if (marathonVotes > gauntletVotes) return Mode.MARATHON;
        return gauntletVotes == 0 && players >= 5 ? Mode.MARATHON : Mode.GAUNTLET;
    }
    public static boolean gauntletOver(int bestRoundWins, int roundsPlayed) {
        return bestRoundWins >= ROUND_WINS || roundsPlayed >= MAX_ROUNDS;
    }

    /**
     * Launch velocity {x, y, z} that carries a player from a pad to a target {@code dy} blocks higher and
     * ({@code dx}, {@code dz}) away, using the client's airborne physics: gravity 0.08, vertical drag 0.98,
     * horizontal drag 0.91 per tick.
     */
    public static double[] padLaunch(double dx, double dy, double dz) {
        double horizontal = Math.hypot(dx, dz);
        double vy = 0.6;
        while (apex(vy) < dy + 1.5 && vy < 3) vy += 0.02;
        int ticks = landingTick(vy, dy);
        double speed = horizontal * 0.09 / (1 - Math.pow(0.91, ticks));
        if (horizontal < 0.01) return new double[]{0, vy, 0};
        return new double[]{speed * dx / horizontal, vy, speed * dz / horizontal};
    }
    public static double apex(double vy) {
        double y = 0;
        double best = 0;
        for (int tick = 0; tick < 200 && vy > 0; tick++) {
            y += vy;
            vy = (vy - 0.08) * 0.98;
            best = Math.max(best, y);
        }
        return best;
    }
    /** The tick on which a jump with this vertical speed comes back down through {@code dy}. */
    public static int landingTick(double vy, double dy) {
        double y = 0;
        for (int tick = 1; tick < 400; tick++) {
            y += vy;
            vy = (vy - 0.08) * 0.98;
            if (vy < 0 && y <= dy) return tick;
        }
        return 400;
    }

    /**
     * Deals every item once, in a random order, before any repeats; the first draw after a refill is never
     * the previous draw. Draws skip items the filter rejects and leave them in the bag.
     */
    public static final class ShuffleBag<T> {
        private final List<T> items;
        private final Random random;
        private final List<T> bag = new ArrayList<>();
        private T last;

        public ShuffleBag(List<T> items, Random random) {
            this.items = List.copyOf(items);
            this.random = random;
        }

        public T next(Predicate<T> allowed) {
            for (int pass = 0; pass < 2; pass++) {
                if (bag.stream().noneMatch(allowed)) refill();
                for (int i = 0; i < bag.size(); i++) {
                    T item = bag.get(i);
                    if (!allowed.test(item) || (item.equals(last) && items.size() > 1 && otherAllowed(item, allowed))) {
                        continue;
                    }
                    bag.remove(i);
                    last = item;
                    return item;
                }
                bag.clear();
            }
            return null;
        }

        private boolean otherAllowed(T item, Predicate<T> allowed) {
            return items.stream().anyMatch(other -> !other.equals(item) && allowed.test(other));
        }

        private void refill() {
            bag.clear();
            bag.addAll(items);
            Collections.shuffle(bag, random);
            if (bag.size() > 1 && bag.getFirst().equals(last)) {
                Collections.swap(bag, 0, 1 + random.nextInt(bag.size() - 1));
            }
        }
    }

    private SumoRules() { }
}
