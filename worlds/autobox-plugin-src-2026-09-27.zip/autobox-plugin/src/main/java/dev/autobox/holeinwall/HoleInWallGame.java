package dev.autobox.holeinwall;

import dev.autobox.util.Sidebar;
import dev.autobox.AutoBoxPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Difficulty;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.util.Vector;
import org.bukkit.util.BoundingBox;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.Map;
import java.util.HashMap;

public final class HoleInWallGame {
    public static final String WORLD_NAME = "hole_in_the_wall_arena";

    private static final int PLATFORM_Y = 100;
    private static final int PLATFORM_SIZE = 11;
    private static final int PLATFORM_RADIUS = PLATFORM_SIZE / 2; // 5
    private static final int CENTER_X = 0;
    private static final int CENTER_Z = 0;

    private static final Material PLATFORM_MATERIAL = Material.LIME_CONCRETE;
    private static final Material WALL_MATERIAL = Material.CYAN_CONCRETE;
    private static final int WALL_WIDTH = WallCourse.WIDTH;
    private static final int WALL_HEIGHT = WallCourse.HEIGHT;
    private static final int WALL_START_Z = -15;
    private static final int WALL_END_Z = 15;
    private static final int WALL_SPAWN_INTERVAL = 45; // short reset, then straight back into play
    private static final int WALL_SPAWN_INTERVAL_RUSH = 25;
    private static final int TWIST_INTERVAL = 400; // 20 seconds

    private enum Twist {
        SPEED("SPEED BOOST!", "Everyone got Speed II for 10 seconds!", NamedTextColor.AQUA),
        JUMP_BOOST("BOUNCY!", "Jump Boost II for 12 seconds!", NamedTextColor.GREEN),
        SWAP("SHUFFLE!", "Everyone swapped positions!", NamedTextColor.YELLOW),
        RUSH("RUSH HOUR!", "The next 4 walls speed up!", NamedTextColor.GOLD),
        TINY_HOLES("TINY HOLES!", "The next walls have smaller gaps!", NamedTextColor.WHITE);

        final String title;
        final String subtitle;
        final NamedTextColor color;
        Twist(String title, String subtitle, NamedTextColor color) {
            this.title = title;
            this.subtitle = subtitle;
            this.color = color;
        }
    }

    private final AutoBoxPlugin plugin;
    private final World world;
    private final Location lobby;
    private final Random random = new Random();

    private final Set<UUID> players = new HashSet<>();
    private final Set<Location> platformBlocks = new HashSet<>();
    private final Set<Location> wallBlocks = new HashSet<>();
    private final Set<UUID> caughtByCurrentWall = new HashSet<>();
    private final Set<UUID> rescuedThisWall = new HashSet<>();
    private final Map<UUID, Integer> lives = new HashMap<>();
    private final Map<UUID, Integer> points = new HashMap<>();
    private final Map<UUID, Integer> streaks = new HashMap<>();
    private final List<Entity> activeMobs = new ArrayList<>();

    private boolean running;
    private Sidebar sidebar;
    private boolean ending;
    private int direction;
    private String patternName = "BIG DOOR";
    private boolean currentRush;
    private static final String[] DIRECTIONS = {"NORTH ↓", "EAST ←", "SOUTH ↑", "WEST →"};
    private int ticks;
    private int ticksSinceLastWall;
    private int twistTicks;
    private int wallsPassed;
    private int wallZ;
    private boolean wallActive;
    private boolean[][] currentPattern;
    private int fastWallsRemaining;
    private int tinyHolesRemaining;
    private Twist lastTwist;
    private BukkitTask task;
    private BukkitTask finishTask;

    public HoleInWallGame(AutoBoxPlugin plugin, World world, Location lobby) {
        this.plugin = plugin;
        this.world = world;
        this.lobby = lobby;
        this.wallZ = WALL_START_Z;
        this.wallActive = false;
        this.world.setDifficulty(Difficulty.PEACEFUL);
    }

    public void start(CommandSender sender, List<Player> roster) {
        if (running) {
            sender.sendMessage(Component.text("Hole in the Wall is already running.", NamedTextColor.RED));
            return;
        }
        List<Player> online = roster.stream().filter(Player::isOnline).limit(6).toList();
        if (online.size() < 2) {
            sender.sendMessage(Component.text("Need at least 2 players to start Hole in the Wall.", NamedTextColor.RED));
            return;
        }
        resetArena();
        buildPlatform();
        players.clear();
        lives.clear();
        points.clear();
        streaks.clear();
        rescuedThisWall.clear();
        lastTwist = null;
        ending = false;
        direction = 0;
        activeMobs.clear();
        ticks = 0;
        ticksSinceLastWall = -35; // four seconds to read the rules and find your footing
        twistTicks = TWIST_INTERVAL;
        wallsPassed = 0;
        wallActive = false;
        wallZ = WALL_START_Z;
        fastWallsRemaining = 0;
        tinyHolesRemaining = 0;
        currentPattern = null;
        running = true;

        List<Location> spawns = generateSpawns(online.size());
        for (int i = 0; i < online.size(); i++) {
            Player player = online.get(i);
            players.add(player.getUniqueId());
            lives.put(player.getUniqueId(), 3);
            preparePlayer(player);
            player.teleport(spawns.get(i));
            player.sendTitle("§a§lHOLE IN THE WALL", "§f3 lives · 24 walls · follow the direction warning", 5, 60, 5);
        }
        broadcast(Component.text("Walls come from all four sides! Clean dodges build a score streak. Jump when you see JUMP GATE. Last survivor wins; at wall 24, lives then score decide!", NamedTextColor.GREEN));
        updateScoreboard();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public boolean isRunning() {
        return running;
    }

    public boolean isPlaying(Player player) {
        return running && players.contains(player.getUniqueId());
    }

    public boolean isWorld(Player player) {
        return player.getWorld() == world;
    }

    public boolean isWorld(World w) {
        return w == world;
    }

    public Location getSpectateLocation() {
        return new Location(world, CENTER_X + 0.5, PLATFORM_Y + 14, CENTER_Z + 0.5, 0, 45);
    }

    public void handleQuit(Player player) {
        UUID id = player.getUniqueId();
        if (!players.remove(id)) {
            return;
        }
        // Return to lobby handled by LobbyManager, but ensure scoreboard update and check end
        if (running && players.size() <= 1) {
            checkEnd();
        }
        updateScoreboard();
    }

    public void endGame() {
        if (!running) {
            return;
        }
        running = false;
        if (finishTask != null) {
            finishTask.cancel();
            finishTask = null;
        }
        if (task != null) {
            task.cancel();
            task = null;
        }
        for (Player player : new ArrayList<>(world.getPlayers())) {
            resetPlayer(player);
            player.teleport(lobby);
        }
        players.clear();
        clearMobs();
        resetArena();
    }

    public void shutdown() {
        if (finishTask != null) {
            finishTask.cancel();
            finishTask = null;
        }
        if (task != null) {
            task.cancel();
            task = null;
        }
        running = false;
        clearMobs();
        resetArena();
    }

    private void tick() {
        if (!running || ending) return;
        ticks++;
        twistTicks--;
        ticksSinceLastWall++;

        // Check falls
        for (UUID id : new ArrayList<>(players)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) continue;
            if (player.getWorld() != world) continue;
            if (player.getGameMode() == GameMode.SPECTATOR) continue;
            if (player.getLocation().getY() < PLATFORM_Y - 6) {
                loseLife(player);
                if (ending) return;
                continue;
            }
        }

        // Walls
        if (wallActive) {
            int moveInterval = WallCourse.moveInterval(wallsPassed, currentRush);
            if (ticks % moveInterval == 0) {
                wallZ++;
                if (wallZ > WALL_END_Z) {
                    clearWall();
                    wallActive = false;
                    wallsPassed++;
                    awardDodges();
                    if (currentRush) fastWallsRemaining = Math.max(0, fastWallsRemaining - 1);
                    ticksSinceLastWall = 0;
                    if (wallsPassed >= WallCourse.FINAL_WAVE) {
                        finishCourse();
                        return;
                    }
                    updateScoreboard();
                } else {
                    placeWallAt(wallZ);
                    checkWallCollisions();
                }
            } else {
                // Even if not moving, still check collisions for wall staying at same Z for multiple ticks
                // This ensures players can't phase through if they move into wall between moves
                checkWallCollisions();
            }
        } else {
            // Twists only happen during the reset, never during a player's dodge.
            if (twistTicks <= 0) {
                twistTicks = TWIST_INTERVAL;
                fireTwist();
            }
            int spawnInterval = fastWallsRemaining > 0 ? WALL_SPAWN_INTERVAL_RUSH : WALL_SPAWN_INTERVAL;
            if (ticksSinceLastWall >= spawnInterval) {
                spawnWall();
            }
        }

        // Periodic scoreboard and action bar
        if (ticks % 10 == 0) {
            for (UUID id : players) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && p.isOnline() && p.getWorld() == world) {
                    p.sendActionBar(Component.text("♥ " + lives.getOrDefault(id, 0) + "  |  "
                            + (wallActive ? DIRECTIONS[direction] + " · " + patternName : "Next wall soon")
                            + "  |  Streak " + streaks.getOrDefault(id, 0) + "  |  " + points.getOrDefault(id, 0) + " pts", NamedTextColor.YELLOW));
                }
            }
        }
        if (ticks % 20 == 0) {
            updateScoreboard();
        }
    }

    private void spawnWall() {
        wallZ = WALL_START_Z;
        wallActive = true;
        // The opening two walls teach the gap; subsequent walls never repeat a direction.
        if (wallsPassed >= 2) direction = (direction + 1 + random.nextInt(3)) % 4;
        currentRush = fastWallsRemaining > 0;
        WallCourse.Pattern pattern = WallCourse.pattern(random, wallsPassed + 1, tinyHolesRemaining > 0);
        currentPattern = pattern.solid();
        patternName = pattern.name();
        if (tinyHolesRemaining > 0) tinyHolesRemaining--;
        caughtByCurrentWall.clear();
        rescuedThisWall.clear();
        placeWallAt(wallZ);
        ticksSinceLastWall = 0;
        // Play sound to warn
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                Location source = new Location(world, WallCourse.x(direction, 0, -8) + 0.5,
                        PLATFORM_Y + 2, WallCourse.z(direction, 0, -8) + 0.5);
                p.playSound(source, Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.2f);
                p.sendTitle("§b" + DIRECTIONS[direction], "§f" + patternName + " · Wall " + (wallsPassed + 1), 0, 30, 5);
            }
        }
    }

    private void placeWallAt(int z) {
        clearWall();
        if (currentPattern == null) return;
        int startX = CENTER_X - WALL_WIDTH / 2;
        for (int lx = 0; lx < WALL_WIDTH; lx++) {
            int x = WallCourse.x(direction, startX + lx, z);
            int worldZ = WallCourse.z(direction, startX + lx, z);
            for (int ly = 0; ly < WALL_HEIGHT; ly++) {
                if (!currentPattern[lx][ly]) continue; // hole
                int y = PLATFORM_Y + 1 + ly;
                Location loc = new Location(world, x, y, worldZ);
                // Only place if within world height and not overlapping platform (platform at PLATFORM_Y)
                Material material = wallMaterial(lx, ly);
                world.getBlockAt(x, y, worldZ).setType(material, false);
                wallBlocks.add(loc);
            }
        }
        // Optional particles along wall edges
        if (ticks % 5 == 0) {
            Location center = new Location(world, WallCourse.x(direction, 0, z) + 0.5,
                    PLATFORM_Y + 2, WallCourse.z(direction, 0, z) + 0.5);
            world.spawnParticle(Particle.CLOUD, center, 8, WALL_WIDTH / 2.0, 1, 0.2, 0.01);
        }
    }

    private Material wallMaterial(int x, int y) {
        // Light the solid blocks bordering a cut-out so the safe route reads at a glance.
        if ((x > 0 && !currentPattern[x - 1][y])
                || (x + 1 < WALL_WIDTH && !currentPattern[x + 1][y])
                || (y > 0 && !currentPattern[x][y - 1])
                || (y + 1 < WALL_HEIGHT && !currentPattern[x][y + 1])) {
            return Material.SEA_LANTERN;
        }
        if (x == 0 || x == WALL_WIDTH - 1 || y == WALL_HEIGHT - 1) {
            return Material.BLACK_CONCRETE;
        }
        return (x + y) % 2 == 0 ? WALL_MATERIAL : Material.LIGHT_BLUE_CONCRETE;
    }

    private void clearWall() {
        for (Location loc : wallBlocks) {
            loc.getBlock().setType(Material.AIR, false);
        }
        wallBlocks.clear();
    }

    private void checkWallCollisions() {
        for (UUID id : new ArrayList<>(players)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline() || player.getWorld() != world) continue;
            if (player.getGameMode() == GameMode.SPECTATOR) continue;
            if (rescuedThisWall.contains(id)) continue;
            Location loc = player.getLocation();
            BoundingBox body = player.getBoundingBox();
            boolean hit = false;
            for (Location block : wallBlocks) {
                // Include the approaching face so ordinary block collision cannot pin a
                // player in place before our knockback is applied. Actual body height
                // handles jumping and crouching without head-clipping false negatives.
                BoundingBox solid = new BoundingBox(block.getX(), block.getY(), block.getZ(),
                        block.getX() + 1, block.getY() + 1, block.getZ() + 1).expand(0.06, 0, 0.06);
                if (body.overlaps(solid)) {
                    hit = true;
                    break;
                }
            }
            if (hit) {
                boolean firstHit = caughtByCurrentWall.add(id);
                int dx = WallCourse.x(direction, 0, 1);
                int dz = WallCourse.z(direction, 0, 1);
                Vector push = new Vector(dx * 1.05, 0.32, dz * 1.05);
                Location clear = loc.clone();
                if (dx != 0) clear.setX(0.5 + dx * (wallZ + 0.87));
                if (dz != 0) clear.setZ(0.5 + dz * (wallZ + 0.87));
                player.teleport(clear);
                if (firstHit) {
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        if (running && !ending && player.isOnline() && player.getWorld() == world
                                && players.contains(id) && !rescuedThisWall.contains(id)) {
                            player.setVelocity(push);
                            player.setFallDistance(0);
                        }
                    });
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1f, 0.8f);
                    world.spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation().add(0, 0.4, 0), 18, 0.4, 0.3, 0.4, 0.08);
                    player.sendActionBar(Component.text("MISSED! The wall caught you!", NamedTextColor.RED, TextDecoration.BOLD));
                }
            }
        }
    }

    private void fireTwist() {
        Twist choice;
        do {
            choice = Twist.values()[random.nextInt(Twist.values().length)];
        } while (choice == lastTwist && Twist.values().length > 1);
        lastTwist = choice;

        broadcast(Component.text("TWIST - " + choice.title, choice.color, TextDecoration.BOLD));
        broadcast(Component.text(choice.subtitle, NamedTextColor.GRAY));
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.sendTitle("§d§l" + choice.title, "§7" + choice.subtitle, 5, 45, 10);
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 1.6f);
            }
        }

        switch (choice) {
            case SPEED -> applyEffectAll(PotionEffectType.SPEED, 200, 1);
            case JUMP_BOOST -> applyEffectAll(PotionEffectType.JUMP_BOOST, 240, 1);
            case SWAP -> swapPositions();
            case RUSH -> {
                fastWallsRemaining = 4;
                broadcast(Component.text("Next 4 walls will be SUPER FAST!", NamedTextColor.RED));
            }
            case TINY_HOLES -> {
                tinyHolesRemaining = 3;
                broadcast(Component.text("Next 3 walls have tiny holes!", NamedTextColor.RED));
            }
        }
    }

    private void applyEffectAll(PotionEffectType type, int duration, int amp) {
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.addPotionEffect(new PotionEffect(type, duration, amp, false, true, true));
        }
    }

    private void swapPositions() {
        List<Player> alive = new ArrayList<>();
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline() && p.getWorld() == world) alive.add(p);
        }
        if (alive.size() < 2) return;
        List<Location> locs = alive.stream().map(Player::getLocation).toList();
        for (int i = 0; i < alive.size(); i++) {
            Player p = alive.get(i);
            Location target = locs.get((i + 1) % alive.size()).clone();
            target.setY(PLATFORM_Y + 1);
            target.setX(Math.max(-3.5, Math.min(3.5, target.getX())));
            target.setZ(Math.max(-3.5, Math.min(3.5, target.getZ())));
            p.teleport(target);
            p.setVelocity(new Vector());
            p.setFallDistance(0);
            world.spawnParticle(Particle.PORTAL, target.clone().add(0, 1, 0), 30, 0.3, 0.8, 0.3, 0.1);
            world.playSound(target, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        }
    }

    private void loseLife(Player player) {
        UUID id = player.getUniqueId();
        int remaining = lives.merge(id, -1, Integer::sum);
        streaks.put(id, 0);
        caughtByCurrentWall.add(id);
        if (remaining <= 0) {
            eliminate(player);
            return;
        }
        rescuedThisWall.add(id);
        // Respawn on the trailing side of an on-deck wall, clear of its solid face.
        int along = wallActive && wallZ >= -5 && wallZ <= 5 ? Math.max(-4, wallZ - 2) : 0;
        Location safe = new Location(world, WallCourse.x(direction, 0, along) + 0.5,
                PLATFORM_Y + 1, WallCourse.z(direction, 0, along) + 0.5);
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        player.teleport(safe);
        player.setVelocity(new Vector());
        player.setFallDistance(0);
        player.sendTitle("§c-1 LIFE", "§f" + remaining + " left · fresh start next wall", 0, 30, 5);
        player.playSound(safe, Sound.ENTITY_ENDERMAN_TELEPORT, 0.7f, 1.4f);
    }

    private void awardDodges() {
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (caughtByCurrentWall.contains(id)) {
                streaks.put(id, 0);
                continue;
            }
            int streak = streaks.merge(id, 1, Integer::sum);
            int reward = 10 + Math.min(5, streak - 1) * 2;
            points.merge(id, reward, Integer::sum);
            if (player != null) {
                player.sendTitle("§aCLEAN DODGE!", "§f+" + reward + " pts · Streak " + streak, 0, 20, 5);
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, Math.min(2f, 1f + streak * 0.1f));
            }
        }
    }

    private void finishCourse() {
        int bestLives = players.stream().mapToInt(id -> lives.getOrDefault(id, 0)).max().orElse(0);
        int bestScore = players.stream().filter(id -> lives.getOrDefault(id, 0) == bestLives)
                .mapToInt(id -> points.getOrDefault(id, 0)).max().orElse(0);
        List<String> winners = players.stream().filter(id -> lives.getOrDefault(id, 0) == bestLives
                        && points.getOrDefault(id, 0) == bestScore).map(Bukkit::getPlayer)
                .filter(java.util.Objects::nonNull).map(Player::getName).toList();
        ending = true;
        clearWall();
        broadcast(Component.text("Course complete! " + String.join(" & ", winners) + " won with "
                + bestLives + " lives and " + bestScore + " points!", NamedTextColor.GOLD));
        for (Player player : world.getPlayers()) {
            player.sendTitle("§6COURSE COMPLETE!", "§f" + String.join(" & ", winners) + " wins!", 5, 60, 10);
        }
        finishTask = Bukkit.getScheduler().runTaskLater(plugin, this::endGame, 60L);
    }

    private void eliminate(Player player) {
        UUID id = player.getUniqueId();
        if (!players.remove(id)) return;
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        player.setVelocity(new Vector());
        player.setFallDistance(0);
        // Spectate briefly then lobby: directly to lobby for now
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(lobby);
        player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        player.sendTitle("§c§lELIMINATED!", "§7You were knocked off!", 10, 50, 10);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_HURT, 1f, 0.8f);
        broadcast(Component.text(player.getName() + " was knocked off! " + players.size() + " remain!", NamedTextColor.RED));
        // Clear any mobs targeting?
        checkEnd();
        updateScoreboard();
    }

    private List<Location> generateSpawns(int count) {
        List<Location> spawns = new ArrayList<>();
        // Spread across platform in grid
        int[][] spots = {{-2, -2}, {2, -2}, {-2, 2}, {2, 2}, {0, 0}, {0, -3}, {0, 3}, {-3, 0}, {3, 0}};
        for (int i = 0; i < count; i++) {
            int x = spots[i % spots.length][0];
            int z = spots[i % spots.length][1];
            spawns.add(new Location(world, CENTER_X + x + 0.5, PLATFORM_Y + 1, CENTER_Z + z + 0.5, 180, 0));
        }
        return spawns;
    }

    private void preparePlayer(Player player) {
        player.closeInventory();
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        player.setGameMode(GameMode.ADVENTURE);
        player.setFireTicks(0);
        player.setFallDistance(0);
        player.setVelocity(new Vector());
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20);
        player.setExp(0);
        player.setLevel(0);
        player.setAllowFlight(false);
    }

    private void resetPlayer(Player player) {
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        player.setFireTicks(0);
        player.setFallDistance(0);
        player.setVelocity(new Vector());
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20);
        player.setLevel(0);
        player.setExp(0);
        player.setGameMode(GameMode.ADVENTURE);
        player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
    }

    private void buildPlatform() {
        for (int x = -PLATFORM_RADIUS; x <= PLATFORM_RADIUS; x++) {
            for (int z = -PLATFORM_RADIUS; z <= PLATFORM_RADIUS; z++) {
                // Shave the four corners into a game-show octagon.
                if (Math.abs(x) == PLATFORM_RADIUS && Math.abs(z) == PLATFORM_RADIUS) continue;
                Location loc = new Location(world, CENTER_X + x, PLATFORM_Y, CENTER_Z + z);
                boolean rim = Math.abs(x) == PLATFORM_RADIUS || Math.abs(z) == PLATFORM_RADIUS;
                boolean runwayLight = !rim && x == 0 && Math.abs(z) % 3 == 0;
                setArenaBlock(loc, rim ? Material.BLACK_CONCRETE
                        : runwayLight ? Material.SEA_LANTERN : PLATFORM_MATERIAL);

                // A layered neon underside makes the arena read as a floating stage.
                Location underside = loc.clone().subtract(0, 1, 0);
                setArenaBlock(underside, rim ? Material.LIME_CONCRETE : Material.LIME_STAINED_GLASS);
                // Clear above platform (2 air blocks)
                world.getBlockAt(CENTER_X + x, PLATFORM_Y + 1, CENTER_Z + z).setType(Material.AIR, false);
                world.getBlockAt(CENTER_X + x, PLATFORM_Y + 2, CENTER_Z + z).setType(Material.AIR, false);
            }
        }

        // Four illuminated pylons frame the wall track without giving players a railing.
        for (int x : new int[]{-7, 7}) {
            for (int z : new int[]{-13, 13}) {
                for (int y = PLATFORM_Y - 2; y <= PLATFORM_Y + 5; y++) {
                    Material material = y == PLATFORM_Y - 2 || y == PLATFORM_Y + 5
                            ? Material.SEA_LANTERN : Material.CYAN_STAINED_GLASS;
                    setArenaBlock(new Location(world, CENTER_X + x, y, CENTER_Z + z), material);
                }
            }
        }
    }

    private void setArenaBlock(Location location, Material material) {
        location.getBlock().setType(material, false);
        platformBlocks.add(location);
    }

    private void resetArena() {
        for (Location loc : platformBlocks) {
            loc.getBlock().setType(Material.AIR, false);
        }
        platformBlocks.clear();
        clearWall();
        clearMobs();
        // Clear any stray blocks in arena volume
        for (int x = -22; x <= 22; x++) {
            for (int z = -22; z <= 22; z++) {
                for (int y = PLATFORM_Y - 2; y <= PLATFORM_Y + 8; y++) {
                    // Sweep remnants from a reload during an animated wall.
                    Material type = world.getBlockAt(x, y, z).getType();
                    if (type == WALL_MATERIAL || type == Material.WHITE_CONCRETE
                            || type == Material.LIGHT_BLUE_CONCRETE || type == Material.BLACK_CONCRETE
                            || type == Material.SEA_LANTERN || type == Material.SLIME_BLOCK
                            || type == Material.LIME_CONCRETE || type == Material.LIME_STAINED_GLASS
                            || type == Material.CYAN_STAINED_GLASS) {
                        world.getBlockAt(x, y, z).setType(Material.AIR, false);
                    }
                }
            }
        }
    }

    private void clearMobs() {
        for (Entity e : new ArrayList<>(activeMobs)) {
            if (e.isValid()) e.remove();
        }
        activeMobs.clear();
        // Also sweep any remaining hostile mobs in world
        for (Entity e : world.getEntities()) {
            if (e instanceof LivingEntity && !(e instanceof Player)) {
                e.remove();
            }
        }
    }

    private void updateScoreboard() {
        if (!running) return;
        if (sidebar == null) {
            sidebar = new Sidebar("hole", Component.text("HOLE IN THE WALL", NamedTextColor.GREEN, TextDecoration.BOLD));
        }
        List<String> lines = new ArrayList<>();
        List<Integer> scores = new ArrayList<>();
        lines.add(ChatColor.YELLOW + (wallActive ? DIRECTIONS[direction] : "Get ready!"));
        scores.add(5);
        lines.add(ChatColor.AQUA + "Walls: " + wallsPassed + "/" + WallCourse.FINAL_WAVE);
        scores.add(4);
        lines.add(ChatColor.WHITE + "Alive: " + players.size());
        scores.add(3);
        lines.add(ChatColor.GRAY + "----------------");
        scores.add(2);
        int score = 1;
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                lines.add(ChatColor.GREEN + p.getName() + ChatColor.RED + " ♥" + lives.getOrDefault(id, 0)
                        + ChatColor.GOLD + " " + points.getOrDefault(id, 0));
                scores.add(score--);
                if (score < -10) break;
            }
        }
        sidebar.set(lines, scores);
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) sidebar.show(p);
        }
    }

    private void checkEnd() {
        if (!running || ending) return;
        if (players.size() <= 1) {
            ending = true;
            clearWall();
            clearMobs();
            if (players.size() == 1) {
                UUID winnerId = players.iterator().next();
                Player winner = Bukkit.getPlayer(winnerId);
                if (winner != null) {
                    broadcast(Component.text(winner.getName() + " wins Hole in the Wall! Last one standing!", NamedTextColor.GOLD, TextDecoration.BOLD));
                    winner.sendTitle("§a§lYOU WIN!", "§fLast one standing!", 10, 60, 10);
                    for (Player p : world.getPlayers()) {
                        p.sendTitle("§6§l" + winner.getName() + " WINS!", "§fHole in the Wall champion", 10, 60, 10);
                        p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                    }
                    spawnFireworks(getSpectateLocation());
                }
            } else {
                broadcast(Component.text("No one survived!", NamedTextColor.GRAY));
            }
            finishTask = Bukkit.getScheduler().runTaskLater(plugin, this::endGame, 60L);
        }
    }

    private void spawnFireworks(Location loc) {
        if (loc == null || loc.getWorld() == null) return;
        World w = loc.getWorld();
        for (int i = 0; i < 6; i++) {
            Location at = loc.clone().add((random.nextDouble() - 0.5) * 10, 2 + random.nextDouble() * 5, (random.nextDouble() - 0.5) * 10);
            w.spawn(at, org.bukkit.entity.Firework.class, fw -> {
                var meta = fw.getFireworkMeta();
                meta.addEffect(org.bukkit.FireworkEffect.builder().withColor(org.bukkit.Color.fromRGB(random.nextInt(0xFFFFFF))).with(org.bukkit.FireworkEffect.Type.BALL).trail(true).build());
                meta.setPower(1);
                fw.setFireworkMeta(meta);
            });
        }
    }

    private void broadcast(Component msg) {
        Component line = Component.text("[Hole in the Wall] ", NamedTextColor.GREEN).append(msg);
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.sendMessage(line);
        }
        // Also to spectators in world
        for (Player p : world.getPlayers()) {
            if (!players.contains(p.getUniqueId())) {
                p.sendMessage(line);
            }
        }
    }
}
