package dev.autobox.luckypillars;

import dev.autobox.AutoBoxPlugin;
import dev.autobox.luckypillars.PillarRules.Layout;
import dev.autobox.luckypillars.PillarRules.Pillar;
import dev.autobox.luckypillars.PillarRules.Twist;
import io.papermc.paper.event.entity.EntityPushedByEntityAttackEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Difficulty;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Wolf;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Lucky Pillars: everyone starts on their own bedrock pillar over the void and gets a random item every three
 * seconds. One twist per game changes the rules. Five minutes of chaos, then up to two minutes of deathmatch
 * while the border closes in on the golden crown in the middle. Last one standing wins.
 */
public final class LuckyPillarsGame implements Listener {
    public static final String WORLD_NAME = "lucky_pillars_arena";
    private static final int MAX_PLAYERS = 10;
    private static final double VANILLA_ATTACK_SPEED = 4.0;
    private static final double LOBBY_ATTACK_SPEED = 64.0;
    private static final int CLEAR_LAYERS_PER_TICK = 3;
    private static final Attribute[] TWIST_ATTRIBUTES = {
            Attribute.GRAVITY, Attribute.SAFE_FALL_DISTANCE, Attribute.SCALE, Attribute.MAX_HEALTH,
            Attribute.ENTITY_INTERACTION_RANGE, Attribute.BLOCK_INTERACTION_RANGE, Attribute.ATTACK_KNOCKBACK
    };

    private enum Phase { COUNTDOWN, MAIN, DEATHMATCH, OVER }

    private final AutoBoxPlugin plugin;
    private final World world;
    private final Location lobby;
    private final Random random = new Random();
    private final NamespacedKey twistKey;
    private final PillarRecords records;
    private final Map<UUID, String> roster = new LinkedHashMap<>();
    private final Set<UUID> alive = new LinkedHashSet<>();
    private final List<UUID> deathOrder = new ArrayList<>();
    private final Map<UUID, Integer> kills = new HashMap<>();
    private final Map<UUID, Integer> legendaries = new HashMap<>();
    private final Map<UUID, Integer> itemsRolled = new HashMap<>();
    private final Map<UUID, Integer> nextLoot = new HashMap<>();
    private final Map<UUID, Integer> lootSpan = new HashMap<>();
    private final Map<UUID, UUID> lastDamager = new HashMap<>();
    private final Map<UUID, Integer> lastDamageTick = new HashMap<>();
    private final Set<Long> protectedBlocks = new HashSet<>();
    private final Deque<Twist> recentTwists = new ArrayDeque<>();
    private final List<String> boardLines = new ArrayList<>();
    private boolean running;
    private BukkitTask task;
    private BukkitTask clearTask;
    private int clearY = Integer.MIN_VALUE;
    private Phase phase = Phase.COUNTDOWN;
    private int phaseTicks;
    private int ticks;
    private int mainElapsed;
    private int deathmatchElapsed;
    private Twist twist = Twist.SLIME_FLOOR;
    private Layout layout = Layout.RING;
    private Layout lastLayout;
    private int playerCount;
    private int lavaY;
    private static final int LAVA_PER_TICK = 400;
    private static final int MAX_MOBS = 24;
    private final java.util.ArrayDeque<int[]> lavaQueue = new java.util.ArrayDeque<>();
    private int mirrorNext;
    private Location pendingStrike;
    private int strikeAt;
    private UUID winner;
    private Scoreboard board;

    public LuckyPillarsGame(AutoBoxPlugin plugin, World world, Location lobby) {
        this.plugin = plugin;
        this.world = world;
        this.lobby = lobby.clone();
        this.twistKey = new NamespacedKey(plugin, "lucky_pillars_twist");
        this.records = new PillarRecords(plugin);
        world.setDifficulty(Difficulty.NORMAL);
        world.setGameRule(org.bukkit.GameRules.NATURAL_HEALTH_REGENERATION, true);
        // Leftovers from a crash or an older build get swept in the background.
        scheduleClear();
    }

    public void start(CommandSender sender, List<Player> requested) {
        if (running) {
            sender.sendMessage(Component.text("Lucky Pillars is already running.", NamedTextColor.RED));
            return;
        }
        List<Player> online = requested.stream().filter(Player::isOnline).distinct().limit(MAX_PLAYERS).toList();
        if (online.size() < 2) {
            sender.sendMessage(Component.text("Need at least 2 players for Lucky Pillars.", NamedTextColor.RED));
            return;
        }
        finishClearNow();
        roster.clear();
        alive.clear();
        deathOrder.clear();
        kills.clear();
        legendaries.clear();
        itemsRolled.clear();
        nextLoot.clear();
        lootSpan.clear();
        lastDamager.clear();
        lastDamageTick.clear();
        protectedBlocks.clear();
        boardLines.clear();
        board = null;
        pendingStrike = null;
        winner = null;
        ticks = 0;
        mainElapsed = 0;
        deathmatchElapsed = 0;
        playerCount = online.size();
        twist = PillarRules.pickTwist(random, recentTwists);
        recentTwists.addLast(twist);
        while (recentTwists.size() > PillarRules.RECENT_TWIST_MEMORY) {
            recentTwists.removeFirst();
        }
        layout = PillarRules.pickLayout(random, playerCount, lastLayout);
        lastLayout = layout;

        world.setTime(6000);
        world.setStorm(false);
        world.setThundering(false);
        world.setGameRule(org.bukkit.GameRules.NATURAL_HEALTH_REGENERATION, true);
        WorldBorder border = world.getWorldBorder();
        border.setCenter(0.5, 0.5);
        border.setSize(PillarRules.borderSize(layout, playerCount));
        border.setDamageAmount(1.0);
        border.setDamageBuffer(0);
        border.setWarningDistance(4);

        List<Pillar> pillars = PillarRules.pillars(layout, playerCount, random.nextDouble() * Math.PI * 2);
        buildCrown();
        for (Pillar pillar : pillars) {
            buildPillar(pillar);
        }
        List<Player> order = new ArrayList<>(online);
        java.util.Collections.shuffle(order, random);
        for (int i = 0; i < order.size(); i++) {
            Player player = order.get(i);
            UUID id = player.getUniqueId();
            roster.put(id, player.getName());
            alive.add(id);
            kills.put(id, 0);
            prepare(player);
            AttributeInstance attackSpeed = player.getAttribute(Attribute.ATTACK_SPEED);
            if (attackSpeed != null) {
                attackSpeed.setBaseValue(VANILLA_ATTACK_SPEED);
            }
            player.teleport(standOn(pillars.get(i)));
            player.setGameMode(GameMode.SURVIVAL);
        }
        running = true;
        phase = Phase.COUNTDOWN;
        phaseTicks = PillarRules.COUNTDOWN_TICKS;
        broadcast(Component.text("Everyone gets a random item every 3 seconds. Bridge over, knock people into the "
                + "void, last one standing wins. Stand on the golden crown in the middle for double loot.",
                NamedTextColor.YELLOW));
        broadcast(Component.text("5 minutes, then a 2 minute deathmatch while the border closes in. Map: ",
                NamedTextColor.GRAY).append(Component.text(layout.label, NamedTextColor.WHITE)));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public boolean isRunning() {
        return running;
    }

    public boolean isPlaying(Player player) {
        return running && roster.containsKey(player.getUniqueId());
    }

    public boolean isWorld(Player player) {
        return player.getWorld() == world;
    }

    public boolean isWorld(World other) {
        return other == world;
    }

    public Location getSpectateLocation() {
        int outer = PillarRules.outerRadius(layout, Math.max(2, playerCount));
        return new Location(world, 0.5, PillarRules.TOP_Y + 14, -outer - 12 + 0.5, 0, 35);
    }

    // ---------------------------------------------------------------- flow

    private void tick() {
        if (!running) {
            return;
        }
        ticks++;
        phaseTicks--;
        switch (phase) {
            case COUNTDOWN -> tickCountdown();
            case MAIN -> {
                mainElapsed++;
                tickLive();
                if (running && phase == Phase.MAIN && phaseTicks <= 0) {
                    beginDeathmatch();
                }
            }
            case DEATHMATCH -> {
                deathmatchElapsed++;
                tickLive();
                if (running && phase == Phase.DEATHMATCH) {
                    if (deathmatchElapsed == PillarRules.MID_BORDER_SECONDS * 20) {
                        world.getWorldBorder().changeSize(PillarRules.FINAL_BORDER,
                                PillarRules.DEATHMATCH_TICKS - PillarRules.MID_BORDER_SECONDS * 20L);
                        broadcast(Component.text("The border is closing on the crown!", NamedTextColor.RED, TextDecoration.BOLD));
                    }
                    if (phaseTicks <= 0) {
                        timeUp();
                    }
                }
            }
            case OVER -> {
                if (phaseTicks % 10 == 0) {
                    Player champion = winner == null ? null : Bukkit.getPlayer(winner);
                    Location around = champion != null && champion.getWorld() == world ? champion.getLocation()
                            : new Location(world, 0.5, PillarRules.TOP_Y + 4, 0.5);
                    double angle = random.nextDouble() * Math.PI * 2;
                    firework(around.clone().add(Math.cos(angle) * 3, 2, Math.sin(angle) * 3));
                }
                if (phaseTicks <= 0) {
                    endGame();
                    return;
                }
            }
        }
        if (running && ticks % 10 == 0) {
            updateScoreboard();
        }
    }

    private void tickCountdown() {
        int revealAt = 40;
        if (phaseTicks > revealAt && phaseTicks % 4 == 0) {
            Twist[] twists = Twist.values();
            Twist fake = twists[random.nextInt(twists.length)];
            float pitch = 0.6f + 1.2f * (1f - (phaseTicks - revealAt) / (float) (PillarRules.COUNTDOWN_TICKS - revealAt));
            forEachInWorld(player -> {
                player.sendTitle("§e§lLUCKY PILLARS", "§7Twist: §d" + fake.label, 0, 6, 0);
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.8f, pitch);
            });
        }
        if (phaseTicks == revealAt) {
            revealTwist();
        }
        if (phaseTicks < revealAt && phaseTicks > 0 && phaseTicks % 20 == 0) {
            int seconds = phaseTicks / 20;
            forEachInWorld(player -> {
                player.sendActionBar(Component.text("Starting in " + seconds + "...", NamedTextColor.YELLOW, TextDecoration.BOLD));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 0.8f + (3 - seconds) * 0.2f);
            });
        }
        if (phaseTicks <= 0) {
            beginMain();
        }
    }

    private void revealTwist() {
        forEachInWorld(player -> {
            player.sendTitle("§d§l" + twist.label, "§f" + twist.description, 0, 45, 10);
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        });
        broadcast(Component.text("Twist: ", NamedTextColor.GRAY)
                .append(Component.text(twist.label, NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD))
                .append(Component.text(" - " + twist.description, NamedTextColor.GRAY).decoration(TextDecoration.BOLD, false)));
        switch (twist) {
            case SLIME_FLOOR -> buildSlimeFloor();
            case THUNDERSTORM -> {
                world.setStorm(true);
                world.setThundering(true);
                world.setWeatherDuration(PillarRules.MAIN_TICKS + PillarRules.DEATHMATCH_TICKS + 1200);
                world.setThunderDuration(PillarRules.MAIN_TICKS + PillarRules.DEATHMATCH_TICKS + 1200);
            }
            case VAMPIRES -> world.setGameRule(org.bukkit.GameRules.NATURAL_HEALTH_REGENERATION, false);
            default -> {
            }
        }
    }

    private void beginMain() {
        phase = Phase.MAIN;
        phaseTicks = PillarRules.MAIN_TICKS;
        mirrorNext = ticks + PillarRules.lootInterval(twist, false, false);
        if (twist == Twist.RISING_LAVA) {
            lavaY = PillarRules.BOTTOM_Y - 1;
            lavaQueue.clear();
            raiseLavaTo(PillarRules.lavaLevel(0, 0));
        }
        for (UUID id : alive) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            applyTwist(player);
            giveLoot(player, LuckyLoot.rollStarter(random));
            scheduleLoot(id, PillarRules.lootInterval(twist, false, false));
            player.sendTitle("§a§lGO!", "§7Loot every " + PillarRules.lootInterval(twist, false, false) / 20.0 + "s", 0, 20, 8);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.4f);
        }
    }

    private void tickLive() {
        checkVoid();
        if (!running || (phase != Phase.MAIN && phase != Phase.DEATHMATCH)) {
            return;
        }
        boolean deathmatch = phase == Phase.DEATHMATCH;
        boolean mirrorDrop = false;
        if (twist == Twist.MIRROR_LOOT && ticks >= mirrorNext) {
            mirrorDrop = true;
            mirrorNext = ticks + PillarRules.lootInterval(twist, deathmatch, false);
        }
        LuckyLoot.Entry mirrored = mirrorDrop ? LuckyLoot.roll(random, PillarRules.lootBoost(twist, mainElapsed, deathmatch)) : null;
        for (UUID id : new ArrayList<>(alive)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            if (twist == Twist.MIRROR_LOOT) {
                if (mirrored != null) {
                    giveLoot(player, mirrored);
                }
                showLootBar(player, mirrorNext - ticks, PillarRules.lootInterval(twist, deathmatch, false));
                continue;
            }
            int due = nextLoot.getOrDefault(id, ticks);
            if (ticks >= due) {
                giveLoot(player, LuckyLoot.roll(random, PillarRules.lootBoost(twist, mainElapsed, deathmatch)));
                int interval = PillarRules.lootInterval(twist, deathmatch, onCrown(player));
                scheduleLoot(id, interval);
                due = ticks + interval;
            }
            showLootBar(player, due - ticks, lootSpan.getOrDefault(id, PillarRules.LOOT_INTERVAL));
        }
        if (ticks % 10 == 0) {
            Particle.DUST.builder().color(Color.fromRGB(0xFFD700), 1.4f)
                    .location(new Location(world, 0.5, PillarRules.TOP_Y + PillarRules.CROWN_RISE + 1.3, 0.5))
                    .count(6).offset(0.35, 0.2, 0.35).receivers(64, true).spawn();
        }
        tickTwist(deathmatch);
    }

    private void tickTwist(boolean deathmatch) {
        switch (twist) {
            case RISING_LAVA -> {
                pourLava();
                int target = PillarRules.lavaLevel(mainElapsed, deathmatchElapsed);
                if (target > lavaY) {
                    raiseLavaTo(target);
                    forEachInWorld(player -> player.sendActionBar(Component.text("The lava rises! (y " + lavaY + ")",
                            NamedTextColor.GOLD)));
                }
            }
            case TNT_RAIN -> {
                if (mainElapsed > 100 && ticks % PillarRules.tntRainInterval(alive.size()) == 0) {
                    Player target = randomAlive();
                    if (target != null) {
                        Location drop = target.getLocation().add(random.nextInt(7) - 3, 14, random.nextInt(7) - 3);
                        world.spawn(drop, TNTPrimed.class, tnt -> tnt.setFuseTicks(60));
                        world.playSound(drop, Sound.ENTITY_TNT_PRIMED, 1.5f, 0.8f);
                    }
                }
            }
            case METEOR_SHOWER -> {
                if (mainElapsed > 100 && ticks % PillarRules.METEOR_INTERVAL == 0) {
                    Player target = randomAlive();
                    if (target != null) {
                        Location aim = target.getLocation().add(random.nextInt(9) - 4, 0, random.nextInt(9) - 4);
                        Location from = aim.clone().add(random.nextInt(11) - 5, 28, random.nextInt(11) - 5);
                        Vector heading = aim.toVector().subtract(from.toVector()).normalize();
                        world.spawn(from, Fireball.class, fireball -> {
                            fireball.setDirection(heading);
                            fireball.setVelocity(heading.clone().multiply(0.6));
                            fireball.setYield(1.6f);
                            fireball.setIsIncendiary(false);
                        });
                        world.playSound(from, Sound.ENTITY_GHAST_SHOOT, 2f, 0.6f);
                    }
                }
            }
            case THUNDERSTORM -> tickLightning();
            case SHUFFLE -> {
                if (deathmatch || mainElapsed <= 0) {
                    return;
                }
                int into = mainElapsed % PillarRules.SHUFFLE_INTERVAL;
                if (into == PillarRules.SHUFFLE_INTERVAL - PillarRules.SHUFFLE_WARNING) {
                    forEachInWorld(player -> {
                        player.sendTitle("", "§dShuffling in 3...", 0, 30, 5);
                        player.playSound(player.getLocation(), Sound.BLOCK_PORTAL_TRIGGER, 0.4f, 1.6f);
                    });
                } else if (into == 0) {
                    shuffle();
                }
            }
            default -> {
            }
        }
        if (ticks % 40 == 0) {
            // Fireballs that miss keep flying forever; don't let them pile up under the arena.
            for (Fireball fireball : world.getEntitiesByClass(Fireball.class)) {
                if (fireball.getLocation().getY() < PillarRules.SWEEP_MIN_Y || fireball.getTicksLived() > 400) {
                    fireball.remove();
                }
            }
        }
    }

    private void tickLightning() {
        if (pendingStrike != null && ticks >= strikeAt) {
            world.strikeLightning(pendingStrike);
            pendingStrike = null;
        }
        if (pendingStrike != null) {
            if (ticks % 3 == 0) {
                Particle.ELECTRIC_SPARK.builder().location(pendingStrike.clone().add(0, 1, 0)).count(12)
                        .offset(0.4, 1, 0.4).receivers(64, true).spawn();
            }
            return;
        }
        if (mainElapsed > 100 && ticks % PillarRules.LIGHTNING_INTERVAL == 0) {
            Player target = randomAlive();
            if (target != null) {
                // Aim near the player and warn with sparks for a second, so a quick step saves you.
                pendingStrike = target.getLocation().add(random.nextInt(5) - 2, 0, random.nextInt(5) - 2);
                strikeAt = ticks + 20;
                world.playSound(pendingStrike, Sound.BLOCK_BEACON_POWER_SELECT, 1.2f, 1.8f);
            }
        }
    }

    private void shuffle() {
        List<Player> players = new ArrayList<>();
        for (UUID id : alive) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                players.add(player);
            }
        }
        if (players.size() < 2) {
            return;
        }
        List<Location> spots = players.stream().map(Player::getLocation).toList();
        int shift = PillarRules.shuffleShift(random, players.size());
        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);
            Location spot = spots.get((i + shift) % players.size()).clone();
            spot.setYaw(player.getLocation().getYaw());
            spot.setPitch(player.getLocation().getPitch());
            player.teleport(spot);
            player.setFallDistance(0);
            player.playSound(spot, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
        }
        broadcast(Component.text("SHUFFLE! Everyone swapped places.", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
    }

    private void beginDeathmatch() {
        if (alive.size() <= 1) {
            finishMatch(alive.isEmpty() ? lastDeath() : alive.iterator().next());
            return;
        }
        phase = Phase.DEATHMATCH;
        phaseTicks = PillarRules.DEATHMATCH_TICKS;
        buildDeathmatchPlatform();
        WorldBorder border = world.getWorldBorder();
        border.changeSize(PillarRules.MID_BORDER, PillarRules.MID_BORDER_SECONDS * 20L);
        for (UUID id : alive) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            player.setGlowing(true);
            give(player, List.of(new ItemStack(Material.WHITE_WOOL, 32)));
            scheduleLoot(id, PillarRules.lootInterval(twist, true, false));
        }
        forEachInWorld(player -> {
            player.sendTitle("§4§lDEATHMATCH", "§fThe border is closing. Get to the crown!", 5, 50, 10);
            player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.6f, 1f);
        });
        broadcast(Component.text("DEATHMATCH! Everyone glows, loot comes every 2 seconds and the border shrinks "
                + "to the crown. Here's 32 wool to get there.", NamedTextColor.DARK_RED, TextDecoration.BOLD));
    }

    private void timeUp() {
        UUID best = null;
        double bestHealth = -1;
        for (UUID id : alive) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            double health = player.getHealth() + player.getAbsorptionAmount();
            if (health > bestHealth || (health == bestHealth && best != null
                    && kills.getOrDefault(id, 0) > kills.getOrDefault(best, 0))) {
                best = id;
                bestHealth = health;
            }
        }
        broadcast(Component.text("Time! " + (best == null ? "Nobody" : roster.get(best))
                + " wins with the most health left.", NamedTextColor.GOLD, TextDecoration.BOLD));
        finishMatch(best);
    }

    private void checkVoid() {
        int voidY = PillarRules.voidY(twist);
        for (UUID id : new ArrayList<>(alive)) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.getWorld() == world && player.getLocation().getY() < voidY) {
                eliminate(player, EntityDamageEvent.DamageCause.VOID, false);
                if (!running || phase == Phase.OVER) {
                    return;
                }
            }
        }
    }

    private void checkEnd() {
        if (phase == Phase.OVER || !running) {
            return;
        }
        if (alive.size() <= 1) {
            finishMatch(alive.isEmpty() ? lastDeath() : alive.iterator().next());
        }
    }

    private UUID lastDeath() {
        return deathOrder.isEmpty() ? null : deathOrder.get(deathOrder.size() - 1);
    }

    private void finishMatch(UUID champion) {
        if (phase == Phase.OVER) {
            return;
        }
        winner = champion;
        phase = Phase.OVER;
        phaseTicks = PillarRules.OVER_TICKS;
        pendingStrike = null;
        world.getWorldBorder().setSize(world.getWorldBorder().getSize());
        String name = champion == null ? "Nobody" : roster.getOrDefault(champion, "?");
        forEachInWorld(player -> {
            player.sendTitle("§6§l" + name, "§ewins Lucky Pillars!", 10, 70, 20);
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            player.setLevel(0);
            player.setExp(0);
        });
        Player championPlayer = champion == null ? null : Bukkit.getPlayer(champion);
        if (championPlayer != null && championPlayer.getWorld() == world) {
            championPlayer.setInvulnerable(true);
            Particle.TOTEM_OF_UNDYING.builder().location(championPlayer.getLocation().add(0, 1, 0)).count(80)
                    .offset(0.6, 1, 0.6).extra(0.4).receivers(96, true).spawn();
        }
        showResults();
    }

    private void showResults() {
        List<UUID> ranking = new ArrayList<>();
        if (winner != null && roster.containsKey(winner)) {
            ranking.add(winner);
        }
        List<UUID> survivors = new ArrayList<>(alive);
        survivors.remove(winner);
        survivors.sort((a, b) -> Double.compare(health(b), health(a)));
        ranking.addAll(survivors);
        for (int i = deathOrder.size() - 1; i >= 0; i--) {
            UUID id = deathOrder.get(i);
            if (!ranking.contains(id) && roster.containsKey(id)) {
                ranking.add(id);
            }
        }
        List<Component> lines = new ArrayList<>();
        lines.add(Component.text("━━━━━ LUCKY PILLARS RESULTS ━━━━━", NamedTextColor.GOLD, TextDecoration.BOLD));
        lines.add(Component.text("Twist: " + twist.label + " · Map: " + layout.label, NamedTextColor.GRAY));
        NamedTextColor[] podium = {NamedTextColor.GOLD, NamedTextColor.WHITE, NamedTextColor.RED};
        for (int i = 0; i < ranking.size(); i++) {
            UUID id = ranking.get(i);
            lines.add(Component.text("#" + (i + 1) + " " + roster.get(id), i < podium.length ? podium[i] : NamedTextColor.GRAY,
                            TextDecoration.BOLD)
                    .append(Component.text("  ☠ " + kills.getOrDefault(id, 0) + " kills · " + itemsRolled.getOrDefault(id, 0)
                            + " items" + (legendaries.getOrDefault(id, 0) > 0 ? " · ★ " + legendaries.get(id) + " legendary" : ""),
                            NamedTextColor.GRAY).decoration(TextDecoration.BOLD, false)));
        }
        Component again = Component.text("[Play again]", NamedTextColor.GREEN, TextDecoration.BOLD)
                .clickEvent(ClickEvent.runCommand("/autobox again"))
                .hoverEvent(HoverEvent.showText(Component.text("Join the Lucky Pillars queue again")));
        for (UUID id : roster.keySet()) {
            boolean best = records.add(id, roster.get(id), id.equals(winner), kills.getOrDefault(id, 0),
                    legendaries.getOrDefault(id, 0));
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            lines.forEach(player::sendMessage);
            player.sendMessage(Component.text("Your lifetime: " + records.summary(id)
                    + (best ? " · new best: " + kills.getOrDefault(id, 0) + " kills in one game!" : ""), NamedTextColor.AQUA));
            player.sendMessage(again);
        }
        records.save();
    }

    public void handleQuit(Player player) {
        UUID id = player.getUniqueId();
        if (!running || !roster.containsKey(id)) {
            return;
        }
        boolean wasAlive = alive.remove(id);
        if (phase != Phase.OVER) {
            // Their game counts now; dropping them from the roster frees them to join something else.
            records.add(id, player.getName(), false, kills.getOrDefault(id, 0), legendaries.getOrDefault(id, 0));
            records.save();
            roster.remove(id);
            deathOrder.remove(id);
        }
        clearTwist(player);
        player.setGlowing(false);
        player.setInvulnerable(false);
        player.setLevel(0);
        player.setExp(0);
        if (phase == Phase.OVER) {
            return;
        }
        broadcast(Component.text(player.getName() + " left the match.", NamedTextColor.GRAY));
        if (wasAlive) {
            checkEnd();
        }
    }

    public void endGame() {
        if (!running) {
            return;
        }
        running = false;
        if (task != null) {
            task.cancel();
            task = null;
        }
        for (Player player : new ArrayList<>(world.getPlayers())) {
            player.getInventory().clear();
            player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
            clearTwist(player);
            player.setGlowing(false);
            player.setInvulnerable(false);
            player.setFireTicks(0);
            player.setFreezeTicks(0);
            player.setGameMode(GameMode.ADVENTURE);
            player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
            player.setFallDistance(0);
            player.setExp(0);
            player.setLevel(0);
            AttributeInstance attackSpeed = player.getAttribute(Attribute.ATTACK_SPEED);
            if (attackSpeed != null) {
                attackSpeed.setBaseValue(LOBBY_ATTACK_SPEED);
            }
            player.teleport(lobby);
            player.setVelocity(new Vector());
        }
        roster.clear();
        alive.clear();
        restoreWorld();
        scheduleClear();
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        for (Player player : new ArrayList<>(world.getPlayers())) {
            clearTwist(player);
        }
        running = false;
        restoreWorld();
        clearEntities();
        if (clearTask != null) {
            clearTask.cancel();
            clearTask = null;
        }
        clearY = PillarRules.SWEEP_MIN_Y;
        finishClearNow();
    }

    private void restoreWorld() {
        lavaQueue.clear();
        world.setStorm(false);
        world.setThundering(false);
        world.setGameRule(org.bukkit.GameRules.NATURAL_HEALTH_REGENERATION, true);
        WorldBorder border = world.getWorldBorder();
        border.setCenter(0, 0);
        border.setSize(256);
        border.setDamageAmount(0.2);
        border.setDamageBuffer(5);
    }

    // ---------------------------------------------------------------- deaths

    /** Knocks a player out without the vanilla death screen; their items spill where they fell. */
    private void eliminate(Player victim, EntityDamageEvent.DamageCause cause, boolean alreadyDead) {
        UUID id = victim.getUniqueId();
        if (!alive.remove(id)) {
            return;
        }
        deathOrder.add(id);
        Location at = victim.getLocation();
        UUID killerId = lastDamager.get(id);
        Player killer = killerId != null && !killerId.equals(id)
                && ticks - lastDamageTick.getOrDefault(id, -100000) <= PillarRules.KILL_CREDIT_TICKS
                ? Bukkit.getPlayer(killerId) : null;
        if (killer != null && !roster.containsKey(killer.getUniqueId())) {
            killer = null;
        }
        if (!alreadyDead) {
            if (at.getY() >= PillarRules.voidY(twist)) {
                for (ItemStack item : victim.getInventory().getContents()) {
                    if (item != null && !item.getType().isAir()) {
                        world.dropItemNaturally(at, item);
                    }
                }
            }
            victim.getInventory().clear();
            victim.getActivePotionEffects().forEach(effect -> victim.removePotionEffect(effect.getType()));
            clearTwist(victim);
            victim.setGlowing(false);
            victim.setFireTicks(0);
            victim.setFreezeTicks(0);
            victim.setHealth(victim.getMaxHealth());
            victim.setLevel(0);
            victim.setExp(0);
            victim.setGameMode(GameMode.SPECTATOR);
            victim.setVelocity(new Vector());
            victim.teleport(at.getY() >= PillarRules.voidY(twist) ? at.clone().add(0, 2, 0) : getSpectateLocation());
        }
        world.strikeLightningEffect(at);
        int place = alive.size() + 1;
        victim.sendTitle("§c§lELIMINATED", "§7#" + place + (killer != null ? " · killed by " + killer.getName() : ""), 0, 50, 10);
        String how = deathText(cause, killer != null);
        broadcast(Component.text("☠ " + victim.getName(), NamedTextColor.RED, TextDecoration.BOLD)
                .append(Component.text(" " + how + (killer != null ? " " + killer.getName() : "")
                        + " (" + alive.size() + " left)", NamedTextColor.GRAY).decoration(TextDecoration.BOLD, false)));
        if (killer != null) {
            kills.merge(killer.getUniqueId(), 1, Integer::sum);
        }
        if (killer != null && alive.contains(killer.getUniqueId())) {
            double heal = twist == Twist.VAMPIRES ? PillarRules.VAMPIRE_KILL_HEAL : PillarRules.KILL_HEAL;
            killer.setHealth(Math.min(killer.getMaxHealth(), killer.getHealth() + heal));
            killer.playSound(killer.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.4f);
            killer.sendActionBar(Component.text("KILL! +" + (int) (heal / 2) + " hearts and a bonus item", NamedTextColor.GOLD,
                    TextDecoration.BOLD));
            giveLoot(killer, LuckyLoot.roll(random, PillarRules.lootBoost(twist, mainElapsed, phase == Phase.DEATHMATCH) + 0.5));
        }
        checkEnd();
    }

    private String deathText(EntityDamageEvent.DamageCause cause, boolean hasKiller) {
        if (hasKiller) {
            return switch (cause) {
                case VOID -> "was knocked into the void by";
                case FALL -> "was knocked off a pillar by";
                case PROJECTILE -> "was shot by";
                case ENTITY_EXPLOSION, BLOCK_EXPLOSION -> "was blown up by";
                case LAVA, FIRE, FIRE_TICK -> "was burned to a crisp thanks to";
                default -> "was slain by";
            };
        }
        return switch (cause) {
            case VOID -> "fell into the void";
            case FALL -> "hit the ground too hard";
            case LAVA -> "tried to swim in lava";
            case FIRE, FIRE_TICK -> "burned to a crisp";
            case ENTITY_EXPLOSION, BLOCK_EXPLOSION -> "blew up";
            case LIGHTNING -> "was struck by lightning";
            case WORLD_BORDER -> "was crushed by the border";
            case STARVATION -> "starved";
            case SUFFOCATION -> "suffocated";
            case FREEZE -> "froze solid";
            default -> "died";
        };
    }

    // ---------------------------------------------------------------- events

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player victim) || victim.getWorld() != world) {
            return;
        }
        UUID id = victim.getUniqueId();
        if (!running || !alive.contains(id) || (phase != Phase.MAIN && phase != Phase.DEATHMATCH)) {
            event.setCancelled(true);
            return;
        }
        Player attacker = null;
        if (event instanceof EntityDamageByEntityEvent byEntity) {
            attacker = responsible(byEntity.getDamager());
            if (attacker != null && !attacker.equals(victim)) {
                if (!alive.contains(attacker.getUniqueId())) {
                    event.setCancelled(true);
                    return;
                }
                lastDamager.put(id, attacker.getUniqueId());
                lastDamageTick.put(id, ticks);
            }
        }
        if (event.getFinalDamage() >= victim.getHealth() && !holdsTotem(victim)) {
            event.setCancelled(true);
            eliminate(victim, event.getCause(), false);
            return;
        }
        if (twist == Twist.VAMPIRES && attacker != null && !attacker.equals(victim)
                && event instanceof EntityDamageByEntityEvent byEntity && byEntity.getDamager() instanceof Player) {
            double healed = event.getFinalDamage() * PillarRules.VAMPIRE_LIFESTEAL;
            attacker.setHealth(Math.min(attacker.getMaxHealth(), attacker.getHealth() + healed));
            Particle.DAMAGE_INDICATOR.builder().location(attacker.getLocation().add(0, 1.8, 0)).count(3)
                    .offset(0.3, 0.2, 0.3).receivers(32, true).spawn();
        }
    }

    /** Wind charges and other shoves count toward kill credit too. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPushed(EntityPushedByEntityAttackEvent event) {
        if (!running || !(event.getEntity() instanceof Player victim) || victim.getWorld() != world) {
            return;
        }
        Player attacker = responsible(event.getPushedBy());
        if (attacker != null && !attacker.equals(victim) && alive.contains(attacker.getUniqueId())) {
            lastDamager.put(victim.getUniqueId(), attacker.getUniqueId());
            lastDamageTick.put(victim.getUniqueId(), ticks);
        }
    }

    /** Backup for anything that kills outright without a damage event we could intercept. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (player.getWorld() != world) {
            return;
        }
        event.deathMessage(null);
        event.setDroppedExp(0);
        if (!running || !alive.contains(player.getUniqueId())) {
            event.setKeepInventory(true);
            event.getDrops().clear();
            return;
        }
        event.setKeepInventory(false);
        EntityDamageEvent last = player.getLastDamageCause();
        eliminate(player, last == null ? EntityDamageEvent.DamageCause.CUSTOM : last.getCause(), true);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (!isPlaying(player)) {
            return;
        }
        event.setRespawnLocation(getSpectateLocation());
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline() && player.getWorld() == world) {
                clearTwist(player);
                player.setGameMode(GameMode.SPECTATOR);
            }
        });
    }

    /** Players are frozen on their pillars until GO. */
    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!running || phase != Phase.COUNTDOWN || !alive.contains(event.getPlayer().getUniqueId())) {
            return;
        }
        Location from = event.getFrom();
        Location to = event.getTo();
        if (from.getX() != to.getX() || from.getZ() != to.getZ() || to.getY() > from.getY()) {
            Location back = from.clone();
            back.setYaw(to.getYaw());
            back.setPitch(to.getPitch());
            event.setTo(back);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (player.getWorld() != world) {
            return;
        }
        if (!running || !alive.contains(player.getUniqueId()) || (phase != Phase.MAIN && phase != Phase.DEATHMATCH)) {
            event.setCancelled(true);
            return;
        }
        Block block = event.getBlockPlaced();
        if (block.getY() > PillarRules.MAX_BUILD_Y) {
            event.setCancelled(true);
            player.sendActionBar(Component.text("Build limit!", NamedTextColor.RED));
            return;
        }
        event.setCancelled(false);
        event.setBuild(true);
        if (block.getType() == Material.TNT) {
            // Lucky TNT lights itself: no flint and steel needed.
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (block.getType() != Material.TNT) {
                    return;
                }
                block.setType(Material.AIR, false);
                world.spawn(block.getLocation().add(0.5, 0, 0.5), TNTPrimed.class, tnt -> {
                    tnt.setFuseTicks(50);
                    tnt.setSource(player);
                });
                world.playSound(block.getLocation(), Sound.ENTITY_TNT_PRIMED, 1f, 1f);
            });
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.getWorld() != world) {
            return;
        }
        if (!running || !alive.contains(player.getUniqueId()) || (phase != Phase.MAIN && phase != Phase.DEATHMATCH)
                || protectedBlocks.contains(event.getBlock().getBlockKey())) {
            event.setCancelled(true);
            return;
        }
        event.setCancelled(false);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent event) {
        if (event.getPlayer().getWorld() == world
                && (!running || !alive.contains(event.getPlayer().getUniqueId()) || phase == Phase.COUNTDOWN)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        if (event.getLocation().getWorld() == world) {
            event.blockList().removeIf(block -> protectedBlocks.contains(block.getBlockKey()));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        if (event.getBlock().getWorld() == world) {
            event.blockList().removeIf(block -> protectedBlocks.contains(block.getBlockKey()));
        }
    }

    /** Keeps water and lava from running out of the area the reset sweep covers. */
    @EventHandler(ignoreCancelled = true)
    public void onFlow(BlockFromToEvent event) {
        Block to = event.getToBlock();
        if (to.getWorld() == world && (to.getY() <= PillarRules.SWEEP_MIN_Y + 2
                || Math.abs(to.getX()) >= PillarRules.SWEEP_RADIUS - 2 || Math.abs(to.getZ()) >= PillarRules.SWEEP_RADIUS - 2)) {
            event.setCancelled(true);
        }
    }

    /** Spawn eggs work (natural spawning is off); wolves hatch already tamed to whoever used the egg. */
    @EventHandler(ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        if (event.getLocation().getWorld() != world) {
            return;
        }
        if (!running || phase == Phase.OVER) {
            event.setCancelled(true);
            return;
        }
        // Thrown eggs and spawn eggs can otherwise pile up dozens of AI mobs on the bridges.
        if (event.getEntity() instanceof Mob && world.getEntitiesByClass(Mob.class).size() >= MAX_MOBS) {
            event.setCancelled(true);
            return;
        }
        if (event.getEntity() instanceof Wolf wolf && event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG) {
            Player owner = null;
            double best = 36;
            for (UUID id : alive) {
                Player player = Bukkit.getPlayer(id);
                if (player != null && player.getWorld() == world) {
                    double distance = player.getLocation().distanceSquared(wolf.getLocation());
                    if (distance < best) {
                        best = distance;
                        owner = player;
                    }
                }
            }
            if (owner != null) {
                wolf.setTamed(true);
                wolf.setOwner(owner);
            }
        }
    }

    // ---------------------------------------------------------------- loot

    private void giveLoot(Player player, LuckyLoot.Entry entry) {
        UUID id = player.getUniqueId();
        itemsRolled.merge(id, 1, Integer::sum);
        give(player, entry.make().get());
        LuckyLoot.Rarity rarity = entry.rarity();
        player.sendActionBar(Component.text("+ " + entry.name(), rarity.color, TextDecoration.BOLD)
                .append(Component.text("  " + rarity.label, rarity.color).decoration(TextDecoration.BOLD, false)));
        float pitch = switch (rarity) {
            case COMMON -> 1.0f;
            case UNCOMMON -> 1.2f;
            case RARE -> 1.5f;
            case EPIC, LEGENDARY -> 1.9f;
        };
        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 0.6f, pitch);
        if (rarity == LuckyLoot.Rarity.EPIC) {
            player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
        }
        if (rarity == LuckyLoot.Rarity.LEGENDARY) {
            legendaries.merge(id, 1, Integer::sum);
            broadcast(Component.text("★ " + player.getName() + " rolled a LEGENDARY: ", NamedTextColor.GOLD)
                    .append(Component.text(entry.name(), NamedTextColor.GOLD, TextDecoration.BOLD)));
            forEachInWorld(other -> other.playSound(other.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.6f, 1.6f));
            Particle.TOTEM_OF_UNDYING.builder().location(player.getLocation().add(0, 1, 0)).count(30)
                    .offset(0.4, 0.8, 0.4).extra(0.3).receivers(64, true).spawn();
        }
    }

    /** Armour goes straight on when the slot is free; anything that doesn't fit drops at your feet. */
    private void give(Player player, List<ItemStack> items) {
        PlayerInventory inventory = player.getInventory();
        for (ItemStack item : items) {
            EquipmentSlot slot = item.getType().getEquipmentSlot();
            boolean armour = slot == EquipmentSlot.HEAD || slot == EquipmentSlot.CHEST || slot == EquipmentSlot.LEGS
                    || slot == EquipmentSlot.FEET;
            if (armour && item.getType() != Material.ELYTRA) {
                ItemStack worn = inventory.getItem(slot);
                if (worn == null || worn.getType().isAir()) {
                    inventory.setItem(slot, item);
                    continue;
                }
            }
            for (ItemStack left : inventory.addItem(item).values()) {
                world.dropItemNaturally(player.getLocation(), left);
            }
        }
    }

    private void scheduleLoot(UUID id, int interval) {
        nextLoot.put(id, ticks + interval);
        lootSpan.put(id, interval);
    }

    private void showLootBar(Player player, int remaining, int span) {
        if (ticks % 2 != 0) {
            return;
        }
        int left = Math.max(0, remaining);
        player.setLevel((left + 19) / 20);
        player.setExp(Math.max(0f, Math.min(0.999f, 1f - left / (float) Math.max(1, span))));
    }

    private boolean onCrown(Player player) {
        Location location = player.getLocation();
        return location.getBlockX() == 0 && location.getBlockZ() == 0
                && location.getY() >= PillarRules.TOP_Y + PillarRules.CROWN_RISE + 1
                && location.getY() < PillarRules.TOP_Y + PillarRules.CROWN_RISE + 1.6;
    }

    // ---------------------------------------------------------------- twists

    private void applyTwist(Player player) {
        switch (twist) {
            case MOON_GRAVITY -> {
                modify(player, Attribute.GRAVITY, -0.05);
                modify(player, Attribute.SAFE_FALL_DISTANCE, 6);
            }
            case SUGAR_RUSH -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION, 1, false, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, PotionEffect.INFINITE_DURATION, 1, false, false));
            }
            case GIANTS -> {
                modify(player, Attribute.SCALE, 0.5);
                modify(player, Attribute.MAX_HEALTH, 10);
                modify(player, Attribute.ENTITY_INTERACTION_RANGE, 1);
                modify(player, Attribute.BLOCK_INTERACTION_RANGE, 1);
                player.setHealth(player.getMaxHealth());
            }
            case TINY_TOWN -> modify(player, Attribute.SCALE, -0.5);
            case BOUNCY_CASTLE -> {
                modify(player, Attribute.ATTACK_KNOCKBACK, 1.5);
                modify(player, Attribute.SAFE_FALL_DISTANCE, 256);
            }
            case SKY_GLIDERS -> {
                player.getInventory().setChestplate(new ItemStack(Material.ELYTRA));
                ItemStack rockets = new ItemStack(Material.FIREWORK_ROCKET, 4);
                FireworkMeta meta = (FireworkMeta) rockets.getItemMeta();
                meta.setPower(1);
                rockets.setItemMeta(meta);
                player.getInventory().addItem(rockets);
            }
            case GLASS_CANNON -> {
                modify(player, Attribute.MAX_HEALTH, -10);
                player.setHealth(Math.min(player.getHealth(), player.getMaxHealth()));
            }
            default -> {
            }
        }
    }

    private void modify(Player player, Attribute attribute, double amount) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance == null) {
            return;
        }
        instance.removeModifier(twistKey);
        instance.addTransientModifier(new AttributeModifier(twistKey, amount, AttributeModifier.Operation.ADD_NUMBER));
    }

    private void clearTwist(Player player) {
        for (Attribute attribute : TWIST_ATTRIBUTES) {
            AttributeInstance instance = player.getAttribute(attribute);
            if (instance != null && instance.getModifier(twistKey) != null) {
                instance.removeModifier(twistKey);
            }
        }
        if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
        }
    }

    // ---------------------------------------------------------------- arena

    private void buildPillar(Pillar pillar) {
        for (int y = PillarRules.BOTTOM_Y; y <= pillar.topY(); y++) {
            world.getBlockAt(pillar.x(), y, pillar.z()).setType(Material.BEDROCK, false);
        }
    }

    private void buildCrown() {
        int top = PillarRules.TOP_Y + PillarRules.CROWN_RISE;
        for (int y = PillarRules.BOTTOM_Y; y < top; y++) {
            world.getBlockAt(0, y, 0).setType(Material.BEDROCK, false);
        }
        Block crown = world.getBlockAt(0, top, 0);
        crown.setType(Material.GOLD_BLOCK, false);
        protectedBlocks.add(crown.getBlockKey());
    }

    private void buildSlimeFloor() {
        int radius = PillarRules.outerRadius(layout, playerCount) + 5;
        int y = PillarRules.BOTTOM_Y - 1;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                if (x * x + z * z > radius * radius) {
                    continue;
                }
                Block block = world.getBlockAt(x, y, z);
                block.setType(Material.SLIME_BLOCK, false);
                protectedBlocks.add(block.getBlockKey());
            }
        }
    }

    private void buildDeathmatchPlatform() {
        int radius = PillarRules.DEATHMATCH_PLATFORM_RADIUS;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                if (x * x + z * z > radius * radius + 1) {
                    continue;
                }
                Block block = world.getBlockAt(x, PillarRules.TOP_Y, z);
                if (block.getType() != Material.BEDROCK) {
                    block.setType(Material.BEDROCK, false);
                }
            }
        }
        world.playSound(new Location(world, 0.5, PillarRules.TOP_Y, 0.5), Sound.BLOCK_BEACON_ACTIVATE, 3f, 0.8f);
    }

    private void raiseLavaTo(int target) {
        // Cover everything inside the border so bridging outward is no escape.
        int radius = PillarRules.borderSize(layout, playerCount) / 2 + 1;
        while (lavaY < target) {
            lavaY++;
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    if (x * x + z * z <= radius * radius) {
                        lavaQueue.add(new int[]{x, lavaY, z});
                    }
                }
            }
        }
        world.playSound(new Location(world, 0.5, lavaY, 0.5), Sound.BLOCK_LAVA_AMBIENT, 3f, 0.6f);
    }

    /** Pours queued lava a few hundred blocks per tick; a whole layer at once is ~1.8k light updates in one tick. */
    private void pourLava() {
        for (int i = 0; i < LAVA_PER_TICK && !lavaQueue.isEmpty(); i++) {
            int[] at = lavaQueue.poll();
            Block block = world.getBlockAt(at[0], at[1], at[2]);
            if (block.getType().isAir()) {
                block.setType(Material.LAVA, false);
            }
        }
    }

    private Location standOn(Pillar pillar) {
        Location spot = new Location(world, pillar.x() + 0.5, pillar.topY() + 1, pillar.z() + 0.5);
        spot.setDirection(new Vector(0.5, spot.getY(), 0.5).subtract(spot.toVector()));
        spot.setPitch(0);
        return spot;
    }

    private void clearEntities() {
        for (Entity entity : world.getEntities()) {
            if (!(entity instanceof Player)) {
                entity.remove();
            }
        }
    }

    /** Sweeps the arena a few layers per tick so ending a match never causes a lag spike. */
    private void scheduleClear() {
        clearEntities();
        clearY = PillarRules.SWEEP_MIN_Y;
        if (clearTask != null) {
            clearTask.cancel();
        }
        clearTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (int i = 0; i < CLEAR_LAYERS_PER_TICK && clearY <= PillarRules.SWEEP_MAX_Y; i++) {
                clearLayer(clearY++);
            }
            if (clearY > PillarRules.SWEEP_MAX_Y) {
                clearEntities();
                clearTask.cancel();
                clearTask = null;
                clearY = Integer.MIN_VALUE;
            }
        }, 1L, 1L);
    }

    private void finishClearNow() {
        if (clearTask != null) {
            clearTask.cancel();
            clearTask = null;
        }
        if (clearY != Integer.MIN_VALUE) {
            while (clearY <= PillarRules.SWEEP_MAX_Y) {
                clearLayer(clearY++);
            }
            clearY = Integer.MIN_VALUE;
        }
        clearEntities();
    }

    private void clearLayer(int y) {
        int reach = PillarRules.SWEEP_RADIUS;
        for (int x = -reach; x <= reach; x++) {
            for (int z = -reach; z <= reach; z++) {
                Block block = world.getBlockAt(x, y, z);
                if (!block.getType().isAir()) {
                    block.setType(Material.AIR, false);
                }
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    /** Who gets credit for this damage: the shooter, the TNT lighter, the wolf's owner, or the player. */
    private Player responsible(Entity source) {
        if (source instanceof Player player) {
            return player;
        }
        if (source instanceof Projectile projectile && projectile.getShooter() instanceof Player shooter) {
            return shooter;
        }
        if (source instanceof TNTPrimed tnt && tnt.getSource() instanceof Player lighter) {
            return lighter;
        }
        if (source instanceof Tameable pet && pet.getOwner() instanceof Player owner) {
            return owner;
        }
        if (source instanceof AreaEffectCloud cloud && cloud.getSource() instanceof Player thrower) {
            return thrower;
        }
        return null;
    }

    private boolean holdsTotem(Player player) {
        return player.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || player.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    private double health(UUID id) {
        Player player = Bukkit.getPlayer(id);
        return player == null ? 0 : player.getHealth() + player.getAbsorptionAmount();
    }

    private Player randomAlive() {
        List<Player> players = new ArrayList<>();
        for (UUID id : alive) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.getWorld() == world) {
                players.add(player);
            }
        }
        return players.isEmpty() ? null : players.get(random.nextInt(players.size()));
    }

    private void prepare(Player player) {
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        clearTwist(player);
        player.setGlowing(false);
        player.setInvulnerable(false);
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20);
        player.setFireTicks(0);
        player.setFreezeTicks(0);
        player.setFallDistance(0);
        player.setLevel(0);
        player.setExp(0);
    }

    private void firework(Location location) {
        Color[] colors = {Color.YELLOW, Color.ORANGE, Color.AQUA, Color.FUCHSIA, Color.WHITE};
        world.spawn(location, Firework.class, firework -> {
            FireworkMeta meta = firework.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder().withColor(colors[random.nextInt(colors.length)])
                    .withFade(Color.WHITE).with(FireworkEffect.Type.BALL_LARGE).withFlicker().build());
            meta.setPower(1);
            firework.setFireworkMeta(meta);
        });
    }

    private String clock(int remainingTicks) {
        int seconds = Math.max(0, (remainingTicks + 19) / 20);
        return seconds / 60 + ":" + String.format("%02d", seconds % 60);
    }

    private void updateScoreboard() {
        if (board == null) {
            board = Bukkit.getScoreboardManager().getNewScoreboard();
            board.registerNewObjective("luckypillars", Criteria.DUMMY,
                    Component.text("LUCKY PILLARS", NamedTextColor.GOLD, TextDecoration.BOLD))
                    .setDisplaySlot(DisplaySlot.SIDEBAR);
        }
        Objective objective = board.getObjective("luckypillars");
        List<String> lines = new ArrayList<>();
        lines.add(ChatColor.LIGHT_PURPLE + "Twist: " + ChatColor.WHITE + twist.label);
        lines.add(switch (phase) {
            case COUNTDOWN -> ChatColor.YELLOW + "Starting...";
            case MAIN -> ChatColor.GREEN + "Deathmatch in " + ChatColor.WHITE + clock(phaseTicks);
            case DEATHMATCH -> ChatColor.DARK_RED + "Deathmatch " + ChatColor.WHITE + clock(phaseTicks);
            case OVER -> ChatColor.GOLD + "Winner: " + (winner == null ? "-" : roster.getOrDefault(winner, "-"));
        });
        if (twist == Twist.RISING_LAVA && phase != Phase.COUNTDOWN) {
            lines.add(ChatColor.GOLD + "Lava: " + ChatColor.WHITE + "y " + lavaY + ChatColor.GRAY + " / top " + PillarRules.TOP_Y);
        }
        lines.add(ChatColor.AQUA + "Alive: " + ChatColor.WHITE + alive.size() + "/" + roster.size());
        lines.add(ChatColor.DARK_GRAY + "--------------");
        List<UUID> ranked = new ArrayList<>(roster.keySet());
        ranked.sort((a, b) -> {
            int life = Boolean.compare(alive.contains(b), alive.contains(a));
            return life != 0 ? life : Integer.compare(kills.getOrDefault(b, 0), kills.getOrDefault(a, 0));
        });
        for (UUID id : ranked) {
            if (lines.size() >= 15) {
                break;
            }
            String marker = alive.contains(id) ? ChatColor.GREEN + "✔ " : ChatColor.DARK_GRAY + "✖ ";
            lines.add(marker + ChatColor.WHITE + roster.get(id) + ChatColor.RED + " ☠" + kills.getOrDefault(id, 0));
        }
        // Only touch entries that changed so the sidebar doesn't get resent (and flicker) every update.
        for (String old : boardLines) {
            if (!lines.contains(old)) {
                board.resetScores(old);
            }
        }
        for (int i = 0; i < lines.size(); i++) {
            int score = lines.size() - i;
            if (objective.getScore(lines.get(i)).getScore() != score) {
                objective.getScore(lines.get(i)).setScore(score);
            }
        }
        boardLines.clear();
        boardLines.addAll(lines);
        for (Player player : world.getPlayers()) {
            if (player.getScoreboard() != board) {
                player.setScoreboard(board);
            }
        }
    }

    private void forEachInWorld(java.util.function.Consumer<Player> action) {
        for (Player player : world.getPlayers()) {
            action.accept(player);
        }
    }

    private void broadcast(Component message) {
        for (Player player : world.getPlayers()) {
            player.sendMessage(Component.text("[Lucky Pillars] ", NamedTextColor.GOLD).append(message));
        }
    }
}
