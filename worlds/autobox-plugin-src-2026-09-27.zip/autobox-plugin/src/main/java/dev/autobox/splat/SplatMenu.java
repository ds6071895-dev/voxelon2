package dev.autobox.splat;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;

/** The host's match setup menu, the kit locker and the Super Jump picker. Menus are identified by holder, not title. */
final class SplatMenu {
    enum Type { HOST, LOCKER, JUMP }

    static final class Holder implements InventoryHolder {
        final Type type;
        final boolean editable;
        /** JUMP menus: slot to a teammate id or a location. */
        final Map<Integer, Object> targets = new HashMap<>();
        Inventory inventory;

        Holder(Type type, boolean editable) { this.type = type; this.editable = editable; }

        @Override
        public Inventory getInventory() { return inventory; }
    }

    private static final int[] MODE_SLOTS = {10, 11, 12, 13, 14};
    private static final int ROTATION = 16, RANDOM_MAP = 19, START = 25, INFO = 4, RATED = 23;
    private static final int[] MAP_SLOTS = {20, 21};

    private final SplatGame g;

    SplatMenu(SplatGame g) { this.g = g; }

    private static ItemStack icon(Material material, Component name, boolean glint, Component... lore) {
        ItemStack item = ItemStack.of(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        meta.lore(Arrays.stream(lore).map(line -> line.decoration(TextDecoration.ITALIC, false)).toList());
        meta.addItemFlags(ItemFlag.values());
        if (glint) meta.setEnchantmentGlintOverride(true);
        item.setItemMeta(meta);
        return item;
    }

    private static Component gray(String s) { return Component.text(s, NamedTextColor.GRAY); }

    private static Inventory create(Holder holder, int size, Component title) {
        Inventory inventory = Bukkit.createInventory(holder, size, title);
        holder.inventory = inventory;
        return inventory;
    }

    // ------------------------------------------------------------------ host menu

    void openHost(Player p, boolean editable) {
        Holder holder = new Holder(Type.HOST, editable);
        Inventory inv = create(holder, 27, Component.text("Splatoon ", NamedTextColor.GOLD, TextDecoration.BOLD)
                .append(Component.text("» Match Setup", NamedTextColor.DARK_GRAY)));
        render(inv, editable);
        p.openInventory(inv);
        p.playSound(p, Sound.UI_BUTTON_CLICK, 0.6f, 1.4f);
    }

    private void render(Inventory inv, boolean editable) {
        ItemStack pane = icon(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "), false);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
        int queued = g.queuedCount();
        inv.setItem(INFO, icon(Material.PAPER, Component.text("Next match", NamedTextColor.GOLD, TextDecoration.BOLD), false,
                gray(g.settingsSummary()),
                gray(queued + " player" + (queued == 1 ? "" : "s") + " queued (2–10)"),
                Component.text(editable ? "You're the host: click to change." : "Only the host can change this.", editable ? NamedTextColor.GREEN : NamedTextColor.YELLOW)));
        SplatMode[] modes = SplatMode.values();
        for (int i = 0; i < modes.length; i++) {
            SplatMode mode = modes[i];
            boolean chosen = !g.rotation && g.hostMode == mode;
            List<Component> lore = new ArrayList<>();
            for (String line : mode.howTo) lore.add(gray(line));
            lore.add(Component.text(mode.ranked ? "Ranked mode · " + mode.playTicks / 1200 + " min" : "Casual · 3 min", mode.color));
            lore.add(Component.text(chosen ? "✔ Selected" : "Click to play this", chosen ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
            inv.setItem(MODE_SLOTS[i], icon(mode.icon, Component.text(mode.title, mode.color, TextDecoration.BOLD), chosen, lore.toArray(Component[]::new)));
        }
        SplatMode next = SplatMode.RANKED.get(g.rotationIndex % SplatMode.RANKED.size());
        inv.setItem(ROTATION, icon(Material.CLOCK, Component.text("Ranked rotation: " + (g.rotation ? "ON" : "OFF"),
                        g.rotation ? NamedTextColor.GREEN : NamedTextColor.RED, TextDecoration.BOLD), g.rotation,
                gray("Cycle Zones → Tower → Rainmaker → Clams,"), gray("one per match."), Component.text("Next up: " + next.title, next.color)));
        inv.setItem(RANDOM_MAP, icon(Material.MAP, Component.text("Random map", NamedTextColor.AQUA, TextDecoration.BOLD), g.hostMap < 0,
                gray("A different map each match.")));
        Material[] mapIcons = {Material.WHITE_CONCRETE, Material.PRISMARINE};
        for (int i = 0; i < SplatArena.MAPS.size() && i < MAP_SLOTS.length; i++) {
            SplatArena.MapDef map = SplatArena.MAPS.get(i);
            inv.setItem(MAP_SLOTS[i], icon(mapIcons[i % mapIcons.length], Component.text(map.name(), NamedTextColor.AQUA, TextDecoration.BOLD),
                    g.hostMap == i, gray(i == 0 ? "Open centre tower, flank deck." : "Tall plaza, sniper perches, long lanes.")));
        }
        inv.setItem(RATED, icon(Material.NETHER_STAR, Component.text("Ranked & levels", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD), false,
                gray("Every match with 2+ players changes your"), gray("rating in that mode and earns XP."), gray("/splat rank · /splat top")));
        boolean canStart = editable && queued >= 2;
        inv.setItem(START, icon(canStart ? Material.LIME_CONCRETE : Material.GRAY_CONCRETE,
                Component.text(canStart ? "▶ START MATCH" : "Waiting for players", canStart ? NamedTextColor.GREEN : NamedTextColor.GRAY, TextDecoration.BOLD), canStart,
                gray(editable ? "Needs 2+ queued players." : "The host starts the match.")));
    }

    // ------------------------------------------------------------------ locker

    void openLocker(Player p) {
        Holder holder = new Holder(Type.LOCKER, true);
        Inventory inv = create(holder, 9, Component.text("Locker ", NamedTextColor.AQUA, TextDecoration.BOLD)
                .append(Component.text("» Pick a kit", NamedTextColor.DARK_GRAY)));
        Inkling in = g.players.get(p.getUniqueId());
        Kit current = in != null ? in.kit : g.stats.get(p.getUniqueId(), p.getName()).kit;
        Kit[] kits = Kit.values();
        for (int i = 0; i < kits.length; i++) inv.setItem(i, g.kitItem(kits[i], kits[i] == current));
        p.openInventory(inv);
    }

    // ------------------------------------------------------------------ super jump

    void openJump(Player p, Inkling in) {
        Holder holder = new Holder(Type.JUMP, true);
        Inventory inv = create(holder, 9, Component.text("Super Jump ", in.team.text, TextDecoration.BOLD)
                .append(Component.text("» Where to?", NamedTextColor.DARK_GRAY)));
        int slot = 0;
        inv.setItem(slot, icon(Material.QUARTZ_BLOCK, Component.text("Spawn", NamedTextColor.WHITE, TextDecoration.BOLD), false, gray("Back to base.")));
        holder.targets.put(slot++, g.spawn(in));
        for (Inkling mate : g.players.values()) {
            if (slot >= 9) break;
            if (mate.team != in.team || mate == in || !mate.alive()) continue;
            ItemStack head = icon(Material.PLAYER_HEAD, Component.text(mate.name, in.team.text, TextDecoration.BOLD), false,
                    gray("Jump to your teammate."));
            if (head.getItemMeta() instanceof SkullMeta skull) {
                skull.setOwningPlayer(Bukkit.getOfflinePlayer(mate.id));
                head.setItemMeta(skull);
            }
            inv.setItem(slot, head);
            holder.targets.put(slot++, mate.id);
        }
        for (SplatWeapons.Device beakon : g.weapons.beakons(in.team)) {
            if (slot >= 9) break;
            inv.setItem(slot, icon(Material.ECHO_SHARD, Component.text("Squid Beakon", in.team.text, TextDecoration.BOLD), false, gray("Jump to the beakon.")));
            holder.targets.put(slot++, beakon.at.clone().add(0, 0.1, 0));
        }
        p.openInventory(inv);
    }

    // ------------------------------------------------------------------ clicks

    void click(Player p, Holder holder, int slot) {
        switch (holder.type) {
            case HOST -> {
                if (!holder.editable || !g.isHost(p) || g.isRunning()) return;
                boolean changed = true;
                int modeIndex = indexOf(MODE_SLOTS, slot), mapIndex = indexOf(MAP_SLOTS, slot);
                if (modeIndex >= 0) { g.hostMode = SplatMode.values()[modeIndex]; g.rotation = false; }
                else if (slot == ROTATION) g.rotation = !g.rotation;
                else if (slot == RANDOM_MAP) g.hostMap = -1;
                else if (mapIndex >= 0 && mapIndex < SplatArena.MAPS.size()) g.hostMap = mapIndex;
                else if (slot == START) { if (g.queuedCount() >= 2) g.startFromMenu(p); return; }
                else changed = false;
                if (!changed) return;
                p.playSound(p, Sound.UI_BUTTON_CLICK, 0.8f, 1.5f);
                render(holder.inventory, true);
            }
            case LOCKER -> {
                Kit[] kits = Kit.values();
                if (slot >= 0 && slot < kits.length) g.chooseKit(p, kits[slot]);
            }
            case JUMP -> {
                Object target = holder.targets.get(slot);
                if (target instanceof UUID mate) g.superJump(p, mate, null);
                else if (target instanceof Location spot) g.superJump(p, null, spot);
            }
        }
    }

    private static int indexOf(int[] slots, int slot) {
        for (int i = 0; i < slots.length; i++) if (slots[i] == slot) return i;
        return -1;
    }
}
