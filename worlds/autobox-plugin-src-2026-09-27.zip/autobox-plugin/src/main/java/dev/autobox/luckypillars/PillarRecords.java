package dev.autobox.luckypillars;

import dev.autobox.util.AsyncFiles;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.util.UUID;

/** Lifetime Lucky Pillars stats per player, kept in {@code luckypillars-records.yml}. */
final class PillarRecords {
    private final Plugin plugin;
    private final File file;
    private final YamlConfiguration records;

    PillarRecords(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "luckypillars-records.yml");
        this.records = YamlConfiguration.loadConfiguration(file);
    }

    /** Adds one match and returns true when this was a new personal best for kills. */
    boolean add(UUID id, String name, boolean won, int kills, int legendaries) {
        String key = id.toString();
        records.set(key + ".name", name);
        add(key + ".games", 1);
        add(key + ".wins", won ? 1 : 0);
        add(key + ".kills", kills);
        add(key + ".legendaries", legendaries);
        boolean best = records.contains(key + ".bestKills") && kills > records.getInt(key + ".bestKills");
        if (kills > records.getInt(key + ".bestKills")) {
            records.set(key + ".bestKills", kills);
        }
        return best;
    }

    String summary(UUID id) {
        String key = id.toString();
        return records.getInt(key + ".wins") + " wins · " + records.getInt(key + ".kills") + " kills · "
                + records.getInt(key + ".games") + " games";
    }

    int wins(UUID id) {
        return records.getInt(id + ".wins");
    }

    void save() {
        // Written off the main thread; this also runs on every mid-match quit.
        AsyncFiles.writeYaml(plugin, records, file);
    }

    private void add(String path, int amount) {
        if (amount != 0) {
            records.set(path, records.getInt(path) + amount);
        }
    }
}
