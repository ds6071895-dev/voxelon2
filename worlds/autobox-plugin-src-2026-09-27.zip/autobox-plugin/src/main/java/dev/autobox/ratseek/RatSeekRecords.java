package dev.autobox.ratseek;

import dev.autobox.util.AsyncFiles;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.util.UUID;

/** Lifetime Rat and Seek stats per player, kept in {@code ratseek-records.yml}. */
final class RatSeekRecords {
    record Match(boolean human, boolean won, int catches, int cheese, int escapes, int points,
                 int fastestCatchSeconds) { }

    private final Plugin plugin;
    private final File file;
    private final YamlConfiguration records;

    RatSeekRecords(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "ratseek-records.yml");
        this.records = YamlConfiguration.loadConfiguration(file);
    }

    /** Adds one match to a player's totals and returns the "new best" notes it earned. */
    java.util.List<String> add(UUID id, String name, Match match) {
        String key = id.toString();
        java.util.List<String> bests = new java.util.ArrayList<>();
        records.set(key + ".name", name);
        increment(key + ".games");
        if (match.won()) {
            increment(key + (match.human() ? ".humanWins" : ".ratWins"));
        }
        add(key + ".catches", match.catches());
        add(key + ".cheese", match.cheese());
        add(key + ".escapes", match.escapes());
        if (!match.human() && match.points() > records.getInt(key + ".bestPoints")) {
            if (records.contains(key + ".bestPoints")) {
                bests.add("new best rat score: " + match.points() + " points");
            }
            records.set(key + ".bestPoints", match.points());
        }
        int previousCatch = records.getInt(key + ".fastestCatchSeconds", Integer.MAX_VALUE);
        if (match.fastestCatchSeconds() >= 0 && match.fastestCatchSeconds() < previousCatch) {
            if (previousCatch != Integer.MAX_VALUE) {
                bests.add("new fastest catch: " + match.fastestCatchSeconds() + "s");
            }
            records.set(key + ".fastestCatchSeconds", match.fastestCatchSeconds());
        }
        return bests;
    }

    String summary(UUID id) {
        String key = id.toString();
        return records.getInt(key + ".games") + " games • " + records.getInt(key + ".ratWins") + " rat wins • "
                + records.getInt(key + ".humanWins") + " human wins • " + records.getInt(key + ".catches")
                + " catches • " + records.getInt(key + ".cheese") + " cheese";
    }

    void save() {
        // Written off the main thread; a slow disk must not freeze the end-of-match screen.
        AsyncFiles.writeYaml(plugin, records, file);
    }

    private void increment(String path) {
        add(path, 1);
    }

    private void add(String path, int amount) {
        if (amount != 0) {
            records.set(path, records.getInt(path) + amount);
        }
    }
}
