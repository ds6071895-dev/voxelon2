package dev.autobox.ratseek;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * One AI seeker. It plays by a human's rules: it only knows what it has seen (in its field of view,
 * with line of sight), heard, or been told by the same hints and alarms human seekers get. It notices
 * rats gradually, turns its head at a human pace, loses rats that break line of sight, and can miss.
 * It walks the manor on {@link RatSeekNav} paths at a human seeker's running speed.
 */
final class RatSeekBot {
    static final String BODY_TAG = "ai_seeker_body";

    /** Play styles, so a squad of bots doesn't all behave the same. */
    enum Style {
        TRACKER("Tracker", 1.35, 1.5, 0.6, 0.6, 0.65, Color.fromRGB(0x8A2B2B)),
        SWEEPER("Sweeper", 1.0, 0.8, 0.8, 1.6, 1.0, Color.fromRGB(0x2B4F8A)),
        TRAPPER("Trapper", 0.9, 0.9, 1.9, 0.8, 0.8, Color.fromRGB(0x5E6B2B));

        final String displayName;
        /** Longer chases before giving up. */
        final double persistence;
        /** Eagerness to use the Scent Pulse. */
        final double scent;
        /** Eagerness to lay mousetraps and bait. */
        final double traps;
        /** How much the flashlight comes out while searching. */
        final double flashlight;
        /** Share of a room's hiding spots checked before moving on. */
        final double thoroughness;
        final Color coat;

        Style(String displayName, double persistence, double scent, double traps, double flashlight,
              double thoroughness, Color coat) {
            this.displayName = displayName;
            this.persistence = persistence;
            this.scent = scent;
            this.traps = traps;
            this.flashlight = flashlight;
            this.thoroughness = thoroughness;
            this.coat = coat;
        }
    }

    enum Goal { WAIT, IDLE, SEARCH, INVESTIGATE, CHASE, AMBUSH, TRAP, BAIT, GUARD, SCENT, DODGE }

    /** Something worth checking: a noise, a hint, an alarm, or where a rat was last seen. */
    record Lead(Location at, double strength, int tick, UUID rat) { }

    private static final double EYE = 1.62;
    private static final double REACH = 2.9;
    private static final double SWAT_REACH = 2.7;

    final RatSeekBots squad;
    final String name;
    final String shortName;
    final Style style;
    final int index;
    private final World world;
    Mannequin body;

    // Body.
    double x, y, z;
    private float headYaw = 180, headPitch, bodyYaw = 180;
    private List<double[]> path;
    private int pathIndex;
    private double[] segmentFrom;
    private int[] pathGoal;
    private boolean moving;
    private int hop = -1;
    private int stepSound;
    private boolean crouched;
    private Material held = Material.AIR;
    private boolean removed;

    // Mind.
    Goal goal = Goal.WAIT;
    private Entity target;
    private final Map<UUID, Double> awareness = new HashMap<>();
    private final Set<UUID> seenThisMatch = new HashSet<>();
    private final Set<UUID> seenThrough = new HashSet<>();
    private Location lastSeen;
    private Vector lastSeenMotion = new Vector();
    private int lastSeenTick;
    private Lead lead;
    private Lead plannedLead;
    private int lastLeadTick;
    private Location lookAt;
    private int lookUntil;
    private int nextGlance;
    private float glanceYaw;
    private boolean glancing;
    private int goalUntil;
    private int decideAt;

    // Search plan.
    private RatSeekNav.SearchRoom room;
    private final List<RatSeekNav.Spot> plan = new ArrayList<>();
    private RatSeekNav.Spot inspecting;
    private int inspectUntil;
    private int lookAroundUntil;

    // Gadget errands.
    private int[] errandSite;
    private int errandReadyAt;
    private int lastTrapTick = -10000;
    private int lastBaitTick = -10000;
    private int lastGuardTick = -10000;
    private int scentAt;

    // Status.
    private int nextSwing;
    private int stunnedUntil;
    private int dazedUntil;
    private int blindUntil;
    private int frenzyUntil;
    private int darkUntil;
    private int exposedUntil;
    private int bounceUntil;
    private int nextChat;
    int fooledThisMatch;
    int catches;
    int misses;

    RatSeekBot(RatSeekBots squad, World world, int index, String name, String shortName, Style style) {
        this.squad = squad;
        this.world = world;
        this.index = index;
        this.name = name;
        this.shortName = shortName;
        this.style = style;
    }

    UUID id() {
        return body == null ? null : body.getUniqueId();
    }

    // ------------------------------------------------------------------ body

    void spawn(Location at, RatSeekSettings settings) {
        x = at.getX();
        y = at.getY();
        z = at.getZ();
        headYaw = bodyYaw = at.getYaw();
        headPitch = 0;
        body = world.spawn(at, Mannequin.class, mannequin -> {
            mannequin.customName(Component.text(name, NamedTextColor.RED)
                    .append(Component.text(" [AI]", NamedTextColor.DARK_GRAY)));
            mannequin.setCustomNameVisible(true);
            mannequin.setDescription(Component.text(style.displayName + " • " + settings.botSkill.displayName,
                    NamedTextColor.GRAY));
            mannequin.setProfile(Mannequin.defaultProfile());
            mannequin.setImmovable(true);
            mannequin.setGravity(false);
            mannequin.setCollidable(false);
            mannequin.setInvulnerable(true);
            mannequin.setSilent(true);
            mannequin.setPersistent(false);
            mannequin.getPersistentDataContainer().set(squad.key, PersistentDataType.STRING, BODY_TAG);
            mannequin.getEquipment().setChestplate(dyed(Material.LEATHER_CHESTPLATE, style.coat));
            mannequin.getEquipment().setBoots(dyed(Material.LEATHER_BOOTS, Color.fromRGB(0x3B2A1E)));
            if (style == Style.TRAPPER) {
                mannequin.getEquipment().setHelmet(dyed(Material.LEATHER_HELMET, Color.fromRGB(0x6B5A2B)));
            } else if (style == Style.SWEEPER) {
                mannequin.getEquipment().setLeggings(dyed(Material.LEATHER_LEGGINGS, Color.fromRGB(0x1E1E2A)));
            }
            // No setDropChance: Mannequin is not a Mob and Paper throws. It is invulnerable and only ever
            // removed, so it never drops its gear anyway.
        });
        hold(Material.IRON_SWORD);
    }

    /** The line under the name tag: play style and skill. */
    void label(RatSeekSettings settings) {
        if (body != null && body.isValid()) {
            body.setDescription(Component.text(style.displayName + " • " + settings.botSkill.displayName,
                    NamedTextColor.GRAY));
        }
    }

    private static ItemStack dyed(Material material, Color color) {
        ItemStack item = ItemStack.of(material);
        if (item.getItemMeta() instanceof LeatherArmorMeta meta) {
            meta.setColor(color);
            item.setItemMeta(meta);
        }
        return item;
    }

    void remove() {
        removed = true;
        if (body != null) {
            body.remove();
        }
        squad.gadgets().setBotLight(id(), false);
    }

    /** Parks the bot, e.g. in the waiting booth, with no plans. */
    void place(Location at) {
        x = at.getX();
        y = at.getY();
        z = at.getZ();
        headYaw = bodyYaw = at.getYaw();
        headPitch = 0;
        path = null;
        goal = Goal.WAIT;
        apply();
    }

    Location location() {
        return new Location(world, x, y, z, headYaw, headPitch);
    }

    Location eye() {
        return new Location(world, x, y + (crouched ? 1.27 : EYE), z, headYaw, headPitch);
    }

    private void hold(Material material) {
        if (held == material || body == null) {
            return;
        }
        held = material;
        body.getEquipment().setItemInMainHand(ItemStack.of(material));
    }

    private void crouch(boolean on) {
        if (crouched == on || body == null) {
            return;
        }
        crouched = on;
        if (Mannequin.validPoses().contains(Pose.SNEAKING)) {
            body.setPose(on ? Pose.SNEAKING : Pose.STANDING, on);
        }
    }

    private void apply() {
        if (body == null || !body.isValid()) {
            return;
        }
        double lift = 0;
        if (hop >= 0) {
            double t = hop / 10.0;
            lift = 4 * 1.05 * t * (1 - t);
        }
        body.teleport(new Location(world, x, y + lift, z, headYaw, headPitch));
        body.setBodyYaw(bodyYaw);
    }

    // ------------------------------------------------------------------ status effects from the house

    void stun(int ticks) {
        stunnedUntil = Math.max(stunnedUntil, squad.ticks + ticks);
        blindUntil = Math.max(blindUntil, squad.ticks + ticks);
        path = null;
        target = null;
        crouch(false);
    }

    void daze(int ticks) {
        dazedUntil = Math.max(dazedUntil, squad.ticks + ticks);
    }

    void frenzy(int ticks) {
        frenzyUntil = squad.ticks + ticks;
    }

    void darkness(int ticks) {
        darkUntil = squad.ticks + ticks;
    }

    void expose(int ticks) {
        exposedUntil = squad.ticks + ticks;
        if (body != null) {
            body.setGlowing(true);
        }
    }

    void bounce(int ticks) {
        bounceUntil = squad.ticks + ticks;
    }

    boolean stunned() {
        return squad.ticks < stunnedUntil;
    }

    // ------------------------------------------------------------------ tick

    void tick(RatSeekSettings settings) {
        if (body == null || removed) {
            return;
        }
        if (!body.isValid()) {
            // Something removed the body (a plugin, a kill command): bring it back where it was.
            spawn(location(), settings);
        }
        int now = squad.ticks;
        if (exposedUntil != 0 && now >= exposedUntil) {
            exposedUntil = 0;
            body.setGlowing(false);
        }
        if (target != null && !targetValid()) {
            target = null;
        }
        if ((now + index) % 4 == 0 && !stunned()) {
            perceive(settings);
        }
        if (now >= decideAt) {
            decideAt = now + 10;
            decide(settings);
        }
        behave(settings);
        move(pace(settings));
        look(settings);
        if (hop >= 0 && ++hop > 10) {
            hop = -1;
        }
        apply();
        footsteps();
    }

    private double pace(RatSeekSettings settings) {
        double run = RatSeekBots.RAT_SPRINT * settings.humanSpeed * settings.botSkill.speed;
        int now = squad.ticks;
        if (now < frenzyUntil) {
            // Hunter's Frenzy swaps a human's Speed II for Speed IV.
            run *= 1 + 0.4 / (1.2 * settings.humanSpeed);
        }
        double pace = switch (goal) {
            case CHASE, DODGE -> run;
            case SEARCH -> inspecting != null ? 0 : run * 0.8;
            case INVESTIGATE -> lead != null && distanceTo(lead.at()) < 5 ? run * 0.7 : run;
            default -> run * 0.9;
        };
        if (crouched) {
            pace = Math.min(pace, run * 0.3);
        }
        if (target != null && goal == Goal.CHASE && distanceTo(target.getLocation()) < 1.6) {
            pace *= 0.55; // Brake for the swing instead of overshooting.
        }
        if (now < stunnedUntil) {
            pace *= 0.4;
        } else if (now < dazedUntil) {
            pace *= 0.55;
        }
        return pace;
    }

    // ------------------------------------------------------------------ movement

    private void setPath(List<double[]> fresh, int[] goalCell) {
        if (fresh == null || fresh.size() < 2) {
            path = null;
            pathGoal = goalCell;
            return;
        }
        path = fresh;
        pathIndex = 1;
        pathGoal = goalCell;
        segmentFrom = new double[]{x, y, z};
    }

    /** Plans a walk to the nearest reachable cell around a point. Returns false if there is none. */
    private boolean walkTo(double tx, double ty, double tz, int radius) {
        RatSeekNav nav = squad.nav();
        int[] to = nav.nearest(tx, ty, tz, radius);
        if (to == null) {
            return false;
        }
        if (pathGoal != null && path != null && pathGoal[0] == to[0] && pathGoal[1] == to[1] && pathGoal[2] == to[2]) {
            return true;
        }
        int[] from = nav.nearest(x, y, z, 2);
        List<double[]> fresh = nav.path(from, to);
        if (fresh == null) {
            return false;
        }
        setPath(fresh, to);
        return true;
    }

    private boolean walkTo(Location at, int radius) {
        return walkTo(at.getX(), at.getY(), at.getZ(), radius);
    }

    private boolean arrived() {
        return path == null || pathIndex >= path.size();
    }

    private void move(double pace) {
        moving = false;
        if (path == null || pathIndex >= path.size() || pace <= 0) {
            return;
        }
        double remaining = pace;
        double startX = x, startZ = z;
        while (remaining > 1e-4 && pathIndex < path.size()) {
            double[] next = path.get(pathIndex);
            double dx = next[0] - x, dz = next[2] - z;
            double distance = Math.sqrt(dx * dx + dz * dz);
            if (distance <= remaining) {
                x = next[0];
                z = next[2];
                y = next[1];
                remaining -= distance;
                segmentFrom = next;
                pathIndex++;
                continue;
            }
            x += dx / distance * remaining;
            z += dz / distance * remaining;
            double span = Math.hypot(next[0] - segmentFrom[0], next[2] - segmentFrom[2]);
            double progress = span < 1e-6 ? 1 : Math.min(1, Math.max(0, 1 - (distance - remaining) / span));
            y = segmentFrom[1] + (next[1] - segmentFrom[1]) * heightAlong(next, progress);
            remaining = 0;
        }
        double mx = x - startX, mz = z - startZ;
        if (mx * mx + mz * mz > 1e-6) {
            moving = true;
            bodyYaw = turn(bodyYaw, yawOf(mx, mz), 30f);
            // Sprinting humans hop now and then on long, level stretches.
            if (hop < 0 && (goal == Goal.CHASE || squad.ticks < bounceUntil) && pace > 0.3 && levelAhead()
                    && squad.random.nextInt(squad.ticks < bounceUntil ? 3 : 14) == 0) {
                hop = 0;
            }
        }
    }

    /**
     * How far through a level change the body is at this point of the segment: stairs are a
     * steady slope, a jump arcs over the block's edge like a player's, and a drop walks to the
     * edge, then falls faster and faster.
     */
    private double heightAlong(double[] next, double progress) {
        double rise = next[1] - segmentFrom[1];
        if (Math.abs(rise) < 0.01) {
            return progress;
        }
        if (rise > 0) {
            if (squad.nav().onStairs((int) Math.floor(next[0]), (int) Math.round(next[1]), (int) Math.floor(next[2]))) {
                return progress;
            }
            // Up to a 1.25-block peak over the edge, then settle onto the top.
            return progress < 0.55 ? 1.25 * Math.sin(progress / 0.55 * Math.PI / 2)
                    : 1 + 0.25 * Math.cos((progress - 0.55) / 0.45 * Math.PI / 2);
        }
        double fall = Math.max(0, (progress - 0.35) / 0.65);
        return fall * fall;
    }

    private boolean levelAhead() {
        if (path == null || pathIndex >= path.size()) {
            return false;
        }
        double[] next = path.get(pathIndex);
        return Math.abs(next[1] - y) < 0.01 && Math.hypot(next[0] - x, next[2] - z) > 3
                && RatSeekNav.passable(world.getBlockAt((int) Math.floor(x), (int) Math.floor(y) + 2,
                (int) Math.floor(z)).getType());
    }

    private void footsteps() {
        if (!moving || hop > 0 || ++stepSound < (crouched ? 12 : 6)) {
            return;
        }
        stepSound = 0;
        Block below = world.getBlockAt((int) Math.floor(x), (int) Math.floor(y - 0.2), (int) Math.floor(z));
        if (!below.getType().isAir()) {
            world.playSound(new Location(world, x, y, z), below.getBlockData().getSoundGroup().getStepSound(),
                    crouched ? 0.08f : 0.3f, 1f);
        }
    }

    // ------------------------------------------------------------------ looking

    private static float yawOf(double dx, double dz) {
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    private static float wrap(float degrees) {
        degrees %= 360;
        if (degrees >= 180) degrees -= 360;
        if (degrees < -180) degrees += 360;
        return degrees;
    }

    private static float turn(float from, float to, float max) {
        return wrap(from + Math.max(-max, Math.min(max, wrap(to - from))));
    }

    private void look(RatSeekSettings settings) {
        int now = squad.ticks;
        float maxTurn = settings.botSkill.turn * (now < dazedUntil ? 0.5f : 1f);
        float wantYaw = headYaw, wantPitch = 0;
        Location focus = null;
        if (target != null && goal == Goal.CHASE) {
            // Eyes follow what the bot believes, not the rat's true position behind a wall.
            focus = chaseSpot().add(0, target.getHeight() * 0.5, 0);
        } else if (inspecting != null) {
            int[] h = inspecting.hide();
            focus = new Location(world, h[0] + 0.5, h[1] + 0.3, h[2] + 0.5);
        } else if (lookAt != null && now < lookUntil) {
            focus = lookAt;
        }
        if (focus != null) {
            double dx = focus.getX() - x, dz = focus.getZ() - z;
            double dy = focus.getY() - (y + (crouched ? 1.27 : EYE));
            wantYaw = yawOf(dx, dz);
            wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        } else if (now < lookAroundUntil) {
            // Scan the room: a slow sweep left and right.
            wantYaw = wrap(bodyYaw + (float) Math.sin(now / 9.0) * 75f);
            wantPitch = 12;
        } else if (moving) {
            if (now >= nextGlance) {
                glancing = !glancing;
                glanceYaw = (squad.random.nextFloat() - 0.5f) * 140f;
                nextGlance = now + (glancing ? 10 + squad.random.nextInt(10) : 30 + squad.random.nextInt(50));
            }
            wantYaw = wrap(bodyYaw + (glancing ? glanceYaw : 0));
            wantPitch = glancing ? 8 : 4;
        }
        if (now < dazedUntil) {
            wantYaw += (float) Math.sin(now / 3.0) * 25f;
        }
        headYaw = turn(headYaw, wantYaw, maxTurn);
        headPitch += Math.max(-maxTurn, Math.min(maxTurn, wantPitch - headPitch));
        headPitch = Math.max(-60, Math.min(70, headPitch));
        if (!moving) {
            float offset = wrap(headYaw - bodyYaw);
            if (Math.abs(offset) > 50) {
                bodyYaw = turn(bodyYaw, headYaw, Math.abs(offset) - 50);
            }
        }
    }

    private void glanceAt(Location at, int ticks) {
        lookAt = at.clone();
        lookUntil = squad.ticks + ticks;
    }

    // ------------------------------------------------------------------ senses

    private boolean targetValid() {
        if (target instanceof Player rat) {
            return rat.isOnline() && rat.getWorld() == world && squad.isFreeRat(rat);
        }
        return target != null && target.isValid();
    }

    private double distanceTo(Location at) {
        double dx = at.getX() - x, dy = at.getY() - y, dz = at.getZ() - z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Sight: builds awareness of each rat (and decoy) in view; a full bar means "spotted". */
    private void perceive(RatSeekSettings settings) {
        Location eye = eye();
        Vector look = eye.getDirection();
        int now = squad.ticks;
        double sightScale = now < blindUntil ? 0.2 : now < darkUntil ? 0.45 : 1.0;
        boolean lightOn = squad.gadgets().botLightOn(id());
        double size = settings.ratSize.scale <= 0.4 ? 0.7 : settings.ratSize.scale >= 0.7 ? 1.0 : 0.85;
        boolean targetSeen = false;
        List<Entity> candidates = new ArrayList<>(squad.freeRatPlayers());
        candidates.addAll(squad.decoys());
        for (Entity candidate : candidates) {
            UUID cid = candidate.getUniqueId();
            if (seenThrough.contains(cid)) {
                continue;
            }
            Location centre = candidate.getLocation().add(0, candidate.getHeight() * 0.5, 0);
            Vector to = centre.toVector().subtract(eye.toVector());
            double distance = to.length();
            double rate = 0;
            if (distance < 36) {
                double angle = distance < 0.01 ? 0 : Math.toDegrees(look.angle(to));
                boolean glowing = candidate.isGlowing()
                        || (candidate instanceof Player p && p.hasPotionEffect(PotionEffectType.GLOWING));
                boolean invisible = candidate instanceof Player p && p.hasPotionEffect(PotionEffectType.INVISIBILITY);
                double motion = squad.motion(candidate);
                if (glowing && angle < 65 && distance < 30 * Math.max(0.5, sightScale)) {
                    // A glow outline shows through walls, for bots just like for players.
                    rate = 0.5;
                } else if (invisible) {
                    rate = distance < 1.8 && motion > 0.05 ? 0.15 : 0;
                } else if (angle < 100) {
                    double range = settings.botSkill.sight * size * sightScale
                            * (lightOn && angle < 25 ? 1.45 : 1.0) * (candidate == target ? 1.4 : 1.0);
                    if (distance <= range && canSee(eye, candidate, distance)) {
                        double proximity = 1 - distance / range;
                        rate = 0.07 + 0.55 * Math.pow(proximity, 1.3);
                        boolean sneaking = candidate instanceof Player p && p.isSneaking();
                        rate *= motion > 0.2 ? 1.7 : motion > 0.05 ? 1.25 : sneaking ? 0.4 : 0.65;
                        if (angle > 60) {
                            rate *= 0.35; // Peripheral vision: movement catches the eye, stillness doesn't.
                        }
                    }
                }
                rate *= settings.botSkill.reaction * squad.momentum;
                if (candidate == target && rate > 0) {
                    rate = Math.max(rate * 2.5, 0.35);
                }
                // Hearing: a sprinting rat's footsteps carry a few blocks, even around corners.
                if (rate == 0 && candidate instanceof Player rat && motion > 0.2 && rat.isSprinting()
                        && distance < 7 && Math.abs(centre.getY() - eye.getY()) < 2.5
                        && squad.random.nextInt(4) == 0) {
                    hear(rat.getLocation(), 0.35, 1.6, rat.getUniqueId());
                }
            }
            double level = awareness.getOrDefault(cid, 0.0);
            level = rate > 0 ? Math.min(1.6, level + rate) : Math.max(0, level - 0.12);
            if (level <= 0) {
                awareness.remove(cid);
            } else {
                awareness.put(cid, level);
            }
            if (rate > 0 && level >= 1) {
                if (candidate == target) {
                    targetSeen = true;
                    lastSeen = candidate.getLocation();
                    lastSeenMotion = squad.velocity(candidate);
                    lastSeenTick = now;
                } else if (target == null || (goal != Goal.CHASE && candidate instanceof Player)
                        || (candidate instanceof Player && distance < 4 && distance + 3 < distanceTo(target.getLocation()))) {
                    spotted(candidate, settings);
                    targetSeen = true;
                }
            }
        }
        if (target != null && !targetSeen && goal == Goal.CHASE
                && now - lastSeenTick > settings.botSkill.patience * style.persistence) {
            lostTarget();
        }
    }

    private boolean canSee(Location eye, Entity candidate, double distance) {
        Location feet = candidate.getLocation();
        double height = candidate.getHeight();
        for (double part : new double[]{0.5, 0.9, 0.15}) {
            if (clearRay(eye, feet.clone().add(0, height * part, 0))) {
                return true;
            }
        }
        // Crouching (or standing right over it) lets a seeker peer under furniture.
        if ((crouched || distance < 3.2) && Math.abs(feet.getY() - y) < 1.3) {
            return clearRay(new Location(world, x, y + 0.38, z), feet.clone().add(0, Math.min(0.36, height * 0.6), 0));
        }
        return false;
    }

    private boolean clearRay(Location from, Location to) {
        Vector ray = to.toVector().subtract(from.toVector());
        double length = ray.length();
        return length < 0.05 || world.rayTraceBlocks(from, ray.multiply(1 / length), length,
                FluidCollisionMode.NEVER, true) == null;
    }

    private void spotted(Entity candidate, RatSeekSettings settings) {
        if (candidate instanceof ArmorStand) {
            double wits = settings.botSkill.wits + fooledThisMatch * 0.25
                    + (settings.botLearning ? squad.memory().decoyWisdom() * 0.6 : 0);
            if (squad.random.nextDouble() < Math.min(0.9, wits)) {
                seenThrough.add(candidate.getUniqueId());
                say(fooledThisMatch > 0 || squad.memory().decoyWisdom() > 0.3
                        ? "Nice try. I'm not falling for that again." : "Hah, that's a decoy.");
                return;
            }
        }
        boolean fresh = target != candidate;
        target = candidate;
        goal = Goal.CHASE;
        inspecting = null;
        crouch(false);
        squad.gadgets().setBotLight(id(), false);
        lastSeen = candidate.getLocation();
        lastSeenMotion = squad.velocity(candidate);
        lastSeenTick = squad.ticks;
        decideAt = squad.ticks; // React on this tick, not at the next planning slot.
        if (candidate instanceof Player rat) {
            squad.shareSighting(this, rat);
            if (seenThisMatch.add(rat.getUniqueId())) {
                squad.learnFound(rat, rat.getLocation());
            }
            if (fresh) {
                say(squad.pick("There you are!", "I see you, " + rat.getName() + "!", "Found one!",
                        "Got eyes on " + rat.getName() + "!"));
            }
        }
    }

    private void lostTarget() {
        Entity lost = target;
        target = null;
        if (lastSeen != null && lost instanceof Player rat) {
            Location guess = lastSeen.clone().add(lastSeenMotion.clone().multiply(18));
            lead = new Lead(guess, 0.7, squad.ticks, rat.getUniqueId());
            squad.learnEscape(lastSeen);
            say(squad.pick("Where did you go...", "I know you're in here.", "Come out, come out...",
                    "Lost them!"));
        }
        goal = Goal.INVESTIGATE;
        path = null;
        decideAt = squad.ticks;
    }

    /** A sound or report. Weaker, older leads give way to stronger, fresher ones. */
    void hear(Location at, double strength, double fuzz, UUID rat) {
        if (stunned() || goal == Goal.CHASE) {
            return;
        }
        if (lead != null && effective(lead) > strength) {
            return;
        }
        double spread = fuzz + distanceTo(at) * 0.08;
        Location guess = at.clone().add((squad.random.nextDouble() - 0.5) * 2 * spread, 0,
                (squad.random.nextDouble() - 0.5) * 2 * spread);
        lead = new Lead(guess, strength, squad.ticks, rat);
        lastLeadTick = squad.ticks;
        glanceAt(at.clone().add(0, 0.4, 0), 20);
        if (goal != Goal.DODGE && goal != Goal.SCENT) {
            decideAt = Math.min(decideAt, squad.ticks + 3 + squad.random.nextInt(6));
        }
    }

    private double effective(Lead l) {
        return l.strength() - (squad.ticks - l.tick()) / 500.0;
    }

    // ------------------------------------------------------------------ decisions

    private void decide(RatSeekSettings settings) {
        int now = squad.ticks;
        if (stunned()) {
            path = null;
            goal = Goal.IDLE;
            return;
        }
        if (goal == Goal.DODGE && now < goalUntil && !arrived()) {
            return;
        }
        if (target != null && targetValid()) {
            chase(settings);
            return;
        }
        if (goal == Goal.CHASE) {
            goal = Goal.IDLE;
        }
        if (goal == Goal.AMBUSH && now < goalUntil) {
            return;
        }
        if (lead != null && effective(lead) > 0.12) {
            investigate();
            return;
        }
        lead = null;
        if ((goal == Goal.TRAP || goal == Goal.BAIT || goal == Goal.GUARD || goal == Goal.SCENT) && now < goalUntil) {
            return;
        }
        if (goal == Goal.SEARCH && room != null && (inspecting != null || !plan.isEmpty() || !arrived())) {
            return;
        }
        if (goal == Goal.SEARCH && room != null) {
            squad.searched(room.name());
        }
        chooseNext(settings);
    }

    private void chooseNext(RatSeekSettings settings) {
        int now = squad.ticks;
        crouch(false);
        squad.gadgets().setBotLight(id(), false);
        hold(Material.IRON_SWORD);
        // Out of ideas for a while? Sniff (shared cooldown with the human seekers).
        if (settings.scentPulse && squad.game.scentReady() && now - lastLeadTick > 200 / style.scent
                && squad.random.nextDouble() < 0.55 * style.scent) {
            goal = Goal.SCENT;
            goalUntil = now + 12;
            scentAt = now + 8;
            path = null;
            hold(Material.SNIFFER_EGG);
            return;
        }
        RatSeekGadgets gadgets = squad.gadgets();
        if (settings.mousetraps && gadgets.botTraps(id()) > 0 && now - lastTrapTick > 500 / style.traps
                && squad.random.nextDouble() < 0.45 * style.traps) {
            int[] site = squad.pickTrapSite(this, settings);
            if (site != null && walkTo(site[0] + 0.5, site[1], site[2] + 0.5, 2)) {
                errand(Goal.TRAP, site);
                return;
            }
        }
        if (settings.bait && gadgets.botBaits(id()) > 0 && now - lastBaitTick > 700 / style.traps
                && squad.random.nextDouble() < 0.35 * style.traps) {
            int[] site = squad.pickBaitSite(this, settings);
            if (site != null && walkTo(site[0] + 0.5, site[1], site[2] + 0.5, 2)) {
                errand(Goal.BAIT, site);
                return;
            }
        }
        if (settings.rescues && squad.shouldGuard(this) && now - lastGuardTick > 1400) {
            Location post = squad.guardPost(this);
            if (walkTo(post, 2)) {
                lastGuardTick = now;
                goal = Goal.GUARD;
                goalUntil = now + 220 + squad.random.nextInt(120);
                errandSite = null;
                return;
            }
        }
        startSearch(settings);
    }

    private void errand(Goal kind, int[] site) {
        goal = kind;
        errandSite = site;
        errandReadyAt = -1;
        goalUntil = squad.ticks + 400;
        if (kind == Goal.TRAP) {
            lastTrapTick = squad.ticks;
        } else {
            lastBaitTick = squad.ticks;
        }
    }

    private void startSearch(RatSeekSettings settings) {
        room = squad.pickRoom(this, settings);
        plan.clear();
        inspecting = null;
        if (room == null) {
            goal = Goal.IDLE;
            return;
        }
        List<RatSeekNav.Spot> spots = new ArrayList<>(room.spots());
        int keep = Math.max(2, (int) Math.ceil(spots.size() * style.thoroughness
                * (settings.botSkill == RatSeekSettings.BotSkill.ROOKIE ? 0.7 : 1.0)));
        // Most promising first (learned hot spots), with a little randomness like a person's hunch.
        spots.sort((a, b) -> Double.compare(squad.spotScore(b, settings), squad.spotScore(a, settings)));
        plan.addAll(spots.subList(0, Math.min(keep, spots.size())));
        orderPlanFromHere();
        goal = Goal.SEARCH;
        if (!walkTo(room.centre()[0] + 0.5, room.centre()[1], room.centre()[2] + 0.5, 2)) {
            squad.searched(room.name());
            room = null;
            goal = Goal.IDLE;
        }
    }

    /** Visits the plan in a sensible walking order: nearest first, but hot spots pull forward. */
    private void orderPlanFromHere() {
        List<RatSeekNav.Spot> ordered = new ArrayList<>();
        double cx = x, cz = z;
        List<RatSeekNav.Spot> left = new ArrayList<>(plan);
        while (!left.isEmpty()) {
            RatSeekNav.Spot best = null;
            double bestScore = Double.MAX_VALUE;
            for (int i = 0; i < left.size(); i++) {
                RatSeekNav.Spot spot = left.get(i);
                double distance = Math.hypot(spot.from()[0] + 0.5 - cx, spot.from()[2] + 0.5 - cz);
                // Earlier entries in the plan are the more promising spots.
                double score = distance - (left.size() - i) * 0.6;
                if (score < bestScore) {
                    bestScore = score;
                    best = spot;
                }
            }
            left.remove(best);
            ordered.add(best);
            cx = best.from()[0] + 0.5;
            cz = best.from()[2] + 0.5;
        }
        plan.clear();
        plan.addAll(ordered);
    }

    private void investigate() {
        if (goal != Goal.INVESTIGATE || path == null || plannedLead != lead) {
            goal = Goal.INVESTIGATE;
            plannedLead = lead;
            inspecting = null;
            crouch(false);
            if (!walkTo(lead.at(), 3)) {
                lead = null;
                goal = Goal.IDLE;
            }
        }
    }

    /**
     * Where the bot believes its target is: the live position while it can see it, otherwise
     * where it was last seen, carried on a little along the way it was running.
     */
    private Location chaseSpot() {
        int unseen = squad.ticks - lastSeenTick;
        if (unseen <= 4 || lastSeen == null) {
            return target.getLocation();
        }
        return lastSeen.clone().add(lastSeenMotion.clone().multiply(Math.min(unseen, 12)));
    }

    private void chase(RatSeekSettings settings) {
        int now = squad.ticks;
        if (goal == Goal.AMBUSH) {
            if (now < goalUntil && target instanceof Player waiting && squad.game.inSecretPassage(waiting.getLocation())) {
                return; // Keep waiting at the exit.
            }
            if (now >= goalUntil) {
                target = null;
                goal = Goal.IDLE;
                say(squad.pick("Fine, stay in there.", "Ugh, forget it."));
                return;
            }
        }
        goal = Goal.CHASE;
        Location at = chaseSpot();
        if (target instanceof Player rat && squad.game.inSecretPassage(rat.getLocation())
                && lastSeen != null && lastSeen.distanceSquared(rat.getLocation()) < 36) {
            // Humans can't fit in the ducts: cut the rat off at the end it will probably use.
            Location exit = squad.predictExit(rat, lastSeenMotion, settings);
            if (exit != null && walkTo(exit, 2)) {
                goal = Goal.AMBUSH;
                goalUntil = now + 100 + (int) (40 * style.persistence);
                glanceAt(exit.clone().add(0, 0.3, 0), 140);
                say(squad.pick("I'll wait for you at the other end.", "You have to come out sometime..."));
                return;
            }
        }
        // Rats under furniture or in mouseholes: get as close as a human can and swat in.
        if (!walkTo(at, 3)) {
            lostTarget();
            return;
        }
        double low = y + 1.3 - at.getY();
        crouch(distanceTo(at) < 3.5 && low > 0.9 && !clearRay(eye(), at.clone().add(0, target.getHeight() * 0.5, 0)));
    }

    // ------------------------------------------------------------------ per-tick behaviour

    private void behave(RatSeekSettings settings) {
        int now = squad.ticks;
        switch (goal) {
            case CHASE -> {
                if ((now + index) % 4 == 0 && target != null) {
                    Location at = chaseSpot();
                    if ((pathGoal == null || Math.hypot(pathGoal[0] + 0.5 - at.getX(), pathGoal[2] + 0.5 - at.getZ()) > 1.2
                            || Math.abs(pathGoal[1] - at.getY()) > 1.5) && squad.takePathBudget()) {
                        walkTo(at, 3);
                    }
                }
                tryCatch(settings);
            }
            case SEARCH -> tickSearch(settings);
            case INVESTIGATE -> {
                if (arrived() && lead != null) {
                    if (lookAroundUntil < now) {
                        lookAroundUntil = now + 30 + squad.random.nextInt(20);
                        if (settings.flashlight && squad.gadgets().botBattery(id()) > 0.4
                                && squad.random.nextDouble() < 0.4 * style.flashlight) {
                            squad.gadgets().setBotLight(id(), true);
                        }
                    }
                    lead = null;
                    decideAt = lookAroundUntil;
                }
            }
            case AMBUSH -> {
                crouch(false);
                if (now >= goalUntil) {
                    goal = Goal.IDLE;
                    decideAt = now;
                }
            }
            case TRAP, BAIT -> tickErrand(settings);
            case GUARD -> {
                if (arrived()) {
                    glanceAt(squad.guardWatch(), 15);
                }
            }
            case SCENT -> {
                if (now == scentAt) {
                    Player found = squad.game.botScentPulse(location());
                    hold(Material.IRON_SWORD);
                    if (found != null) {
                        hear(found.getLocation(), 0.85, 1.0, found.getUniqueId());
                        say(squad.pick("*sniff sniff* ...this way.", "I can smell cheese breath."));
                    }
                    goalUntil = now;
                }
            }
            case DODGE -> {
                if (arrived()) {
                    goal = Goal.IDLE;
                    decideAt = now;
                }
            }
            default -> { }
        }
        if (goal != Goal.CHASE && (target == null || targetValid())) {
            tryCatch(settings);
        }
    }

    private void tickSearch(RatSeekSettings settings) {
        int now = squad.ticks;
        if (inspecting != null) {
            if (now >= inspectUntil) {
                inspecting = null;
                crouch(false);
                squad.gadgets().setBotLight(id(), false);
            }
            return;
        }
        if (!arrived()) {
            return;
        }
        if (plan.isEmpty()) {
            if (lookAroundUntil < now - 60) {
                lookAroundUntil = now + 25;
            }
            return;
        }
        RatSeekNav.Spot next = plan.getFirst();
        int[] from = next.from();
        if (Math.hypot(from[0] + 0.5 - x, from[2] + 0.5 - z) > 1.2 || Math.abs(from[1] - y) > 0.6) {
            if (!walkTo(from[0] + 0.5, from[1], from[2] + 0.5, 1)) {
                plan.removeFirst();
            }
            return;
        }
        plan.removeFirst();
        inspecting = next;
        inspectUntil = now + (int) ((12 + squad.random.nextInt(12)) * (style == Style.SWEEPER ? 1.3 : 1.0));
        crouch(next.low());
        if (settings.flashlight && squad.gadgets().botBattery(id()) > 0.35
                && squad.random.nextDouble() < 0.3 * style.flashlight) {
            squad.gadgets().setBotLight(id(), true);
        }
    }

    private void tickErrand(RatSeekSettings settings) {
        int now = squad.ticks;
        if (errandSite == null || now >= goalUntil) {
            goal = Goal.IDLE;
            decideAt = now;
            return;
        }
        if (!arrived()) {
            return;
        }
        Location site = new Location(world, errandSite[0] + 0.5, errandSite[1], errandSite[2] + 0.5);
        if (errandReadyAt < 0) {
            errandReadyAt = now + 10;
            crouch(true);
            hold(goal == Goal.TRAP ? Material.HEAVY_WEIGHTED_PRESSURE_PLATE : Material.HONEYCOMB);
            glanceAt(site, 12);
            return;
        }
        glanceAt(site, 5);
        if (now < errandReadyAt) {
            return;
        }
        body.swingMainHand();
        Block block = world.getBlockAt(errandSite[0], errandSite[1], errandSite[2]);
        boolean placed = goal == Goal.TRAP
                ? squad.gadgets().botPlaceTrap(id(), block, this.name)
                : squad.gadgets().botPlaceBait(id(), block, this.name);
        if (placed) {
            squad.learnPlaced(goal == Goal.TRAP ? "trap" : "bait", errandSite, settings);
        }
        crouch(false);
        hold(Material.IRON_SWORD);
        errandSite = null;
        goal = Goal.IDLE;
        decideAt = now + 4;
    }

    // ------------------------------------------------------------------ catching

    /** Horizontal distance to something the bot could swing at right now, or -1 if it can't. */
    private double swingRange(Entity victim, float maxFacing) {
        Location at = victim.getLocation();
        double dx = at.getX() - x, dz = at.getZ() - z;
        double horizontal = Math.hypot(dx, dz);
        double reach = crouched ? SWAT_REACH : REACH;
        // Like a player: three blocks from the eye, so rats on shelves and tables are in reach.
        double rise = at.getY() + Math.min(0.2, victim.getHeight() * 0.3) - (y + EYE);
        if (horizontal > reach + 0.3 || at.getY() - y < -2.2 || Math.hypot(horizontal, Math.max(0, rise)) > 3.1) {
            return -1;
        }
        if (horizontal > 0.6 && Math.abs(wrap(yawOf(dx, dz) - headYaw)) > maxFacing) {
            return -1;
        }
        Location centre = at.clone().add(0, victim.getHeight() * 0.5, 0);
        boolean sight = clearRay(eye(), centre) || clearRay(eye(), at.clone().add(0, victim.getHeight() * 0.9, 0))
                || (Math.abs(at.getY() - y) < 1.2
                && clearRay(new Location(world, x, y + 0.38, z), at.clone().add(0, Math.min(0.36, victim.getHeight() * 0.6), 0)));
        return sight ? horizontal : -1;
    }

    /**
     * A rat right in front of the bot that it isn't chasing: like a player, it swings at whatever
     * it runs into rather than only its target. Needs a little awareness unless the rat is moving.
     */
    private Player bystander() {
        Player best = null;
        double bestRange = Double.MAX_VALUE;
        for (Player rat : squad.freeRatPlayers()) {
            if (rat == target || rat.hasPotionEffect(PotionEffectType.INVISIBILITY)) {
                continue;
            }
            if (awareness.getOrDefault(rat.getUniqueId(), 0.0) < 0.3 && squad.motion(rat) < 0.05) {
                continue;
            }
            double range = swingRange(rat, 60);
            if (range >= 0 && range < bestRange) {
                best = rat;
                bestRange = range;
            }
        }
        return best;
    }

    private void tryCatch(RatSeekSettings settings) {
        int now = squad.ticks;
        if (now < nextSwing || stunned()) {
            return;
        }
        double horizontal = target == null ? -1 : swingRange(target, 40);
        if (horizontal < 0) {
            Player other = bystander();
            if (other == null) {
                return;
            }
            // Switch to the rat within reach; the old target can be picked up again later.
            if (target instanceof Player && squad.random.nextInt(2) == 0) {
                say(squad.pick("Ooh, you'll do!", "Two rats? Don't mind if I do.", "Wait, " + other.getName() + "?!"));
            }
            target = other;
            goal = Goal.CHASE;
            lastSeen = other.getLocation();
            lastSeenMotion = squad.velocity(other);
            lastSeenTick = now;
            horizontal = swingRange(other, 60);
        }
        double reach = crouched ? SWAT_REACH : REACH;
        int rhythm = settings.botSkill == RatSeekSettings.BotSkill.ROOKIE ? 13 : 9;
        nextSwing = now + rhythm + squad.random.nextInt(6);
        body.swingMainHand();
        world.playSound(location(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.7f, 0.9f + squad.random.nextFloat() * 0.2f);
        if (target instanceof ArmorStand decoy) {
            if (squad.hitDecoy(this, decoy)) {
                fooledThisMatch++;
                daze(40);
                target = null;
                goal = Goal.IDLE;
                say(squad.pick("Hey! That's not a rat!", "A DUMMY?!", "Oh, come ON."));
            }
            return;
        }
        if (!(target instanceof Player rat)) {
            return;
        }
        double chance = settings.botSkill.accuracy * squad.momentum;
        double ratSpeed = squad.motion(rat);
        if (ratSpeed > 0.22) {
            chance *= 0.8; // A dodging, sprinting rat is harder to tag.
        }
        if (settings.ratSize.scale <= 0.4) {
            chance *= 0.85;
        }
        if (horizontal > reach - 0.4) {
            chance *= 0.8;
        }
        if (now < dazedUntil) {
            chance *= 0.5;
        }
        if (squad.random.nextDouble() < chance) {
            catches++;
            target = null;
            goal = Goal.IDLE;
            crouch(false);
            decideAt = now + 20;
            squad.botCaught(this, rat);
        } else {
            misses++;
            if (squad.random.nextInt(3) == 0) {
                say(squad.pick("Argh, so close!", "Slippery little thing...", "Stand STILL!", "Missed!"));
            }
        }
    }

    // ------------------------------------------------------------------ chandeliers

    /** A chandelier above is about to drop; a sharp (or experienced) bot jumps clear. */
    void chandelierWarning(Location floor, int ticksLeft, RatSeekSettings settings) {
        double dx = x - floor.getX(), dz = z - floor.getZ();
        if (dx * dx + dz * dz > 3.2 * 3.2 || Math.abs(y - floor.getY()) > 2.5 || stunned()) {
            return;
        }
        double chance = 0.25 + (settings.botSkill.reaction - 0.6) * 0.35
                + (settings.botLearning ? squad.memory().chandelierWisdom() * 0.5 : 0);
        if (squad.random.nextDouble() >= Math.min(0.9, chance)) {
            glanceAt(floor.clone().add(0, 4, 0), 15);
            return;
        }
        double length = Math.hypot(dx, dz);
        double ux = length < 0.1 ? 1 : dx / length, uz = length < 0.1 ? 0 : dz / length;
        if (walkTo(floor.getX() + ux * 3.8, floor.getY(), floor.getZ() + uz * 3.8, 2)) {
            goal = Goal.DODGE;
            goalUntil = squad.ticks + ticksLeft + 10;
            target = null;
            if (squad.memory().chandelierWisdom() > 0.3) {
                say("Not this time!");
            }
        }
    }

    boolean under(Location floor) {
        double dx = x - floor.getX(), dz = z - floor.getZ();
        return dx * dx + dz * dz <= 2.3 * 2.3 && Math.abs(y - floor.getY()) <= 2.5;
    }

    // ------------------------------------------------------------------ chat

    void say(String message) {
        int now = squad.ticks;
        if (now < nextChat || !squad.chatSlot()) {
            return;
        }
        nextChat = now + 160 + squad.random.nextInt(120);
        squad.chat(this, message);
    }

    void sayNow(String message) {
        nextChat = squad.ticks + 100;
        squad.chat(this, message);
    }

    // ------------------------------------------------------------------ squad queries

    Entity target() {
        return target;
    }

    boolean busy() {
        return goal == Goal.CHASE || goal == Goal.AMBUSH || goal == Goal.DODGE || stunned();
    }

    RatSeekNav.SearchRoom searchingRoom() {
        return goal == Goal.SEARCH ? room : null;
    }

    void resetMind() {
        // No sniffing or trap-laying the instant the doors open; look around first like a person.
        lastLeadTick = squad.ticks;
        lastTrapTick = squad.ticks - 250;
        lastBaitTick = squad.ticks - 300;
        target = null;
        lead = null;
        awareness.clear();
        plan.clear();
        inspecting = null;
        room = null;
        path = null;
        goal = Goal.IDLE;
        decideAt = squad.ticks;
        crouch(false);
    }

    void particlesOnCatch() {
        world.spawnParticle(Particle.CRIT, location().add(0, 1, 0), 12, 0.3, 0.3, 0.3, 0.2);
    }
}
