package dev.autobox;

import dev.autobox.holeinwall.HoleInWallGame;
import dev.autobox.luckypillars.LuckyPillarsGame;
import dev.autobox.ratseek.RatSeekGame;
import dev.autobox.game.AutoBoxGame;
import dev.autobox.game.AutoBoxCommand;
import dev.autobox.game.Disadvantage;
import dev.autobox.game.GameListener;
import dev.autobox.chicken.ChickenRunGame;
import dev.autobox.zombie.ZombieApocalypseGame;
import dev.autobox.lobby.LobbyAttractions;
import dev.autobox.lobby.LobbyListener;
import dev.autobox.lobby.LobbyManager;
import dev.autobox.sumo.BlockSumoGame;
import dev.autobox.splat.SplatArena;
import dev.autobox.splat.SplatCommand;
import dev.autobox.splat.SplatGame;
import dev.autobox.splat.SplatListener;
import dev.autobox.splat.SplatPack;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.block.sign.SignSide;
import org.bukkit.entity.Player;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class AutoBoxPlugin extends JavaPlugin {

    public static final String ARENA_WORLD_NAME = "autobox_arena";
    public static final String LOBBY_WORLD_NAME = "autobox_lobby";
    public static final Component SETTINGS_TITLE = Component.text("AutoBox Settings", NamedTextColor.GOLD);

    private final Map<UUID, Set<Disadvantage>> playerSettings = new HashMap<>();

    private AutoBoxGame game;
    private LuckyPillarsGame luckyPillars;
    private BlockSumoGame blockSumo;
    private ChickenRunGame chickenRun;
    private HoleInWallGame holeInWall;
    private SplatGame splat;
    private SplatPack splatPack;
    private ZombieApocalypseGame zombieApocalypse;
    private RatSeekGame ratSeek;
    private LobbyManager lobbyManager;
    private LobbyAttractions lobbyAttractions;
    private World arenaWorld;
    private Location lobbySpawn;

    @Override
    public void onEnable() {
        World lobby = Bukkit.getWorld(LOBBY_WORLD_NAME);
        if (lobby == null) {
            WorldCreator creator = new WorldCreator(LOBBY_WORLD_NAME);
            creator.generator(new VoidGenerator());
            creator.generateStructures(false);
            lobby = Bukkit.createWorld(creator);
        }
        configureLobby(lobby);
        lobbySpawn = buildLobby(lobby);

        arenaWorld = Bukkit.getWorld(ARENA_WORLD_NAME);
        if (arenaWorld == null) {
            WorldCreator creator = new WorldCreator(ARENA_WORLD_NAME);
            creator.generator(new VoidGenerator());
            creator.generateStructures(false);
            arenaWorld = Bukkit.createWorld(creator);
        }
        configureArena(arenaWorld);

        World pillarsWorld = Bukkit.getWorld(LuckyPillarsGame.WORLD_NAME);
        if (pillarsWorld == null) {
            WorldCreator creator = new WorldCreator(LuckyPillarsGame.WORLD_NAME);
            creator.generator(new VoidGenerator());
            creator.generateStructures(false);
            pillarsWorld = Bukkit.createWorld(creator);
        }
        configureArena(pillarsWorld);

        World sumoWorld = Bukkit.getWorld(BlockSumoGame.WORLD_NAME);
        if (sumoWorld == null) {
            WorldCreator creator = new WorldCreator(BlockSumoGame.WORLD_NAME);
            creator.generator(new VoidGenerator());
            creator.generateStructures(false);
            sumoWorld = Bukkit.createWorld(creator);
        }
        configureArena(sumoWorld);

        World chickenWorld = Bukkit.getWorld(ChickenRunGame.WORLD_NAME);
        if (chickenWorld == null) {
            WorldCreator creator = new WorldCreator(ChickenRunGame.WORLD_NAME);
            creator.generator(new VoidGenerator());
            creator.generateStructures(false);
            chickenWorld = Bukkit.createWorld(creator);
        }

        World holeWorld = Bukkit.getWorld(HoleInWallGame.WORLD_NAME);
        if (holeWorld == null) {
            WorldCreator creator = new WorldCreator(HoleInWallGame.WORLD_NAME);
            creator.generator(new VoidGenerator());
            creator.generateStructures(false);
            holeWorld = Bukkit.createWorld(creator);
        }
        configureArena(holeWorld);
        holeWorld.setPVP(false);
        holeWorld.setMonsterSpawnLimit(20);

        World splatArena = Bukkit.getWorld(SplatGame.WORLD_NAME);
        if (splatArena == null) {
            WorldCreator creator = new WorldCreator(SplatGame.WORLD_NAME);
            creator.generator(new VoidGenerator());
            creator.generateStructures(false);
            splatArena = Bukkit.createWorld(creator);
        }
        configureArena(splatArena);
        // configureArena's 256-block border stops at x=128, which cut Coral Heights (x 112-188) in half.
        int splatMinX = SplatArena.MAPS.stream().mapToInt(m -> m.blueprint().bounds().minX()).min().orElse(0) - 64;
        int splatMaxX = SplatArena.MAPS.stream().mapToInt(m -> m.blueprint().bounds().maxX()).max().orElse(0) + 64;
        splatArena.getWorldBorder().setCenter((splatMinX + splatMaxX) / 2.0, 0);
        splatArena.getWorldBorder().setSize(Math.max(256, splatMaxX - splatMinX));

        World zombieWorld = Bukkit.getWorld(ZombieApocalypseGame.WORLD_NAME);
        if (zombieWorld == null) {
            WorldCreator creator = new WorldCreator(ZombieApocalypseGame.WORLD_NAME);
            creator.generator(new VoidGenerator());
            creator.generateStructures(false);
            zombieWorld = Bukkit.createWorld(creator);
        }
        configureArena(zombieWorld);
        zombieWorld.setDifficulty(Difficulty.NORMAL);
        zombieWorld.setPVP(false);
        zombieWorld.setTime(18000);
        zombieWorld.setViewDistance(4);
        zombieWorld.setSimulationDistance(4);
        zombieWorld.setGameRule(GameRule.MOB_GRIEFING, false);
        zombieWorld.setGameRule(GameRule.NATURAL_REGENERATION, false);
        zombieWorld.getWorldBorder().setSize(82);

        World ratWorld = Bukkit.getWorld(RatSeekGame.WORLD_NAME);
        if (ratWorld == null) {
            WorldCreator creator = new WorldCreator(RatSeekGame.WORLD_NAME);
            creator.generator(new VoidGenerator());
            creator.generateStructures(false);
            ratWorld = Bukkit.createWorld(creator);
        }
        configureArena(ratWorld);
        ratWorld.getWorldBorder().setCenter(0, 4);
        ratWorld.getWorldBorder().setSize(96);

        game = new AutoBoxGame(this, arenaWorld, lobbySpawn);
        luckyPillars = new LuckyPillarsGame(this, pillarsWorld, lobbySpawn);
        blockSumo = new BlockSumoGame(this, sumoWorld, lobbySpawn);
        chickenRun = new ChickenRunGame(this, chickenWorld, lobbySpawn);
        holeInWall = new HoleInWallGame(this, holeWorld, lobbySpawn);
        try {
            splatPack = SplatPack.fromResource(getLogger(), getClassLoader());
            splatPack.start();
        } catch (java.io.IOException failure) {
            getLogger().log(java.util.logging.Level.WARNING, "Splatoon pack unavailable; matches use vanilla visuals", failure);
        }
        splat = new SplatGame(this, splatArena, splatPack);
        zombieApocalypse = new ZombieApocalypseGame(this, zombieWorld);
        ratSeek = new RatSeekGame(this, ratWorld, lobbySpawn);
        lobbyAttractions = new LobbyAttractions(this, lobbySpawn);
        lobbyAttractions.build();
        lobbyManager = new LobbyManager(this, luckyPillars, blockSumo, chickenRun, holeInWall, splat,
                zombieApocalypse, ratSeek, lobbySpawn);
        lobbyManager.setAttractions(lobbyAttractions);
        lobbyAttractions.setLobbyManager(lobbyManager);

        AutoBoxCommand command = new AutoBoxCommand(this, luckyPillars);
        getCommand("autobox").setExecutor(command);
        getCommand("autobox").setTabCompleter(command);
        getCommand("lobby").setExecutor(command);
        getCommand("leave").setExecutor(command);
        getCommand("crtp").setExecutor((sender, ignoredCommand, ignoredLabel, ignoredArgs) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(Component.text("Only players can use this command.", NamedTextColor.RED));
                return true;
            }
            chickenRun.teleportToLeader(player);
            return true;
        });
        SplatCommand splatCommand = new SplatCommand(this, splat);
        getCommand("splat").setExecutor(splatCommand);
        getCommand("splat").setTabCompleter(splatCommand);
        Bukkit.getPluginManager().registerEvents(new GameListener(this, game), this);
        Bukkit.getPluginManager().registerEvents(ratSeek, this);
        Bukkit.getPluginManager().registerEvents(luckyPillars, this);
        Bukkit.getPluginManager().registerEvents(zombieApocalypse, this);
        Bukkit.getPluginManager().registerEvents(new LobbyListener(lobbyManager), this);
        Bukkit.getPluginManager().registerEvents(new SplatListener(splat), this);
        Bukkit.getPluginManager().registerEvents(lobbyAttractions, this);
        lobbyManager.start();
        lobbyAttractions.start();

        getLogger().info("Worlds enabled: Splatoon, Lucky Pillars, Block Sumo, ChickenRun, Hole in the Wall, "
                + "Zombie Apocalypse, and Rat and Seek are ready.");
    }

    @Override
    public void onDisable() {
        if (game != null) {
            game.shutdown();
        }
        if (luckyPillars != null) {
            luckyPillars.shutdown();
        }
        if (blockSumo != null) {
            blockSumo.shutdown();
        }
        if (chickenRun != null) {
            chickenRun.shutdown();
        }
        if (holeInWall != null) {
            holeInWall.shutdown();
        }
        if (splat != null) {
            splat.shutdown();
        }
        if (splatPack != null) {
            splatPack.stop();
        }
        if (zombieApocalypse != null) {
            zombieApocalypse.shutdown();
        }
        if (ratSeek != null) {
            ratSeek.shutdown();
        }
        if (lobbyManager != null) {
            lobbyManager.shutdown();
        }
        if (lobbyAttractions != null) {
            lobbyAttractions.shutdown();
        }
    }

    @Override
    public ChunkGenerator getDefaultWorldGenerator(String worldName, String id) {
        return null;
    }

    public Location getLobbySpawn() {
        return lobbySpawn;
    }

    public BlockSumoGame getBlockSumo() {
        return blockSumo;
    }

    public LuckyPillarsGame getLuckyPillars() {
        return luckyPillars;
    }

    public ChickenRunGame getChickenRun() {
        return chickenRun;
    }

    public HoleInWallGame getHoleInWall() {
        return holeInWall;
    }

    public SplatGame getSplat() {
        return splat;
    }

    public ZombieApocalypseGame getZombieApocalypse() {
        return zombieApocalypse;
    }

    public RatSeekGame getRatSeek() {
        return ratSeek;
    }

    public LobbyManager getLobbyManager() {
        return lobbyManager;
    }

    public LobbyAttractions getLobbyAttractions() {
        return lobbyAttractions;
    }

    public Set<Disadvantage> getDisadvantages(Player player) {
        return playerSettings.computeIfAbsent(player.getUniqueId(), key -> EnumSet.noneOf(Disadvantage.class));
    }

    public void toggleDisadvantage(Player player, Disadvantage disadvantage) {
        Set<Disadvantage> set = getDisadvantages(player);
        if (!set.add(disadvantage)) {
            set.remove(disadvantage);
        }
        if (game != null) {
            game.applyDisadvantages(player);
        }
    }

    public void openSettings(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 9, SETTINGS_TITLE);
        updateSettingsInventory(player, inventory);
        player.openInventory(inventory);
    }

    public void refreshSettingsInventory(Player player) {
        if (player.getOpenInventory() != null
                && player.getOpenInventory().title().equals(SETTINGS_TITLE)) {
            updateSettingsInventory(player, player.getOpenInventory().getTopInventory());
        }
    }

    private void updateSettingsInventory(Player player, Inventory inventory) {
        inventory.clear();
        Disadvantage[] disadvantages = Disadvantage.values();
        for (int i = 0; i < disadvantages.length; i++) {
            Disadvantage disadvantage = disadvantages[i];
            boolean enabled = getDisadvantages(player).contains(disadvantage);
            ItemStack item = ItemStack.of(disadvantage.getIcon());
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text(disadvantage.getDisplayName(),
                    enabled ? NamedTextColor.GREEN : NamedTextColor.GRAY));
            List<Component> lore = new ArrayList<>();
            lore.add(Component.text(disadvantage.getDescription(), NamedTextColor.GRAY));
            lore.add(Component.text(enabled ? "ENABLED" : "DISABLED",
                    enabled ? NamedTextColor.GREEN : NamedTextColor.DARK_GRAY));
            lore.add(Component.text("Click to toggle", NamedTextColor.DARK_GRAY, TextDecoration.ITALIC));
            meta.lore(lore);
            item.setItemMeta(meta);
            inventory.setItem(i, item);
        }
        ItemStack close = ItemStack.of(Material.BARRIER);
        ItemMeta closeMeta = close.getItemMeta();
        closeMeta.displayName(Component.text("Close", NamedTextColor.RED));
        close.setItemMeta(closeMeta);
        inventory.setItem(8, close);
    }

    private void configureLobby(World lobby) {
        lobby.setAutoSave(false);
        lobby.setPVP(false);
        lobby.setDifficulty(Difficulty.PEACEFUL);
        lobby.setMonsterSpawnLimit(0);
        lobby.setAnimalSpawnLimit(0);
        lobby.setAmbientSpawnLimit(0);
        lobby.setWaterAnimalSpawnLimit(0);
        lobby.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        lobby.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        lobby.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        lobby.setGameRule(GameRule.KEEP_INVENTORY, true);
        lobby.setGameRule(GameRule.DO_IMMEDIATE_RESPAWN, true);
        lobby.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
        lobby.setGameRule(GameRule.DO_FIRE_TICK, false);
        lobby.setGameRule(GameRule.RANDOM_TICK_SPEED, 0);
        // The lobby is a 96-block island: 5 chunks covers it from any edge, and every chunk a player
        // keeps loaded costs heap and ticks.
        lobby.setViewDistance(5);
        lobby.setSimulationDistance(4);
        lobby.setTime(6000);
        lobby.setStorm(false);
        lobby.setThundering(false);
        lobby.setWeatherDuration(0);
        lobby.getWorldBorder().setCenter(0.5, 0.5);
        lobby.getWorldBorder().setSize(96);
        lobby.getWorldBorder().setDamageBuffer(0);
        lobby.getWorldBorder().setDamageAmount(4);
    }

    private void configureArena(World arena) {
        arena.setAutoSave(false);
        arena.setPVP(true);
        arena.setDifficulty(Difficulty.PEACEFUL);
        arena.setMonsterSpawnLimit(0);
        arena.setAnimalSpawnLimit(0);
        arena.setAmbientSpawnLimit(0);
        arena.setWaterAnimalSpawnLimit(0);
        arena.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        arena.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        arena.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        arena.setGameRule(GameRule.DO_FIRE_TICK, false);
        arena.setGameRule(GameRule.DO_TILE_DROPS, false);
        arena.setGameRule(GameRule.DO_MOB_LOOT, false);
        arena.setGameRule(GameRule.DO_IMMEDIATE_RESPAWN, true);
        arena.setGameRule(GameRule.KEEP_INVENTORY, true);
        arena.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
        arena.setGameRule(GameRule.RANDOM_TICK_SPEED, 0);
        // Arenas are small void islands; games with bigger maps (Splatoon, Zombie) set their own distances.
        arena.setViewDistance(5);
        arena.setSimulationDistance(4);
        arena.setTime(6000);
        arena.setStorm(false);
        arena.setThundering(false);
        arena.setWeatherDuration(0);
        arena.setSpawnLocation(new Location(arena, 0, AutoBoxGame.BOX_Y_CENTER, 0));
        arena.getWorldBorder().setCenter(0, 0);
        arena.getWorldBorder().setSize(256);
    }



    private void configureMission(World world) {
        world.setAutoSave(true);
        world.setViewDistance(2);
        world.setSimulationDistance(2);
        world.setPVP(false);
        world.setDifficulty(Difficulty.NORMAL);
        world.setGameRule(GameRule.DO_IMMEDIATE_RESPAWN, true);
        world.setGameRule(GameRule.KEEP_INVENTORY, true);
        world.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
        world.setGameRule(GameRule.DO_MOB_SPAWNING, true);
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setStorm(false);
        world.setThundering(false);
        world.setMonsterSpawnLimit(20);
        world.setAnimalSpawnLimit(20);
        world.setAmbientSpawnLimit(5);
        world.setWaterAnimalSpawnLimit(10);
    }

    private Location buildLobby(World world) {
        int cx = 0;
        int y = 100;
        int cz = 0;
        // Widened platform so every game NPC (x = -9..10) stands over solid glass,
        // never over the void.
        int halfX = 11;
        int halfZ = 6;

        for (int dx = -halfX - 2; dx <= halfX + 2; dx++) {
            for (int dz = -halfZ - 2; dz <= halfZ + 2; dz++) {
                for (int dy = y - 3; dy <= y + 8; dy++) {
                    world.getBlockAt(cx + dx, dy, cz + dz).setType(Material.AIR, false);
                }
            }
        }

        for (int dx = -halfX; dx <= halfX; dx++) {
            for (int dz = -halfZ; dz <= halfZ; dz++) {
                world.getBlockAt(cx + dx, y, cz + dz).setType(Material.GLASS);
                world.getBlockAt(cx + dx, y + 1, cz + dz).setType(Material.GLASS);
            }
        }

        int[] lanternXs = {-9, -4, 0, 4, 9};
        int[] lanternZs = {-4, 0, 4};
        for (int lx : lanternXs) {
            for (int lz : lanternZs) {
                world.getBlockAt(cx + lx, y - 1, cz + lz).setType(Material.SEA_LANTERN);
            }
        }

        for (int dx = -halfX; dx <= halfX; dx++) {
            world.getBlockAt(cx + dx, y + 1, cz - halfZ).setType(Material.POLISHED_DEEPSLATE);
            world.getBlockAt(cx + dx, y + 1, cz + halfZ).setType(Material.POLISHED_DEEPSLATE);
        }
        for (int dz = -halfZ; dz <= halfZ; dz++) {
            world.getBlockAt(cx - halfX, y + 1, cz + dz).setType(Material.POLISHED_DEEPSLATE);
            world.getBlockAt(cx + halfX, y + 1, cz + dz).setType(Material.POLISHED_DEEPSLATE);
        }

        int[][] corners = {{-halfX, -halfZ}, {-halfX, halfZ}, {halfX, -halfZ}, {halfX, halfZ}};
        for (int[] corner : corners) {
            for (int py = y + 2; py < y + 5; py++) {
                world.getBlockAt(cx + corner[0], py, cz + corner[1]).setType(Material.POLISHED_BLACKSTONE);
            }
            world.getBlockAt(cx + corner[0], y + 5, cz + corner[1]).setType(Material.SEA_LANTERN);
        }

        int[][] ring = {
                {6, 0}, {5, 3}, {3, 5}, {0, 6}, {-3, 5}, {-5, 3},
                {-6, 0}, {-5, -3}, {-3, -5}, {0, -6}, {3, -5}, {5, -3}
        };
        Material[] wools = {
                Material.WHITE_WOOL, Material.ORANGE_WOOL, Material.MAGENTA_WOOL,
                Material.LIGHT_BLUE_WOOL, Material.YELLOW_WOOL, Material.LIME_WOOL,
                Material.PINK_WOOL, Material.CYAN_WOOL, Material.PURPLE_WOOL,
                Material.BLUE_WOOL, Material.RED_WOOL, Material.GREEN_WOOL
        };
        for (int i = 0; i < ring.length; i++) {
            world.getBlockAt(cx + ring[i][0], y + 2, cz + ring[i][1]).setType(wools[i]);
        }

        // Dedicated pedestal for the Hole in the Wall NPC (lime concrete theme).
        world.getBlockAt(cx + 6, y + 2, cz - 3).setType(Material.LIME_CONCRETE);
        // Ink-orange pedestal for the Splatoon NPC.
        world.getBlockAt(cx - 6, y + 2, cz - 3).setType(Material.ORANGE_CONCRETE);
        // Outer pedestals: Zombie Apocalypse (far left) and Rat and Seek (far right).
        buildNpcPedestal(world, cx - 8, y, cz - 3, Material.MOSSY_STONE_BRICKS, cx - halfX);
        buildNpcPedestal(world, cx + 9, y, cz - 3, Material.HAY_BLOCK, cx + halfX);

        // Solid 2x2 support blocks directly under every game NPC villager so none
        // of them float. Coordinates must match LobbyManager.spawnNpcs().
        double[] npcXs = {-8.5, -5.5, -2.5, 0.5, 3.5, 6.5, 9.5};
        for (double npcX : npcXs) {
            int bx = cx + (int) Math.floor(npcX);
            int bz = cz + (int) Math.floor(-2.5);
            for (int dx = 0; dx <= 1; dx++) {
                for (int dz = 0; dz <= 1; dz++) {
                    Block pad = world.getBlockAt(bx + dx, y + 2, bz + dz);
                    if (pad.getType().isAir()) {
                        pad.setType(Material.POLISHED_ANDESITE, false);
                    }
                }
            }
            for (int dy = y + 3; dy <= y + 4; dy++) {
                for (int dx = 0; dx <= 1; dx++) {
                    for (int dz = 0; dz <= 1; dz++) {
                        world.getBlockAt(bx + dx, dy, bz + dz).setType(Material.AIR, false);
                    }
                }
            }
        }

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                world.getBlockAt(cx + dx, y + 2, cz + dz).setType(Material.POLISHED_BLACKSTONE);
            }
        }
        for (int x : new int[]{-3, 0, 3}) {
            world.getBlockAt(cx + x, y + 2, cz - 3).setType(Material.SEA_LANTERN);
        }
        Block signBlock = world.getBlockAt(cx, y + 3, cz + 2);
        signBlock.setType(Material.OAK_SIGN, false);
        if (signBlock.getState() instanceof Sign sign
                && signBlock.getBlockData() instanceof org.bukkit.block.data.type.Sign signData) {
            signData.setRotation(BlockFace.NORTH);
            signBlock.setBlockData(signData, false);
            SignSide back = sign.getSide(Side.BACK);
            back.setLine(0, "§d§lWORLDS");
            back.setLine(1, "§fFun Minigame Server");
            back.setLine(2, "§7Choose an NPC");
            back.setLine(3, "§7and play!");
            sign.update();
        }

        Location lobby = new Location(world, cx + 0.5, y + 2, cz + 5.5, 180, 0);
        world.setSpawnLocation(lobby);
        return lobby;
    }

    /** A 3-wide walkway out from the hub edge topped with a single pedestal block. */
    private void buildNpcPedestal(World world, int x, int y, int z, Material pedestal, int fromEdge) {
        int step = fromEdge < x ? 1 : -1;
        for (int px = fromEdge + step; px <= x; px += step) {
            for (int oz = -1; oz <= 1; oz++) {
                world.getBlockAt(px, y, z + oz).setType(Material.POLISHED_ANDESITE, false);
                world.getBlockAt(px, y + 1, z + oz).setType(Material.POLISHED_ANDESITE, false);
            }
        }
        world.getBlockAt(x, y + 2, z).setType(pedestal, false);
    }
}
