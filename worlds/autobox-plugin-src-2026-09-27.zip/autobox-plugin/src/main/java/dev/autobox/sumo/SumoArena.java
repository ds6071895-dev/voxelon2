package dev.autobox.sumo;

import org.bukkit.Material;

import java.util.List;

/**
 * One Block Sumo map as pure data: the blocks to place, where players spawn and where pickups land.
 * Nothing here touches a world, so the layouts are checked headlessly.
 *
 * @param spawns       {x, feetY, z}
 * @param spots        {x, surfaceY, z} of solid blocks where spheres, hearts and crates may appear
 * @param radii        the arena radius after each of the three collapses
 * @param lowestFloor  the lowest block y of the map
 */
public record SumoArena(Kind kind, List<Block> blocks, List<int[]> spawns, List<int[]> spots,
                        int startRadius, int[] radii, int suddenDeathRadius, int lowestFloor) {
    public static final int BASE_Y = 50;
    /** Everything must fit in the box the pre-match sweep clears. */
    public static final int SWEEP_RADIUS = 22;
    public static final int SWEEP_BOTTOM = BASE_Y - 6;
    public static final int SWEEP_TOP = BASE_Y + 14;

    public enum Kind {
        RIFT("Rift Archipelago", "Floating islands and broken bridges"),
        DOHYO("The Dohyo", "One ring. Push them out."),
        FROSTBITE("Frostbite Rink", "Solid ice: every hit slides further"),
        BOUNCE("Bounce House", "Slime pads launch you to the top; honey holds you down"),
        HEX("Hex Layers", "Tiles crumble under your feet. Three floors to fall through"),
        SWEEPER("The Sweeper", "Jump the spinning arms or get swept away");
        public final String label;
        public final String description;
        Kind(String label, String description) {
            this.label = label;
            this.description = description;
        }
    }

    public record Block(int x, int y, int z, Material material) { }

    public int radiusAfter(int collapseIndex) {
        return radii[collapseIndex];
    }
}
