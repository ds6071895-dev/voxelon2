package dev.autobox.splat;

import dev.autobox.splat.SplatRules.Team;
import dev.autobox.util.Sidebar;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.Display;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;

import java.time.Duration;
import java.util.*;

/** Boss bars, sidebar, action bar, titles and the end-of-match cards. */
final class SplatHud {
    private final SplatGame g;
    private final EnumMap<Team, BossBar> bars = new EnumMap<>(Team.class);
    private final BossBar spectatorBar = BossBar.bossBar(Component.text("Splatoon"), 1, BossBar.Color.YELLOW, BossBar.Overlay.PROGRESS);

    private Sidebar sidebar;

    SplatHud(SplatGame g) {
        this.g = g;
        for (Team team : Team.values()) bars.put(team, BossBar.bossBar(Component.text("Splatoon"), 1, BossBar.Color.YELLOW, BossBar.Overlay.PROGRESS));
    }

    /** Starts the next match on a fresh sidebar (new roster, teams and mode title). */
    void newMatch() {
        sidebar = null;
    }

    void hide(Player p) {
        p.hideBossBar(spectatorBar);
        bars.values().forEach(p::hideBossBar);
    }

    // ------------------------------------------------------------------ titles

    void announce(String title, String subtitle, NamedTextColor color) {
        Title show = Title.title(Component.text(title, color, TextDecoration.BOLD), SplatGame.text(subtitle),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(1200), Duration.ofMillis(200)));
        for (Player p : g.world.getPlayers()) p.showTitle(show);
    }

    String scoreLine() {
        if (g.settings.mode().ranked) {
            return "Orange " + count(Team.ORANGE) + " — Blue " + count(Team.BLUE);
        }
        return "Orange " + SplatRules.format(g.objective.count(Team.ORANGE)) + " — Blue " + SplatRules.format(g.objective.count(Team.BLUE));
    }

    private int count(Team team) { return (int) Math.ceil(g.objective.count(team) - 1e-9); }

    /** Turf War: both bars grow until the smaller stops. Ranked: each team's progress toward zero. */
    void judgingReveal() {
        double orange, blue;
        if (g.settings.mode().ranked) {
            orange = RankedRules.START - g.objective.count(Team.ORANGE);
            blue = RankedRules.START - g.objective.count(Team.BLUE);
        } else {
            orange = g.turf.get(Team.ORANGE);
            blue = g.turf.get(Team.BLUE);
        }
        double top = Math.max(1, Math.max(orange, blue));
        int cells = 20;
        double grown = Math.min(1, g.elapsed / (double) (SplatRules.JUDGING - 16)) * cells;
        int o = (int) Math.round(Math.min(grown, cells * orange / top));
        int b = (int) Math.round(Math.min(grown, cells * blue / top));
        Component bars = Component.text("█".repeat(o), Team.ORANGE.text)
                .append(Component.text("  vs  ", NamedTextColor.GRAY))
                .append(Component.text("█".repeat(b), Team.BLUE.text));
        String head = g.knockout != null ? "KNOCKOUT!" : "Time's up! Judging…";
        Title show = Title.title(Component.text(head, g.knockout != null ? g.knockout.text : NamedTextColor.WHITE, TextDecoration.BOLD), bars,
                Title.Times.times(Duration.ZERO, Duration.ofMillis(400), Duration.ZERO));
        for (Player p : g.world.getPlayers()) p.showTitle(show);
    }

    // ------------------------------------------------------------------ damage numbers

    /** Floating number above the victim that only the attacker can see. */
    void damageNumber(Player viewer, Player victim, double damage, boolean splat) {
        if (SplatGame.bedrock(viewer.getUniqueId())) return;
        Location at = victim.getEyeLocation().add(g.random.nextDouble() * 0.6 - 0.3, 0.35, g.random.nextDouble() * 0.6 - 0.3);
        String label = splat ? "SPLAT!" : String.valueOf((int) Math.round(damage * 5));
        TextColor color = splat ? NamedTextColor.GOLD : damage >= 10 ? NamedTextColor.RED : damage >= 6 ? NamedTextColor.YELLOW : NamedTextColor.WHITE;
        TextDisplay display = g.world.spawn(at, TextDisplay.class, t -> {
            t.text(Component.text(label, color, TextDecoration.BOLD));
            t.setBillboard(Display.Billboard.CENTER);
            t.setVisibleByDefault(false);
            t.setPersistent(false);
            t.setShadowed(true);
            t.setSeeThrough(true);
            t.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            t.setTeleportDuration(10);
        });
        viewer.showEntity(g.plugin, display);
        g.track(display);
        Bukkit.getScheduler().runTaskLater(g.plugin, () -> { if (display.isValid()) display.teleport(at.clone().add(0, 0.8, 0)); }, 1);
        Bukkit.getScheduler().runTaskLater(g.plugin, () -> { display.remove(); g.entities.remove(display); }, splat ? 20 : 12);
    }

    // ------------------------------------------------------------------ live HUD

    private static Component meter(double fraction, int cells, TextColor color) {
        int filled = (int) Math.round(Math.max(0, Math.min(1, fraction)) * cells);
        return Component.text("■".repeat(filled), color).append(Component.text("■".repeat(cells - filled), NamedTextColor.DARK_GRAY));
    }

    Component hudLine(Inkling in) {
        Kit kit = in.kit;
        if (g.phase == SplatGame.Phase.COUNTDOWN) return Component.text(in.team.title + " team | " + kit.main.title + " + " + kit.sub.title
                + " + " + kit.special.title + " — click or hold another kit to switch", in.team.text);
        if (g.phase != SplatGame.Phase.PLAY) return SplatGame.text(scoreLine());
        if (in.respawnAt >= 0) return Component.text("Respawning in " + Math.max(1, (in.respawnAt - g.elapsed + 19) / 20) + "…", NamedTextColor.GRAY);
        if (in.jump != null) return Component.text("Super Jumping!", in.team.text, TextDecoration.BOLD);
        TextComponent.Builder line = Component.text();
        if (in.hitMarkerUntil >= g.elapsed) {
            line.append(in.hitMarkerSplat ? Component.text("✖ SPLAT  ", NamedTextColor.GOLD, TextDecoration.BOLD)
                    : Component.text("✕  ", NamedTextColor.WHITE, TextDecoration.BOLD));
        }
        if (in.notice != null && g.elapsed < in.noticeUntil) return line.append(in.notice).build();
        Weapon main = in.main();
        line.append(Component.text(main.title + (in.trizookaShots > 0 ? " ×" + in.trizookaShots : "") + "  ", in.team.text, TextDecoration.BOLD));
        line.append(Component.text("Ink ", NamedTextColor.GRAY)).append(meter(in.ink / SplatRules.MAX_INK, 10,
                in.ink < 20 ? NamedTextColor.RED : in.team.text));
        if (in.chargeStart >= 0) {
            double charge = g.weapons.chargeLevel(in);
            line.append(Component.text("  Charge ", NamedTextColor.GRAY)).append(meter(charge, 8, charge >= 1 ? NamedTextColor.YELLOW : NamedTextColor.WHITE));
        }
        if (!in.rainmaker) {
            line.append(Component.text("  " + kit.special.title + " ", NamedTextColor.GRAY));
            if (in.special >= SplatRules.SPECIAL_MAX) line.append(Component.text("READY! (F)", NamedTextColor.GOLD, TextDecoration.BOLD));
            else line.append(meter(in.special / SplatRules.SPECIAL_MAX, 8, NamedTextColor.LIGHT_PURPLE));
        }
        if (in.squid) line.append(Component.text(in.climbing ? "  ≈ CLIMBING" : "  ≈ SQUID", NamedTextColor.AQUA));
        String hint = g.objective.hint(in);
        if (hint != null) line.append(Component.text("  " + hint, NamedTextColor.GOLD));
        return line.build();
    }

    void actionBars() {
        for (Player p : g.online()) p.sendActionBar(hudLine(g.players.get(p.getUniqueId())));
    }

    /** Splatoon-style team row: a square per player, gold when their special is ready, hollow while splatted. */
    private Component teamRow(Team team) {
        TextComponent.Builder row = Component.text();
        for (Inkling in : g.players.values()) {
            if (in.team != team) continue;
            if (in.rainmaker) row.append(Component.text("♦", NamedTextColor.GOLD, TextDecoration.BOLD));
            else if (!in.alive()) row.append(Component.text("□", NamedTextColor.DARK_GRAY));
            else if (in.special >= SplatRules.SPECIAL_MAX) row.append(Component.text("■", NamedTextColor.GOLD));
            else row.append(Component.text("■", team.text));
        }
        return row.build();
    }

    private Component countText(Team team) {
        Component text = Component.text(String.valueOf(count(team)), team.text, TextDecoration.BOLD);
        double penalty = g.objective.penalty(team);
        if (penalty >= 0.5) text = text.append(Component.text(" +" + (int) Math.ceil(penalty), NamedTextColor.RED));
        return text;
    }

    private Component bossName(Team left) {
        Team right = left.opponent();
        SplatMode mode = g.settings.mode();
        int remaining = g.phase == SplatGame.Phase.COUNTDOWN ? SplatRules.COUNTDOWN - g.elapsed
                : g.phase == SplatGame.Phase.PLAY ? mode.playTicks - g.elapsed : 0;
        Component centre = switch (g.phase) {
            case COUNTDOWN -> Component.text(mode.title + " · " + g.map.name() + " · " + SplatRules.clock(remaining), NamedTextColor.WHITE);
            case PLAY -> g.overtime ? Component.text("OVERTIME", NamedTextColor.RED, TextDecoration.BOLD)
                    : Component.text(SplatRules.clock(remaining), remaining <= 1200 ? NamedTextColor.RED : NamedTextColor.WHITE, TextDecoration.BOLD);
            case JUDGING -> Component.text(g.knockout != null ? "KNOCKOUT!" : "Judging…", NamedTextColor.WHITE, TextDecoration.BOLD);
            default -> g.winner == null ? Component.text("Draw", NamedTextColor.WHITE, TextDecoration.BOLD)
                    : Component.text(g.winner.title + " wins!", g.winner.text, TextDecoration.BOLD);
        };
        TextComponent.Builder name = Component.text().append(teamRow(left)).append(Component.text("   "));
        if (mode.ranked && g.phase != SplatGame.Phase.COUNTDOWN) name.append(countText(left)).append(Component.text("  "));
        name.append(centre);
        if (mode.ranked && g.phase != SplatGame.Phase.COUNTDOWN) name.append(Component.text("  ")).append(countText(right));
        return name.append(Component.text("   ")).append(teamRow(right)).build();
    }

    void update() {
        SplatMode mode = g.settings.mode();
        int duration = g.phase == SplatGame.Phase.COUNTDOWN ? SplatRules.COUNTDOWN : mode.playTicks;
        int remaining = switch (g.phase) {
            case COUNTDOWN -> SplatRules.COUNTDOWN - g.elapsed;
            case PLAY -> g.overtime ? duration : mode.playTicks - g.elapsed;
            default -> 0;
        };
        float progress = Math.max(0, Math.min(1, remaining / (float) duration));
        BossBar.Color color = g.overtime ? BossBar.Color.RED : g.phase == SplatGame.Phase.PLAY && remaining <= 1200 ? BossBar.Color.RED : BossBar.Color.YELLOW;
        for (Team team : Team.values()) {
            BossBar bar = bars.get(team);
            bar.name(bossName(team));
            bar.progress(progress);
            bar.color(color);
        }
        spectatorBar.name(bossName(Team.ORANGE));
        spectatorBar.progress(progress);
        spectatorBar.color(color);

        Component title = Component.text("SPLATOON · " + mode.title.toUpperCase(Locale.ROOT), NamedTextColor.GOLD, TextDecoration.BOLD);
        if (sidebar == null) {
            // One board per match, updated in place: re-sending a whole new board (objective, 15 lines,
            // 2 teams) to every player twice a second flickered and was the bulk of the HUD's packets.
            sidebar = new Sidebar("splat", title);
            for (Team team : Team.values()) {
                org.bukkit.scoreboard.Team scoreboardTeam = sidebar.team(team.name().toLowerCase(Locale.ROOT));
                scoreboardTeam.color(team.text);
                scoreboardTeam.setCanSeeFriendlyInvisibles(true);
                scoreboardTeam.setOption(org.bukkit.scoreboard.Team.Option.COLLISION_RULE, org.bukkit.scoreboard.Team.OptionStatus.NEVER);
                scoreboardTeam.setOption(org.bukkit.scoreboard.Team.Option.NAME_TAG_VISIBILITY, org.bukkit.scoreboard.Team.OptionStatus.FOR_OWN_TEAM);
            }
        }
        sidebar.title(title);
        List<String> lines = new ArrayList<>();
        String label = switch (g.phase) {
            case COUNTDOWN -> "Starting";
            case PLAY -> g.overtime ? "§c§lOVERTIME" : mode.title;
            case JUDGING -> "Judging";
            default -> "Results";
        };
        lines.add("§f" + label + (g.overtime ? "" : " §e" + SplatRules.clock(remaining)));
        lines.add("§7Map: §f" + g.map.name());
        if (mode.ranked) {
            for (Team team : Team.values()) {
                double penalty = g.objective.penalty(team);
                lines.add((team == Team.ORANGE ? "§6■ Orange §f" : "§9■ Blue §f") + count(team)
                        + (penalty >= 0.5 ? " §c+" + (int) Math.ceil(penalty) : ""));
            }
        }
        g.objective.sidebar(lines);
        lines.add(" ");
        List<Inkling> order = g.players.values().stream()
                .sorted(Comparator.comparing((Inkling in) -> in.team).thenComparing(in -> -(in.splats * 50 + in.painted))).toList();
        for (Inkling in : order) {
            String name = (in.team == Team.ORANGE ? "§6" : "§9") + in.name + " §8Lv" + g.stats.get(in.id, in.name).level();
            lines.add(name + " §7" + (mode.ranked ? in.splats + "✦ " + in.assists + "✚" : in.painted + "p " + in.splats + "✦"));
        }
        sidebar.lines(lines, 15);
        for (Inkling in : g.players.values()) {
            org.bukkit.scoreboard.Team scoreboardTeam = sidebar.team(in.team.name().toLowerCase(Locale.ROOT));
            if (!scoreboardTeam.hasEntry(in.name)) scoreboardTeam.addEntry(in.name);
        }

        for (UUID id : new HashSet<>(g.viewers())) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) g.viewers().remove(id);
            else if (!g.isWorld(p)) g.forgetViewer(p);
        }
        for (Player p : g.world.getPlayers()) {
            Inkling in = g.players.get(p.getUniqueId());
            BossBar mine = in == null ? spectatorBar : bars.get(in.team);
            if (mine != spectatorBar) p.hideBossBar(spectatorBar);
            for (BossBar bar : bars.values()) if (bar != mine) p.hideBossBar(bar);
            p.showBossBar(mine);
            g.markViewer(p);
            sidebar.show(p);
            if (g.phase == SplatGame.Phase.JUDGING) continue;
            p.sendActionBar(in == null ? SplatGame.text("Spectating " + mode.title + " — " + scoreLine()) : hudLine(in));
        }
    }

    // ------------------------------------------------------------------ results

    void results() {
        String headline = g.winner == null ? "It's a draw!" : g.winner.title + " team wins!";
        String how = g.forfeitWinner != null ? "Victory by forfeit" : g.knockout != null ? "Knockout! " + scoreLine() : scoreLine();
        for (Player p : g.world.getPlayers()) {
            Inkling in = g.players.get(p.getUniqueId());
            Component title;
            if (in == null || g.winner == null) title = Component.text(headline, g.winner == null ? NamedTextColor.WHITE : g.winner.text, TextDecoration.BOLD);
            else if (in.team == g.winner) title = Component.text("VICTORY!", NamedTextColor.GOLD, TextDecoration.BOLD);
            else title = Component.text("DEFEAT", NamedTextColor.RED, TextDecoration.BOLD);
            p.showTitle(Title.title(title, SplatGame.text(how), Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(3), Duration.ofMillis(500))));
            p.playSound(p, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1f, 1f);
        }
        g.broadcast(headline + " " + how);
        g.roster.values().stream().max(Comparator.comparingInt(in -> in.splats * 100 + in.assists * 50 + in.painted - in.splatted * 30))
                .ifPresent(mvp -> g.broadcast("★ MVP: " + mvp.name + " (" + mvp.splats + " splats, " + mvp.assists + " assists, " + mvp.painted + " turf)"));
        g.roster.values().stream().max(Comparator.comparingInt(in -> in.painted)).ifPresent(top ->
                g.broadcast("🖌 Top inker: " + top.name + " with " + top.painted + " turf."));
        for (Player p : g.online()) card(p, g.players.get(p.getUniqueId()));
    }

    private void card(Player p, Inkling in) {
        SplatMode mode = g.settings.mode();
        boolean won = g.winner == in.team, draw = g.winner == null;
        NamedTextColor accent = draw ? NamedTextColor.WHITE : won ? NamedTextColor.GOLD : NamedTextColor.RED;
        p.sendMessage(Component.text("━━━━━━ " + mode.title + " — " + (draw ? "DRAW" : won ? "VICTORY" : "DEFEAT") + " ━━━━━━", accent, TextDecoration.BOLD));
        p.sendMessage(Component.text(" ✦ Splats ", NamedTextColor.GRAY).append(Component.text(in.splats, NamedTextColor.WHITE))
                .append(Component.text("   ✚ Assists ", NamedTextColor.GRAY)).append(Component.text(in.assists, NamedTextColor.WHITE))
                .append(Component.text("   ✖ Splatted ", NamedTextColor.GRAY)).append(Component.text(in.splatted, NamedTextColor.WHITE))
                .append(Component.text("   ▦ Turf ", NamedTextColor.GRAY)).append(Component.text(in.painted, NamedTextColor.WHITE))
                .append(Component.text("   ★ Specials ", NamedTextColor.GRAY)).append(Component.text(in.specials, NamedTextColor.WHITE)));
        SplatGame.Result r = g.results.get(in.id);
        if (r == null) {
            p.sendMessage(Component.text(" Test match — ranks and XP weren't changed.", NamedTextColor.DARK_GRAY));
        } else {
            int after = r.ratingBefore() + r.ratingDelta();
            SplatRating.Rank before = SplatRating.rank(r.ratingBefore()), now = SplatRating.rank(after);
            String oldLabel = SplatRating.label(r.ratingBefore(), r.matchesAfter() - 1), newLabel = SplatRating.label(after, r.matchesAfter());
            Component delta = Component.text((r.ratingDelta() >= 0 ? " +" : " ") + r.ratingDelta(), r.ratingDelta() >= 0 ? NamedTextColor.GREEN : NamedTextColor.RED, TextDecoration.BOLD);
            p.sendMessage(Component.text(" Rank ", NamedTextColor.GRAY)
                    .append(Component.text(oldLabel + " " + r.ratingBefore(), before.color))
                    .append(Component.text(" → ", NamedTextColor.GRAY))
                    .append(Component.text(newLabel + " " + after, now.color, TextDecoration.BOLD))
                    .append(delta)
                    .append(Component.text(r.matchesAfter() < SplatRating.PROVISIONAL
                            ? "  (placement " + r.matchesAfter() + "/" + SplatRating.PROVISIONAL + ")" : "", NamedTextColor.DARK_GRAY)));
            long into = SplatRating.xpIntoLevel(r.xpAfter()), need = SplatRating.xpToNext(r.levelAfter());
            p.sendMessage(Component.text(" Level " + r.levelAfter() + "  ", NamedTextColor.AQUA)
                    .append(meter(r.levelAfter() >= SplatRating.MAX_LEVEL ? 1 : into / (double) need, 12, NamedTextColor.AQUA))
                    .append(Component.text("  " + into + "/" + need + " XP ", NamedTextColor.GRAY))
                    .append(Component.text("(+" + r.xp() + ")", NamedTextColor.GREEN)));
        }
        p.sendMessage(Component.text(" [Play again]", NamedTextColor.GREEN, TextDecoration.BOLD)
                .clickEvent(ClickEvent.runCommand("/splat again"))
                .hoverEvent(HoverEvent.showText(Component.text("Rejoin the Splatoon queue when this match ends")))
                .append(Component.text("   [My ranks]", NamedTextColor.AQUA)
                        .clickEvent(ClickEvent.runCommand("/splat rank"))
                        .hoverEvent(HoverEvent.showText(Component.text("See your rank in every mode")))));
    }

    /** A beat after the result title: level-ups and rank-ups get their own moment. */
    void levelUps() {
        for (Player p : g.online()) {
            SplatGame.Result r = g.results.get(p.getUniqueId());
            if (r == null) continue;
            SplatRating.Rank before = SplatRating.rank(r.ratingBefore()), after = SplatRating.rank(r.ratingBefore() + r.ratingDelta());
            boolean levelUp = r.levelAfter() > r.levelBefore(), rankUp = after.ordinal() > before.ordinal() && r.matchesAfter() >= SplatRating.PROVISIONAL;
            if (!levelUp && !rankUp) continue;
            Component title = levelUp ? Component.text("LEVEL UP!", NamedTextColor.AQUA, TextDecoration.BOLD)
                    : Component.text("RANK UP!", after.color, TextDecoration.BOLD);
            Component subtitle = levelUp ? Component.text("Level " + r.levelAfter() + (rankUp ? "  ·  Rank " + after.label : ""), NamedTextColor.WHITE)
                    : Component.text(r.mode().title + " rank " + after.label, after.color);
            p.showTitle(Title.title(title, subtitle, Title.Times.times(Duration.ofMillis(100), Duration.ofSeconds(2), Duration.ofMillis(400))));
            p.playSound(p, Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.2f);
            Firework f = g.world.spawn(p.getLocation().add(0, 1, 0), Firework.class);
            var meta = f.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder().withColor(Color.AQUA, Color.WHITE).with(FireworkEffect.Type.STAR).build());
            meta.setPower(0);
            f.setFireworkMeta(meta);
            g.track(f);
        }
    }
}
