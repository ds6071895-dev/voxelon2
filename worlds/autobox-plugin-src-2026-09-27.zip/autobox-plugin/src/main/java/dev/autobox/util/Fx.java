package dev.autobox.util;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** Particle helpers: find the viewers once per effect instead of once per particle point. */
public final class Fx {

    private Fx() {
    }

    /** Players in the same world within {@code radius} blocks of {@code at}. */
    public static List<Player> near(Location at, double radius) {
        World world = at.getWorld();
        List<Player> viewers = new ArrayList<>();
        if (world == null) {
            return viewers;
        }
        double limit = radius * radius;
        double x = at.getX();
        double y = at.getY();
        double z = at.getZ();
        for (Player player : world.getPlayers()) {
            Location location = player.getLocation();
            double dx = location.getX() - x;
            double dy = location.getY() - y;
            double dz = location.getZ() - z;
            if (dx * dx + dy * dy + dz * dz <= limit) {
                viewers.add(player);
            }
        }
        return viewers;
    }
}
