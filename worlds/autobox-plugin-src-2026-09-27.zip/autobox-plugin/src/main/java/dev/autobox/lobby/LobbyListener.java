package dev.autobox.lobby;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

public final class LobbyListener implements Listener {
    private final LobbyManager manager;

    public LobbyListener(LobbyManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onNpcClick(PlayerInteractEntityEvent event) {
        if (!event.getRightClicked().getPersistentDataContainer().has(manager.getNpcKey())) {
            return;
        }
        event.setCancelled(true);
        manager.handleNpc(event.getPlayer(), event.getRightClicked());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        manager.handleLobbyArrival(event.getPlayer());
    }
}
