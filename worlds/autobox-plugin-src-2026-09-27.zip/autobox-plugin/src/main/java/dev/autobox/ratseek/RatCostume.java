package dev.autobox.ratseek;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimMaterial;
import org.bukkit.inventory.meta.trim.TrimPattern;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Vanilla-only rat disguise: a textured rat head and dyed fur armour. The player itself
 * stays visible so Bedrock clients still see a head-and-fur rat.
 */
final class RatCostume {
    /** "Rat (head)" skin, textures.minecraft.net/texture/d66bcec8c22e…9904. */
    private static final String RAT_TEXTURE = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZDY2YmNlYzhjMjJlMGM4YjNiZDFjOTI2ZDVhZWVmM2ExZDE3MzZlYTEzN2FjMTllNGEwNWU0NmJlZTc2OTkwNCJ9fX0=";
    private static final UUID RAT_PROFILE_ID = UUID.fromString("5f1e3a52-7c1b-4d0e-9a57-2b4d6c1a9e01");
    private static final Color FUR = Color.fromRGB(0x6B4A35);
    private static final Color BELLY = Color.fromRGB(0x8A6A55);
    private static final Color PRISON = Color.fromRGB(0x1E1E1E);

    private final NamespacedKey tagKey;
    private final Set<UUID> dressed = new HashSet<>();
    /** Ticks left on the Ghost Rats twist, per rat. */
    private final Map<UUID, Integer> ghosts = new HashMap<>();

    RatCostume(NamespacedKey tagKey) {
        this.tagKey = tagKey;
    }

    /** Puts the disguise on (or refreshes it after a size change, cage or respawn). */
    void dress(Player rat, double scale, boolean caged) {
        dressed.add(rat.getUniqueId());
        PlayerInventory inventory = rat.getInventory();
        if (ghosts.containsKey(rat.getUniqueId())) {
            // Ghosts keep their armour off until the twist ends; tick() restores it.
            inventory.setHelmet(null);
        } else {
            wearArmour(inventory, caged);
        }
    }

    /** Strips armour. Safe to call for players who never wore it. */
    void undress(Player player) {
        dressed.remove(player.getUniqueId());
        ghosts.remove(player.getUniqueId());
        PlayerInventory inventory = player.getInventory();
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack worn = inventory.getItem(slot);
            if (isCostume(worn)) {
                inventory.setItem(slot, null);
            }
        }
    }

    /** Hides the whole disguise for the Ghost Rats twist; invisibility alone leaves armour visible. */
    void ghost(Player rat, int ticks) {
        if (!dressed.contains(rat.getUniqueId())) {
            return;
        }
        ghosts.put(rat.getUniqueId(), ticks);
        PlayerInventory inventory = rat.getInventory();
        inventory.setHelmet(null);
        inventory.setChestplate(null);
        inventory.setLeggings(null);
        inventory.setBoots(null);
    }

    boolean isCostume(ItemStack item) {
        return item != null && item.hasItemMeta()
                && "costume".equals(item.getItemMeta().getPersistentDataContainer().get(tagKey, PersistentDataType.STRING));
    }

    /** Counts down ghosts. {@code caged} decides which outfit returns after a ghost. */
    void tick(int ticks, java.util.function.Predicate<UUID> caged) {
        ghosts.entrySet().removeIf(entry -> {
            Player rat = Bukkit.getPlayer(entry.getKey());
            if (rat == null || !rat.isOnline()) {
                return true;
            }
            int left = entry.getValue() - 1;
            if (left <= 0) {
                wearArmour(rat.getInventory(), caged.test(entry.getKey()));
                return true;
            }
            entry.setValue(left);
            return false;
        });
    }

    void clear() {
        dressed.clear();
        ghosts.clear();
    }

    /** Removes tail segments left behind by older builds or an unclean shutdown. */
    void purgeStrays(World world) {
        for (BlockDisplay display : world.getEntitiesByClass(BlockDisplay.class)) {
            if ("rat_tail".equals(display.getPersistentDataContainer().get(tagKey, PersistentDataType.STRING))) {
                display.remove();
            }
        }
    }

    static ItemStack ratHead(NamespacedKey tagKey, Component name) {
        ItemStack head = ItemStack.of(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        PlayerProfile profile = Bukkit.createProfile(RAT_PROFILE_ID, "CrookedRat");
        profile.setProperty(new ProfileProperty("textures", RAT_TEXTURE));
        meta.setPlayerProfile(profile);
        meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        meta.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, "costume");
        head.setItemMeta(meta);
        return head;
    }

    // ------------------------------------------------------------------ internals

    private void wearArmour(PlayerInventory inventory, boolean caged) {
        inventory.setHelmet(ratHead(tagKey, Component.text("Rat Face", NamedTextColor.GOLD)));
        inventory.setChestplate(fur(Material.LEATHER_CHESTPLATE, caged ? PRISON : FUR,
                caged ? TrimPattern.RIB : null, TrimMaterial.QUARTZ));
        inventory.setLeggings(fur(Material.LEATHER_LEGGINGS, caged ? PRISON : BELLY,
                caged ? TrimPattern.RIB : TrimPattern.WILD, caged ? TrimMaterial.QUARTZ : TrimMaterial.COPPER));
        inventory.setBoots(fur(Material.LEATHER_BOOTS, Color.fromRGB(0xE8A0A8), null, null));
    }

    private ItemStack fur(Material material, Color color, TrimPattern pattern, TrimMaterial trimMaterial) {
        ItemStack item = ItemStack.of(material);
        ItemMeta meta = item.getItemMeta();
        if (meta instanceof LeatherArmorMeta leather) {
            leather.setColor(color);
        }
        if (pattern != null && meta instanceof ArmorMeta armor) {
            armor.setTrim(new ArmorTrim(trimMaterial, pattern));
        }
        meta.displayName(Component.text("Rat Fur", NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
        meta.addEnchant(Enchantment.BINDING_CURSE, 1, true);
        meta.setEnchantmentGlintOverride(false);
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.values());
        meta.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, "costume");
        item.setItemMeta(meta);
        return item;
    }
}
