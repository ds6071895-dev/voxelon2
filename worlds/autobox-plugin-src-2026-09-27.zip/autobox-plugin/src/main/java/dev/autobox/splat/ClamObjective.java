package dev.autobox.splat;

import dev.autobox.splat.SplatArena.Pos;
import dev.autobox.splat.SplatRules.Team;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Clam Blitz: pick up clams, turn ten into a Power Clam, throw it into the enemy basket to
 * break its barrier, then score clams while it's open. Baskets are real blocks; clams are
 * dropped items that never merge.
 */
final class ClamObjective implements Objective {
    static final int SPAWN_TICKS = 60, BARRIER_Y = 4;
    static final double SCORE_RADIUS = 1.5, PICKUP_RADIUS = 1.4;

    private final SplatGame g;
    private final EnumMap<Team, Double> count = new EnumMap<>(Team.class);
    /** Basket each team scores into (in front of the enemy base), and until when its barrier is open. */
    private final EnumMap<Team, Integer> openUntil = new EnumMap<>(Team.class);
    private final Map<Pos, Material> placed = new LinkedHashMap<>();
    private final Map<Item, Boolean> clams = new LinkedHashMap<>();
    private final EnumMap<Team, ArmorStand> labels = new EnumMap<>(Team.class);

    ClamObjective(SplatGame g) {
        this.g = g;
        for (Team team : Team.values()) { count.put(team, RankedRules.START); openUntil.put(team, -1); }
    }

    private Pos basket(Team scorer) { return g.map.anchors().goal().get(scorer); }

    private Location target(Team scorer) {
        Pos b = basket(scorer);
        return new Location(g.world, b.x() + 0.5, b.y() + BARRIER_Y - 0.2, b.z() + 0.5);
    }

    private boolean open(Team scorer) { return g.elapsed < openUntil.get(scorer); }

    @Override
    public void start() {
        for (Team scorer : Team.values()) {
            buildBasket(scorer);
            Location at = target(scorer).add(0, 2.2, 0);
            ArmorStand label = g.world.spawn(at, ArmorStand.class, s -> {
                s.setInvisible(true); s.setMarker(true); s.setGravity(false); s.setPersistent(false); s.setCustomNameVisible(true);
            });
            g.track(label);
            labels.put(scorer, label);
        }
        for (Pos spot : g.map.anchors().clams()) spawnClam(spot);
        relabel();
    }

    /** A defending-team pillar with a hoop on top and a glass barrier lid. */
    private void buildBasket(Team scorer) {
        Pos b = basket(scorer);
        Team defender = scorer.opponent();
        Material pillar = defender == Team.ORANGE ? Material.ORANGE_TERRACOTTA : Material.BLUE_TERRACOTTA;
        set(b.add(0, 1, 0), pillar);
        set(b.add(0, 2, 0), pillar);
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++)
                set(b.add(dx, 3, dz), dx == 0 && dz == 0 ? Material.GOLD_BLOCK : defender.glass);
        barrier(scorer, true);
    }

    private void barrier(Team scorer, boolean closed) {
        Pos b = basket(scorer);
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++) {
                Pos p = b.add(dx, BARRIER_Y, dz);
                if (closed) set(p, Material.WHITE_STAINED_GLASS);
                else restore(p);
            }
    }

    private void set(Pos p, Material material) {
        placed.putIfAbsent(p, g.map.blueprint().at(p));
        g.world.getBlockAt(p.x(), p.y(), p.z()).setType(material, false);
    }

    private void restore(Pos p) {
        Material original = placed.remove(p);
        if (original != null) g.world.getBlockAt(p.x(), p.y(), p.z()).setType(original, false);
    }

    private void spawnClam(Pos turf) { dropClam(new Location(g.world, turf.x() + 0.5, turf.y() + 1.1, turf.z() + 0.5), false); }

    private void dropClam(Location at, boolean power) {
        if (at.getY() < SplatArena.VOID_Y + 3) return;
        Item item = g.dropStill(at, g.uniqueItem(power ? Weapon.POWER_CLAM : Weapon.CLAM), true);
        if (power) item.setGlowing(true);
        clams.put(item, power);
    }

    @Override
    public void tick() {
        // Refill empty clam spots.
        if (g.elapsed % SPAWN_TICKS == 0) {
            for (Pos spot : g.map.anchors().clams()) {
                Location at = new Location(g.world, spot.x() + 0.5, spot.y() + 1.1, spot.z() + 0.5);
                boolean taken = clams.keySet().stream().anyMatch(c -> c.isValid() && c.getLocation().distanceSquared(at) < 4);
                if (!taken && g.random.nextInt(3) == 0) spawnClam(spot);
            }
        }
        for (Iterator<Map.Entry<Item, Boolean>> it = clams.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<Item, Boolean> e = it.next();
            Item item = e.getKey();
            if (!item.isValid() || item.getLocation().getY() < SplatArena.VOID_Y) { item.remove(); g.entities.remove(item); it.remove(); continue; }
            if (e.getValue() && g.elapsed % 5 == 0)
                g.world.spawnParticle(Particle.DUST, item.getLocation().add(0, 0.5, 0), 3, 0.2, 0.3, 0.2, 0, new Particle.DustOptions(Color.fromRGB(0xFFD23F), 1f));
        }
        for (Player p : g.online()) {
            Inkling in = g.players.get(p.getUniqueId());
            if (!in.alive() || in.jump != null) continue;
            for (Iterator<Map.Entry<Item, Boolean>> it = clams.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<Item, Boolean> e = it.next();
                if (p.getLocation().distanceSquared(e.getKey().getLocation()) > PICKUP_RADIUS * PICKUP_RADIUS) continue;
                boolean power = e.getValue();
                if (in.powerClam) continue;
                e.getKey().remove();
                g.entities.remove(e.getKey());
                it.remove();
                if (power) gainPower(p, in);
                else {
                    in.clams++;
                    p.playSound(p, Sound.ENTITY_ITEM_PICKUP, 0.6f, 1.2f + in.clams * 0.08f);
                    if (in.clams >= RankedRules.CLAMS_FOR_POWER) { in.clams = 0; gainPower(p, in); }
                }
                g.refreshHotbar(p, in);
            }
        }
        for (Team scorer : Team.values()) {
            if (openUntil.get(scorer) >= 0 && !open(scorer)) {
                openUntil.put(scorer, -1);
                barrier(scorer, false);
                barrier(scorer, true);
                g.callout(scorer, "Their basket closed.", "Our basket is sealed again!", "The " + scorer.opponent().title + " basket closed.");
            }
            if (open(scorer) && g.elapsed % 4 == 0) {
                Location t = target(scorer);
                for (int i = 0; i < 10; i++) {
                    double a = i * Math.PI / 5 + g.elapsed * 0.2;
                    g.world.spawnParticle(Particle.DUST, t.clone().add(Math.cos(a) * 1.3, 0.3, Math.sin(a) * 1.3), 1, 0, 0, 0, 0, SplatGame.dust(scorer));
                }
            }
        }
        if (g.elapsed % 10 == 0) relabel();
    }

    private void gainPower(Player p, Inkling in) {
        in.powerClam = true;
        p.getInventory().setHeldItemSlot(SplatGame.SUB_SLOT);
        p.playSound(p, Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.5f);
        g.callout(in.team, "We've got a Power Clam!", "They've got a Power Clam!", in.team.title + " has a Power Clam!");
    }

    @Override
    public void throwClam(Player p, Inkling in) {
        if (in.powerClam) {
            in.powerClam = false;
            g.weapons.shoot(p, in, Weapon.POWER_CLAM, 0, -8, 1, 0, 0);
        } else if (in.clams > 0) {
            in.clams--;
            g.weapons.shoot(p, in, Weapon.CLAM, 0, -8, 1, 0, 0);
        } else return;
        g.world.playSound(p.getLocation(), Sound.ENTITY_SNOWBALL_THROW, 0.9f, 0.7f);
        g.refreshHotbar(p, in);
    }

    @Override
    public boolean flying(Entity ball, SplatWeapons.Shot shot) {
        if (ball.getLocation().distanceSquared(target(shot.team())) > SCORE_RADIUS * SCORE_RADIUS) return false;
        resolve(shot);
        return true;
    }

    private void resolve(SplatWeapons.Shot shot) {
        Location t = target(shot.team());
        boolean power = shot.weapon() == Weapon.POWER_CLAM;
        Team scorer = shot.team();
        Inkling thrower = g.players.get(shot.owner());
        if (power) {
            boolean wasOpen = open(scorer);
            score(scorer, RankedRules.POWER_CLAM);
            openUntil.put(scorer, g.elapsed + RankedRules.BARRIER_OPEN);
            if (!wasOpen) barrier(scorer, false);
            g.world.playSound(t, Sound.BLOCK_GLASS_BREAK, 1.5f, 0.8f);
            g.world.spawnParticle(Particle.EXPLOSION, t, 2);
            g.callout(scorer, "Barrier broken! Throw in your clams!", "Our basket's barrier is broken!", scorer.title + " broke the barrier!");
        } else if (open(scorer)) {
            score(scorer, RankedRules.CLAM);
            g.world.playSound(t, Sound.ENTITY_ITEM_PICKUP, 1f, 1.8f);
            g.world.spawnParticle(Particle.DUST, t, 10, 0.3, 0.3, 0.3, 0, SplatGame.dust(scorer));
        } else {
            // Bounces off the closed barrier.
            g.world.playSound(t, Sound.BLOCK_GLASS_HIT, 1f, 1.4f);
            dropClam(t.clone().add(g.random.nextDouble() * 2 - 1, 1.2, 0), false);
            if (thrower != null) { thrower.notice = Component.text("Break the barrier with a Power Clam first!", NamedTextColor.RED); thrower.noticeUntil = g.elapsed + 40; }
        }
    }

    private void score(Team scorer, double points) {
        count.put(scorer, Math.max(0, count.get(scorer) - points * g.outnumbered(scorer)));
        relabel();
    }

    @Override
    public void landed(Location at, SplatWeapons.Shot shot) {
        // Clams that clip the basket's blocks count as reaching it.
        if (at.distanceSquared(target(shot.team())) <= 2.2 * 2.2) resolve(shot);
        else dropClam(at, shot.weapon() == Weapon.POWER_CLAM);
    }

    @Override
    public void onSplat(Player victim, Inkling in, Location at) {
        Location spot = at.getY() < SplatArena.VOID_Y + 3 ? g.map.centre(g.world).add(0, 1, 0) : at.clone().add(0, 0.6, 0);
        if (in.powerClam) dropClam(spot, true);
        for (int i = 0; i < in.clams; i++) dropClam(spot.clone().add(g.random.nextDouble() - 0.5, 0.2, g.random.nextDouble() - 0.5), false);
        in.powerClam = false;
        in.clams = 0;
    }

    private void relabel() {
        for (Team scorer : Team.values()) {
            ArmorStand label = labels.get(scorer);
            if (label == null) continue;
            Team defender = scorer.opponent();
            label.customName(open(scorer)
                    ? Component.text("⌂ " + defender.title.toUpperCase(Locale.ROOT) + " BASKET · OPEN " + (openUntil.get(scorer) - g.elapsed + 19) / 20 + "s", NamedTextColor.YELLOW, TextDecoration.BOLD)
                    : Component.text("⌂ " + defender.title.toUpperCase(Locale.ROOT) + " BASKET · sealed", defender.text, TextDecoration.BOLD));
        }
    }

    @Override
    public double count(Team team) { return count.get(team); }

    @Override
    public Team advantage() {
        Team result = null;
        for (Team team : Team.values()) {
            boolean holds = open(team) || g.players.values().stream().anyMatch(in -> in.team == team && in.powerClam && in.alive());
            if (holds) { if (result != null) return null; result = team; }
        }
        return result;
    }

    @Override
    public Team winner() { return RankedRules.winner(count.get(Team.ORANGE), count.get(Team.BLUE)); }

    @Override
    public void sidebar(List<String> lines) {
        // The Orange basket is the one Blue scores into, and vice versa.
        lines.add("§6Orange basket: " + (open(Team.BLUE) ? "§eOPEN" : "§7sealed"));
        lines.add("§9Blue basket: " + (open(Team.ORANGE) ? "§eOPEN" : "§7sealed"));
    }

    @Override
    public String hint(Inkling in) {
        if (in.powerClam) return "★ Power Clam! Throw it at their basket (slot 2)";
        if (in.clams > 0) return "Clams " + in.clams + "/10" + (open(in.team) ? " · basket OPEN!" : "");
        return open(in.team) ? "Their basket is open!" : null;
    }

    @Override
    public void cleanup() {
        for (Item item : clams.keySet()) item.remove();
        clams.clear();
        for (Pos p : new ArrayList<>(placed.keySet())) restore(p);
        labels.values().forEach(Entity::remove);
        for (Inkling in : g.players.values()) { in.clams = 0; in.powerClam = false; }
    }
}
