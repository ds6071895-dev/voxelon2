package dev.autobox.game;

import com.destroystokyo.paper.ParticleBuilder;
import dev.autobox.util.Sidebar;
import com.destroystokyo.paper.ParticleBuilder;
import dev.autobox.AutoBoxPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class AutoBoxGame {

    public static final int BOX_HALF = 10;
    public static final int BOX_Y_CENTER = 30;
    public static final int BOX_DIRECTION_INTERVAL = 300;
    public static final int BOX_STEP_INTERVAL = 20;
    public static final int TOWER_INTERVAL = 400;
    public static final long COUNTDOWN_MILLIS = 2000L;
    public static final int MAX_LIVES = 5;
    private static final int RESPAWN_TICKS = 60;
    private static final int WARN_TICKS = 20;

    private static final Material TOWER_MATERIAL = Material.POLISHED_DEEPSLATE;
    private static final Material TOWER_TOP_MATERIAL = Material.SMOOTH_STONE;
    private static final Color BORDER_COLOR = Color.fromRGB(0, 255, 255);
    private static final int TOWER_COUNT = 6;
    private static final int BOX_CENTER_BOUNDS = 48;
    private static final Material[] WOOL_COLORS = {
            Material.WHITE_WOOL, Material.ORANGE_WOOL, Material.LIME_WOOL,
            Material.CYAN_WOOL, Material.LIGHT_BLUE_WOOL, Material.MAGENTA_WOOL,
            Material.YELLOW_WOOL, Material.PINK_WOOL, Material.PURPLE_WOOL,
            Material.RED_WOOL, Material.GREEN_WOOL, Material.BLUE_WOOL
    };
    private static final double MIN_RESPAWN_SEPARATION = 8.0;
    private static final int[][] RESPAWN_DIRECTIONS = {
            {1, 0}, {-1, 0}, {0, 1}, {0, -1},
            {1, 1}, {1, -1}, {-1, 1}, {-1, -1}
    };

    private enum MapType {
        TOWERS("Towers"), WALLS("Walls"), FORTRESS("Fortress"),
        PLATFORMS("Sky Platforms"), PILLARS("Pillars"),
        CROSS("Cross"), RINGS("Rings");

        final String displayName;

        MapType(String displayName) {
            this.displayName = displayName;
        }

        void build(AutoBoxGame game) {
            switch (this) {
                case WALLS -> game.buildWallsMap();
                case FORTRESS -> game.buildFortressMap();
                case PLATFORMS -> game.buildPlatformsMap();
                case PILLARS -> game.buildPillarsMap();
                case CROSS -> game.buildCrossMap();
                case RINGS -> game.buildRingsMap();
                default -> game.buildTowersMap();
            }
        }
    }

    private final AutoBoxPlugin plugin;
    private final World arena;
    private final Location lobbySpawn;
    private final Random random = new Random();

    private boolean running = false;
    /** Bumped every round so delayed tasks from an earlier round never act on a later one. */
    private int round;
    private Sidebar sidebar;
    private final Set<UUID> players = new HashSet<>();
    private final Set<Location> placedWool = new HashSet<>();
    private final Set<Location> warnedBlocks = new HashSet<>();
    private final Set<Location> towerBlocks = new HashSet<>();
    private final Set<Location> chests = new HashSet<>();
    private final List<Location> towerTops = new ArrayList<>();
    private final Map<UUID, Long> countdown = new HashMap<>();
    private final Map<UUID, Material> woolColor = new HashMap<>();
    private final Map<UUID, Integer> lives = new HashMap<>();
    private final Map<UUID, Integer> respawnSlot = new HashMap<>();
    private final Map<UUID, BukkitTask> respawnTasks = new HashMap<>();

    private int centerX = 0;
    private int centerZ = 0;
    private int moveDirX = 1;
    private int moveDirZ = 0;
    private int tickCounter = 0;
    private int boxTicks = 0;
    private int boxSize = 20;
    private MapType currentMap = MapType.TOWERS;
    private String winnerName;
    private BukkitTask task;

    public AutoBoxGame(AutoBoxPlugin plugin, World arena, Location lobbySpawn) {
        this.plugin = plugin;
        this.arena = arena;
        this.lobbySpawn = lobbySpawn;
    }

    public void start(CommandSender sender) {
        start(sender, new ArrayList<>(Bukkit.getOnlinePlayers()));
    }

    public void start(CommandSender sender, List<Player> roster) {
        if (running) {
            sender.sendMessage(Component.text("A game is already running!", NamedTextColor.RED));
            return;
        }
        List<Player> online = roster.stream().filter(Player::isOnline).limit(6).toList();
        if (online.size() < 2) {
            sender.sendMessage(Component.text("Need at least 2 players online to start AutoBox.", NamedTextColor.RED));
            return;
        }

        round++;
        resetArena(true);
        players.clear();
        countdown.clear();
        woolColor.clear();
        centerX = 0;
        centerZ = 0;
        tickCounter = 0;
        boxTicks = 0;
        boxSize = switch (online.size()) {
            case 3 -> 30;
            case 4 -> 35;
            case 5 -> 40;
            case 6 -> 45;
            default -> 20;
        };
        winnerName = null;
        currentMap = MapType.values()[random.nextInt(MapType.values().length)];
        running = true;

        regenerateStructures();
        pickNewDirection();

        int i = 0;
        for (Player player : online) {
            players.add(player.getUniqueId());
            lives.put(player.getUniqueId(), MAX_LIVES);
            Material color = WOOL_COLORS[random.nextInt(WOOL_COLORS.length)];
            woolColor.put(player.getUniqueId(), color);
            giveKit(player, color);
            respawnSlot.put(player.getUniqueId(), i);
            player.teleport(respawnSpotFor(player));
            player.setGameMode(GameMode.SURVIVAL);
            player.setBedSpawnLocation(lobbySpawn, true);
            showTitle(player, "AUTOBOX", "Survive the moving box!", 2500L, NamedTextColor.GOLD, NamedTextColor.AQUA);
            player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.4f, 2f);
            i++;
        }

        broadcast(Component.text("AutoBox started! " + players.size() + " players. " + boxSize + "x"
                + boxSize + "x" + boxSize + " box. Map: "
                + currentMap.displayName + ". The box slides 1 block per second and changes direction every 15s. "
                + "Towers are rebuilt every 20s. Don't leave the box!", NamedTextColor.AQUA));
        updateScoreboard();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public void endGame() {
        if (!running) {
            return;
        }
        running = false;
        if (task != null) {
            task.cancel();
            task = null;
        }
        cancelAllRespawnTasks();
        broadcast(Component.text("Game over - type /autobox start to play again.", NamedTextColor.GRAY));
        resetArena(false);
        players.clear();
        countdown.clear();
        woolColor.clear();
        lives.clear();
        respawnSlot.clear();
        clearScoreboards();
        for (Player player : new ArrayList<>(arena.getPlayers())) {
            player.getInventory().clear();
            player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
            player.setGameMode(GameMode.ADVENTURE);
            player.setBedSpawnLocation(lobbySpawn, true);
            player.teleport(lobbySpawn);
        }
        if (winnerName != null) {
            spawnLobbyFireworks();
            winnerName = null;
        }
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        running = false;
        cancelAllRespawnTasks();
        resetArena(false);
        players.clear();
        countdown.clear();
        woolColor.clear();
        lives.clear();
        respawnSlot.clear();
        clearScoreboards();
    }

    public void handleDeath(Player player) {
        UUID id = player.getUniqueId();
        countdown.remove(id);
        cancelRespawnTask(id);
        if (!running || !players.contains(id)) {
            return;
        }
        int remaining = lives.getOrDefault(id, MAX_LIVES) - 1;
        lives.put(id, remaining);
        if (remaining > 0) {
            broadcast(Component.text(player.getName() + " fell out of the box! -1 life ("
                    + remaining + " left)", NamedTextColor.RED));
        } else {
            players.remove(id);
            woolColor.remove(id);
            broadcast(Component.text(player.getName() + " was eliminated!", NamedTextColor.RED));
            player.playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1f);
            checkEnd();
        }
        updateScoreboard();
    }

    public void handleQuit(Player player) {
        UUID id = player.getUniqueId();
        countdown.remove(id);
        cancelRespawnTask(id);
        woolColor.remove(id);
        lives.remove(id);
        respawnSlot.remove(id);
        if (!running) {
            return;
        }
        if (players.remove(id)) {
            broadcast(Component.text(player.getName() + " abandoned the box!", NamedTextColor.YELLOW));
            checkEnd();
            updateScoreboard();
        }
    }

    public void openChest(Player player, Location chestLocation) {
        if (!running || !isPlaying(player) || player.getWorld() != arena) {
            return;
        }
        chests.remove(chestLocation);
        chestLocation.getBlock().setType(Material.AIR);
        Location effectLocation = chestLocation.clone().add(0.5, 0.5, 0.5);

        Particle.POOF.builder()
                .location(effectLocation)
                .count(24)
                .offset(0.4, 0.4, 0.4)
                .extra(0.1)
                .receivers(32, true)
                .spawn();
        player.playSound(effectLocation, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.5f);

        if (random.nextBoolean()) {
            player.addPotionEffect(PotionEffectType.JUMP_BOOST.createEffect(15 * 20, 2));
            showTitle(player, "JUMP BOOST III!", "15 seconds of hops", 1800L, NamedTextColor.GREEN, NamedTextColor.AQUA);
            player.sendActionBar(Component.text("JUMP BOOST III for 15 seconds!", NamedTextColor.GREEN));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
        } else {
            player.getInventory().addItem(ItemStack.of(Material.SNOWBALL, 4));
            showTitle(player, "4 SNOWBALLS!", "BONK them out of the box!", 1800L, NamedTextColor.WHITE, NamedTextColor.RED);
            player.sendActionBar(Component.text("4 SNOWBALLS! Snowballs knock players!", NamedTextColor.WHITE));
            player.playSound(player.getLocation(), Sound.ENTITY_SNOWBALL_THROW, 1f, 1.5f);
        }

        int chestRound = round;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (running && round == chestRound) {
                int x = centerX + random.nextInt(17) - 8;
                int z = centerZ + random.nextInt(17) - 8;
                int y = BOX_Y_CENTER - BOX_HALF + 8 + random.nextInt(10);
                placeChest(x, y, z);
            }
        }, 600L);
    }

    public boolean onWoolPlace(Player player, Location location, Material type) {
        if (!running || !isPlaying(player) || player.getWorld() != arena) {
            return false;
        }
        if (!type.name().endsWith("_WOOL")) {
            return false;
        }
        placedWool.add(location);
        Material color = woolColor.get(player.getUniqueId());
        if (color == null) {
            color = Material.WHITE_WOOL;
        }
        if (!plugin.getDisadvantages(player).contains(Disadvantage.NO_WOOL_REFILL)) {
            player.getInventory().setItemInMainHand(ItemStack.of(color, 64));
        }
        player.playSound(location, Sound.BLOCK_WOOL_PLACE, 1f, 1.5f);
        return true;
    }

    public boolean isRunning() {
        return running;
    }

    public boolean isPlaying(Player player) {
        return running && players.contains(player.getUniqueId());
    }

    public boolean isInArenaWorld(Player player) {
        return player.getWorld() == arena;
    }

    /** Where a lobby spectator is dropped in to watch the current match. */
    public Location getSpectateLocation() {
        return new Location(arena, centerX + 0.5, BOX_Y_CENTER + boxSize / 2.0 + 4, centerZ + 0.5);
    }

    public boolean hasLives(Player player) {
        return running && players.contains(player.getUniqueId())
                && lives.getOrDefault(player.getUniqueId(), 0) > 0;
    }

    /**
     * Picks the spot inside the box that is furthest from every other living player,
     * preferring tower tops, then guarantees the player materialises in open air on
     * solid ground rather than inside a structure.
     */
    public Location respawnSpotFor(Player player) {
        List<Location> candidates = new ArrayList<>();
        for (Location top : towerTops) {
            candidates.add(top.clone());
        }
        int reach = Math.max(3, boxSize / 2 - 3);
        for (int radius = 3; radius <= reach; radius += 3) {
            for (int[] direction : RESPAWN_DIRECTIONS) {
                candidates.add(new Location(arena,
                        centerX + direction[0] * radius + 0.5,
                        BOX_Y_CENTER + 1,
                        centerZ + direction[1] * radius + 0.5));
            }
        }
        candidates.add(new Location(arena, centerX + 0.5, BOX_Y_CENTER + 1, centerZ + 0.5));

        Location best = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (Location candidate : candidates) {
            if (!inBox(candidate)) {
                continue;
            }
            // Cap the reward for distance so a far-but-buried spot never beats a clear one.
            double score = Math.min(nearestPlayerDistance(candidate, player), MIN_RESPAWN_SEPARATION * 2);
            if (!hasHeadroom(candidate)) {
                score -= 100;
            }
            if (score > bestScore) {
                bestScore = score;
                best = candidate;
            }
        }
        if (best == null) {
            best = new Location(arena, centerX + 0.5, BOX_Y_CENTER + 1, centerZ + 0.5);
        }
        return prepareSpawnPad(best, player);
    }

    /** Distance from a candidate spot to the closest other player still in the fight. */
    private double nearestPlayerDistance(Location spot, Player self) {
        double nearest = Double.MAX_VALUE;
        for (UUID id : players) {
            if (id.equals(self.getUniqueId())) {
                continue;
            }
            Player other = Bukkit.getPlayer(id);
            if (other == null || !other.isOnline() || other.getWorld() != arena
                    || other.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            nearest = Math.min(nearest, other.getLocation().distance(spot));
        }
        return nearest;
    }

    /** True when a player would stand in open air at this spot. */
    private boolean hasHeadroom(Location spot) {
        int x = spot.getBlockX();
        int y = spot.getBlockY();
        int z = spot.getBlockZ();
        return arena.getBlockAt(x, y, z).getType().isAir()
                && arena.getBlockAt(x, y + 1, z).getType().isAir();
    }

    /** Carves out body space and lays a wool pad so nobody spawns inside a tower or in mid-air. */
    private Location prepareSpawnPad(Location spot, Player player) {
        int x = spot.getBlockX();
        int y = spot.getBlockY();
        int z = spot.getBlockZ();
        for (int dy = 0; dy < 2; dy++) {
            Block body = arena.getBlockAt(x, y + dy, z);
            if (!body.getType().isAir()) {
                Location location = body.getLocation();
                towerBlocks.remove(location);
                placedWool.remove(location);
                chests.remove(location);
                body.setType(Material.AIR, false);
            }
        }
        Block floor = arena.getBlockAt(x, y - 1, z);
        if (!floor.getType().isSolid()) {
            Material color = woolColor.getOrDefault(player.getUniqueId(), Material.WHITE_WOOL);
            floor.setType(color);
            placedWool.add(floor.getLocation());
        }
        return new Location(arena, x + 0.5, y, z + 0.5);
    }

    public void startRespawnCountdown(Player player, Location spot) {
        UUID id = player.getUniqueId();
        cancelRespawnTask(id);
        int[] counter = {RESPAWN_TICKS / 20};
        BukkitTask respawnTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!running || !players.contains(id)) {
                cancelRespawnTask(id);
                return;
            }
            counter[0]--;
            if (counter[0] > 0) {
                player.showTitle(Title.title(
                        Component.text("YOU DIED!", NamedTextColor.RED, TextDecoration.BOLD),
                        Component.text("Respawning in " + counter[0] + "...", NamedTextColor.AQUA),
                        Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(1800), Duration.ofMillis(200))));
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
            } else {
                cancelRespawnTask(id);
                Location respawn = respawnSpotFor(player);
                player.teleport(respawn);
                player.setGameMode(GameMode.SURVIVAL);
                giveKit(player, woolColor.getOrDefault(id, Material.WHITE_WOOL));
                player.showTitle(Title.title(
                        Component.text("GO!", NamedTextColor.GREEN, TextDecoration.BOLD),
                        Component.text(lives.getOrDefault(id, MAX_LIVES) + " lives left!", NamedTextColor.AQUA),
                        Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(1500), Duration.ofMillis(300))));
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
                updateScoreboard();
            }
        }, 20L, 20L);
        respawnTasks.put(id, respawnTask);
    }

    private void cancelRespawnTask(UUID id) {
        BukkitTask pending = respawnTasks.remove(id);
        if (pending != null) {
            pending.cancel();
        }
    }

    private void cancelAllRespawnTasks() {
        respawnTasks.values().forEach(BukkitTask::cancel);
        respawnTasks.clear();
    }

    private void updateScoreboard() {
        if (sidebar == null) {
            sidebar = new Sidebar("autobox", Component.text("AUTOBOX", NamedTextColor.GOLD, TextDecoration.BOLD));
        }
        List<String> lines = new ArrayList<>();
        List<Integer> scores = new ArrayList<>();
        lines.add(ChatColor.AQUA + "Box: " + directionName());
        scores.add(100);
        lines.add(ChatColor.GREEN + "Alive: " + players.size());
        scores.add(99);
        lines.add(ChatColor.GRAY + "---");
        scores.add(98);
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            int life = lives.getOrDefault(id, MAX_LIVES);
            String hearts = ChatColor.RED + "♥".repeat(Math.max(0, life))
                    + ChatColor.DARK_GRAY + "♥".repeat(Math.max(0, MAX_LIVES - life));
            lines.add(ChatColor.WHITE + player.getName() + " " + hearts);
            scores.add(Math.max(1, life));
        }
        sidebar.set(lines, scores);
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                sidebar.show(player);
            }
        }
    }

    private void clearScoreboards() {
        Scoreboard empty = Bukkit.getScoreboardManager().getNewScoreboard();
        arena.getPlayers().forEach(player -> player.setScoreboard(empty));
    }

    public boolean inBox(Location location) {
        return location.getX() >= minX() && location.getX() < minX() + boxSize
                && location.getY() >= minY() && location.getY() < minY() + boxSize
                && location.getZ() >= minZ() && location.getZ() < minZ() + boxSize;
    }

    private void tick() {
        tickCounter++;
        if (tickCounter % 2 == 0) {
            spawnBorderParticles();
        }

        long now = System.currentTimeMillis();
        for (UUID id : new ArrayList<>(players)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline() || player.getWorld() != arena
                    || player.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            updateActionBar(player);
            Set<Disadvantage> set = plugin.getDisadvantages(player);
            if (set.contains(Disadvantage.HUNGER)) {
                player.setFoodLevel(2);
                player.setSaturation(0f);
            }
            if (set.contains(Disadvantage.NO_SPRINT)) {
                player.setSprinting(false);
            }
            if (set.contains(Disadvantage.SLOWNESS) && !player.hasPotionEffect(PotionEffectType.SLOWNESS)) {
                player.addPotionEffect(PotionEffectType.SLOWNESS.createEffect(20 * 60, 1));
            }
            if (inBox(player.getLocation())) {
                if (countdown.remove(id) != null) {
                    player.sendActionBar(Component.empty());
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 2f);
                }
            } else {
                if (!countdown.containsKey(id)) {
                    countdown.put(id, now + COUNTDOWN_MILLIS);
                    showTitle(player, "OUT OF THE BOX!", "Get back in!", 1500L, NamedTextColor.RED, NamedTextColor.YELLOW);
                    player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1f, 0.5f);
                }
                long deadline = countdown.get(id);
                int seconds = (int) Math.max(1, Math.ceil((deadline - now) / 1000.0));
                player.sendActionBar(Component.text("GET BACK IN THE BOX! " + seconds).color(NamedTextColor.RED));
                if (now >= deadline) {
                    countdown.remove(id);
                    player.setHealth(0.0);
                }
            }
        }

        if (boxTicks >= BOX_STEP_INTERVAL) {
            stepBox();
            boxTicks = 0;
            warnConsumption();
        } else {
            boxTicks++;
        }
        if (tickCounter % BOX_DIRECTION_INTERVAL == 0) {
            pickNewDirection();
        }
        if (tickCounter % TOWER_INTERVAL == 0) {
            regenerateStructures();
        }
    }

    private void stepBox() {
        for (Location location : warnedBlocks) {
            location.getBlock().setType(Material.AIR, false);
            placedWool.remove(location);
        }
        warnedBlocks.clear();
        centerX += moveDirX;
        centerZ += moveDirZ;
    }

    private void warnConsumption() {
        warnedBlocks.forEach(location -> location.getBlock().setType(Material.AIR, false));
        warnedBlocks.clear();
        int layerX = moveDirX > 0 ? minX() + boxSize : moveDirX < 0 ? minX() - 1 : centerX;
        int layerZ = moveDirZ > 0 ? minZ() + boxSize : moveDirZ < 0 ? minZ() - 1 : centerZ;
        for (int y = minY(); y < minY() + boxSize; y++) {
            for (int offset = 0; offset < boxSize; offset++) {
                int x = layerX + moveDirZ * offset;
                int z = layerZ + moveDirX * offset;
                if (moveDirZ != 0) {
                    x = minX() + offset;
                }
                if (moveDirX != 0) {
                    z = minZ() + offset;
                }
                Block block = arena.getBlockAt(x, y, z);
                if (block.getType() != Material.AIR) {
                    block.setType(Material.RED_WOOL, false);
                    warnedBlocks.add(block.getLocation());
                }
            }
        }
    }

    private void updateActionBar(Player player) {
        double yaw = Math.toRadians(player.getLocation().getYaw());
        double fx = -Math.sin(yaw);
        double fz = Math.cos(yaw);
        double forward = fx * moveDirX + fz * moveDirZ;
        double right = fx * moveDirZ - fz * moveDirX;
        String arrow;
        if (Math.abs(forward) >= Math.abs(right)) {
            arrow = forward > 0 ? ChatColor.GREEN + "\u2191" : ChatColor.RED + "\u2193";
        } else {
            arrow = right > 0 ? ChatColor.GOLD + "\u2192" : ChatColor.GOLD + "\u2190";
        }
        double pos = moveDirX != 0 ? player.getLocation().getX() : player.getLocation().getZ();
        double edge = moveDirX > 0 ? minX() + boxSize : moveDirX < 0 ? minX()
                : moveDirZ > 0 ? minZ() + boxSize : minZ();
        int blocks = (int) Math.ceil(Math.abs(edge - pos));
        player.sendActionBar(Component.text(arrow + " " + blocks + " blocks", NamedTextColor.WHITE));
    }

    private void pickNewDirection() {
        int[][] directions = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        List<int[]> candidates = new ArrayList<>();
        for (int[] direction : directions) {
            int endX = centerX + direction[0] * 15;
            int endZ = centerZ + direction[1] * 15;
            if (Math.abs(endX) <= BOX_CENTER_BOUNDS && Math.abs(endZ) <= BOX_CENTER_BOUNDS) {
                candidates.add(direction);
            }
        }
        if (candidates.isEmpty()) {
            return;
        }
        int[] direction = candidates.get(random.nextInt(candidates.size()));
        moveDirX = direction[0];
        moveDirZ = direction[1];
        broadcast(Component.text("THE BOX IS NOW MOVING " + directionName() + "!", NamedTextColor.AQUA));
        updateScoreboard();
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline() && player.getWorld() == arena) {
                player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.5f);
            }
        }
    }

    private String directionName() {
        if (moveDirX == 1) {
            return "EAST";
        }
        if (moveDirX == -1) {
            return "WEST";
        }
        if (moveDirZ == 1) {
            return "SOUTH";
        }
        return "NORTH";
    }

    private void regenerateStructures() {
        for (Location location : towerBlocks) {
            location.getBlock().setType(Material.AIR);
        }
        for (Location location : chests) {
            location.getBlock().setType(Material.AIR);
        }
        towerBlocks.clear();
        chests.clear();
        towerTops.clear();

        currentMap.build(this);
        placeExtraChests();
    }

    private void placeExtraChests() {
        int extras = random.nextInt(3) == 0 ? 1 : 0;
        for (int i = 0; i < extras; i++) {
            int tx = centerX + random.nextInt(17) - 8;
            int tz = centerZ + random.nextInt(17) - 8;
            int ty = BOX_Y_CENTER - BOX_HALF + 8 + random.nextInt(10);
            placeChest(tx, ty, tz);
        }
    }

    private void addBlock(int x, int y, int z, Material material) {
        Location location = new Location(arena, x, y, z);
        location.getBlock().setType(material);
        towerBlocks.add(location);
    }

    private void buildBox(int x, int z, int width, int depth, int topY, Material material, Material cap) {
        for (int dx = 0; dx < width; dx++) {
            for (int dz = 0; dz < depth; dz++) {
                for (int y = BOX_Y_CENTER - BOX_HALF; y <= topY; y++) {
                    addBlock(x + dx, y, z + dz, y == topY ? cap : material);
                }
            }
        }
    }

    private void buildTowersMap() {
        List<int[]> spots = new ArrayList<>();
        int guard = 0;
        while (spots.size() < TOWER_COUNT && guard++ < 300) {
            int tx = centerX + random.nextInt(15) - 7;
            int tz = centerZ + random.nextInt(15) - 7;
            boolean ok = true;
            for (int[] existing : spots) {
                int ddx = existing[0] - tx;
                int ddz = existing[1] - tz;
                if (ddx * ddx + ddz * ddz < 30) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                spots.add(new int[]{tx, tz});
            }
        }

        int baseY = BOX_Y_CENTER - BOX_HALF;
        for (int[] spot : spots) {
            int tx = spot[0];
            int tz = spot[1];
            int height = 6 + random.nextInt(9);
            int topY = baseY + height - 1;

            for (int y = baseY; y <= topY; y++) {
                addBlock(tx, y, tz, TOWER_MATERIAL);
            }
            for (int ddx = -1; ddx <= 1; ddx++) {
                for (int ddz = -1; ddz <= 1; ddz++) {
                    addBlock(tx + ddx, topY, tz + ddz, TOWER_TOP_MATERIAL);
                }
            }
            towerTops.add(new Location(arena, tx + 0.5, topY + 1.5, tz + 0.5));
            if (random.nextInt(100) < 13) {
                placeChest(tx, topY + 1, tz);
            }
        }
    }

    private void buildWallsMap() {
        int baseY = BOX_Y_CENTER - BOX_HALF;
        for (int side = -1; side <= 1; side += 2) {
            int wallX = centerX + side * 5;
            int gap1 = centerZ - 6 + random.nextInt(5);
            int gap2 = centerZ + 2 + random.nextInt(5);
            for (int z = centerZ - 9; z <= centerZ + 9; z++) {
                if ((z >= gap1 && z < gap1 + 3) || (z >= gap2 && z < gap2 + 3)) {
                    continue;
                }
                for (int y = baseY; y <= baseY + 8; y++) {
                    addBlock(wallX, y, z, Material.STONE_BRICKS);
                }
            }
        }
        int lowGap = centerX - 4 + random.nextInt(6);
        for (int x = centerX - 9; x <= centerX + 9; x++) {
            if (x >= lowGap && x < lowGap + 4) {
                continue;
            }
            for (int y = baseY; y <= baseY + 5; y++) {
                addBlock(x, y, centerZ + 3, Material.DARK_PRISMARINE);
            }
        }
        buildBox(centerX - 6, centerZ + 7, 2, 2, baseY + 14, Material.POLISHED_DEEPSLATE, TOWER_TOP_MATERIAL);
        buildBox(centerX + 4, centerZ - 8, 2, 2, baseY + 14, Material.POLISHED_DEEPSLATE, TOWER_TOP_MATERIAL);
    }

    private void buildFortressMap() {
        int baseY = BOX_Y_CENTER - BOX_HALF;
        int cx0 = centerX - 4;
        int cz0 = centerZ - 4;
        for (int dx = 0; dx <= 8; dx++) {
            for (int dz = 0; dz <= 8; dz++) {
                addBlock(cx0 + dx, baseY, cz0 + dz, Material.SMOOTH_STONE);
            }
        }
        for (int y = baseY + 1; y <= baseY + 2; y++) {
            for (int i = 0; i <= 8; i++) {
                boolean door = i >= 3 && i <= 5;
                if (!door) {
                    addBlock(cx0 + i, y, cz0, Material.POLISHED_DEEPSLATE);
                    addBlock(cx0 + i, y, cz0 + 8, Material.POLISHED_DEEPSLATE);
                    addBlock(cx0, y, cz0 + i, Material.POLISHED_DEEPSLATE);
                    addBlock(cx0 + 8, y, cz0 + i, Material.POLISHED_DEEPSLATE);
                }
            }
        }
        int[][] corners = {{0, 0}, {0, 7}, {7, 0}, {7, 7}};
        for (int[] corner : corners) {
            for (int y = baseY + 1; y <= baseY + 12; y++) {
                for (int dx = 0; dx < 2; dx++) {
                    for (int dz = 0; dz < 2; dz++) {
                        addBlock(cx0 + corner[0] + dx, y, cz0 + corner[1] + dz, Material.DARK_PRISMARINE);
                    }
                }
            }
            for (int dx = 0; dx < 2; dx++) {
                for (int dz = 0; dz < 2; dz++) {
                    addBlock(cx0 + corner[0] + dx, baseY + 13, cz0 + corner[1] + dz, TOWER_TOP_MATERIAL);
                }
            }
        }
    }

    private void buildPlatformsMap() {
        int baseY = BOX_Y_CENTER - BOX_HALF;
        buildBox(centerX + 3, centerZ + 3, 5, 5, baseY + 3, Material.DARK_PRISMARINE, Material.DARK_PRISMARINE);
        buildBox(centerX - 5, centerZ - 4, 3, 3, baseY + 7, Material.SMOOTH_STONE, Material.SMOOTH_STONE);
        buildBox(centerX - 3, centerZ + 5, 5, 5, baseY + 11, Material.DARK_PRISMARINE, Material.DARK_PRISMARINE);
        buildBox(centerX + 6, centerZ - 6, 3, 3, baseY + 15, Material.SMOOTH_STONE, Material.SMOOTH_STONE);
        for (int y = baseY; y < baseY + 3; y++) {
            addBlock(centerX + 3, y, centerZ + 3, Material.POLISHED_DEEPSLATE);
        }
        for (int y = baseY; y < baseY + 15; y++) {
            addBlock(centerX + 6, y, centerZ - 6, Material.POLISHED_DEEPSLATE);
        }
    }

    private void buildPillarsMap() {
        int[][] spots = {{-8, -6}, {-4, 7}, {0, -7}, {5, 3}, {8, -2}, {-6, 2}, {7, 8}, {-7, -8}};
        for (int[] spot : spots) {
            int width = random.nextBoolean() ? 1 : 2;
            int height = 6 + random.nextInt(12);
            int topY = BOX_Y_CENTER - BOX_HALF + height;
            for (int dx = 0; dx < width; dx++) {
                for (int dz = 0; dz < width; dz++) {
                    for (int y = BOX_Y_CENTER - BOX_HALF; y <= topY; y++) {
                        addBlock(centerX + spot[0] + dx, y, centerZ + spot[1] + dz,
                                y == topY ? TOWER_TOP_MATERIAL : Material.POLISHED_DEEPSLATE);
                    }
                }
            }
        }
        buildBox(centerX - 1, centerZ - 1, 3, 3, BOX_Y_CENTER - BOX_HALF + 15,
                Material.POLISHED_DEEPSLATE, Material.SMOOTH_STONE);
    }

    private void buildCrossMap() {
        int baseY = BOX_Y_CENTER - BOX_HALF;
        for (int x = centerX - 9; x <= centerX + 9; x++) {
            if (Math.abs(x - centerX) <= 2) {
                continue;
            }
            for (int y = baseY; y <= baseY + 16; y++) {
                addBlock(x, y, centerZ, Material.NETHER_BRICKS);
            }
        }
        for (int z = centerZ - 9; z <= centerZ + 9; z++) {
            if (Math.abs(z - centerZ) <= 2) {
                continue;
            }
            for (int y = baseY; y <= baseY + 16; y++) {
                addBlock(centerX, y, z, Material.NETHER_BRICKS);
            }
        }
        int[][] quads = {{5, 5}, {5, -5}, {-5, 5}, {-5, -5}};
        for (int[] quad : quads) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    addBlock(centerX + quad[0] + dx, baseY + 8, centerZ + quad[1] + dz, Material.SMOOTH_STONE);
                }
            }
        }
        int[][] corners = {{-8, -8}, {-8, 8}, {8, -8}, {8, 8}};
        for (int[] corner : corners) {
            for (int y = baseY; y <= baseY + 14; y++) {
                addBlock(centerX + corner[0], y, centerZ + corner[1], Material.POLISHED_DEEPSLATE);
            }
        }
    }

    private void buildRingsMap() {
        int baseY = BOX_Y_CENTER - BOX_HALF;
        int[] gaps = new int[4];
        for (int s = 0; s < 4; s++) {
            gaps[s] = random.nextInt(11) - 5;
        }
        for (int i = -8; i <= 8; i++) {
            if (i < gaps[0] || i >= gaps[0] + 3) {
                addBlock(centerX + i, baseY, centerZ - 8, Material.PRISMARINE);
            }
            if (i < gaps[1] || i >= gaps[1] + 3) {
                addBlock(centerX + i, baseY, centerZ + 8, Material.PRISMARINE);
            }
            if (i < gaps[2] || i >= gaps[2] + 3) {
                addBlock(centerX - 8, baseY, centerZ + i, Material.PRISMARINE);
            }
            if (i < gaps[3] || i >= gaps[3] + 3) {
                addBlock(centerX + 8, baseY, centerZ + i, Material.PRISMARINE);
            }
        }
        for (int s = 0; s < 4; s++) {
            gaps[s] = random.nextInt(7) - 3;
        }
        for (int i = -4; i <= 4; i++) {
            if (i < gaps[0] || i >= gaps[0] + 2) {
                addBlock(centerX + i, baseY + 4, centerZ - 4, Material.PRISMARINE);
            }
            if (i < gaps[1] || i >= gaps[1] + 2) {
                addBlock(centerX + i, baseY + 4, centerZ + 4, Material.PRISMARINE);
            }
            if (i < gaps[2] || i >= gaps[2] + 2) {
                addBlock(centerX - 4, baseY + 4, centerZ + i, Material.PRISMARINE);
            }
            if (i < gaps[3] || i >= gaps[3] + 2) {
                addBlock(centerX + 4, baseY + 4, centerZ + i, Material.PRISMARINE);
            }
        }
        for (int y = baseY; y < baseY + 10; y++) {
            addBlock(centerX, y, centerZ, Material.POLISHED_DEEPSLATE);
        }
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                addBlock(centerX + dx, baseY + 10, centerZ + dz, Material.SMOOTH_STONE);
            }
        }
    }

    private void placeChest(int x, int y, int z) {
        Location location = new Location(arena, x, y, z);
        towerBlocks.remove(location);
        location.getBlock().setType(Material.CHEST);
        chests.add(location);
    }

    private void spawnBorderParticles() {
        int minX = minX();
        int maxX = minX + boxSize - 1;
        int minY = minY();
        int maxY = minY + boxSize - 1;
        int minZ = minZ();
        int maxZ = minZ + boxSize - 1;
        // Viewers are looked up once per frame instead of once per edge particle (hundreds per frame).
        List<Player> viewers = arena.getPlayers();
        if (viewers.isEmpty()) {
            return;
        }
        ParticleBuilder edge = Particle.DUST.builder().color(BORDER_COLOR, 1.2f).count(1).extra(0).receivers(viewers);
        Location at = new Location(arena, 0, 0, 0);

        for (int x = minX; x <= maxX; x++) {
            spawnEdgeParticle(edge, at, x, minY, minZ);
            spawnEdgeParticle(edge, at, x, minY, maxZ);
            spawnEdgeParticle(edge, at, x, maxY, minZ);
            spawnEdgeParticle(edge, at, x, maxY, maxZ);
        }
        for (int y = minY; y <= maxY; y++) {
            spawnEdgeParticle(edge, at, minX, y, minZ);
            spawnEdgeParticle(edge, at, minX, y, maxZ);
            spawnEdgeParticle(edge, at, maxX, y, minZ);
            spawnEdgeParticle(edge, at, maxX, y, maxZ);
        }
        for (int z = minZ; z <= maxZ; z++) {
            spawnEdgeParticle(edge, at, minX, minY, z);
            spawnEdgeParticle(edge, at, minX, maxY, z);
            spawnEdgeParticle(edge, at, maxX, minY, z);
            spawnEdgeParticle(edge, at, maxX, maxY, z);
        }
    }

    private static void spawnEdgeParticle(ParticleBuilder edge, Location at, int x, int y, int z) {
        at.set(x + 0.5, y + 0.5, z + 0.5);
        edge.location(at).spawn();
    }

    private void giveKit(Player player, Material wool) {
        player.getInventory().clear();
        player.getInventory().setItemInMainHand(ItemStack.of(wool, 64));
        ItemStack shears = ItemStack.of(Material.SHEARS);
        ItemMeta shearsMeta = shears.getItemMeta();
        shearsMeta.setUnbreakable(true);
        shearsMeta.displayName(Component.text("Wool Shears", NamedTextColor.AQUA));
        shears.setItemMeta(shearsMeta);
        player.getInventory().addItem(shears);
        player.setHealth(20.0);
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.setFireTicks(0);
        player.setFallDistance(0);
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        AttributeInstance attackSpeed = player.getAttribute(Attribute.ATTACK_SPEED);
        if (attackSpeed != null) {
            attackSpeed.setBaseValue(64.0);
        }
        applyDisadvantages(player);
    }

    public void applyDisadvantages(Player player) {
        Set<Disadvantage> set = plugin.getDisadvantages(player);
        double maxHealth = set.contains(Disadvantage.HALF_HEARTS) ? 10.0 : 20.0;
        AttributeInstance health = player.getAttribute(Attribute.MAX_HEALTH);
        if (health != null) {
            health.setBaseValue(maxHealth);
        }
        if (player.getHealth() > maxHealth) {
            player.setHealth(maxHealth);
        }
        if (set.contains(Disadvantage.SLOWNESS)) {
            player.addPotionEffect(PotionEffectType.SLOWNESS.createEffect(20 * 60, 1));
        }
    }

    public void onWoolBreak(Location location) {
        placedWool.remove(location);
    }

    private int minX() {
        return centerX - boxSize / 2;
    }

    private int minY() {
        return BOX_Y_CENTER - boxSize / 2;
    }

    private int minZ() {
        return centerZ - boxSize / 2;
    }

    private void checkEnd() {
        if (!running) {
            return;
        }
        if (players.size() <= 1) {
            if (players.size() == 1) {
                Player winner = Bukkit.getPlayer(players.iterator().next());
                if (winner != null && winner.isOnline()) {
                    winnerName = winner.getName();
                    showTitle(winner, "YOU WIN!", "Last one standing in the box", 4000L, NamedTextColor.GOLD, NamedTextColor.AQUA);
                    broadcast(Component.text(winner.getName() + " wins AUTOBOX!", NamedTextColor.GOLD));
                    for (Player player : arena.getPlayers()) {
                        player.showTitle(Title.title(
                                Component.text(winnerName + " WINS!", NamedTextColor.GOLD, TextDecoration.BOLD),
                                Component.text("Congratulations!", NamedTextColor.AQUA),
                                Title.Times.times(Duration.ofMillis(500), Duration.ofMillis(5000), Duration.ofMillis(1000))));
                        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                    }
                }
            } else {
                broadcast(Component.text("No one survived the box!", NamedTextColor.GRAY));
            }
            int endingRound = round;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (round == endingRound) {
                    endGame();
                }
            }, 60L);
        }
    }

    private void spawnLobbyFireworks() {
        if (lobbySpawn == null || lobbySpawn.getWorld() == null) {
            return;
        }
        World world = lobbySpawn.getWorld();
        FireworkEffect.Type[] types = {
                FireworkEffect.Type.BALL, FireworkEffect.Type.BALL_LARGE,
                FireworkEffect.Type.STAR, FireworkEffect.Type.BURST
        };
        for (int i = 0; i < 8; i++) {
            Location location = lobbySpawn.clone().add(
                    (random.nextDouble() - 0.5) * 10,
                    2 + random.nextDouble() * 6,
                    (random.nextDouble() - 0.5) * 10);
            world.spawn(location, Firework.class, firework -> {
                FireworkMeta meta = firework.getFireworkMeta();
                meta.addEffect(FireworkEffect.builder()
                        .withColor(Color.fromRGB(random.nextInt(0x1000000)))
                        .withFade(Color.WHITE)
                        .trail(random.nextBoolean())
                        .flicker(random.nextBoolean())
                        .with(types[random.nextInt(types.length)])
                        .build());
                meta.setPower(1);
                firework.setFireworkMeta(meta);
            });
            world.playSound(location, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.6f, 1.2f);
        }
    }

    private void resetArena(boolean sweep) {
        for (Location location : placedWool) {
            location.getBlock().setType(Material.AIR);
        }
        for (Location location : warnedBlocks) {
            location.getBlock().setType(Material.AIR);
        }
        for (Location location : towerBlocks) {
            location.getBlock().setType(Material.AIR);
        }
        for (Location location : chests) {
            location.getBlock().setType(Material.AIR);
        }
        placedWool.clear();
        warnedBlocks.clear();
        towerBlocks.clear();
        chests.clear();
        towerTops.clear();
        if (!sweep) {
            return;
        }
        // Safety net for blocks the tracked sets missed (e.g. after a crash). Only run before a round:
        // it reads ~540k blocks, which used to stall every round end and every server stop as well.
        for (int x = -60; x <= 60; x++) {
            for (int z = -60; z <= 60; z++) {
                for (int y = BOX_Y_CENTER - BOX_HALF - 8; y <= BOX_Y_CENTER + BOX_HALF + 8; y++) {
                    if (!arena.getType(x, y, z).isAir()) {
                        arena.getBlockAt(x, y, z).setType(Material.AIR, false);
                    }
                }
            }
        }
    }

    private void broadcast(Component message) {
        Component line = Component.text("[AutoBox] ", NamedTextColor.GOLD).append(message);
        for (Player player : arena.getPlayers()) {
            player.sendMessage(line);
        }
    }

    private void showTitle(Player player, String title, String subtitle, long stayMillis,
                           NamedTextColor titleColor, NamedTextColor subtitleColor) {
        player.showTitle(Title.title(
                Component.text(title, titleColor, TextDecoration.BOLD),
                Component.text(subtitle, subtitleColor),
                Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(stayMillis), Duration.ofMillis(300))
        ));
    }
}
