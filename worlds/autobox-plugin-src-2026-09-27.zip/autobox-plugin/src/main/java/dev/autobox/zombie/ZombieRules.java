package dev.autobox.zombie;

/** Server-independent pacing and economy used by the game and its simulation checks. */
public final class ZombieRules {
    private ZombieRules() {}
    public static final int WAVES = 30, COMBAT_SECONDS = 50, BREAK_SECONDS = 10, BOSS_OVERTIME = 40;
    public static final int MOB_CAP = 48, MAX_TIER = 5;
    public static boolean validParty(int size) { return size >= 2 && size <= 6; }
    public static boolean bossWave(int wave) { return wave > 0 && wave % 5 == 0; }
    public static int enemies(int wave, int party) { return (8 + wave * 2 + party * 3) / (bossWave(wave) ? 2 : 1); }
    public static double health(int wave, boolean runner) { return (runner ? 12 : 18) + wave * 1.1; }
    public static double bossHealth(int wave, int party) { return (100 + wave * 8) * (0.55 + party * 0.45); }
    public static int upgradeCost(int tier) { return tier >= MAX_TIER ? Integer.MAX_VALUE : 35 + tier * 30; }
    public static int reward(int wave) { return 20 + wave + (bossWave(wave) ? 45 : 0); }
    public enum Outcome { FIGHT, CLEAR, VICTORY, DEFEAT }
    public static Outcome outcome(int wave, int seconds, boolean bossAlive, int survivors) {
        if (survivors == 0) return Outcome.DEFEAT;
        if (seconds < COMBAT_SECONDS) return Outcome.FIGHT;
        if (bossWave(wave) && bossAlive)
            return seconds < COMBAT_SECONDS + BOSS_OVERTIME ? Outcome.FIGHT : Outcome.DEFEAT;
        return wave == WAVES ? Outcome.VICTORY : Outcome.CLEAR;
    }
}
