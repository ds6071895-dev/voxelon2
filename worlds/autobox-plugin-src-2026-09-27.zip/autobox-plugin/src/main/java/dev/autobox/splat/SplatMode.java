package dev.autobox.splat;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;

import java.util.List;

/** Match rules a host can pick. Every mode keeps its own rating, so a Rainmaker main isn't judged on Turf War. */
public enum SplatMode {
    TURF_WAR("Turf War", "turf", false, 3600, Material.WHITE_CONCRETE, NamedTextColor.GREEN,
            "Ink the most turf in 3 minutes.",
            "Only the ground counts at the buzzer.",
            "Splats help, but painting wins."),
    SPLAT_ZONES("Splat Zones", "zones", true, 6000, Material.LIME_STAINED_GLASS, NamedTextColor.GREEN,
            "Ink 70% of the centre zone to take it.",
            "Your count drops while you hold it.",
            "Lose it and you get a penalty. First to 0 wins!"),
    TOWER_CONTROL("Tower Control", "tower", true, 6000, Material.PURPLE_STAINED_GLASS, NamedTextColor.LIGHT_PURPLE,
            "Stand on the tower to ride it to their base.",
            "It stops at checkpoints and when a foe climbs on.",
            "Furthest push wins; reaching the goal is a knockout."),
    RAINMAKER("Rainmaker", "rainmaker", true, 6000, Material.GOLDEN_HOE, NamedTextColor.GOLD,
            "Shoot the shield in the middle to burst it.",
            "Carry the Rainmaker to the enemy pedestal.",
            "The carrier is slow and can't swim, so escort them!"),
    CLAM_BLITZ("Clam Blitz", "clams", true, 6000, Material.NAUTILUS_SHELL, NamedTextColor.AQUA,
            "Grab clams: 10 of them make a Power Clam.",
            "Throw the Power Clam into their basket to break it open.",
            "While it's open, every clam scores. First to 0 wins!");

    /** Ranked rotation order when the host leaves rotation on. */
    public static final List<SplatMode> RANKED = List.of(SPLAT_ZONES, TOWER_CONTROL, RAINMAKER, CLAM_BLITZ);

    public final String title, key;
    public final boolean ranked;
    public final int playTicks;
    public final Material icon;
    public final NamedTextColor color;
    public final List<String> howTo;

    SplatMode(String title, String key, boolean ranked, int playTicks, Material icon, NamedTextColor color, String... howTo) {
        this.title = title; this.key = key; this.ranked = ranked; this.playTicks = playTicks;
        this.icon = icon; this.color = color; this.howTo = List.of(howTo);
    }

    public static SplatMode byKey(String key) {
        for (SplatMode mode : values()) if (mode.key.equalsIgnoreCase(key) || mode.name().equalsIgnoreCase(key)) return mode;
        return null;
    }
}
