package dev.autobox.sumo;

import dev.autobox.util.Fx;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Egg;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Mystery crates that drop into the arena, and the one-off items inside them. */
final class SumoCrates {
    private static final Particle.DustOptions BUBBLE = new Particle.DustOptions(Color.fromRGB(120, 210, 255), 1.1f);
    private static final int BUBBLE_TICKS = 3 * 20;
    private static final int GRAPPLE_USES = 3;
    private static final int EGG_LIFETIME = 30;

    private static final class Crate {
        final Location spot;
        final BlockDisplay display;
        final int landsAt;
        final int expiresAt;
        Crate(Location spot, BlockDisplay display, int landsAt, int expiresAt) {
            this.spot = spot;
            this.display = display;
            this.landsAt = landsAt;
            this.expiresAt = expiresAt;
        }
    }

    private record BridgeEgg(Egg egg, UUID owner, int thrownAt) { }

    private final BlockSumoGame game;
    private final NamespacedKey itemKey;
    private final NamespacedKey usesKey;
    private final NamespacedKey swapKey;
    private final List<Crate> crates = new ArrayList<>();
    private final List<BridgeEgg> eggs = new ArrayList<>();
    private final Map<UUID, Integer> bubbleUntil = new HashMap<>();
    private final Map<UUID, Integer> opened = new HashMap<>();
    private final Map<UUID, Location> eggLast = new HashMap<>();

    SumoCrates(BlockSumoGame game, Plugin plugin) {
        this.game = game;
        this.itemKey = new NamespacedKey(plugin, "sumo_item");
        this.usesKey = new NamespacedKey(plugin, "sumo_uses");
        this.swapKey = new NamespacedKey(plugin, "sumo_swap");
    }

    /** Clears the arena of crates and in-flight items; bubbles pop. Match stats are kept. */
    void clear() {
        crates.forEach(crate -> crate.display.remove());
        crates.clear();
        eggs.forEach(egg -> egg.egg().remove());
        eggs.clear();
        eggLast.clear();
        bubbleUntil.clear();
    }

    void resetStats() {
        opened.clear();
    }

    int opened(UUID id) {
        return opened.getOrDefault(id, 0);
    }

    boolean bubbled(Player player) {
        return bubbleUntil.getOrDefault(player.getUniqueId(), 0) > game.ticks();
    }

    void spawnCrate() {
        List<int[]> spots = game.survivingSpots();
        spots.removeIf(spot -> crates.stream().anyMatch(crate -> crate.spot.getBlockX() == spot[0]
                && crate.spot.getBlockZ() == spot[2]));
        if (spots.isEmpty()) return;
        int[] spot = spots.get(game.random().nextInt(spots.size()));
        World world = game.world();
        Location landing = new Location(world, spot[0] + 0.5, spot[1] + 1, spot[2] + 0.5);
        BlockDisplay display = world.spawn(landing.clone().add(0, 14, 0), BlockDisplay.class, spawned -> {
            spawned.setBlock(Material.CHEST.createBlockData());
            spawned.setTransformation(new Transformation(new Vector3f(-0.4f, 0, -0.4f), new Quaternionf(),
                    new Vector3f(0.8f, 0.8f, 0.8f), new Quaternionf()));
            spawned.setTeleportDuration(SumoRules.CRATE_FALL_TICKS - 1);
            spawned.setGlowing(true);
            spawned.setGlowColorOverride(Color.fromRGB(255, 200, 40));
            spawned.setPersistent(false);
            spawned.addScoreboardTag(BlockSumoGame.FX_TAG);
        });
        int now = game.ticks();
        crates.add(new Crate(landing, display, now + SumoRules.CRATE_FALL_TICKS,
                now + SumoRules.CRATE_FALL_TICKS + SumoRules.CRATE_LIFETIME));
        game.broadcast(Component.text("A mystery crate is dropping in. Grab it!", NamedTextColor.GOLD));
        world.playSound(landing, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.5f, 0.5f);
    }

    void tick() {
        int now = game.ticks();
        for (Iterator<Crate> iterator = crates.iterator(); iterator.hasNext(); ) {
            Crate crate = iterator.next();
            int left = crate.landsAt - now;
            if (left == SumoRules.CRATE_FALL_TICKS - 1) crate.display.teleport(crate.spot);
            boolean gone = Math.hypot(crate.spot.getX() - 0.5, crate.spot.getZ() - 0.5) > game.arenaRadius() + 0.5
                    || crate.spot.clone().subtract(0, 1, 0).getBlock().getType().isAir();
            if (now >= crate.expiresAt || (left <= 0 && gone)) {
                Particle.POOF.builder().location(crate.spot.clone().add(0, 0.4, 0)).count(10).offset(0.3, 0.3, 0.3)
                        .extra(0.02).receivers(48, true).spawn();
                crate.display.remove();
                iterator.remove();
                continue;
            }
            if (now % 5 == 0) {
                List<Player> viewers = Fx.near(crate.spot, 64);
                for (int i = 0; i < 6; i++) {
                    Particle.END_ROD.builder().location(crate.spot.clone().add(0, 1 + i * 1.5, 0)).count(1).extra(0)
                            .receivers(viewers).spawn();
                }
            }
            if (left == 0) {
                game.world().playSound(crate.spot, Sound.BLOCK_WOOD_PLACE, 1.2f, 0.7f);
                Particle.CLOUD.builder().location(crate.spot).count(8).offset(0.5, 0.05, 0.5).extra(0.03)
                        .receivers(48, true).spawn();
            }
            if (left > 0) continue;
            Player taker = null;
            for (Player player : game.alivePlayers()) {
                Location feet = player.getLocation();
                if (Math.hypot(feet.getX() - crate.spot.getX(), feet.getZ() - crate.spot.getZ()) <= 1.3
                        && Math.abs(feet.getY() - crate.spot.getY()) <= 1.8) {
                    taker = player;
                    break;
                }
            }
            if (taker == null) continue;
            crate.display.remove();
            iterator.remove();
            open(taker);
        }
        tickEggs(now);
        if (now % 4 == 0) {
            for (Player player : game.alivePlayers()) {
                if (!bubbled(player)) continue;
                List<Player> viewers = Fx.near(player.getLocation(), 48);
                double spin = now * 0.2;
                for (int i = 0; i < 10; i++) {
                    double angle = spin + i * Math.PI / 5;
                    double height = 0.2 + (i % 5) * 0.45;
                    Particle.DUST.builder().location(player.getLocation().add(Math.cos(angle) * 0.9, height,
                            Math.sin(angle) * 0.9)).count(1).data(BUBBLE).receivers(viewers).spawn();
                }
            }
        }
    }

    private void open(Player player) {
        SumoRules.CrateItem item = SumoRules.crateRoll(game.random().nextInt(100));
        opened.merge(player.getUniqueId(), 1, Integer::sum);
        player.getInventory().addItem(item(item));
        player.sendTitle("", "§6CRATE: §f§l" + item.label, 0, 30, 8);
        player.sendMessage(Component.text("[Block Sumo] ", NamedTextColor.AQUA)
                .append(Component.text("Crate: ", NamedTextColor.GOLD))
                .append(Component.text(item.label, NamedTextColor.WHITE, TextDecoration.BOLD))
                .append(Component.text(" · " + hint(item), NamedTextColor.GRAY)));
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 1f, 1.2f);
        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 0.8f);
        Particle.TOTEM_OF_UNDYING.builder().location(player.getLocation().add(0, 1, 0)).count(12)
                .offset(0.3, 0.5, 0.3).extra(0.2).receivers(48, true).spawn();
    }

    static String hint(SumoRules.CrateItem item) {
        return switch (item) {
            case WIND_CHARGES -> "throw at feet to rocket-jump, or at rivals to blast them";
            case KNOCKBACK_FISH -> "slap someone for huge knockback (3 slaps)";
            case GRAPPLE -> "cast and reel in to fly to the bobber, or hook a rival to yank them";
            case BRIDGE_EGG -> "throw it and it lays a wool bridge";
            case SWAP_ORB -> "hit a rival to swap places with them";
            case BUBBLE_SHIELD -> "right-click: 3 seconds of knockback immunity";
            case BOOM_STICK -> "one enormous hit";
            case SECOND_WIND -> "passive: your next fall bounces you back";
        };
    }

    ItemStack item(SumoRules.CrateItem kind) {
        ItemStack item = switch (kind) {
            case WIND_CHARGES -> ItemStack.of(Material.WIND_CHARGE, 3);
            case KNOCKBACK_FISH -> ItemStack.of(Material.COD, 3);
            case GRAPPLE -> ItemStack.of(Material.FISHING_ROD);
            case BRIDGE_EGG -> ItemStack.of(Material.EGG, 2);
            case SWAP_ORB -> ItemStack.of(Material.ENDER_EYE);
            case BUBBLE_SHIELD -> ItemStack.of(Material.SHULKER_SHELL);
            case BOOM_STICK -> ItemStack.of(Material.BREEZE_ROD);
            case SECOND_WIND -> ItemStack.of(Material.PHANTOM_MEMBRANE);
        };
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(kind.label, NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text(hint(kind), NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, kind.name());
        if (kind == SumoRules.CrateItem.GRAPPLE) {
            meta.setUnbreakable(true);
            meta.getPersistentDataContainer().set(usesKey, PersistentDataType.INTEGER, GRAPPLE_USES);
        }
        item.setItemMeta(meta);
        return item;
    }

    SumoRules.CrateItem kind(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        String name = item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
        if (name == null) return null;
        try {
            return SumoRules.CrateItem.valueOf(name);
        } catch (IllegalArgumentException unknown) {
            return null;
        }
    }

    /** Right-click with a crate item in the main hand. Returns true when the click was used. */
    boolean use(Player player, ItemStack held) {
        SumoRules.CrateItem kind = kind(held);
        if (kind == null) return false;
        switch (kind) {
            case BRIDGE_EGG -> {
                Egg egg = player.launchProjectile(Egg.class, player.getLocation().getDirection().multiply(1.3));
                eggs.add(new BridgeEgg(egg, player.getUniqueId(), game.ticks()));
                player.playSound(player.getLocation(), Sound.ENTITY_EGG_THROW, 1f, 1f);
                consume(player, held);
            }
            case SWAP_ORB -> {
                Snowball orb = player.launchProjectile(Snowball.class, player.getLocation().getDirection().multiply(1.8));
                orb.setItem(ItemStack.of(Material.ENDER_EYE));
                orb.getPersistentDataContainer().set(swapKey, PersistentDataType.BYTE, (byte) 1);
                player.playSound(player.getLocation(), Sound.ENTITY_ENDER_EYE_LAUNCH, 1f, 1.2f);
                consume(player, held);
            }
            case BUBBLE_SHIELD -> {
                bubbleUntil.put(player.getUniqueId(), game.ticks() + BUBBLE_TICKS);
                player.playSound(player.getLocation(), Sound.BLOCK_BUBBLE_COLUMN_UPWARDS_INSIDE, 1f, 1f);
                player.sendActionBar(Component.text("BUBBLE SHIELD · 3s", NamedTextColor.AQUA, TextDecoration.BOLD));
                consume(player, held);
            }
            case SECOND_WIND -> player.sendActionBar(Component.text("Second Wind works by itself: just fall!",
                    NamedTextColor.GRAY));
            default -> {
                return false;
            }
        }
        return true;
    }

    /** Extra melee strength from the held item, used up as it hits: {horizontal, vertical}. */
    double[] meleeBonus(Player attacker) {
        ItemStack held = attacker.getInventory().getItemInMainHand();
        SumoRules.CrateItem kind = kind(held);
        if (kind == SumoRules.CrateItem.KNOCKBACK_FISH) {
            consume(attacker, held);
            attacker.playSound(attacker.getLocation(), Sound.ENTITY_COD_FLOP, 1f, 0.8f);
            return new double[]{1.1, 0.12};
        }
        if (kind == SumoRules.CrateItem.BOOM_STICK) {
            consume(attacker, held);
            game.world().playSound(attacker.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.3f);
            Particle.EXPLOSION.builder().location(attacker.getLocation().add(attacker.getLocation().getDirection())
                    .add(0, 1, 0)).count(1).receivers(64, true).spawn();
            return new double[]{2.3, 0.45};
        }
        return new double[]{0, 0};
    }

    /** Uses up Second Wind if the player carries one. */
    boolean secondWind(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (kind(item) == SumoRules.CrateItem.SECOND_WIND) {
                item.setAmount(item.getAmount() - 1);
                return true;
            }
        }
        return false;
    }

    /** Handles every projectile landing in the arena. Returns true when it was one of ours. */
    boolean onProjectileHit(ProjectileHitEvent event) {
        Projectile projectile = event.getEntity();
        if (!(projectile.getShooter() instanceof Player shooter)) return false;
        if (projectile instanceof org.bukkit.entity.AbstractWindCharge) {
            event.setCancelled(true);
            Location at = projectile.getLocation();
            projectile.remove();
            game.windBurst(at, shooter);
            return true;
        }
        if (projectile instanceof Egg egg) {
            event.setCancelled(true);
            egg.remove();
            return true;
        }
        PersistentDataContainer data = projectile.getPersistentDataContainer();
        if (projectile instanceof Snowball && data.has(swapKey)) {
            event.setCancelled(true);
            projectile.remove();
            if (event.getHitEntity() instanceof Player victim && game.isPlaying(victim) && game.isPlaying(shooter)
                    && !victim.equals(shooter)) {
                swap(shooter, victim);
            } else {
                Particle.PORTAL.builder().location(projectile.getLocation()).count(20).offset(0.2, 0.2, 0.2)
                        .receivers(32, true).spawn();
            }
            return true;
        }
        return false;
    }

    private void swap(Player shooter, Player victim) {
        Location a = shooter.getLocation();
        Location b = victim.getLocation();
        Location toB = b.clone();
        toB.setYaw(a.getYaw());
        toB.setPitch(a.getPitch());
        Location toA = a.clone();
        toA.setYaw(b.getYaw());
        toA.setPitch(b.getPitch());
        shooter.teleport(toB);
        victim.teleport(toA);
        shooter.setVelocity(new Vector());
        victim.setVelocity(new Vector());
        shooter.setFallDistance(0);
        victim.setFallDistance(0);
        game.recordHit(victim, shooter);
        for (Location at : new Location[]{toA, toB}) {
            Particle.REVERSE_PORTAL.builder().location(at.clone().add(0, 1, 0)).count(40).offset(0.3, 0.6, 0.3)
                    .extra(0.05).receivers(48, true).spawn();
            game.world().playSound(at, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.3f);
        }
        victim.sendActionBar(Component.text(shooter.getName() + " swapped places with you!", NamedTextColor.LIGHT_PURPLE));
    }

    void onFish(PlayerFishEvent event) {
        Player player = event.getPlayer();
        ItemStack rod = player.getInventory().getItemInMainHand();
        if (kind(rod) != SumoRules.CrateItem.GRAPPLE) {
            rod = player.getInventory().getItemInOffHand();
            if (kind(rod) != SumoRules.CrateItem.GRAPPLE) return;
        }
        FishHook hook = event.getHook();
        PlayerFishEvent.State state = event.getState();
        if (state == PlayerFishEvent.State.CAUGHT_ENTITY && event.getCaught() instanceof Player caught
                && game.isPlaying(caught) && !caught.equals(player)) {
            Vector pull = player.getLocation().toVector().subtract(caught.getLocation().toVector()).setY(0);
            if (pull.lengthSquared() < 0.01) pull = new Vector(1, 0, 0);
            if (game.knock(caught, pull.normalize().multiply(1.15).setY(0.5), player)) {
                caught.sendActionBar(Component.text(player.getName() + " hooked you!", NamedTextColor.GOLD));
            }
            useCharge(player, rod);
        } else if (state == PlayerFishEvent.State.IN_GROUND
                || (state == PlayerFishEvent.State.REEL_IN && (hook.isOnGround() || blockNear(hook)))) {
            Vector to = hook.getLocation().toVector().subtract(player.getLocation().toVector());
            double distance = to.length();
            if (distance < 2) return;
            Vector horizontal = to.clone().setY(0);
            double speed = Math.min(2.3, 0.35 + distance * 0.11);
            Vector launch = horizontal.lengthSquared() < 0.01 ? new Vector() : horizontal.normalize().multiply(speed);
            launch.setY(Math.max(0.45, Math.min(1.3, 0.45 + to.getY() * 0.12)));
            player.setVelocity(launch);
            player.setFallDistance(0);
            player.playSound(player.getLocation(), Sound.ENTITY_FISHING_BOBBER_RETRIEVE, 1f, 0.7f);
            useCharge(player, rod);
        }
    }

    private boolean blockNear(Entity hook) {
        Location at = hook.getLocation();
        return !at.clone().subtract(0, 0.3, 0).getBlock().getType().isAir();
    }

    private void useCharge(Player player, ItemStack rod) {
        ItemMeta meta = rod.getItemMeta();
        int uses = meta.getPersistentDataContainer().getOrDefault(usesKey, PersistentDataType.INTEGER, GRAPPLE_USES) - 1;
        if (uses <= 0) {
            rod.setAmount(0);
            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
            return;
        }
        meta.getPersistentDataContainer().set(usesKey, PersistentDataType.INTEGER, uses);
        meta.lore(List.of(Component.text(hint(SumoRules.CrateItem.GRAPPLE), NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text(uses + " uses left", NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false)));
        rod.setItemMeta(meta);
    }

    private void consume(Player player, ItemStack held) {
        held.setAmount(held.getAmount() - 1);
    }

    private void tickEggs(int now) {
        for (Iterator<BridgeEgg> iterator = eggs.iterator(); iterator.hasNext(); ) {
            BridgeEgg entry = iterator.next();
            Egg egg = entry.egg();
            Player owner = org.bukkit.Bukkit.getPlayer(entry.owner());
            if (!egg.isValid() || now - entry.thrownAt() > EGG_LIFETIME || owner == null || !game.isPlaying(owner)) {
                egg.remove();
                eggLast.remove(egg.getUniqueId());
                iterator.remove();
                continue;
            }
            Location current = egg.getLocation();
            Location last = eggLast.getOrDefault(egg.getUniqueId(), current);
            eggLast.put(egg.getUniqueId(), current.clone());
            // Wait for the egg to clear the thrower before laying track under it.
            if (now - entry.thrownAt() < 3) continue;
            Vector path = current.toVector().subtract(last.toVector());
            int steps = Math.max(1, (int) Math.ceil(path.length() / 0.5));
            for (int step = 1; step <= steps; step++) {
                Location point = last.clone().add(path.clone().multiply(step / (double) steps));
                Block block = game.world().getBlockAt(point.getBlockX(), point.getBlockY() - 2, point.getBlockZ());
                if (game.placeWool(block, owner) && game.random().nextInt(3) == 0) {
                    game.world().playSound(block.getLocation(), Sound.BLOCK_WOOL_PLACE, 0.6f, 1.2f);
                }
            }
        }
    }
}
