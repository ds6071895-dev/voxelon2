package dev.autobox.splat;

import org.bukkit.Material;

import java.util.Arrays;

/**
 * Base items are plain vanilla items tagged with a custom_model_data string. The pack's
 * item definitions select the Splatoon model for that string and fall back to the vanilla
 * model otherwise, so players without the pack (or on Bedrock) see ordinary items.
 */
public enum Weapon {
    // ---------------------------------------------------------------- mains
    SPLATTERSHOT(Kind.MAIN, "Splattershot", Material.IRON_HOE, "splattershot", 1.2, 3, 7, 170,
            new Ballistics(2.1, 2.2, 1, 0, 1, 6, 14, 0.5, 5),
            "Rapid ink shots: three hits splat. Hold right-click or tap left-click."),
    ROLLER(Kind.MAIN, "Splat Roller", Material.IRON_SHOVEL, "splat_roller", 9, 14, 7, 240,
            new Ballistics(1.05, 2.0, 5, 6, 0, 3, 9, 0.3, 2),
            "Walk to roll a wide strip and flatten foes. Click to fling a close-range splash."),
    CHARGER(Kind.MAIN, "Splat Charger", Material.BLAZE_ROD, "splat_charger", 18, 8, 20, 150, null,
            "Hold right-click to charge, let go to fire. Only a full charge splats in one hit."),
    DUALIES(Kind.MAIN, "Splat Dualies", Material.SHEARS, "splat_dualies", 1.0, 2, 5, 180,
            new Ballistics(2.0, 3.0, 1, 0, 1, 5, 12, 0.5, 4),
            "Fast twin shots: four hits splat. Press Q (drop) to dodge roll, then shoot steadier."),
    SLOSHER(Kind.MAIN, "Slosher", Material.BUCKET, "slosher", 7, 14, 10, 190,
            new Ballistics(0.95, 1.2, 3, 0, 1, 8, 16, 0.6, 0),
            "Fling a heavy arc of ink that sails over walls. Two full hits splat."),
    BLASTER(Kind.MAIN, "Blaster", Material.NETHERITE_HOE, "blaster", 9, 16, 20, 200,
            new Ballistics(1.5, 0.8, 1, 0, 2, 6, 6, 1, 6),
            "A direct hit splats. Shots burst in mid-air, splashing anyone nearby."),
    INKBRUSH(Kind.MAIN, "Inkbrush", Material.BRUSH, "inkbrush", 2, 5, 4, 260,
            new Ballistics(0.9, 4.0, 3, 9, 0, 2, 6, 0.4, 1),
            "Hold it and run to paint a fast strip. Click to flick short splashes."),

    // ---------------------------------------------------------------- subs
    BOMB(Kind.SUB, "Splat Bomb", Material.CLAY_BALL, "splat_bomb", 55, 20, 20, 0,
            new Ballistics(0.9, 0, 1, 0, 0, 0, 0, 1, 0),
            "Throw it: bursts into a big splash after 1.5 seconds."),
    BURST_BOMB(Kind.SUB, "Burst Bomb", Material.SLIME_BALL, "burst_bomb", 40, 10, 12, 0,
            new Ballistics(1.0, 0, 1, 0, 0, 0, 0, 1, 0),
            "Bursts the moment it touches anything. Great for finishing foes."),
    SUCTION_BOMB(Kind.SUB, "Suction Bomb", Material.MAGMA_CREAM, "suction_bomb", 70, 30, 20, 0,
            new Ballistics(0.85, 0, 1, 0, 0, 0, 0, 1, 0),
            "Sticks where it lands, then blows up in a huge splash."),
    SPRINKLER(Kind.SUB, "Sprinkler", Material.PRISMARINE_SHARD, "sprinkler", 60, 20, 1.5, 0,
            new Ballistics(0.7, 0, 1, 0, 0, 0, 0, 1, 0),
            "Throw it down: it sprays ink around itself for 20 seconds."),
    BEAKON(Kind.SUB, "Squid Beakon", Material.ECHO_SHARD, "squid_beakon", 75, 20, 0, 0,
            new Ballistics(0.7, 0, 1, 0, 0, 0, 0, 1, 0),
            "Place a beacon your team can Super Jump to."),

    // ---------------------------------------------------------------- specials
    SPLASHDOWN(Kind.SPECIAL, "Splashdown", Material.HEART_OF_THE_SEA, "splashdown", 0, 20, 20, 0, null,
            "Special! Click (or press F) to leap up and slam down in a huge ink explosion."),
    TRIZOOKA(Kind.SPECIAL, "Trizooka", Material.FIREWORK_STAR, "trizooka", 0, 14, 20, 0,
            new Ballistics(2.2, 0.3, 1, 0, 2, 30, 30, 1, 30),
            "Special! Three huge blast shots. Click to fire."),
    BUBBLER(Kind.SPECIAL, "Big Bubbler", Material.GLASS_BOTTLE, "big_bubbler", 0, 20, 0, 0, null,
            "Special! A dome that blocks every enemy shot for 8 seconds."),
    INK_STORM(Kind.SPECIAL, "Ink Storm", Material.PHANTOM_MEMBRANE, "ink_storm", 0, 20, 1.5, 0, null,
            "Special! Throw a rain cloud that drifts forward, inking and chipping foes."),
    BOOYAH(Kind.SPECIAL, "Booyah Bomb", Material.NETHER_STAR, "booyah_bomb", 0, 20, 30, 0,
            new Ballistics(1.0, 0, 1, 0, 0, 0, 0, 1, 0),
            "Special! Float up, charge, and hurl a gigantic bomb."),

    // ---------------------------------------------------------------- objectives and utility
    RAINMAKER(Kind.OBJECTIVE, "Rainmaker", Material.GOLDEN_HOE, "rainmaker", 0, 20, 20, 0,
            new Ballistics(1.3, 0.5, 1, 0, 3, 0, 0, 1, 0),
            "Hold to charge, release to launch a big blast. Take it to their pedestal!"),
    CLAM(Kind.OBJECTIVE, "Clam", Material.NAUTILUS_SHELL, "clam", 0, 6, 0, 0,
            new Ballistics(0.9, 0, 1, 0, 0, 0, 0, 1, 0),
            "Click to throw a clam into the enemy basket (only while it's open)."),
    POWER_CLAM(Kind.OBJECTIVE, "Power Clam", Material.SHULKER_SHELL, "power_clam", 0, 10, 0, 0,
            new Ballistics(0.95, 0, 1, 0, 0, 0, 0, 1, 0),
            "Click to throw it into the enemy basket and break the barrier!"),
    SUPER_JUMP(Kind.UTILITY, "Super Jump", Material.FEATHER, "super_jump", 0, 0, 0, 0, null,
            "Click to Super Jump to a teammate, a Squid Beakon or your spawn."),
    LOCKER(Kind.UTILITY, "Locker", Material.BOOK, "locker", 0, 0, 0, 0, null,
            "Click to see every kit.");

    public enum Kind { MAIN, SUB, SPECIAL, OBJECTIVE, UTILITY }

    /**
     * Snowball-based weapons: launch speed, aim spread in degrees, pellets fanned pelletAngle
     * degrees apart, block splash radius, damage that is full until fullUntil ticks of flight
     * then fades linearly to minFactor at fadeUntil, and straightTicks of flight before gravity.
     */
    public record Ballistics(double speed, double spread, int pellets, double pelletAngle, int splash,
                             int fullUntil, int fadeUntil, double minFactor, int straightTicks) {}

    public static final Weapon[] MAIN = Arrays.stream(values()).filter(w -> w.kind == Kind.MAIN).toArray(Weapon[]::new);
    /** Ink projectiles are snowballs whose item model is swapped per team. */
    public static final Material PROJECTILE = Material.SNOWBALL;
    public static final int BOMB_FUSE = 30, SUCTION_FUSE = 40;
    /** Rolling costs ink per block travelled, flattens only above walking pace, and splats on contact. */
    public static final double ROLL_INK = 1.4, FLATTEN_SPEED = 0.12, ROLL_DAMAGE = 20, BRUSH_INK = 0.5, BRUSH_SPEED = 0.45;
    /** Charger: ticks to full charge, click gap treated as a release (Bedrock/left-click), and full-charge hold before auto-fire. */
    public static final int CHARGE_TICKS = 24, CHARGE_RELEASE = 6, CHARGE_HOLD = 40;
    public static final double CHARGER_RANGE = 40, CHARGER_MIN_RANGE = 12, CHARGER_MIN_INK = 6, CHARGER_MIN_DAMAGE = 4, CHARGER_PARTIAL_DAMAGE = 10;
    /** Splashdown: rise ticks, then a slam that splats within the inner radius and chips within the outer one. */
    public static final int SPLASHDOWN_RISE = 10, SPLASHDOWN_PAINT = 4;
    public static final double SPLASHDOWN_INNER = 3, SPLASHDOWN_OUTER = 5, SPLASHDOWN_CHIP = 10;
    /** Dualies dodge roll: ink, speed, rolls before a cooldown, and the steadier "turret" window after rolling. */
    public static final double DODGE_INK = 8, DODGE_SPEED = 1.05;
    public static final int DODGE_ROLLS = 2, DODGE_COOLDOWN = 24, DODGE_TURRET = 20;
    /** Blaster: flight ticks before the mid-air burst, burst radius and splash damage. */
    public static final int BLASTER_BURST_AGE = 7;
    public static final double BLASTER_RADIUS = 2.2, BLASTER_SPLASH = 7;
    /** Slosher: the lead blob hits hard, the trailing ones chip. */
    public static final double SLOSH_TRAIL_DAMAGE = 4;
    /** Specials. */
    public static final int TRIZOOKA_SHOTS = 3, TRIZOOKA_TICKS = 160, BUBBLER_TICKS = 160, STORM_TICKS = 140, BOOYAH_RISE = 30,
            SPRINKLER_TICKS = 400, BEAKON_TICKS = 1200, BEAKONS = 2;
    public static final double BUBBLER_RADIUS = 3.5, STORM_RADIUS = 3.2, TRIZOOKA_RADIUS = 2.5, BOOYAH_RADIUS = 5.5;
    /** Rainmaker: charge ticks and blast. */
    public static final int RAINMAKER_CHARGE = 20;
    public static final double RAINMAKER_RADIUS = 3;

    public final Kind kind;
    public final String title;
    public final Material base;
    public final String model;
    public final double ink;
    public final int cooldown;
    public final double damage;
    /** Inked turf needed to fill the special gauge; zero for everything but mains. */
    public final int specialTurf;
    public final Ballistics ballistics;
    public final String help;

    Weapon(Kind kind, String title, Material base, String model, double ink, int cooldown, double damage, int specialTurf,
           Ballistics ballistics, String help) {
        this.kind = kind; this.title = title; this.base = base; this.model = model; this.ink = ink; this.cooldown = cooldown;
        this.damage = damage; this.specialTurf = specialTurf; this.ballistics = ballistics; this.help = help;
    }

    public boolean charges() { return this == CHARGER || this == RAINMAKER; }

    public static String inkModel(SplatRules.Team team) { return "ink_" + team.name().toLowerCase(java.util.Locale.ROOT); }
}
