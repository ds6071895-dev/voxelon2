package dev.autobox.splat;

import dev.autobox.splat.SplatArena.Pos;
import dev.autobox.splat.SplatRules.Team;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;

import java.util.EnumMap;
import java.util.List;
import java.util.Set;

/** Splat Zones: hold 70% of the centre zone to count down; losing it costs a penalty. */
final class ZonesObjective implements Objective {
    private final SplatGame g;
    private final Set<Pos> zone;
    private final EnumMap<Team, Double> count = new EnumMap<>(Team.class), penalty = new EnumMap<>(Team.class);
    private final EnumMap<Team, Integer> inked = new EnumMap<>(Team.class);
    private final int minX, maxX, minZ, maxZ, topY;
    private Team holder;
    private double scoredThisHold;
    private ArmorStand label;

    ZonesObjective(SplatGame g) {
        this.g = g;
        this.zone = g.map.anchors().zone();
        minX = zone.stream().mapToInt(Pos::x).min().orElse(0);
        maxX = zone.stream().mapToInt(Pos::x).max().orElse(0);
        minZ = zone.stream().mapToInt(Pos::z).min().orElse(0);
        maxZ = zone.stream().mapToInt(Pos::z).max().orElse(0);
        topY = zone.stream().mapToInt(Pos::y).max().orElse(SplatArena.FLOOR);
        for (Team team : Team.values()) { count.put(team, RankedRules.START); penalty.put(team, 0.0); inked.put(team, 0); }
    }

    @Override
    public void start() {
        Location at = new Location(g.world, g.map.offsetX() + 0.5, topY + 3.2, 0.5);
        label = g.world.spawn(at, ArmorStand.class, s -> {
            s.setInvisible(true); s.setMarker(true); s.setGravity(false); s.setPersistent(false);
            s.setCustomNameVisible(true);
        });
        g.track(label);
        relabel();
    }

    @Override
    public void onPaint(Pos pos, Team before, Team after) {
        if (!zone.contains(pos)) return;
        if (before != null) inked.merge(before, -1, Integer::sum);
        if (after != null) inked.merge(after, 1, Integer::sum);
    }

    @Override
    public void tick() {
        Team now = RankedRules.zoneControl(holder, inked.get(Team.ORANGE), inked.get(Team.BLUE), zone.size());
        if (now != holder) {
            Team lost = holder;
            if (lost != null) {
                penalty.merge(lost, RankedRules.penaltyAfterLoss(scoredThisHold), Double::sum);
            }
            holder = now;
            scoredThisHold = 0;
            if (now != null) g.callout(now, "We've taken the zone!", "They've taken the zone!", now.title + " took the zone!");
            else g.callout(lost, "Our zone was lost!", "The zone is neutral!", "The zone is neutral!");
            relabel();
        }
        if (holder != null) {
            double owed = penalty.get(holder), rate = RankedRules.ZONE_RATE * g.outnumbered(holder);
            if (owed > 0) penalty.put(holder, Math.max(0, owed - rate));
            else {
                count.put(holder, Math.max(0, count.get(holder) - rate));
                scoredThisHold += rate;
            }
            if (g.elapsed % 20 == 0) {
                for (Player p : g.world.getPlayers()) {
                    Inkling in = g.players.get(p.getUniqueId());
                    if (in != null && in.team == holder) p.playSound(p, Sound.BLOCK_NOTE_BLOCK_HAT, 0.25f, 1.8f);
                }
                relabel();
            }
        }
        if (g.elapsed % 10 == 0) outline();
    }

    private void relabel() {
        if (label == null) return;
        int share = holder == null ? 0 : (int) Math.round(100.0 * inked.get(holder) / Math.max(1, zone.size()));
        label.customName(holder == null
                ? Component.text("◆ SPLAT ZONE ◆ neutral", NamedTextColor.WHITE, TextDecoration.BOLD)
                : Component.text("◆ SPLAT ZONE ◆ " + holder.title + " " + share + "%", holder.text, TextDecoration.BOLD));
    }

    private void outline() {
        Particle.DustOptions dust = new Particle.DustOptions(holder == null ? Color.WHITE : holder.color, 1.4f);
        double y = SplatArena.FLOOR + 1.15;
        for (int x = minX; x <= maxX + 1; x++) {
            g.world.spawnParticle(Particle.DUST, x, y, minZ, 1, 0, 0, 0, 0, dust);
            g.world.spawnParticle(Particle.DUST, x, y, maxZ + 1, 1, 0, 0, 0, 0, dust);
        }
        for (int z = minZ; z <= maxZ + 1; z++) {
            g.world.spawnParticle(Particle.DUST, minX, y, z, 1, 0, 0, 0, 0, dust);
            g.world.spawnParticle(Particle.DUST, maxX + 1, y, z, 1, 0, 0, 0, 0, dust);
        }
    }

    @Override
    public double count(Team team) { return count.get(team); }

    @Override
    public double penalty(Team team) { return penalty.get(team); }

    @Override
    public Team advantage() { return holder; }

    @Override
    public Team winner() { return RankedRules.winner(count.get(Team.ORANGE), count.get(Team.BLUE)); }

    @Override
    public void sidebar(List<String> lines) {
        String state = holder == null ? "§7neutral" : (holder == Team.ORANGE ? "§6" : "§9") + holder.title;
        lines.add("§fZone: " + state);
        lines.add("§6" + pct(Team.ORANGE) + "% §7/ §9" + pct(Team.BLUE) + "% §7(70% takes it)");
    }

    private int pct(Team team) { return (int) Math.round(100.0 * inked.get(team) / Math.max(1, zone.size())); }

    @Override
    public String hint(Inkling in) {
        if (holder == in.team) return "Zone ours " + pct(in.team) + "%";
        return "Zone " + pct(in.team) + "%/70%";
    }

    @Override
    public void cleanup() {
        if (label != null) label.remove();
    }
}
