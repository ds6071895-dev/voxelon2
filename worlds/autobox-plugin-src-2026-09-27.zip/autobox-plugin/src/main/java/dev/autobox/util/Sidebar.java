package dev.autobox.util;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * A sidebar that is created once and then updated in place. Swapping in a brand-new scoreboard makes
 * the client tear down and rebuild the objective, every score and every team (and Geyser re-translate
 * it all for Bedrock), which flickers and costs packets. Here only the lines that changed are sent.
 */
public final class Sidebar {

    private static final int MAX_LINES = 15;

    private final Scoreboard board;
    private final Objective objective;
    private Component title;
    private List<String> shown = List.of();
    private int[] shownScores = new int[0];

    public Sidebar(String name, Component title) {
        this.board = Bukkit.getScoreboardManager().getNewScoreboard();
        this.objective = board.registerNewObjective(name, Criteria.DUMMY, title);
        this.objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        this.title = title;
    }

    public Scoreboard board() {
        return board;
    }

    public void title(Component title) {
        if (!title.equals(this.title)) {
            this.title = title;
            objective.displayName(title);
        }
    }

    /** Shows these lines top to bottom (at most 15). Repeated lines are made unique with a reset code. */
    public void lines(List<String> lines) {
        lines(lines, -1);
    }

    /** As {@link #lines(List)}, numbering the top line {@code topScore} (or the line count if negative). */
    public void lines(List<String> lines, int topScore) {
        int count = Math.min(lines.size(), MAX_LINES);
        int top = topScore < 0 ? count : topScore;
        int[] scores = new int[count];
        for (int i = 0; i < count; i++) {
            scores[i] = top - i;
        }
        set(lines, scores);
    }

    public void set(List<String> lines, List<Integer> scores) {
        set(lines, scores.stream().mapToInt(Integer::intValue).toArray());
    }

    /**
     * Shows {@code lines[i]} with score {@code scores[i]} (the client sorts by score, highest on top).
     * Repeated lines are made unique with a reset code; lines past {@code scores.length} or 15 are dropped.
     */
    public void set(List<String> lines, int[] scores) {
        int count = Math.min(Math.min(lines.size(), scores.length), MAX_LINES);
        List<String> next = new ArrayList<>(count);
        Set<String> used = new HashSet<>();
        for (int i = 0; i < count; i++) {
            String line = lines.get(i);
            while (!used.add(line)) {
                line += "§r";
            }
            next.add(line);
        }
        int[] values = java.util.Arrays.copyOf(scores, count);
        if (next.equals(shown) && java.util.Arrays.equals(values, shownScores)) {
            return;
        }
        for (String old : shown) {
            if (!used.contains(old)) {
                board.resetScores(old);
            }
        }
        for (int i = 0; i < count; i++) {
            Score score = objective.getScore(next.get(i));
            if (!score.isScoreSet() || score.getScore() != values[i]) {
                score.setScore(values[i]);
            }
        }
        shown = next;
        shownScores = values;
    }

    /** The team with this name on the sidebar's board, registered the first time it is asked for. */
    public Team team(String name) {
        Team team = board.getTeam(name);
        return team != null ? team : board.registerNewTeam(name);
    }

    public void show(Player player) {
        if (player.getScoreboard() != board) {
            player.setScoreboard(board);
        }
    }
}
