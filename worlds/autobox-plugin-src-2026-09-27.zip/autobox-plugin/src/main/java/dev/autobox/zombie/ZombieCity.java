package dev.autobox.zombie;

import org.bukkit.Material;
import java.util.*;

/** Quarantine City: an enclosed street grid with four open ruins and a central extraction plaza. */
public final class ZombieCity {
    public static final int FLOOR = 80, HALF = 40;
    public record Pos(int x, int y, int z) {}
    private final Map<Pos, Material> blocks = new LinkedHashMap<>();
    public static final List<Pos> GATES = List.of(new Pos(0,81,-35), new Pos(35,81,0),
            new Pos(0,81,35), new Pos(-35,81,0), new Pos(-30,81,-30), new Pos(30,81,30),
            new Pos(-30,81,30), new Pos(30,81,-30));
    public ZombieCity() {
        for (int x=-HALF;x<=HALF;x++) for (int z=-HALF;z<=HALF;z++) {
            boolean street = Math.abs(x)<=5 || Math.abs(z)<=5;
            put(x, FLOOR, z, street ? Material.GRAY_CONCRETE : (Math.floorMod(x*31+z*17,9)==0
                    ? Material.MOSSY_STONE_BRICKS : Material.STONE_BRICKS));
            if (street && ((x==0 && Math.abs(z)%6<3) || (z==0 && Math.abs(x)%6<3)))
                put(x,FLOOR,z,Material.YELLOW_CONCRETE);
            if (Math.abs(x)==HALF || Math.abs(z)==HALF)
                for (int y=81;y<=87;y++) put(x,y,z,y>=85?Material.IRON_BARS:Material.DEEPSLATE_BRICKS);
        }
        for (int x=-5;x<=5;x++) for(int z=-5;z<=5;z++) put(x,80,z,Material.SMOOTH_QUARTZ);
        for (int i=-4;i<=4;i++) { put(i,80,0,Material.LIME_CONCRETE); put(0,80,i,Material.LIME_CONCRETE); }
        ruin(-23,-23,Material.RED_TERRACOTTA); ruin(12,-23,Material.CYAN_TERRACOTTA);
        ruin(-23,12,Material.BROWN_TERRACOTTA); ruin(12,12,Material.WHITE_TERRACOTTA);
        // Raised street lamps, clear streets and two-door ruins prevent dead ends.
        for(int x:new int[]{-7,7}) for(int z:new int[]{-30,-8,8,30}) {
            for(int y=81;y<85;y++) put(x,y,z,Material.POLISHED_BLACKSTONE_WALL);
            put(x,85,z,Material.SEA_LANTERN);
        }
        for (Pos gate:GATES) {
            for(int dx=-2;dx<=2;dx++) put(gate.x+dx,80,gate.z,Material.CRYING_OBSIDIAN);
            for(int y=81;y<=84;y++) for(int dx:new int[]{-3,3}) put(gate.x+dx,y,gate.z,Material.OBSIDIAN);
            for(int dx=-3;dx<=3;dx++) put(gate.x+dx,85,gate.z,Material.PURPLE_STAINED_GLASS);
        }
        // Graveyard, abandoned ambulance and supply point, with walkable routes around each.
        for(int z=12;z<=26;z+=7) for(int x=-35;x<=-29;x+=6) {
            put(x,81,z,Material.COBBLESTONE_WALL); put(x,80,z+1,Material.PODZOL);
        }
        for(int x=9;x<=14;x++) for(int z=-3;z<=-1;z++) {
            put(x,81,z,Material.BLACK_CONCRETE); put(x,82,z,Material.WHITE_CONCRETE);
            if(x<12) put(x,83,z,Material.WHITE_CONCRETE);
        }
        put(10,83,-2,Material.RED_CONCRETE); put(13,83,-2,Material.LIGHT_BLUE_STAINED_GLASS);
        put(-4,81,-5,Material.SMITHING_TABLE); put(4,81,-5,Material.BARREL);
    }
    private void ruin(int x,int z,Material wall) {
        for(int dx=0;dx<=11;dx++) for(int dz=0;dz<=11;dz++) {
            boolean edge=dx==0||dz==0||dx==11||dz==11;
            // Wide entrances on all four sides, no enclosed rooms or inaccessible rooftops.
            boolean door=((dx==0||dx==11)&&dz>=4&&dz<=7)||((dz==0||dz==11)&&dx>=4&&dx<=7);
            if(edge && !door) for(int y=81;y<=86;y++)
                put(x+dx,y,z+dz,y==83 && (dx%3==1||dz%3==1)?Material.GLASS_PANE:wall);
            if(!edge) put(x+dx,80,z+dz,Material.CRACKED_STONE_BRICKS);
        }
        put(x+2,81,z+2,Material.BOOKSHELF); put(x+9,81,z+9,Material.BARREL);
        put(x+2,82,z+2,Material.SOUL_LANTERN);
    }
    private void put(int x,int y,int z,Material type) { blocks.put(new Pos(x,y,z),type); }
    public Material at(int x,int y,int z) { return blocks.getOrDefault(new Pos(x,y,z),Material.AIR); }
    public Map<Pos,Material> blocks() { return Collections.unmodifiableMap(blocks); }
    public boolean walkable(int x,int z) { return at(x,80,z)!=Material.AIR && at(x,81,z)==Material.AIR && at(x,82,z)==Material.AIR; }
}
