package dev.autobox.sumo;

import dev.autobox.util.Fx;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Timed arena events: what each one does while it runs, and cleaning up after it. */
final class SumoEvents {
    private static final int METEOR_FALL_TICKS = 40;
    private static final int ANVIL_FALL_TICKS = 30;
    private static final int GALE_GUST_TICKS = 40;
    private static final int SHUFFLE_DELAY = 60;

    private record Meteor(Location target, int impactTick, boolean anvil, BlockDisplay display) { }

    private final BlockSumoGame game;
    private final List<Meteor> meteors = new ArrayList<>();
    private final Map<Location, Material> frozen = new HashMap<>();
    private final Map<UUID, Integer> tornadoReady = new HashMap<>();
    private Vector galeDirection = new Vector(1, 0, 0);
    private Location tornado;
    private Location tornadoTarget;
    private int startedAt;

    SumoEvents(BlockSumoGame game) {
        this.game = game;
    }

    String description(SumoRules.Event event) {
        return switch (event) {
            case DOUBLE_CHARGE -> "Spheres capture twice as fast for 12 seconds!";
            case GALE -> "Wind gusts blow everyone " + galeName() + " every 2 seconds! Sneak to brace.";
            case SKY_RUSH -> "Vaults recharge in 4 seconds for 12 seconds!";
            case METEOR_SHOWER -> "Meteors are falling! Get out of the burning rings!";
            case POWER_SURGE -> "Melee knockback +20% for 12 seconds!";
            case LOW_GRAVITY -> "Big jumps and slow falls for 12 seconds!";
            case ICE_AGE -> "The floor froze solid! Every hit slides.";
            case ANVIL_RAIN -> "Anvils incoming! Watch for the white rings.";
            case SHUFFLE -> "Everyone swaps places in 3 seconds!";
            case TORNADO -> "A tornado is roaming the arena. It spits you out hard!";
            default -> "";
        };
    }

    void start(SumoRules.Event event) {
        startedAt = game.ticks();
        switch (event) {
            case GALE -> {
                Vector[] directions = {new Vector(1, 0, 0), new Vector(-1, 0, 0), new Vector(0, 0, 1), new Vector(0, 0, -1)};
                galeDirection = directions[game.random().nextInt(directions.length)];
            }
            case ICE_AGE -> freeze();
            case TORNADO -> {
                tornado = randomSpot();
                tornadoTarget = randomSpot();
                tornadoReady.clear();
            }
            default -> { }
        }
    }

    void stop(SumoRules.Event event) {
        switch (event) {
            case LOW_GRAVITY -> game.forEachPlayer(player -> {
                player.removePotionEffect(PotionEffectType.SLOW_FALLING);
                player.removePotionEffect(PotionEffectType.JUMP_BOOST);
                game.restoreEffects(player);
            });
            case ICE_AGE -> thaw();
            case TORNADO -> tornado = null;
            default -> { }
        }
    }

    /** Undo everything, e.g. at round end. Falling meteors and anvils are dropped. */
    void clear() {
        thaw();
        tornado = null;
        for (Meteor meteor : meteors) {
            if (meteor.display() != null) meteor.display().remove();
        }
        meteors.clear();
    }

    void tick(SumoRules.Event event) {
        int roundTicks = game.roundTicks();
        if (event == SumoRules.Event.LOW_GRAVITY && roundTicks % 20 == 0) {
            game.forEachPlayer(player -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 30, 2, true, false, true));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 30, 0, true, false, true));
            });
        }
        if (event == SumoRules.Event.GALE) tickGale(roundTicks);
        if (event == SumoRules.Event.METEOR_SHOWER && roundTicks % 20 == 0) {
            int count = game.aliveCount() >= 4 ? 2 : 1;
            for (int i = 0; i < count; i++) drop(false);
        }
        if (event == SumoRules.Event.ANVIL_RAIN && roundTicks % 10 == 0) drop(true);
        if (event == SumoRules.Event.SHUFFLE) tickShuffle();
        if (event == SumoRules.Event.TORNADO) tickTornado();
        tickFalling();
    }

    String galeName() {
        if (galeDirection.getX() > 0) return "EAST";
        if (galeDirection.getX() < 0) return "WEST";
        return galeDirection.getZ() > 0 ? "SOUTH" : "NORTH";
    }

    private void tickGale(int roundTicks) {
        int phase = roundTicks % GALE_GUST_TICKS;
        if (phase % 5 == 0) {
            game.forEachPlayer(player -> Particle.CLOUD.builder()
                    .location(player.getLocation().add(0, 1, 0).subtract(galeDirection.clone().multiply(3)))
                    .count(0).offset(galeDirection.getX(), 0, galeDirection.getZ()).extra(0.6)
                    .receivers(player).spawn());
        }
        if (phase == GALE_GUST_TICKS - 10) {
            game.forEachPlayer(player -> player.playSound(player.getLocation(), Sound.ITEM_ELYTRA_FLYING, 0.35f, 1.6f));
        }
        if (phase != 0) return;
        game.forEachPlayer(player -> {
            boolean braced = player.isSneaking() && player.isOnGround();
            Vector velocity = player.getVelocity().add(galeDirection.clone().multiply(braced ? 0.22 : 0.62));
            if (player.isOnGround()) velocity.setY(Math.max(velocity.getY(), 0.18));
            if (game.knock(player, velocity, null)) {
                player.playSound(player.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, 0.8f, 0.9f);
            }
        });
    }

    private void drop(boolean anvil) {
        Location target = fallTarget();
        if (target == null) return;
        World world = game.world();
        BlockDisplay display = null;
        int fall = anvil ? ANVIL_FALL_TICKS : METEOR_FALL_TICKS;
        if (anvil) {
            display = world.spawn(target.clone().add(0, 16, 0), BlockDisplay.class, spawned -> {
                spawned.setBlock(Material.ANVIL.createBlockData());
                spawned.setTransformation(new Transformation(new Vector3f(-0.5f, 0, -0.5f), new Quaternionf(),
                        new Vector3f(1, 1, 1), new Quaternionf()));
                spawned.setTeleportDuration(fall - 1);
                spawned.setPersistent(false);
                spawned.addScoreboardTag(BlockSumoGame.FX_TAG);
            });
        }
        meteors.add(new Meteor(target, game.ticks() + fall, anvil, display));
        world.playSound(target, anvil ? Sound.BLOCK_ANVIL_PLACE : Sound.ITEM_FIRECHARGE_USE, 0.8f, anvil ? 0.5f : 0.6f);
    }

    private void tickFalling() {
        int ticks = game.ticks();
        for (Iterator<Meteor> iterator = meteors.iterator(); iterator.hasNext(); ) {
            Meteor meteor = iterator.next();
            int left = meteor.impactTick() - ticks;
            double radius = (meteor.anvil() ? SumoRules.ANVIL_RADIUS_TENTHS : SumoRules.METEOR_RADIUS_TENTHS) / 10.0;
            if (left > 0) {
                // The display was spawned last tick; moving it now makes the client glide it down.
                if (meteor.display() != null && left == ANVIL_FALL_TICKS - 1) {
                    meteor.display().teleport(meteor.target());
                }
                if (!meteor.anvil() && left % 2 == 0) {
                    Location head = meteor.target().clone().add(0, left * 0.55, 0);
                    Particle.FLAME.builder().location(head).count(6).offset(0.25, 0.25, 0.25).extra(0.02)
                            .receivers(64, true).spawn();
                    Particle.LARGE_SMOKE.builder().location(head.add(0, 0.6, 0)).count(2).offset(0.2, 0.3, 0.2)
                            .extra(0.01).receivers(64, true).spawn();
                }
                if (left % 5 == 0) {
                    List<Player> viewers = Fx.near(meteor.target(), 48);
                    Particle ring = meteor.anvil() ? Particle.CRIT : Particle.FLAME;
                    for (int i = 0; i < 16; i++) {
                        double angle = i * Math.PI * 2 / 16;
                        ring.builder().location(meteor.target().clone().add(Math.cos(angle) * radius,
                                0.15, Math.sin(angle) * radius)).count(1).extra(0).receivers(viewers).spawn();
                    }
                }
                continue;
            }
            iterator.remove();
            if (meteor.display() != null) meteor.display().remove();
            impact(meteor.target(), radius, meteor.anvil());
        }
    }

    private void impact(Location center, double radius, boolean anvil) {
        World world = game.world();
        if (anvil) {
            Particle.BLOCK.builder().location(center).count(24).offset(0.6, 0.2, 0.6)
                    .data(Material.ANVIL.createBlockData()).receivers(64, true).spawn();
            world.playSound(center, Sound.BLOCK_ANVIL_LAND, 1f, 0.8f);
        } else {
            Particle.EXPLOSION.builder().location(center).count(4).offset(1, 0.4, 1).receivers(64, true).spawn();
            Particle.LAVA.builder().location(center).count(14).offset(1.2, 0.2, 1.2).receivers(64, true).spawn();
            world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.8f);
        }
        int radiusTenths = anvil ? SumoRules.ANVIL_RADIUS_TENTHS : SumoRules.METEOR_RADIUS_TENTHS;
        game.forEachPlayer(player -> {
            Location location = player.getLocation();
            if (Math.abs(location.getY() - center.getY()) > 3.0) return;
            Vector push = location.toVector().subtract(center.toVector()).setY(0);
            double strength = SumoRules.meteorPush(push.length(), radiusTenths);
            if (strength <= 0) return;
            if (push.lengthSquared() < 0.01) {
                double angle = game.random().nextDouble() * Math.PI * 2;
                push = new Vector(Math.cos(angle), 0, Math.sin(angle));
            }
            game.knock(player, push.normalize().multiply(strength).setY(anvil ? 0.85 : 0.7), null);
        });
        game.breakWoolNear(center, anvil ? 1.5 : 2.5);
    }

    private Location fallTarget() {
        List<Player> targets = new ArrayList<>();
        game.forEachPlayer(player -> {
            if (!game.immune(player)) targets.add(player);
        });
        World world = game.world();
        if (!targets.isEmpty() && game.random().nextInt(10) < 6) {
            Location location = targets.get(game.random().nextInt(targets.size())).getLocation();
            // Aim at the ground under an airborne player so the warning ring sits on a surface.
            int floorY = location.getBlockY();
            for (int y = location.getBlockY() - 1; y >= location.getBlockY() - 8; y--) {
                if (world.getBlockAt(location.getBlockX(), y, location.getBlockZ()).getType().isSolid()) {
                    floorY = y + 1;
                    break;
                }
            }
            return new Location(world, location.getX(), floorY, location.getZ());
        }
        return randomSpot();
    }

    /** A random standing spot on a surviving arena block, or null. */
    private Location randomSpot() {
        List<Location> ground = new ArrayList<>(game.arenaBlocks());
        for (int attempt = 0; attempt < 16 && !ground.isEmpty(); attempt++) {
            Location block = ground.get(game.random().nextInt(ground.size()));
            if (Math.hypot(block.getX(), block.getZ()) > game.arenaRadius() - 1) continue;
            if (block.getBlock().getRelative(0, 1, 0).getType().isAir()) {
                return block.clone().add(0.5, 1, 0.5);
            }
        }
        return null;
    }

    private void freeze() {
        for (Location location : game.arenaBlocks()) {
            Block block = location.getBlock();
            Material type = block.getType();
            if (type.isAir() || type == Material.SLIME_BLOCK || type == Material.HONEY_BLOCK
                    || !block.getRelative(0, 1, 0).getType().isAir()) continue;
            frozen.put(location, type);
            block.setType(Material.PACKED_ICE, false);
        }
        game.world().playSound(new Location(game.world(), 0.5, SumoArena.BASE_Y + 6, 0.5),
                Sound.BLOCK_GLASS_BREAK, 2f, 0.5f);
    }

    private void thaw() {
        for (Map.Entry<Location, Material> entry : frozen.entrySet()) {
            Block block = entry.getKey().getBlock();
            if (block.getType() == Material.PACKED_ICE) block.setType(entry.getValue(), false);
        }
        frozen.clear();
    }

    private void tickShuffle() {
        int elapsed = game.ticks() - startedAt;
        if (elapsed < SHUFFLE_DELAY && elapsed % 20 == 0) {
            int seconds = (SHUFFLE_DELAY - elapsed) / 20;
            game.forEachPlayer(player -> {
                player.sendTitle("§d" + seconds, "§fShuffle incoming", 0, 22, 0);
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 1f, 0.8f + seconds * 0.2f);
            });
        }
        if (elapsed != SHUFFLE_DELAY) return;
        List<Player> alive = new ArrayList<>();
        game.forEachPlayer(alive::add);
        if (alive.size() < 2) return;
        java.util.Collections.shuffle(alive, game.random());
        List<Location> spots = new ArrayList<>();
        for (Player player : alive) spots.add(player.getLocation());
        for (int i = 0; i < alive.size(); i++) {
            Player player = alive.get(i);
            Location target = spots.get((i + 1) % spots.size()).clone();
            target.setYaw(player.getLocation().getYaw());
            target.setPitch(player.getLocation().getPitch());
            Vector keep = player.getVelocity();
            player.teleport(target);
            player.setVelocity(keep);
            player.setFallDistance(0);
            Particle.PORTAL.builder().location(target.clone().add(0, 1, 0)).count(30).offset(0.3, 0.6, 0.3)
                    .receivers(48, true).spawn();
            player.playSound(target, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
        }
        game.broadcast(Component.text("Shuffled!", NamedTextColor.LIGHT_PURPLE));
    }

    private void tickTornado() {
        if (tornado == null) return;
        if (tornadoTarget == null || tornado.distanceSquared(tornadoTarget) < 1) tornadoTarget = randomSpot();
        if (tornadoTarget != null) {
            Vector step = tornadoTarget.toVector().subtract(tornado.toVector());
            if (step.lengthSquared() > 0.01) tornado.add(step.normalize().multiply(0.11));
        }
        int ticks = game.ticks();
        if (ticks % 2 == 0) {
            List<Player> viewers = Fx.near(tornado, 64);
            double spin = ticks * 0.35;
            for (int i = 0; i < 14; i++) {
                double height = i * 0.45;
                double radius = 0.4 + height * 0.28;
                double angle = spin + i * 0.9;
                Particle.CLOUD.builder().location(tornado.clone().add(Math.cos(angle) * radius, height,
                        Math.sin(angle) * radius)).count(1).extra(0).receivers(viewers).spawn();
            }
        }
        if (ticks % 20 == 0) game.world().playSound(tornado, Sound.ITEM_ELYTRA_FLYING, 0.6f, 0.7f);
        game.forEachPlayer(player -> {
            Location location = player.getLocation();
            Vector offset = location.toVector().subtract(tornado.toVector());
            double dy = offset.getY();
            offset.setY(0);
            double distance = offset.length();
            if (distance > 4.5 || dy < -1.5 || dy > 6) return;
            UUID id = player.getUniqueId();
            if (distance < 1.3 && tornadoReady.getOrDefault(id, 0) <= ticks) {
                Vector out = distance < 0.05 ? new Vector(1, 0, 0) : offset.clone().normalize();
                if (game.knock(player, out.multiply(1.5).setY(1.05), null)) {
                    tornadoReady.put(id, ticks + 30);
                    player.playSound(location, Sound.ENTITY_BREEZE_WIND_BURST, 1f, 0.6f);
                }
                return;
            }
            if (game.immune(player) || distance < 0.05) return;
            Vector inward = offset.clone().normalize().multiply(-0.05);
            Vector tangent = new Vector(-offset.getZ(), 0, offset.getX()).normalize().multiply(0.09);
            Vector velocity = player.getVelocity().add(inward).add(tangent);
            velocity.setY(Math.min(0.5, velocity.getY() + 0.03));
            player.setVelocity(velocity);
        });
    }
}
