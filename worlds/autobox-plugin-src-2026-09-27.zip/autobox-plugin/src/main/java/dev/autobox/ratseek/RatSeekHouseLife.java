package dev.autobox.ratseek;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.Switch;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Cat;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/** The manor fights back: a house cat and droppable chandeliers. */
final class RatSeekHouseLife {
    private static final String TAG = "ratseek_house";
    private static final int CHANDELIER_WARNING = 20;
    private static final int CHANDELIER_REHANG = 900;
    private static final int CAT_RANGE = 10;
    private final RatSeekGame game;
    private final World world;
    private final NamespacedKey key;
    private final Random random = new Random();

    // Blueprint copies, filled in by build().
    private final List<RatSeekHouse.Pos> chandelierLevers = new ArrayList<>();
    private final List<RatSeekHouse.Pos> chandelierHangs = new ArrayList<>();
    private final List<Location> patrolPoints = new ArrayList<>();

    private final List<Entity> entities = new ArrayList<>();
    private final Chandelier[] chandeliers = new Chandelier[4];

    private Cat cat;
    private int catNap;
    private Location catDistraction;
    private int catDistractionTicks;
    private int catPounces;

    private static final class Chandelier {
        final List<BlockDisplay> parts = new ArrayList<>();
        Location hang;
        UUID puller;
        int warning;
        int rehang;
    }

    RatSeekHouseLife(RatSeekGame game, World world, NamespacedKey key) {
        this.game = game;
        this.world = world;
        this.key = key;
    }

    /** Reads the blueprint and orients the floor levers; call after the house blocks are placed. */
    void build(RatSeekHouse house, List<Location> ratSpawns) {
        chandelierLevers.clear();
        chandelierLevers.addAll(house.chandelierLevers);
        chandelierHangs.clear();
        chandelierHangs.addAll(house.chandeliers);
        patrolPoints.clear();
        patrolPoints.addAll(ratSpawns);
        for (RatSeekHouse.Pos lever : chandelierLevers) {
            orientLever(lever, false);
        }
    }

    private void orientLever(RatSeekHouse.Pos pos, boolean powered) {
        Block block = world.getBlockAt(pos.x(), pos.y(), pos.z());
        if (block.getBlockData() instanceof Switch lever) {
            lever.setAttachedFace(org.bukkit.block.data.FaceAttachable.AttachedFace.FLOOR);
            lever.setFacing(pos.x() < 0 ? org.bukkit.block.BlockFace.EAST : org.bukkit.block.BlockFace.WEST);
            lever.setPowered(powered);
            block.setBlockData(lever, false);
        }
    }

    /** Called when the hunt begins. */
    void startHunt(RatSeekSettings settings) {
        if (settings.chandeliers) {
            for (int i = 0; i < chandelierHangs.size() && i < chandeliers.length; i++) {
                chandeliers[i] = hangChandelier(chandelierHangs.get(i));
            }
        }
        if (settings.cat != RatSeekSettings.CatMode.OFF) {
            spawnCat();
        }
    }

    // ------------------------------------------------------------------ tick

    void tick(int ticks, RatSeekSettings settings) {
        tickChandeliers();
        if (ticks % 10 == 0) {
            tickCat(settings);
        }
    }

    // ------------------------------------------------------------------ interactions

    /** Handles a right-click on a manor lever; returns true if the block was one. */
    boolean useLever(Player player, Block block, RatSeekSettings settings, boolean isHuman, boolean isFreeRat,
                     boolean hunting) {
        RatSeekHouse.Pos pos = new RatSeekHouse.Pos(block.getX(), block.getY(), block.getZ());
        int rope = chandelierLevers.indexOf(pos);
        if (rope >= 0) {
            Chandelier chandelier = rope < chandeliers.length ? chandeliers[rope] : null;
            if (!settings.chandeliers || !hunting || chandelier == null) {
                player.sendActionBar(Component.text("The chandelier rope is tied off.", NamedTextColor.GRAY));
            } else if (!isFreeRat) {
                player.sendActionBar(Component.text("Only a rat can chew through the rope.", NamedTextColor.GRAY));
            } else if (chandelier.warning > 0 || chandelier.rehang > 0) {
                player.sendActionBar(Component.text("That chandelier is already down.", NamedTextColor.GRAY));
            } else {
                chandelier.puller = player.getUniqueId();
                chandelier.warning = CHANDELIER_WARNING;
                orientLever(pos, true);
                game.chandelierFalling(chandelier.hang.clone().add(0, -4, 0), CHANDELIER_WARNING, player.getLocation());
                world.playSound(chandelier.hang, Sound.BLOCK_CHAIN_BREAK, 2f, 0.6f);
                world.playSound(chandelier.hang, Sound.ENTITY_IRON_GOLEM_DAMAGE, 1.2f, 0.5f);
                player.sendActionBar(Component.text("The rope snaps...", NamedTextColor.GOLD));
            }
            return true;
        }
        return false;
    }

    /** A rat's squeak lures the cat towards the noise. */
    void distractCat(Location noise) {
        if (cat == null || !cat.isValid() || catNap > 0 || cat.getLocation().distanceSquared(noise) > 400) {
            return;
        }
        catDistraction = noise.clone();
        catDistractionTicks = 60;
    }

    // ------------------------------------------------------------------ chandeliers

    private Chandelier hangChandelier(RatSeekHouse.Pos hang) {
        Chandelier chandelier = new Chandelier();
        chandelier.hang = new Location(world, hang.x() + 0.5, hang.y(), hang.z() + 0.5);
        spawnPart(chandelier, Material.IRON_CHAIN, new Vector3f(-0.1f, 0.3f, -0.1f), new Vector3f(0.2f, 0.7f, 0.2f));
        spawnPart(chandelier, Material.GOLD_BLOCK, new Vector3f(-0.8f, 0.1f, -0.8f), new Vector3f(1.6f, 0.2f, 1.6f));
        for (float[] corner : new float[][]{{-0.75f, -0.75f}, {0.4f, -0.75f}, {-0.75f, 0.4f}, {0.4f, 0.4f}}) {
            spawnPart(chandelier, Material.LANTERN, new Vector3f(corner[0], -0.3f, corner[1]),
                    new Vector3f(0.35f, 0.4f, 0.35f));
        }
        return chandelier;
    }

    private void spawnPart(Chandelier chandelier, Material material, Vector3f offset, Vector3f size) {
        BlockDisplay part = world.spawn(chandelier.hang, BlockDisplay.class, display -> {
            display.setBlock(material.createBlockData());
            display.setTransformation(new Transformation(offset, new AxisAngle4f(), size, new AxisAngle4f()));
            display.setBrightness(new Display.Brightness(15, 15));
            display.setPersistent(false);
            display.getPersistentDataContainer().set(key, PersistentDataType.STRING, TAG);
        });
        chandelier.parts.add(part);
        entities.add(part);
    }

    private void tickChandeliers() {
        for (int i = 0; i < chandeliers.length; i++) {
            Chandelier chandelier = chandeliers[i];
            if (chandelier == null) {
                continue;
            }
            if (chandelier.warning > 0) {
                chandelier.warning--;
                world.spawnParticle(Particle.FALLING_DUST, chandelier.hang.clone().add(0, -0.4, 0), 3, 0.7, 0, 0.7, 0,
                        Material.GRAVEL.createBlockData());
                if (chandelier.warning == 6) {
                    for (BlockDisplay part : chandelier.parts) {
                        Transformation current = part.getTransformation();
                        part.setInterpolationDelay(0);
                        part.setInterpolationDuration(6);
                        part.setTransformation(new Transformation(new Vector3f(current.getTranslation()).add(0, -3.6f, 0),
                                current.getLeftRotation(), current.getScale(), current.getRightRotation()));
                    }
                }
                if (chandelier.warning == 0) {
                    crash(i, chandelier);
                }
            } else if (chandelier.rehang > 0 && --chandelier.rehang == 0) {
                for (BlockDisplay part : chandelier.parts) {
                    Transformation current = part.getTransformation();
                    part.setInterpolationDelay(0);
                    part.setInterpolationDuration(20);
                    part.setTransformation(new Transformation(new Vector3f(current.getTranslation()).add(0, 3.6f, 0),
                            current.getLeftRotation(), current.getScale(), current.getRightRotation()));
                }
                if (i < chandelierLevers.size()) {
                    orientLever(chandelierLevers.get(i), false);
                }
                world.playSound(chandelier.hang, Sound.BLOCK_CHAIN_PLACE, 1.2f, 0.8f);
            }
        }
    }

    private void crash(int index, Chandelier chandelier) {
        chandelier.rehang = CHANDELIER_REHANG;
        Location floor = chandelier.hang.clone().add(0, -4, 0);
        world.playSound(floor, Sound.BLOCK_ANVIL_LAND, 2f, 0.7f);
        world.playSound(floor, Sound.BLOCK_GLASS_BREAK, 1.6f, 0.8f);
        world.spawnParticle(Particle.EXPLOSION, floor.clone().add(0, 0.3, 0), 2, 0.5, 0.1, 0.5, 0);
        world.spawnParticle(Particle.BLOCK, floor.clone().add(0, 0.3, 0), 40, 1.2, 0.2, 1.2, 0.1,
                Material.GOLD_BLOCK.createBlockData());
        int hits = 0;
        for (Player human : game.humanPlayers()) {
            Location at = human.getLocation();
            if (at.getWorld() != world || Math.abs(at.getY() - floor.getY()) > 2.5) {
                continue;
            }
            double dx = at.getX() - floor.getX();
            double dz = at.getZ() - floor.getZ();
            if (dx * dx + dz * dz <= 2.3 * 2.3) {
                hits++;
                human.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, 3, false, false, true));
                human.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 50, 0, false, false, false));
                human.sendTitle("§6§lCLANG!", "§fA chandelier landed on you", 0, 35, 5);
            }
        }
        hits += game.chandelierHitsBots(floor);
        Player puller = chandelier.puller == null ? null : Bukkit.getPlayer(chandelier.puller);
        if (puller != null && hits > 0) {
            game.addPoints(chandelier.puller, 3 * hits);
            game.announce(Component.text(puller.getName() + " dropped a chandelier on "
                    + (hits == 1 ? "a seeker" : hits + " seekers") + "!", NamedTextColor.GOLD));
        } else if (puller != null) {
            puller.sendActionBar(Component.text("Missed! The chandelier hit nothing.", NamedTextColor.GRAY));
        }
    }

    // ------------------------------------------------------------------ cat

    private void spawnCat() {
        Location spawn = new Location(world, 0.5, RatSeekHouse.GROUND + 1, 6.5);
        cat = world.spawn(spawn, Cat.class, entity -> {
            entity.setCatType(Cat.Type.ALL_BLACK);
            entity.customName(Component.text("Mr. Whiskers", NamedTextColor.DARK_GRAY, TextDecoration.BOLD));
            entity.setCustomNameVisible(true);
            entity.setInvulnerable(true);
            entity.setPersistent(false);
            entity.setRemoveWhenFarAway(false);
            entity.setAdult();
            entity.getPersistentDataContainer().set(key, PersistentDataType.STRING, TAG);
        });
        // Untamed cats avoid players; drop every vanilla goal so only we steer it.
        Bukkit.getMobGoals().removeAllGoals(cat);
        entities.add(cat);
        catNap = 60;
    }

    private void tickCat(RatSeekSettings settings) {
        if (cat == null || !cat.isValid()) {
            return;
        }
        if (catNap > 0) {
            catNap -= 10;
            cat.setSitting(true);
            if (catNap % 40 == 0) {
                world.spawnParticle(Particle.CLOUD, cat.getLocation().add(0, 0.9, 0), 1, 0.1, 0.1, 0.1, 0);
                world.playSound(cat.getLocation(), Sound.ENTITY_CAT_PURR, 0.6f, 1f);
            }
            if (catNap <= 0) {
                cat.setSitting(false);
            }
            return;
        }
        Player target = nearestPrey();
        if (catDistractionTicks > 0) {
            catDistractionTicks -= 10;
            cat.getPathfinder().moveTo(catDistraction, 1.4);
            if (catDistractionTicks <= 0 || cat.getLocation().distanceSquared(catDistraction) < 2) {
                catDistractionTicks = 0;
                world.playSound(cat.getLocation(), Sound.ENTITY_CAT_AMBIENT, 1f, 1.3f);
            }
            return;
        }
        if (target == null) {
            if (!cat.getPathfinder().hasPath() && !patrolPoints.isEmpty()) {
                cat.getPathfinder().moveTo(patrolPoints.get(random.nextInt(patrolPoints.size())), 1.0);
            }
            return;
        }
        double distanceSq = cat.getLocation().distanceSquared(target.getLocation());
        if (distanceSq <= 1.7) {
            pounce(target, settings);
            return;
        }
        cat.getPathfinder().moveTo(target, settings.cat == RatSeekSettings.CatMode.HUNGRY ? 1.6 : 1.3);
        if (random.nextInt(8) == 0) {
            world.playSound(cat.getLocation(), Sound.ENTITY_CAT_STRAY_AMBIENT, 0.9f, 1.1f);
        }
    }

    private Player nearestPrey() {
        Player best = null;
        double bestSq = CAT_RANGE * CAT_RANGE;
        for (UUID id : game.freeRats()) {
            Player rat = Bukkit.getPlayer(id);
            if (rat == null || rat.getWorld() != world || game.inSecretPassage(rat.getLocation())
                    || Math.abs(rat.getY() - cat.getY()) > 2.5) {
                continue;
            }
            double sq = rat.getLocation().distanceSquared(cat.getLocation());
            if (sq < bestSq) {
                bestSq = sq;
                best = rat;
            }
        }
        return best;
    }

    private void pounce(Player rat, RatSeekSettings settings) {
        catPounces++;
        Vector leap = rat.getLocation().toVector().subtract(cat.getLocation().toVector()).setY(0);
        if (leap.lengthSquared() > 0.001) {
            cat.setVelocity(leap.normalize().multiply(0.4).setY(0.35));
        }
        rat.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 6, false, false, true));
        rat.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, false, false, false));
        rat.sendTitle("§8§lPOUNCE!", "§fMr. Whiskers has you pinned", 0, 30, 5);
        world.playSound(rat.getLocation(), Sound.ENTITY_CAT_HISS, 1.6f, 1f);
        world.spawnParticle(Particle.ANGRY_VILLAGER, rat.getLocation().add(0, 0.6, 0), 4, 0.3, 0.2, 0.3, 0);
        game.pointHumanCompasses(rat.getLocation());
        game.notifyHumans(Component.text("Mr. Whiskers pounced on a rat in the " + game.roomAt(rat.getLocation()) + "!",
                NamedTextColor.GRAY, TextDecoration.BOLD));
        catNap = settings.cat == RatSeekSettings.CatMode.HUNGRY ? 200 : 400;
    }

    int catPounces() {
        return catPounces;
    }

    private Location centre(RatSeekHouse.Pos pos) {
        return new Location(world, pos.x() + 0.5, pos.y(), pos.z() + 0.5);
    }

    // ------------------------------------------------------------------ lifecycle

    /** Removes the cat and chandeliers and clears match state. */
    void reset() {
        entities.forEach(Entity::remove);
        entities.clear();
        cat = null;
        catNap = 0;
        catDistraction = null;
        catDistractionTicks = 0;
        catPounces = 0;
        java.util.Arrays.fill(chandeliers, null);
        for (Entity entity : world.getEntities()) {
            if (TAG.equals(entity.getPersistentDataContainer().get(key, PersistentDataType.STRING))) {
                entity.remove();
            }
        }
    }
}
