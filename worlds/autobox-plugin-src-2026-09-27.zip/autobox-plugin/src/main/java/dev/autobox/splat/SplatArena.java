package dev.autobox.splat;

import dev.autobox.splat.SplatRules.Team;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.*;

/**
 * Code-only white arenas. Every block is placed at (x, z) and its point mirror, so each map is
 * point-symmetric and both teams get identical routes. Orange spawns west, Blue east. Maps are
 * drawn around a local origin and shifted along x so several fit in the same world.
 */
public final class SplatArena {
    public record Pos(int x, int y, int z) {
        public Pos add(int dx, int dy, int dz) { return new Pos(x + dx, y + dy, z + dz); }
        /** Mirror around the local origin; world positions use {@link MapDef#mirror}. */
        public Pos mirror() { return new Pos(-x, y, -z); }
    }

    public record Bounds(int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
        public boolean contains(Pos p) {
            return p.x() >= minX && p.x() <= maxX && p.y() >= minY && p.y() <= maxY && p.z() >= minZ && p.z() <= maxZ;
        }
    }

    /** paintable: blocks that take ink; turf: paintable walkable tops that count toward the score. */
    public record Blueprint(Map<Pos, Material> blocks, Set<Pos> paintable, Set<Pos> turf,
                            Map<Team, List<Pos>> spawns, Bounds bounds) {
        public Material at(Pos pos) { return blocks.getOrDefault(pos, Material.AIR); }
    }

    /**
     * Mode anchors, all in world coordinates.
     * zone: turf inside the Splat Zone. tower: platform-centre blocks from the middle toward Blue's base
     * (the way Orange pushes; Blue uses the mirror). goal: the floor block each team pushes to.
     * shield: centre block of the Rainmaker shield. clams: turf blocks clams appear on.
     */
    public record Anchors(Set<Pos> zone, List<Pos> tower, List<Integer> checkpoints, Pos shield,
                          Map<Team, Pos> goal, List<Pos> clams) {}

    public record MapDef(String name, int offsetX, int baseLine, Blueprint blueprint, Anchors anchors,
                         double spectateY, double spectateZ) {
        public Pos mirror(Pos p) { return new Pos(2 * offsetX - p.x(), p.y(), -p.z()); }

        /** Spawn quartz starts one block past baseLine on each side. */
        public boolean inBase(Team team, double x) {
            return team == Team.ORANGE ? x < offsetX - baseLine : x >= offsetX + baseLine + 1;
        }

        /** Tower step: positive toward Blue's base (Orange's push), negative toward Orange's. */
        public Pos towerAt(int step) { return step >= 0 ? anchors.tower.get(step) : mirror(anchors.tower.get(-step)); }

        public int towerGoal() { return anchors.tower.size() - 1; }

        /** How far toward its goal a team is at world x, from 0 at the centre to 1 at the goal. */
        public double progress(Team team, double x) {
            double span = anchors.goal.get(Team.ORANGE).x() + 0.5 - (offsetX + 0.5);
            double signed = (x - (offsetX + 0.5)) * (team == Team.ORANGE ? 1 : -1);
            return Math.max(0, Math.min(1, signed / span));
        }

        public Location spectate(World world) { return new Location(world, offsetX + 0.5, spectateY, spectateZ, 0, 38); }

        public Location centre(World world) { return new Location(world, offsetX + 0.5, SplatArena.FLOOR + 1, 0.5); }
    }

    public static final int FLOOR = 100, VOID_Y = 90;
    public static final Material TURF = Material.WHITE_CONCRETE, BASE = Material.QUARTZ_BLOCK;
    public static final List<MapDef> MAPS = List.of(inkblotPlaza(), coralHeights());

    private SplatArena() {}

    /** The original arena: open centre tower on pillars, a raised flank deck and a low platform. */
    private static MapDef inkblotPlaza() {
        Builder a = new Builder();
        for (int x = -25; x <= 25; x++) for (int z = -20; z <= 20; z++) a.turf(x, FLOOR, z);

        // Two-high perimeter walls keep players out of the void except through the base gates.
        for (int x = -26; x <= 26; x++) for (int y = FLOOR; y <= 102; y++) a.wall(x, y, 21);
        for (int z = 7; z <= 21; z++) for (int y = FLOOR; y <= 102; y++) a.wall(-26, y, z);

        // Spawn base: raised unpaintable quartz with a turf step back up from the arena.
        a.base(-32, -26, 6);
        for (int z = -2; z <= 2; z++) a.turf(-25, 101, z);

        // Centre tower on corner pillars, climbed by four-block stairs from both sides.
        for (int x = -3; x <= 3; x++) for (int z = -3; z <= 3; z++) a.turf(x, 104, z);
        for (int y = 101; y <= 103; y++) { a.wall(-3, y, -3); a.wall(-3, y, 3); }
        for (int z = -1; z <= 1; z++) a.stairsX(-7, z, 101, 4, 1);

        // Cover walls and pillars in the mid lanes.
        for (int z = 8; z <= 11; z++) for (int y = 101; y <= 102; y++) a.wall(-14, y, z);
        for (int z = -13; z <= -10; z++) for (int y = 101; y <= 102; y++) a.wall(-8, y, z);
        for (int y = 101; y <= 103; y++) { a.wall(-10, y, 4); a.wall(-11, y, -5); }

        // A raised flank deck with a step, and a low platform on the other flank.
        for (int x = -20; x <= -15; x++) for (int z = 12; z <= 18; z++) { a.wall(x, 101, z); a.turf(x, 102, z); }
        for (int x = -18; x <= -17; x++) a.turf(x, 101, 11);
        for (int x = -20; x <= -15; x++) for (int z = -17; z <= -12; z++) a.turf(x, 101, z);

        List<Pos> clams = List.of(new Pos(-12, 100, -16), new Pos(-18, 102, 15), new Pos(-17, 101, -14), new Pos(-5, 100, 10),
                new Pos(-10, 100, -1), new Pos(-2, 104, 2), new Pos(-21, 100, 6));
        return a.finish("Inkblot Plaza", 0, 25, new Bounds(-34, 34, 99, 110, -23, 23), 5, new Pos(0, 106, 0), 23, clams, 124, -40.5);
    }

    /** A longer, taller map: a solid raised plaza with four ramps, sniper perches and a sunken flank. */
    private static MapDef coralHeights() {
        Builder a = new Builder();
        for (int x = -30; x <= 30; x++) for (int z = -16; z <= 16; z++) a.turf(x, FLOOR, z);

        for (int x = -31; x <= 31; x++) for (int y = FLOOR; y <= 102; y++) a.wall(x, y, 17);
        for (int z = 7; z <= 17; z++) for (int y = FLOOR; y <= 102; y++) a.wall(-31, y, z);

        a.base(-37, -31, 6);
        for (int z = -2; z <= 2; z++) a.turf(-30, 101, z);

        // Solid centre plaza with ramps from the lanes and from the flanks.
        for (int x = -4; x <= 4; x++) for (int z = -4; z <= 4; z++) {
            for (int y = 101; y <= 102; y++) a.wall(x, y, z);
            a.turf(x, 103, z);
        }
        for (int d = -1; d <= 1; d++) {
            a.stairsX(-7, d, 101, 3, 1);
            a.stairsZ(d, -7, 101, 3, 1);
        }

        // Sniper perches reached by a long ramp.
        for (int x = -19; x <= -15; x++) for (int z = 9; z <= 13; z++) {
            for (int y = 101; y <= 103; y++) a.wall(x, y, z);
            a.turf(x, 104, z);
        }
        for (int z = 10; z <= 12; z++) a.stairsX(-23, z, 101, 4, 1);

        // Cover, pillars and a one-step flank platform.
        for (int z = 6; z <= 9; z++) for (int y = 101; y <= 102; y++) a.wall(-10, y, z);
        for (int z = -10; z <= -6; z++) for (int y = 101; y <= 102; y++) a.wall(-24, y, z);
        for (int y = 101; y <= 103; y++) { a.wall(-12, y, -8); a.wall(-22, y, 3); }
        for (int x = -20; x <= -12; x++) for (int z = -15; z <= -11; z++) a.turf(x, 101, z);

        List<Pos> clams = List.of(new Pos(-16, 101, -13), new Pos(-17, 104, 11), new Pos(-8, 100, 12), new Pos(-26, 100, -12),
                new Pos(-14, 100, 1), new Pos(-3, 103, 2), new Pos(-26, 100, 8));
        return a.finish("Coral Heights", 150, 30, new Bounds(-38, 38, 99, 110, -18, 18), 6, new Pos(0, 105, 0), 27, clams, 126, -36.5);
    }

    private static final class Builder {
        final Map<Pos, Material> blocks = new LinkedHashMap<>();
        final Set<Pos> paintable = new LinkedHashSet<>(), surfaces = new LinkedHashSet<>();
        final List<Pos> orangeSpawns = new ArrayList<>();

        void put(Pos p, Material material) { blocks.put(p, material); blocks.put(p.mirror(), material); }

        void wall(int x, int y, int z) {
            Pos p = new Pos(x, y, z);
            put(p, TURF);
            paintable.add(p); paintable.add(p.mirror());
        }

        void turf(int x, int y, int z) {
            wall(x, y, z);
            Pos p = new Pos(x, y, z);
            surfaces.add(p); surfaces.add(p.mirror());
        }

        /** Steps along +x starting at (x, z) with the first top at 'top', each one 'rise' higher, filled below. */
        void stairsX(int x, int z, int top, int steps, int rise) {
            for (int step = 0; step < steps; step++) {
                int t = top + step * rise;
                for (int y = FLOOR + 1; y < t; y++) wall(x + step, y, z);
                turf(x + step, t, z);
            }
        }

        void stairsZ(int x, int z, int top, int steps, int rise) {
            for (int step = 0; step < steps; step++) {
                int t = top + step * rise;
                for (int y = FLOOR + 1; y < t; y++) wall(x, y, z + step);
                turf(x, t, z + step);
            }
        }

        /** Quartz spawn block from x0 to x1 (west side), glass rails, and ten spawn points. */
        void base(int x0, int x1, int halfZ) {
            for (int x = x0; x <= x1; x++) for (int z = -halfZ; z <= halfZ; z++) for (int y = 99; y <= 102; y++) {
                Pos p = new Pos(x, y, z);
                put(p, BASE);
                for (Pos q : List.of(p, p.mirror())) { paintable.remove(q); surfaces.remove(q); }
            }
            for (int x = x0 - 1; x <= x1; x++) for (int y = 103; y <= 104; y++) { team(x, y, halfZ + 1); team(x, y, -halfZ - 1); }
            for (int z = -halfZ; z <= halfZ; z++) for (int y = 103; y <= 104; y++) team(x0 - 1, y, z);
            int near = x0 + 2;
            for (int i = 0; i < SplatRules.MAX_PLAYERS; i++) orangeSpawns.add(new Pos(i % 2 == 0 ? near : near + 2, 103, -4 + (i / 2) * 2));
        }

        void team(int x, int y, int z) {
            Pos p = new Pos(x, y, z);
            blocks.put(p, Team.ORANGE.glass);
            blocks.put(p.mirror(), Team.BLUE.glass);
        }

        MapDef finish(String name, int offset, int baseLine, Bounds local, int zoneRadius, Pos shield, int goalX,
                      List<Pos> clamSide, double spectateY, double spectateZ) {
            Set<Pos> turf = new LinkedHashSet<>();
            for (Pos p : surfaces) if (!blocks.containsKey(p.add(0, 1, 0))) turf.add(p);

            // Tower path: the platform floats one block above the highest block under its 3x3 footprint.
            List<Pos> tower = new ArrayList<>();
            for (int c = 0; c <= goalX; c++) {
                int top = FLOOR;
                for (int x = c - 1; x <= c + 1; x++)
                    for (int z = -1; z <= 1; z++)
                        for (int y = local.maxY(); y >= local.minY(); y--)
                            if (blocks.containsKey(new Pos(x, y, z))) { top = Math.max(top, y); break; }
                tower.add(new Pos(c, top + 1, 0));
            }
            Set<Pos> zone = new LinkedHashSet<>();
            for (Pos p : turf) if (Math.abs(p.x()) <= zoneRadius && Math.abs(p.z()) <= zoneRadius) zone.add(p);
            List<Pos> clams = new ArrayList<>();
            for (Pos p : clamSide) { clams.add(p); clams.add(p.mirror()); }

            Map<Team, List<Pos>> spawns = new EnumMap<>(Team.class);
            spawns.put(Team.ORANGE, List.copyOf(orangeSpawns));
            spawns.put(Team.BLUE, orangeSpawns.stream().map(Pos::mirror).toList());
            Map<Team, Pos> goal = new EnumMap<>(Team.class);
            goal.put(Team.ORANGE, new Pos(goalX, FLOOR, 0));
            goal.put(Team.BLUE, new Pos(-goalX, FLOOR, 0));

            // Shift everything into world space.
            Map<Pos, Material> worldBlocks = new LinkedHashMap<>();
            blocks.forEach((p, m) -> worldBlocks.put(shift(p, offset), m));
            Map<Team, List<Pos>> worldSpawns = new EnumMap<>(Team.class);
            spawns.forEach((t, list) -> worldSpawns.put(t, list.stream().map(p -> shift(p, offset)).toList()));
            Map<Team, Pos> worldGoal = new EnumMap<>(Team.class);
            goal.forEach((t, p) -> worldGoal.put(t, shift(p, offset)));
            Bounds bounds = new Bounds(local.minX() + offset, local.maxX() + offset, local.minY(), local.maxY(), local.minZ(), local.maxZ());
            Blueprint blueprint = new Blueprint(Collections.unmodifiableMap(worldBlocks), shiftSet(paintable, offset),
                    shiftSet(turf, offset), Collections.unmodifiableMap(worldSpawns), bounds);
            int thirds = goalX / 3;
            Anchors anchors = new Anchors(shiftSet(zone, offset), tower.stream().map(p -> shift(p, offset)).toList(),
                    List.of(thirds, 2 * thirds), shift(shield, offset), Collections.unmodifiableMap(worldGoal),
                    clams.stream().map(p -> shift(p, offset)).toList());
            return new MapDef(name, offset, baseLine, blueprint, anchors, spectateY, spectateZ);
        }

        static Pos shift(Pos p, int dx) { return new Pos(p.x() + dx, p.y(), p.z()); }

        static Set<Pos> shiftSet(Set<Pos> set, int dx) {
            Set<Pos> out = new LinkedHashSet<>();
            for (Pos p : set) out.add(shift(p, dx));
            return Collections.unmodifiableSet(out);
        }
    }
}
