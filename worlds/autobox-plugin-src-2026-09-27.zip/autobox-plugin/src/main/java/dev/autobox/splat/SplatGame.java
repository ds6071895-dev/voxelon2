package dev.autobox.splat;

import dev.autobox.AutoBoxPlugin;
import dev.autobox.splat.SplatArena.MapDef;
import dev.autobox.splat.SplatArena.Pos;
import dev.autobox.splat.SplatRules.Team;
import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.Consumable;
import io.papermc.paper.datacomponent.item.consumable.ItemUseAnimation;
import io.papermc.paper.entity.TeleportFlag;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.logging.Level;

/** Two-team Splatoon matches: Turf War and the four ranked modes, with saved ranks and levels. */
public final class SplatGame {
    public static final String WORLD_NAME = "splat_arena", ENTITY_TAG = "splat_temporary";
    private static final int BUILD_BATCH = 2000;
    static final int MAIN_SLOT = 0, SUB_SLOT = 1, SPECIAL_SLOT = 2, JUMP_SLOT = 7, SQUID_SLOT = 8, LOCKER_SLOT = 8;
    private static final float MUSIC_VOLUME = 0.9f;
    /** Keeps the player's momentum through a teleport; the target always carries their current view. */
    private static final TeleportFlag[] SMOOTH = {TeleportFlag.Relative.VELOCITY_X, TeleportFlag.Relative.VELOCITY_Y,
            TeleportFlag.Relative.VELOCITY_Z, TeleportFlag.Relative.VELOCITY_ROTATION};
    public enum Phase { IDLE, COUNTDOWN, PLAY, JUDGING, RESULTS }

    /** Host choices and the resolved settings a match runs with. */
    public record MatchSettings(SplatMode mode, int map) {}

    /** What a player gained or lost at the end of a match. */
    record Result(SplatMode mode, int ratingBefore, int ratingDelta, int matchesAfter, int xp, int levelBefore, int levelAfter,
                  long xpAfter, boolean win, boolean draw) {}

    final AutoBoxPlugin plugin;
    final World world;
    private final SplatPack pack;
    final SplatStats stats;
    final NamespacedKey weaponKey, uniqueKey;
    private final NamespacedKey swimKey, enemyInkKey, enemyJumpKey, climbKey, carryKey, brushKey, floatKey;
    final Random random = new Random();
    final LinkedHashMap<UUID, Inkling> players = new LinkedHashMap<>();
    /** Everyone who started this match, including players who left. */
    final LinkedHashMap<UUID, Inkling> roster = new LinkedHashMap<>();
    private final Set<UUID> viewers = new HashSet<>(), packed = new HashSet<>(), muted = new HashSet<>(), requeue = new LinkedHashSet<>();
    final Map<Pos, Team> paint = new HashMap<>();
    final EnumMap<Team, Integer> turf = new EnumMap<>(Team.class);
    final EnumMap<Team, BlockData> inkData = new EnumMap<>(Team.class);
    final Set<Entity> entities = new HashSet<>();
    final Map<UUID, Result> results = new HashMap<>();
    final SplatWeapons weapons;
    final SplatHud hud;
    private final SplatMenu menu;
    private SplatWebLink leaderboard;
    private BukkitTask builder, ticker;
    private boolean ready, solo, test;
    Phase phase = Phase.IDLE;
    int elapsed, overtimeTicks, overtimeGrace;
    boolean overtime;
    private int trackTick;
    private SplatMusic.Track track;
    Team forfeitWinner, winner, knockout;
    MapDef map = SplatArena.MAPS.getFirst();
    MatchSettings settings = new MatchSettings(SplatMode.TURF_WAR, 0);
    Objective objective = new TurfObjective(this);

    // Host menu choices (persist between matches until the server restarts).
    SplatMode hostMode = SplatMode.TURF_WAR;
    boolean rotation;
    int hostMap = -1, rotationIndex;

    // Lobby hooks.
    private Predicate<Player> isHost = p -> false;
    private Supplier<Integer> queued = () -> 0;
    private Consumer<Player> starter = p -> {}, joinQueue = p -> {};

    public SplatGame(AutoBoxPlugin plugin, World world, SplatPack pack) {
        this.plugin = plugin;
        this.world = world;
        this.pack = pack;
        this.weaponKey = new NamespacedKey(plugin, "splat_weapon");
        this.uniqueKey = new NamespacedKey(plugin, "splat_unique");
        this.swimKey = new NamespacedKey(plugin, "splat_swim");
        this.enemyInkKey = new NamespacedKey(plugin, "splat_enemy_ink");
        this.enemyJumpKey = new NamespacedKey(plugin, "splat_enemy_jump");
        this.climbKey = new NamespacedKey(plugin, "splat_climb");
        this.carryKey = new NamespacedKey(plugin, "splat_carry");
        this.brushKey = new NamespacedKey(plugin, "splat_brush");
        this.floatKey = new NamespacedKey(plugin, "splat_float");
        this.stats = new SplatStats(plugin);
        this.weapons = new SplatWeapons(this);
        this.hud = new SplatHud(this);
        this.menu = new SplatMenu(this);
        for (Team team : Team.values()) inkData.put(team, team.ink.createBlockData());
        world.setViewDistance(4);
        world.setSimulationDistance(4);
        for (Entity e : world.getEntities()) if (!(e instanceof Player)) e.remove();
        resetCounts();
        build();
        Bukkit.getScheduler().runTask(plugin, () -> {
            Location lobby = plugin.getLobbySpawn();
            if (lobby == null || lobby.getWorld() == null) return;
            leaderboard = new SplatWebLink(plugin, new Location(lobby.getWorld(), -5.5, 110.2, -5.0));
            leaderboard.start();
        });
    }

    /** Clears and rebuilds every map volume with a hard per-tick bound. */
    private void build() {
        for (MapDef m : SplatArena.MAPS) {
            SplatArena.Bounds b = m.blueprint().bounds();
            for (int cx = b.minX() >> 4; cx <= b.maxX() >> 4; cx++)
                for (int cz = b.minZ() >> 4; cz <= b.maxZ() >> 4; cz++) world.addPluginChunkTicket(cx, cz, plugin);
        }
        builder = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            int index;
            SplatArena.Bounds b = SplatArena.MAPS.getFirst().blueprint().bounds();
            int x = b.minX(), y = b.minY(), z = b.minZ();

            public void run() {
                try {
                    for (int n = 0; n < BUILD_BATCH; n++) {
                        if (x > b.maxX()) {
                            plugin.getLogger().info("Splatoon: " + SplatArena.MAPS.get(index).name() + " ready ("
                                    + SplatArena.MAPS.get(index).blueprint().turf().size() + " turf blocks).");
                            if (++index >= SplatArena.MAPS.size()) {
                                ready = true;
                                builder.cancel();
                                builder = null;
                                return;
                            }
                            b = SplatArena.MAPS.get(index).blueprint().bounds();
                            x = b.minX(); y = b.minY(); z = b.minZ();
                        }
                        Material material = SplatArena.MAPS.get(index).blueprint().at(new Pos(x, y, z));
                        Block block = world.getBlockAt(x, y, z);
                        if (block.getType() != material) block.setType(material, false);
                        if (++y > b.maxY()) { y = b.minY(); if (++z > b.maxZ()) { z = b.minZ(); x++; } }
                    }
                } catch (Throwable failure) {
                    builder.cancel();
                    builder = null;
                    plugin.getLogger().log(Level.SEVERE, "Splatoon arena construction failed; starts remain blocked", failure);
                }
            }
        }, 1, 1);
    }

    public static Component text(String s) { return Component.text(s, NamedTextColor.AQUA); }
    public boolean isReady() { return ready; }
    public Phase phase() { return phase; }
    public boolean isRunning() { return phase != Phase.IDLE; }
    public boolean isPlaying(Player p) { return players.containsKey(p.getUniqueId()); }
    public boolean isWorld(Player p) { return p.getWorld().equals(world); }
    public World world() { return world; }
    public SplatStats stats() { return stats; }

    public Location getSpectateLocation() { return map.spectate(world); }

    // ------------------------------------------------------------------ lobby, host menu and settings

    public void setLobbyHooks(Predicate<Player> isHost, Supplier<Integer> queued, Consumer<Player> starter, Consumer<Player> joinQueue) {
        this.isHost = isHost; this.queued = queued; this.starter = starter; this.joinQueue = joinQueue;
    }

    public boolean isHost(Player p) { return isHost.test(p); }
    int queuedCount() { return queued.get(); }

    /** Short description for the lobby sidebar and join messages. */
    public String settingsSummary() {
        String mode = rotation ? "Ranked rotation: " + SplatMode.RANKED.get(rotationIndex % SplatMode.RANKED.size()).title : hostMode.title;
        return mode + ", " + (hostMap < 0 ? "random map" : SplatArena.MAPS.get(hostMap).name());
    }

    public String modeShort() { return rotation ? "Rotation" : hostMode.title; }

    public void openHostMenu(Player p) { menu.openHost(p, isHost(p) && !isRunning()); }
    void menuClick(Player p, SplatMenu.Holder holder, int slot) { menu.click(p, holder, slot); }
    public void projectileHit(org.bukkit.event.entity.ProjectileHitEvent event) { weapons.projectileHit(event); }
    public void openLocker(Player p) { menu.openLocker(p); }

    void startFromMenu(Player p) {
        if (!p.isOnline() || !isHost(p) || isRunning()) return;
        p.closeInventory();
        starter.accept(p);
    }

    private MatchSettings nextSettings() {
        SplatMode mode = hostMode;
        if (rotation) mode = SplatMode.RANKED.get(rotationIndex++ % SplatMode.RANKED.size());
        int mapIndex = hostMap >= 0 && hostMap < SplatArena.MAPS.size() ? hostMap : random.nextInt(SplatArena.MAPS.size());
        return new MatchSettings(mode, mapIndex);
    }

    // ------------------------------------------------------------------ starting

    public void start(CommandSender sender, List<Player> roster) {
        if (!ready) { sender.sendMessage(text("The Splatoon arena is still being built. Try again shortly.")); return; }
        begin(sender, roster, nextSettings(), false, false);
    }

    public void testStart(CommandSender sender, List<Player> roster, boolean solo, SplatMode mode, Integer mapIndex) {
        MatchSettings next = nextSettings();
        if (mode != null || mapIndex != null) next = new MatchSettings(mode == null ? next.mode() : mode, mapIndex == null ? next.map() : mapIndex);
        begin(sender, roster, next, solo, true);
    }

    /** Per-player soundtrack switch; returns whether music is now on. */
    public boolean toggleMusic(Player p) {
        if (muted.remove(p.getUniqueId())) return true;
        muted.add(p.getUniqueId());
        return false;
    }

    private void begin(CommandSender sender, List<Player> party, MatchSettings next, boolean solo, boolean test) {
        if (isRunning()) { sender.sendMessage(text("Splatoon is already running.")); return; }
        if (!ready) { sender.sendMessage(text("The Splatoon arena is still being built. Try again shortly.")); return; }
        if (!(solo && party.size() == 1) && !SplatRules.validParty(party.size())) {
            sender.sendMessage(text("Splatoon needs 2–10 players.")); return;
        }
        if (party.stream().anyMatch(p -> !p.isOnline()) || party.stream().map(Player::getUniqueId).distinct().count() != party.size()) {
            sender.sendMessage(text("The entire party must be online and unique.")); return;
        }
        for (Player p : party) plugin.getLobbyManager().leave(p);
        cleanup();
        players.clear(); roster.clear(); packed.clear(); results.clear(); requeue.clear();
        hud.newMatch();
        forfeitWinner = null; winner = null; knockout = null; overtime = false; overtimeTicks = 0; overtimeGrace = 0;
        this.solo = solo;
        this.test = test;
        settings = next;
        map = SplatArena.MAPS.get(next.map());
        objective = switch (next.mode()) {
            case TURF_WAR -> new TurfObjective(this);
            case SPLAT_ZONES -> new ZonesObjective(this);
            case TOWER_CONTROL -> new TowerObjective(this);
            case RAINMAKER -> new RainmakerObjective(this);
            case CLAM_BLITZ -> new ClamObjective(this);
        };

        Map<UUID, Integer> ratings = new HashMap<>();
        for (Player p : party) ratings.put(p.getUniqueId(), stats.rating(p.getUniqueId(), next.mode()));
        Map<UUID, Team> teams = SplatRating.draft(party.stream().map(Player::getUniqueId).toList(), ratings, random);
        EnumMap<Team, Integer> slots = new EnumMap<>(Team.class);
        for (Player p : party) {
            Team team = teams.get(p.getUniqueId());
            SplatStats.Record record = stats.get(p.getUniqueId(), p.getName());
            Inkling in = new Inkling(p.getUniqueId(), p.getName(), team, slots.merge(team, 1, Integer::sum) - 1, record.kit);
            players.put(p.getUniqueId(), in);
            roster.put(p.getUniqueId(), in);
        }
        phase = Phase.COUNTDOWN;
        elapsed = 0;
        for (Player p : party) {
            Inkling in = players.get(p.getUniqueId());
            reset(p);
            p.teleport(spawn(in));
            giveSelectors(p, in);
            SplatStats.ModeStats m = stats.get(p.getUniqueId(), p.getName()).mode(next.mode());
            SplatRating.Rank rank = SplatRating.rank(m.rating);
            p.sendMessage(Component.text("You are on the " + in.team.title + " team!", in.team.text, TextDecoration.BOLD)
                    .append(Component.text("  Your " + next.mode().title + " rank: ", NamedTextColor.GRAY))
                    .append(Component.text(SplatRating.label(m.rating, m.matches) + " (" + m.rating + ")", rank.color, TextDecoration.BOLD)));
        }
        moveSpectators();
        hud.announce(next.mode().title, map.name(), next.mode().color);
        broadcast("━━ " + next.mode().title + " on " + map.name() + (test ? " (test, unrated)" : "") + " ━━");
        for (String line : next.mode().howTo) broadcast("• " + line);
        broadcast("Pick a kit in your hotbar (slot 9 shows them all). Sneak on your ink to swim; slot 8 Super Jumps.");
        for (Player p : party) {
            if (!muted.contains(p.getUniqueId())) p.sendMessage(Component.text("♪ Music on — /splat music to turn it off (Jukebox/Note Blocks volume).", NamedTextColor.GRAY));
        }
        playMusic(SplatMusic.Track.COUNTDOWN);
        sendPack();
        ticker = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            try {
                tick();
            } catch (Throwable failure) {
                plugin.getLogger().log(Level.SEVERE, "Splatoon stopped after a match failure", failure);
                stop();
            }
        }, 1, 1);
        hud.update();
    }

    boolean rated() { return !solo && !test; }

    // ------------------------------------------------------------------ resource pack

    /** Floodgate (Bedrock) UUIDs have zero high bits; Geyser cannot hot-swap Java packs. */
    static boolean bedrock(UUID id) { return id.getMostSignificantBits() == 0; }

    private void sendPack() {
        if (pack == null || !pack.serving()) return;
        List<UUID> ids = List.copyOf(players.keySet());
        pack.resolve().thenAccept(url -> {
            if (!plugin.isEnabled()) return;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!isRunning()) return;
                if (url.isEmpty()) {
                    broadcast("Ink textures are unavailable right now, so this match uses vanilla visuals.");
                    return;
                }
                ResourcePackRequest request = pack.request(url.get());
                for (UUID id : ids) {
                    Player p = Bukkit.getPlayer(id);
                    if (p == null || !players.containsKey(id) || bedrock(id)) continue;
                    p.sendResourcePacks(request);
                    packed.add(id);
                }
            });
        });
    }

    public void packStatus(Player p, PlayerResourcePackStatusEvent.Status status) {
        if (!packed.contains(p.getUniqueId())) return;
        switch (status) {
            case SUCCESSFULLY_LOADED -> p.sendActionBar(Component.text("Ink textures loaded!", NamedTextColor.GOLD));
            case DECLINED -> p.sendMessage(text("You declined the ink textures, so you'll see vanilla visuals this match."));
            case FAILED_DOWNLOAD, INVALID_URL, FAILED_RELOAD -> {
                p.sendMessage(text("The ink textures couldn't load, so you'll see vanilla visuals this match."));
                plugin.getLogger().warning("Splatoon pack failed for " + p.getName() + ": " + status);
            }
            default -> {}
        }
    }

    // ------------------------------------------------------------------ match flow

    private void tick() {
        if (!isRunning()) return;
        for (UUID id : new ArrayList<>(players.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline() || !isWorld(p)) forfeit(id);
            if (!isRunning()) return;
        }
        elapsed++;
        switch (phase) {
            case COUNTDOWN -> {
                int left = SplatRules.COUNTDOWN - elapsed;
                if (elapsed == 50 || elapsed == 95) {
                    String line = settings.mode().howTo.get(elapsed == 50 ? 0 : 1);
                    hud.announce(settings.mode().title, line, settings.mode().color);
                }
                if (left % 20 == 0 && left > 0 && left <= 60) {
                    hud.announce(left == 20 ? "Ready?" : String.valueOf(left / 20), left == 20 ? "" : "Get ready to ink!", NamedTextColor.GOLD);
                    for (Player p : world.getPlayers()) p.playSound(p, Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, left == 20 ? 1.5f : 1f);
                }
                if (elapsed >= SplatRules.COUNTDOWN) startPlay();
            }
            case PLAY -> {
                playTick();
                if (phase != Phase.PLAY) break;
                objective.tick();
                if (phase != Phase.PLAY) break;
                timerTick();
            }
            case JUDGING -> {
                if (elapsed % 2 == 0) hud.judgingReveal();
                if (elapsed >= SplatRules.JUDGING) reveal();
            }
            case RESULTS -> {
                if (elapsed % 30 == 0) fireworks();
                if (elapsed == 70) hud.levelUps();
                if (elapsed >= SplatRules.RESULTS) stop();
            }
            default -> {}
        }
        if (!isRunning()) return;
        musicTick();
        if (elapsed % 10 == 0) hud.update();
        else if (phase == Phase.PLAY && elapsed % 4 == 0) hud.actionBars();
    }

    private void timerTick() {
        SplatMode mode = settings.mode();
        if (mode.ranked) {
            Team ko = objective.knockout();
            if (ko != null) {
                knockout = ko;
                for (Player p : world.getPlayers()) {
                    Inkling in = players.get(p.getUniqueId());
                    boolean ours = in == null || in.team == ko;
                    p.showTitle(Title.title(Component.text("KNOCKOUT!", ours ? ko.text : NamedTextColor.RED, TextDecoration.BOLD),
                            Component.text(ko.title + " team wins by knockout", ko.text),
                            Title.Times.times(Duration.ZERO, Duration.ofMillis(1800), Duration.ofMillis(300))));
                    p.playSound(p, Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1f, 1f);
                }
                judge();
                return;
            }
        }
        if (overtime) {
            overtimeTicks++;
            double o = objective.count(Team.ORANGE), b = objective.count(Team.BLUE);
            Team holder = objective.advantage();
            if (RankedRules.overtimeDecided(o, b, holder) || overtimeTicks >= RankedRules.OVERTIME_CAP) { judge(); return; }
            Team leader = RankedRules.leader(o, b);
            overtimeGrace = holder != null && holder != leader ? 0 : overtimeGrace + 1;
            if (overtimeGrace >= RankedRules.OVERTIME_GRACE) judge();
            return;
        }
        int left = mode.playTicks - elapsed;
        if (left == 1200) {
            hud.announce("1 minute left!", hud.scoreLine(), NamedTextColor.GOLD);
            playMusic(SplatMusic.Track.FINAL_MINUTE);
        }
        if (left > 0 && left <= 200 && left % 20 == 0) {
            hud.announce(String.valueOf(left / 20), "", NamedTextColor.GOLD);
            for (Player p : world.getPlayers()) p.playSound(p, Sound.BLOCK_NOTE_BLOCK_COW_BELL, 0.7f, left <= 60 ? 2f : 1.5f);
        }
        if (elapsed >= mode.playTicks) {
            double o = objective.count(Team.ORANGE), b = objective.count(Team.BLUE);
            if (mode.ranked && RankedRules.overtime(o, b, objective.advantage(), 0)) {
                overtime = true;
                overtimeTicks = 0;
                overtimeGrace = 0;
                for (Player p : world.getPlayers()) {
                    p.showTitle(Title.title(Component.text("OVERTIME!", NamedTextColor.RED, TextDecoration.BOLD),
                            Component.text(objective.advantage().title + " team holds the objective!", objective.advantage().text),
                            Title.Times.times(Duration.ZERO, Duration.ofMillis(1500), Duration.ofMillis(300))));
                    p.playSound(p, Sound.EVENT_RAID_HORN, 0.8f, 1.2f);
                }
                playMusic(SplatMusic.Track.OVERTIME);
            } else {
                judge();
            }
        }
    }

    private void startPlay() {
        phase = Phase.PLAY;
        elapsed = 0;
        objective.start();
        for (Player p : online()) {
            Inkling in = players.get(p.getUniqueId());
            equip(p, in);
            in.lastPos = p.getLocation();
            world.spawnParticle(Particle.DUST, p.getLocation().add(0, 0.2, 0), 25, 0.6, 0.1, 0.6, 0, dust(in.team));
        }
        Title go = Title.title(Component.text("GO!", NamedTextColor.YELLOW, TextDecoration.BOLD), text(settings.mode().howTo.getFirst()),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(900), Duration.ofMillis(300)));
        for (Player p : world.getPlayers()) {
            p.showTitle(go);
            p.playSound(p, Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 2f);
            p.playSound(p, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.8f, 1.2f);
        }
        announceUnderdog();
        playMusic(settings.mode().ranked ? SplatMusic.Track.RANKED_BATTLE : SplatMusic.Track.BATTLE);
    }

    public void skip() {
        switch (phase) {
            case COUNTDOWN -> startPlay();
            case PLAY -> judge();
            case JUDGING -> reveal();
            case RESULTS -> stop();
            default -> {}
        }
    }

    private void judge() {
        phase = Phase.JUDGING;
        elapsed = 0;
        clearProjectiles();
        for (Player p : online()) {
            Inkling in = players.get(p.getUniqueId());
            setSquid(p, in, false);
            if (p.getGameMode() == GameMode.SPECTATOR) p.setSpectatorTarget(null);
            reset(p);
            in.respawnAt = -1; in.killcamUntil = -1; in.chargeStart = -1; in.splashdownAt = -1; in.slamming = false;
            in.jump = null; in.booyahAt = -1; in.trizookaShots = 0;
            p.teleport(spawn(in));
        }
        for (Player p : world.getPlayers()) p.playSound(p, Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 1f);
        playMusic(SplatMusic.Track.JUDGING);
        hud.judgingReveal();
    }

    private void reveal() {
        phase = Phase.RESULTS;
        elapsed = 0;
        clearProjectiles();
        for (Player p : online()) { setSquid(p, players.get(p.getUniqueId()), false); p.getInventory().clear(); }
        if (forfeitWinner != null) winner = forfeitWinner;
        else if (knockout != null) winner = knockout;
        else winner = objective.winner();
        rate();
        hud.results();
        playMusic(SplatMusic.Track.VICTORY);
        fireworks();
        hud.update();
    }

    /** Elo, records and XP for everyone who started, including leavers (who take a loss). */
    private void rate() {
        if (!rated()) return;
        SplatMode mode = settings.mode();
        EnumMap<Team, List<Inkling>> sides = new EnumMap<>(Team.class);
        for (Team team : Team.values()) sides.put(team, new ArrayList<>());
        for (Inkling in : roster.values()) sides.get(in.team).add(in);
        if (sides.values().stream().anyMatch(List::isEmpty)) return;
        EnumMap<Team, Double> averages = new EnumMap<>(Team.class);
        for (Team team : Team.values())
            averages.put(team, sides.get(team).stream().mapToInt(in -> stats.rating(in.id, mode)).average().orElse(SplatRating.START));
        for (Inkling in : roster.values()) {
            boolean left = !players.containsKey(in.id);
            boolean win = !left && winner == in.team, draw = !left && winner == null;
            double score = win ? 1 : draw ? 0.5 : 0;
            double expected = SplatRating.expected(averages.get(in.team), averages.get(in.team.opponent()),
                    sides.get(in.team).size(), sides.get(in.team.opponent()).size());
            SplatStats.Record record = stats.get(in.id, in.name);
            SplatStats.ModeStats m = record.mode(mode);
            int before = m.rating;
            int delta = SplatRating.delta(m.matches, expected, score, knockout != null && knockout == in.team);
            m.rating = Math.max(0, before + delta);
            m.matches++;
            if (win) m.wins++;
            else if (!draw) m.losses++;
            m.splats += in.splats;
            m.deaths += in.splatted;
            m.turf += in.painted;
            int levelBefore = record.level(), xp = left ? 0 : SplatRating.matchXp(win, draw, in.painted, in.splats, in.assists, in.specials);
            record.xp += xp;
            results.put(in.id, new Result(mode, before, delta, m.matches, xp, levelBefore, record.level(), record.xp, win, draw));
        }
        stats.save();
    }

    private void forfeit(UUID id) {
        Inkling in = players.remove(id);
        if (in == null) return;
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            objective.onSplat(p, in, p.getLocation());
            detach(p);
        }
        broadcast(in.name + " left the match.");
        if (players.isEmpty()) { stop(); return; }
        if (solo || phase == Phase.RESULTS) return;
        Map<Team, Integer> sizes = sizes();
        for (Team team : Team.values()) {
            if (sizes.get(team) == 0) {
                forfeitWinner = team.opponent();
                reveal();
                return;
            }
        }
    }

    public void handleQuit(Player p) {
        boolean playing = isPlaying(p);
        if (!playing && !viewers.contains(p.getUniqueId()) && !isWorld(p)) return;
        if (playing) {
            p.getInventory().clear();
            p.getActivePotionEffects().forEach(effect -> p.removePotionEffect(effect.getType()));
            forfeit(p.getUniqueId());
        }
        detach(p);
    }

    public void stop() {
        if (ticker != null) { ticker.cancel(); ticker = null; }
        List<Player> returning = new ArrayList<>(world.getPlayers());
        phase = Phase.IDLE;
        track = null;
        cleanup();
        for (UUID id : new HashSet<>(viewers)) { Player p = Bukkit.getPlayer(id); if (p != null) detach(p); }
        for (Player p : online()) detach(p);
        players.clear(); roster.clear(); packed.clear();
        forfeitWinner = null; winner = null; knockout = null; solo = false; test = false; overtime = false;
        for (Player p : returning) {
            detach(p);
            if (p.getGameMode() == GameMode.SPECTATOR) p.setSpectatorTarget(null);
            plugin.getLobbyManager().returnToLobby(p);
        }
        List<UUID> again = List.copyOf(requeue);
        requeue.clear();
        if (!again.isEmpty() && plugin.isEnabled()) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                for (UUID id : again) {
                    Player p = Bukkit.getPlayer(id);
                    if (p != null && p.isOnline() && !isRunning()) joinQueue.accept(p);
                }
            });
        }
    }

    /** Clickable "Play again": rejoin the Splatoon queue now, or as soon as this match ends. */
    public void playAgain(Player p) {
        if (isRunning() && isWorld(p)) {
            requeue.add(p.getUniqueId());
            p.sendMessage(text("You'll rejoin the Splatoon queue when this match ends."));
        } else if (isRunning()) {
            p.sendMessage(text("A Splatoon match is running. Right-click the Splatoon NPC to watch."));
        } else {
            joinQueue.accept(p);
        }
    }

    public void shutdown() {
        stop();
        if (builder != null) { builder.cancel(); builder = null; }
        if (leaderboard != null) leaderboard.stop();
        stats.save();
        world.removePluginChunkTickets(plugin);
    }

    // ------------------------------------------------------------------ music

    void playMusic(SplatMusic.Track next) {
        track = next;
        trackTick = 0;
    }

    private void musicTick() {
        if (track == null) return;
        if (trackTick % SplatMusic.STEP_TICKS == 0) {
            int step = trackTick / SplatMusic.STEP_TICKS;
            if (!track.loops && step >= SplatMusic.length(track)) { track = null; return; }
            for (Player p : world.getPlayers()) {
                if (muted.contains(p.getUniqueId())) continue;
                for (SplatMusic.Note note : SplatMusic.step(trackFor(p), step))
                    p.playSound(p, sound(note.voice()), SoundCategory.RECORDS, note.volume() * MUSIC_VOLUME, note.pitch());
            }
        }
        trackTick++;
    }

    /** Results play a fanfare for winners and spectators, a sad tune for the losing team. */
    private SplatMusic.Track trackFor(Player p) {
        if (phase != Phase.RESULTS) return track;
        if (winner == null) return SplatMusic.Track.DRAW;
        Inkling in = players.get(p.getUniqueId());
        return in == null || in.team == winner ? SplatMusic.Track.VICTORY : SplatMusic.Track.DEFEAT;
    }

    private static Sound sound(SplatMusic.Voice voice) {
        return switch (voice) {
            case BASS -> Sound.BLOCK_NOTE_BLOCK_BASS;
            case GUITAR -> Sound.BLOCK_NOTE_BLOCK_GUITAR;
            case BIT -> Sound.BLOCK_NOTE_BLOCK_BIT;
            case PLING -> Sound.BLOCK_NOTE_BLOCK_PLING;
            case FLUTE -> Sound.BLOCK_NOTE_BLOCK_FLUTE;
            case BELL -> Sound.BLOCK_NOTE_BLOCK_BELL;
            case CHIME -> Sound.BLOCK_NOTE_BLOCK_CHIME;
            case KICK -> Sound.BLOCK_NOTE_BLOCK_BASEDRUM;
            case SNARE -> Sound.BLOCK_NOTE_BLOCK_SNARE;
            case HAT -> Sound.BLOCK_NOTE_BLOCK_HAT;
        };
    }

    // ------------------------------------------------------------------ per-tick player simulation

    private void playTick() {
        Map<Team, Integer> sizes = sizes();
        for (Player p : online()) {
            Inkling in = players.get(p.getUniqueId());
            if (in.respawnAt >= 0) {
                if (in.killcamUntil >= 0 && elapsed >= in.killcamUntil) {
                    in.killcamUntil = -1;
                    p.setSpectatorTarget(null);
                    p.teleport(getSpectateLocation());
                }
                if (elapsed >= in.respawnAt) respawn(p, in);
                continue;
            }
            Location l = p.getLocation();
            Vector moved = in.lastPos == null || in.lastPos.getWorld() != world ? new Vector()
                    : l.toVector().subtract(in.lastPos.toVector()).setY(0);
            in.lastPos = l.clone();
            in.lastMove = moved;
            if (in.jump != null) { jumpTick(p, in); continue; }
            if (l.getY() < SplatArena.VOID_Y) { splat(p, in, null, null); continue; }
            if (map.inBase(in.team.opponent(), l.getX()) && elapsed % 10 == 0) hurt(p, in, 3, null, null);
            if (in.respawnAt >= 0) continue;

            Team under = inkUnder(l);
            boolean canSquid = in.splashdownAt < 0 && in.booyahAt < 0 && objective.allowSquid(in);
            boolean squid = canSquid && p.isSneaking() && (under == in.team || (in.squid && under == null && !p.isOnGround()));
            setSquid(p, in, squid);
            Weapon held = weaponOf(p.getInventory().getItemInMainHand());
            boolean painter = in.main() == Weapon.ROLLER || in.main() == Weapon.INKBRUSH;
            boolean rolling = !in.squid && in.splashdownAt < 0 && in.booyahAt < 0 && painter && held == in.main() && p.isOnGround()
                    && moved.lengthSquared() >= 0.03 * 0.03 && moved.lengthSquared() < 1;
            boolean inEnemyInk = under == in.team.opponent() && !rolling;
            modifier(p, Attribute.MOVEMENT_SPEED, enemyInkKey, -0.3, inEnemyInk);
            modifier(p, Attribute.JUMP_STRENGTH, enemyJumpKey, -0.35, inEnemyInk);
            modifier(p, Attribute.MOVEMENT_SPEED, brushKey, Weapon.BRUSH_SPEED, in.main() == Weapon.INKBRUSH && held == Weapon.INKBRUSH && !in.squid);
            modifier(p, Attribute.MOVEMENT_SPEED, carryKey, -0.3, in.rainmaker);

            if (under == in.team.opponent()) {
                if (elapsed % 10 == 0 && p.getHealth() > SplatRules.MAX_HEALTH / 2) hurt(p, in, 1, null, null);
            } else {
                if (elapsed - in.lastFire > 10 && in.chargeStart < 0) {
                    boolean wasFull = in.ink >= SplatRules.MAX_INK;
                    double regen = SplatRules.INK_REGEN * SplatRules.regenMultiplier(in.team, sizes)
                            * (in.squid ? SplatRules.SQUID_REGEN_MULTIPLIER : 1);
                    in.ink = Math.min(SplatRules.MAX_INK, in.ink + regen);
                    if (!wasFull && in.ink >= SplatRules.MAX_INK && in.squid) p.playSound(p, Sound.BLOCK_NOTE_BLOCK_CHIME, 0.6f, 1.9f);
                }
                if (elapsed - in.lastHurt >= SplatRules.COMBAT_REGEN_DELAY && p.getHealth() < maxHealth(p)) {
                    p.setHealth(Math.min(maxHealth(p), p.getHealth() + SplatRules.HEALTH_REGEN));
                    if (elapsed % 10 == 0) tint(p, in);
                }
            }
            if (p.getHealth() < 7 && elapsed >= in.nextHeartbeat) {
                in.nextHeartbeat = elapsed + 16;
                p.playSound(p, Sound.ENTITY_WARDEN_HEARTBEAT, 0.9f, 1.1f);
            }

            if (in.squid) squidTick(p, in, l, moved);
            else if (in.climbing) climb(p, in, false);
            if (rolling) weapons.roll(p, in, moved);
            // Holding right-click through the cooldown starts the next charge as soon as it's ready.
            if (in.chargeStart < 0 && !in.busy() && p.hasActiveItem() && held != null && held.charges() && held == in.main())
                weapons.beginCharge(p, in, held);
            if (in.chargeStart >= 0) weapons.chargeTick(p, in);
            if (in.splashdownAt >= 0) weapons.splashdownTick(p, in);
            if (in.booyahAt >= 0) weapons.booyahTick(p, in);
            if (in.trizookaShots > 0 && elapsed >= in.trizookaUntil) weapons.endTrizooka(p, in);
            if (in.special >= SplatRules.SPECIAL_MAX && !in.specialAnnounced && !in.rainmaker) specialReady(p, in);
            if (in.special >= SplatRules.SPECIAL_MAX && elapsed % 10 == 0)
                world.spawnParticle(Particle.DUST, l.clone().add(0, 1, 0), 4, 0.35, 0.5, 0.35, 0, SPECIAL_READY_DUST);
            // Each set forces an experience packet, so only send when the ink or special meter moved.
            float inkBar = (float) Math.min(0.999, in.ink / SplatRules.MAX_INK);
            if (p.getExp() != inkBar) p.setExp(inkBar);
            if (p.getLevel() != (int) in.special) p.setLevel((int) in.special);
        }
        weapons.tick();
    }

    /** Swimming: steady wall climbs with gravity off, ripples everyone sees only while you move. */
    private void squidTick(Player p, Inkling in, Location l, Vector moved) {
        Vector look = l.getDirection().setY(0);
        boolean wall = false;
        if (look.lengthSquared() > 0.01) {
            look.normalize().multiply(0.7);
            for (double dy : new double[]{0.1, 1.0}) {
                Pos front = new Pos((int) Math.floor(l.getX() + look.getX()), (int) Math.floor(l.getY() + dy), (int) Math.floor(l.getZ() + look.getZ()));
                if (paint.get(front) == in.team) { wall = true; break; }
            }
        }
        if (wall) climb(p, in, true);
        else if (in.climbing) climb(p, in, false);
        if (moved.lengthSquared() > 0.004) {
            if (elapsed % 3 == 0) world.spawnParticle(Particle.DUST, l.clone().add(0, 0.1, 0), 3, 0.2, 0, 0.2, 0, dust(in.team));
            if (moved.lengthSquared() > 0.04 && elapsed % 6 == 0) {
                world.spawnParticle(Particle.BLOCK, l.clone().add(0, 0.1, 0), 4, 0.2, 0.05, 0.2, 0, inkData.get(in.team));
                world.playSound(l, Sound.ENTITY_PLAYER_SWIM, 0.15f, 1.7f);
            }
        } else if (elapsed % 8 == 0) {
            // A still squid is hidden from enemies; teammates still see where it is.
            for (Player mate : online()) {
                Inkling mi = players.get(mate.getUniqueId());
                if (mi.team == in.team && !mate.equals(p)) mate.spawnParticle(Particle.DUST, l.clone().add(0, 0.15, 0), 2, 0.15, 0, 0.15, 0, dust(in.team));
            }
        }
    }

    private void climb(Player p, Inkling in, boolean on) {
        if (on) {
            if (!in.climbing) {
                in.climbing = true;
                modifier(p, Attribute.GRAVITY, climbKey, -1, true);
            }
            if (elapsed % 3 == 0 || p.getVelocity().getY() < 0.2) p.setVelocity(p.getVelocity().setY(0.34));
            if (elapsed % 5 == 0) world.spawnParticle(Particle.BLOCK, p.getLocation().add(0, 0.5, 0), 3, 0.25, 0.3, 0.25, 0, inkData.get(in.team));
        } else if (in.climbing) {
            in.climbing = false;
            modifier(p, Attribute.GRAVITY, climbKey, -1, false);
            if (in.squid && p.isSneaking()) {
                // Popping over the top of a wall: a small hop onto the ledge.
                Vector forward = p.getLocation().getDirection().setY(0);
                if (forward.lengthSquared() > 0.01) forward.normalize().multiply(0.28);
                p.setVelocity(forward.setY(0.42));
            }
        }
    }

    /** Jumping out of your own ink as a squid launches you higher and further. */
    public void jumped(Player p) {
        Inkling in = players.get(p.getUniqueId());
        if (in == null || phase != Phase.PLAY || !in.squid || in.climbing) return;
        Vector forward = p.getLocation().getDirection().setY(0);
        if (forward.lengthSquared() > 0.01) forward.normalize().multiply(0.32);
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline() || !in.squid) return;
            p.setVelocity(p.getVelocity().add(forward).setY(0.62));
            world.spawnParticle(Particle.BLOCK, p.getLocation(), 8, 0.3, 0.1, 0.3, 0, inkData.get(in.team));
            world.playSound(p.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 0.3f, 1.9f);
        });
    }

    Team inkUnder(Location l) {
        return paint.get(new Pos(l.getBlockX(), (int) Math.floor(l.getY() - 0.05), l.getBlockZ()));
    }

    void setSquid(Player p, Inkling in, boolean on) {
        if (in == null || in.squid == on) return;
        in.squid = on;
        if (on) {
            weapons.cancelCharge(p, in);
            in.heldSlot = p.getInventory().getHeldItemSlot();
            p.getInventory().setHeldItemSlot(SQUID_SLOT);
            p.getInventory().setArmorContents(new ItemStack[4]);
            p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, PotionEffect.INFINITE_DURATION, 0, false, false, false));
            modifier(p, Attribute.MOVEMENT_SPEED, swimKey, 0.65, true);
            world.playSound(p.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 0.35f, 1.8f);
            world.spawnParticle(Particle.BLOCK, p.getLocation().add(0, 0.2, 0), 10, 0.3, 0.1, 0.3, 0, inkData.get(in.team));
        } else {
            p.removePotionEffect(PotionEffectType.INVISIBILITY);
            modifier(p, Attribute.MOVEMENT_SPEED, swimKey, 0, false);
            climb(p, in, false);
            if (phase == Phase.PLAY && in.respawnAt < 0) {
                armor(p, in);
                p.getInventory().setHeldItemSlot(in.heldSlot);
                world.playSound(p.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 0.3f, 1.4f);
                world.spawnParticle(Particle.DUST, p.getLocation().add(0, 0.5, 0), 12, 0.3, 0.4, 0.3, 0, dust(in.team));
            }
        }
    }

    /** Adds or removes a keyed attribute modifier; never stacks. */
    void modifier(Player p, Attribute attribute, NamespacedKey key, double amount, boolean on) {
        AttributeInstance instance = p.getAttribute(attribute);
        if (instance == null) return;
        AttributeModifier existing = instance.getModifier(key);
        if (on && existing == null) instance.addModifier(new AttributeModifier(key, amount, AttributeModifier.Operation.ADD_SCALAR));
        else if (!on && existing != null) instance.removeModifier(key);
    }

    void floating(Player p, boolean on) { modifier(p, Attribute.GRAVITY, floatKey, -1, on); }

    private void clearModifiers(Player p) {
        modifier(p, Attribute.MOVEMENT_SPEED, swimKey, 0, false);
        modifier(p, Attribute.MOVEMENT_SPEED, enemyInkKey, 0, false);
        modifier(p, Attribute.JUMP_STRENGTH, enemyJumpKey, 0, false);
        modifier(p, Attribute.GRAVITY, climbKey, 0, false);
        modifier(p, Attribute.MOVEMENT_SPEED, carryKey, 0, false);
        modifier(p, Attribute.MOVEMENT_SPEED, brushKey, 0, false);
        modifier(p, Attribute.GRAVITY, floatKey, 0, false);
    }

    // ------------------------------------------------------------------ input

    public void click(Player p) {
        Inkling in = players.get(p.getUniqueId());
        if (in == null) return;
        Weapon weapon = weaponOf(p.getInventory().getItemInMainHand());
        if (weapon == null) return;
        if (phase == Phase.COUNTDOWN) {
            if (weapon == Weapon.LOCKER) menu.openLocker(p);
            else if (weapon.kind == Weapon.Kind.MAIN) selectKit(p, in, Kit.of(weapon));
        } else if (phase == Phase.PLAY) {
            if (weapon == Weapon.SUPER_JUMP) openJump(p);
            else weapons.fire(p, in, weapon);
        }
    }

    /** Java charger and Rainmaker players hold right-click with a bow pose; the item may only be "used" then. */
    public boolean canCharge(Player p) {
        Inkling in = players.get(p.getUniqueId());
        if (in == null || phase != Phase.PLAY || in.busy()) return false;
        Weapon held = weaponOf(p.getInventory().getItemInMainHand());
        return held != null && held.charges() && held == in.main();
    }

    public void release(Player p) {
        Inkling in = players.get(p.getUniqueId());
        if (in == null || in.chargeStart < 0 || phase != Phase.PLAY) return;
        weapons.releaseCharge(p, in);
    }

    public void useSpecial(Player p) {
        Inkling in = players.get(p.getUniqueId());
        if (in != null && phase == Phase.PLAY && !in.busy()) weapons.activateSpecial(p, in);
    }

    /** Q: Dualies dodge roll. */
    public void dropKey(Player p) {
        Inkling in = players.get(p.getUniqueId());
        if (in != null && phase == Phase.PLAY && !in.busy()) weapons.dodge(p, in);
    }

    public void heldChanged(Player p, int slot) {
        Inkling in = players.get(p.getUniqueId());
        if (in == null || phase != Phase.COUNTDOWN) return;
        Weapon weapon = weaponOf(p.getInventory().getItem(slot));
        if (weapon != null && weapon.kind == Weapon.Kind.MAIN && weapon != in.kit.main) selectKit(p, in, Kit.of(weapon));
    }

    void selectKit(Player p, Inkling in, Kit kit) {
        if (kit == null || in.kit == kit) return;
        in.kit = kit;
        stats.get(in.id, in.name).kit = kit;
        if (phase == Phase.COUNTDOWN) {
            int held = p.getInventory().getHeldItemSlot();
            giveSelectors(p, in);
            p.getInventory().setHeldItemSlot(held);
        }
        p.playSound(p, Sound.UI_BUTTON_CLICK, 1f, 1.3f);
        p.sendActionBar(Component.text(kit.main.title + "  +  " + kit.sub.title + "  +  " + kit.special.title, in.team.text));
    }

    /** Locker clicks from the lobby just remember the kit for next time. */
    void chooseKit(Player p, Kit kit) {
        Inkling in = players.get(p.getUniqueId());
        if (in != null && phase == Phase.COUNTDOWN) { selectKit(p, in, kit); p.closeInventory(); return; }
        stats.get(p.getUniqueId(), p.getName()).kit = kit;
        stats.saveSoon();
        p.closeInventory();
        p.sendMessage(text("Saved kit: " + kit.main.title + " + " + kit.sub.title + " + " + kit.special.title + "."));
    }

    // ------------------------------------------------------------------ super jump

    public void openJump(Player p) {
        Inkling in = players.get(p.getUniqueId());
        if (in == null || phase != Phase.PLAY) { p.sendMessage(text("You can only Super Jump during a match.")); return; }
        if (in.busy()) return;
        if (!objective.allowSuperJump(in)) { in.notice = Component.text("You can't Super Jump while carrying the Rainmaker!", NamedTextColor.RED); in.noticeUntil = elapsed + 40; return; }
        menu.openJump(p, in);
    }

    /** Target is a teammate id, a location (spawn or beakon). */
    void superJump(Player p, UUID mate, Location spot) {
        Inkling in = players.get(p.getUniqueId());
        p.closeInventory();
        if (in == null || phase != Phase.PLAY || in.busy() || !objective.allowSuperJump(in)) return;
        Location from = p.getLocation();
        in.jump = new Inkling.Jump(mate, spot, from, elapsed + 20, elapsed + 44);
        weapons.cancelCharge(p, in);
        p.playSound(p, Sound.ENTITY_BREEZE_CHARGE, 1f, 1.2f);
        world.spawnParticle(Particle.DUST, from.clone().add(0, 0.5, 0), 30, 0.4, 0.6, 0.4, 0, dust(in.team));
    }

    private Location jumpTarget(Inkling in) {
        Inkling.Jump j = in.jump;
        if (j.mate() == null) return j.spot();
        Player mate = Bukkit.getPlayer(j.mate());
        Inkling mi = players.get(j.mate());
        if (mate == null || mi == null || !mi.alive() || mi.jump != null) return null;
        return mate.getLocation();
    }

    private void jumpTick(Player p, Inkling in) {
        Location target = jumpTarget(in);
        if (target == null) {
            in.jump = null;
            floating(p, false);
            in.notice = Component.text("Super Jump cancelled: your target is gone.", NamedTextColor.RED);
            in.noticeUntil = elapsed + 40;
            return;
        }
        Inkling.Jump j = in.jump;
        // The landing marker everyone can see, so enemies can wait for you.
        if (elapsed % 2 == 0) {
            double r = 1.2;
            for (int i = 0; i < 12; i++) {
                double a = i * Math.PI / 6 + elapsed * 0.2;
                world.spawnParticle(Particle.DUST, target.clone().add(Math.cos(a) * r, 0.15, Math.sin(a) * r), 1, 0, 0, 0, 0, dust(in.team));
            }
        }
        if (elapsed < j.launchAt()) {
            p.sendActionBar(Component.text("Super Jump in " + (j.launchAt() - elapsed + 19) / 20 + "…", in.team.text, TextDecoration.BOLD));
            return;
        }
        if (elapsed == j.launchAt()) {
            floating(p, true);
            world.playSound(p.getLocation(), Sound.ENTITY_WIND_CHARGE_WIND_BURST, 1f, 0.8f);
        }
        double t = Math.min(1, (elapsed - j.launchAt()) / (double) (j.landAt() - j.launchAt()));
        Vector start = j.from().toVector(), end = target.toVector();
        double height = 10 + start.distance(end) * 0.15;
        Vector at = start.clone().multiply(1 - t).add(end.clone().multiply(t)).add(new Vector(0, height * 4 * t * (1 - t), 0));
        Location next = p.getLocation();
        next.setX(at.getX()); next.setY(at.getY()); next.setZ(at.getZ());
        p.teleport(next, SMOOTH);
        p.setFallDistance(0);
        if (elapsed % 2 == 0) world.spawnParticle(Particle.DUST, next.clone().add(0, 0.5, 0), 4, 0.2, 0.2, 0.2, 0, dust(in.team));
        if (t >= 1) {
            in.jump = null;
            floating(p, false);
            p.setVelocity(new Vector(0, -0.3, 0));
            splash(new Pos(next.getBlockX(), (int) Math.floor(next.getY() - 0.05), next.getBlockZ()), in.team, 2, in);
            world.spawnParticle(Particle.BLOCK, next, 30, 1, 0.2, 1, 0, inkData.get(in.team));
            world.playSound(next, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1f, 1.1f);
            in.lastPos = next.clone();
        }
    }

    // ------------------------------------------------------------------ damage, splats and respawns

    boolean enemy(Inkling in, Player v) {
        Inkling other = players.get(v.getUniqueId());
        return other != null && other.team != in.team && other.respawnAt < 0;
    }

    void hurt(Player v, Inkling vi, double damage, Player attacker, Weapon weapon) {
        if (vi == null || phase != Phase.PLAY || vi.respawnAt >= 0 || elapsed < vi.protectedUntil || damage <= 0) return;
        Inkling ai = attacker == null ? null : players.get(attacker.getUniqueId());
        if (ai != null && ai.team == vi.team) return;
        // Enemy ink and spawn damage stay full; hits from players shrink for the outnumbered side.
        if (attacker != null || weapon != null) damage = SplatRules.damageTaken(damage, vi.team, sizes());
        vi.lastHurt = elapsed;
        if (attacker != null) { vi.lastAttacker = attacker.getUniqueId(); vi.lastWeapon = weapon; vi.damagedBy.put(attacker.getUniqueId(), elapsed); }
        double health = v.getHealth() - damage;
        if (health <= 0.01) { splat(v, vi, attacker, weapon); return; }
        v.setHealth(health);
        tint(v, vi);
        v.playHurtAnimation(attacker == null ? 0 : attacker.getLocation().getYaw() - v.getLocation().getYaw() + 180);
        world.playSound(v.getLocation(), Sound.ENTITY_PLAYER_HURT, 0.6f, 1.3f);
        world.spawnParticle(Particle.DUST, v.getLocation().add(0, 1, 0), 10, 0.3, 0.5, 0.3, 0,
                dust(ai == null ? vi.team.opponent() : ai.team));
        if (attacker != null && ai != null) {
            // Hit marker: the lower their health, the higher the ding.
            attacker.playSound(attacker, Sound.ENTITY_ARROW_HIT_PLAYER, 0.45f, (float) (1.9 - health / SplatRules.MAX_HEALTH * 0.8));
            ai.hitMarkerUntil = elapsed + 6;
            ai.hitMarkerSplat = false;
            attacker.sendActionBar(hud.hudLine(ai));
            hud.damageNumber(attacker, v, damage, false);
        }
    }

    /** Red screen edges that deepen as health drops, drawn with a private world border warning. */
    void tint(Player p, Inkling in) {
        double target = !in.alive() ? 0 : Math.max(0, 1 - p.getHealth() / maxHealth(p)) * 0.8;
        if (Math.abs(target - in.tint) < 0.04 && target > 0) return;
        in.tint = target;
        if (target < 0.05) { p.setWorldBorder(null); return; }
        WorldBorder border = Bukkit.getServer().createWorldBorder();
        border.setCenter(p.getLocation());
        border.setSize(2000);
        border.setWarningTimeTicks(0);
        border.setWarningDistance((int) Math.min(Integer.MAX_VALUE, 1000 / (1 - target)));
        p.setWorldBorder(border);
    }

    void splat(Player p, Inkling in, Player killer, Weapon weapon) {
        if (killer == null && in.lastAttacker != null && elapsed - in.lastHurt < 100) {
            killer = Bukkit.getPlayer(in.lastAttacker);
            weapon = in.lastWeapon;
        }
        Inkling ki = killer == null ? null : players.get(killer.getUniqueId());
        if (ki == null) killer = null;
        Team burst = ki == null ? in.team.opponent() : ki.team;
        Location l = p.getLocation();
        boolean voided = l.getY() < SplatArena.VOID_Y;
        objective.onSplat(p, in, l);
        if (!voided) {
            splash(new Pos(l.getBlockX(), (int) Math.floor(l.getY() - 0.05), l.getBlockZ()), burst, 2, ki);
            world.spawnParticle(Particle.DUST, l.clone().add(0, 1, 0), 40, 0.6, 0.8, 0.6, 0, dust(burst));
            world.spawnParticle(Particle.BLOCK, l.clone().add(0, 1, 0), 30, 0.5, 0.7, 0.5, 0, inkData.get(burst));
        }
        world.playSound(l, Sound.ENTITY_SLIME_DEATH, 1f, 0.8f);
        world.playSound(l, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 0.9f, 1.3f);
        in.splatted++;
        in.lastAttacker = null;
        in.streak = 0;
        in.special *= SplatRules.SPECIAL_KEPT_ON_SPLAT;
        in.specialAnnounced = false;
        in.splashdownAt = -1;
        in.slamming = false;
        in.booyahAt = -1;
        in.trizookaShots = 0;
        in.jump = null;
        in.climbing = false;
        clearModifiers(p);
        weapons.cancelCharge(p, in);
        UUID killerId = killer == null ? null : killer.getUniqueId();
        for (Map.Entry<UUID, Integer> hit : in.damagedBy.entrySet()) {
            if (hit.getKey().equals(killerId) || elapsed - hit.getValue() > 100) continue;
            Inkling helper = players.get(hit.getKey());
            Player helperPlayer = Bukkit.getPlayer(hit.getKey());
            if (helper == null || helper.team == in.team || helperPlayer == null) continue;
            helper.assists++;
            helper.special = Math.min(SplatRules.SPECIAL_MAX, helper.special + SplatRules.SPECIAL_PER_SPLAT / 2 * outnumbered(helper.team));
            helper.notice = Component.text("✚ Assist on " + in.name + "!", helper.team.text, TextDecoration.BOLD);
            helper.noticeUntil = elapsed + 30;
            helperPlayer.playSound(helperPlayer, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.7f, 1.6f);
        }
        in.damagedBy.clear();
        feed(killer, ki, weapon, p, in, voided);
        if (ki != null) rewardSplat(killer, ki, p);
        setSquid(p, in, false);
        int wait = SplatRules.respawnTicks(in.team, sizes());
        in.respawnAt = elapsed + wait;
        in.tint = 0;
        p.setWorldBorder(null);
        p.getInventory().clear();
        p.setGameMode(GameMode.SPECTATOR);
        if (killer != null && killer.isOnline() && isWorld(killer) && killer.getGameMode() != GameMode.SPECTATOR && !voided) {
            // Brief kill cam from the splatter's point of view, then the overview.
            p.teleport(killer.getLocation());
            p.setSpectatorTarget(killer);
            in.killcamUntil = elapsed + 40;
        } else {
            p.teleport(getSpectateLocation());
        }
        Component subtitle = killer == null ? text("Respawning in " + (wait + 19) / 20 + " seconds")
                : Component.text("by ", NamedTextColor.GRAY).append(Component.text(killer.getName(), ki.team.text, TextDecoration.BOLD))
                        .append(Component.text(weapon == null ? "" : " with " + weapon.title, NamedTextColor.GRAY));
        p.showTitle(Title.title(Component.text("Splatted!", NamedTextColor.RED, TextDecoration.BOLD), subtitle,
                Title.Times.times(Duration.ZERO, Duration.ofSeconds(2), Duration.ofMillis(300))));
    }

    private void rewardSplat(Player killer, Inkling ki, Player victim) {
        ki.splats++;
        ki.special = Math.min(SplatRules.SPECIAL_MAX, ki.special + SplatRules.SPECIAL_PER_SPLAT * outnumbered(ki.team));
        ki.streak = elapsed - ki.lastSplatAt <= 100 ? ki.streak + 1 : 1;
        ki.lastSplatAt = elapsed;
        ki.hitMarkerUntil = elapsed + 12;
        ki.hitMarkerSplat = true;
        hud.damageNumber(killer, victim, 0, true);
        String streak = switch (ki.streak) {
            case 1 -> "";
            case 2 -> "DOUBLE SPLAT!";
            case 3 -> "TRIPLE SPLAT!";
            default -> "UNSTOPPABLE!";
        };
        Component subtitle = Component.text("✦ Splatted " + victim.getName() + "!", ki.team.text, TextDecoration.BOLD);
        killer.showTitle(Title.title(streak.isEmpty() ? Component.empty() : Component.text(streak, NamedTextColor.YELLOW, TextDecoration.BOLD),
                subtitle, Title.Times.times(Duration.ZERO, Duration.ofMillis(900), Duration.ofMillis(250))));
        killer.playSound(killer, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.7f);
        killer.playSound(killer, Sound.ENTITY_PLAYER_LEVELUP, 0.6f, 1.6f);
        killer.playSound(killer, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
        killer.sendActionBar(hud.hudLine(ki));
        if (!streak.isEmpty()) {
            for (Player p : world.getPlayers()) {
                p.sendMessage(Component.text("★ " + killer.getName() + ": " + streak, NamedTextColor.YELLOW, TextDecoration.BOLD));
                p.playSound(p, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.6f, 1.4f);
            }
        }
    }

    private void feed(Player killer, Inkling ki, Weapon weapon, Player victim, Inkling vi, boolean voided) {
        Component name = Component.text(victim.getName(), vi.team.text);
        Component line = killer == null
                ? name.append(Component.text(voided ? " fell off the stage" : " was splatted", NamedTextColor.GRAY))
                : Component.text("✦ ", NamedTextColor.GRAY).append(Component.text(killer.getName(), ki.team.text, TextDecoration.BOLD))
                        .append(Component.text(" Lv" + stats.get(ki.id, ki.name).level(), NamedTextColor.DARK_AQUA))
                        .append(Component.text(voided ? " knocked " : " splatted ", NamedTextColor.GRAY)).append(name)
                        .append(Component.text(weapon == null ? "" : "  [" + weapon.title + "]", NamedTextColor.DARK_GRAY));
        for (Player p : world.getPlayers()) p.sendMessage(line);
    }

    private void respawn(Player p, Inkling in) {
        in.respawnAt = -1;
        in.killcamUntil = -1;
        in.ink = SplatRules.MAX_INK;
        in.protectedUntil = elapsed + SplatRules.SPAWN_PROTECTION;
        in.tint = 0;
        if (p.getGameMode() == GameMode.SPECTATOR) p.setSpectatorTarget(null);
        reset(p);
        Location spawn = spawn(in);
        p.teleport(spawn);
        in.lastPos = spawn.clone();
        equip(p, in);
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, 1, false, false, false));
        world.spawnParticle(Particle.DUST, spawn.clone().add(0, 0.3, 0), 30, 0.5, 0.6, 0.5, 0, dust(in.team));
        world.playSound(spawn, Sound.ENTITY_PLAYER_SPLASH, 0.6f, 1.6f);
        p.sendActionBar(Component.text("Back in! Slot 8 Super Jumps to a teammate.", in.team.text));
    }

    private void specialReady(Player p, Inkling in) {
        in.specialAnnounced = true;
        refreshHotbar(p, in);
        p.showTitle(Title.title(Component.empty(), Component.text("★ " + in.kit.special.title.toUpperCase(Locale.ROOT) + " READY! Slot 3 or F ★", NamedTextColor.GOLD, TextDecoration.BOLD),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(1200), Duration.ofMillis(300))));
        p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.4f);
        p.playSound(p, Sound.BLOCK_NOTE_BLOCK_CHIME, 0.8f, 2f);
    }

    // ------------------------------------------------------------------ painting

    void splash(Pos center, Team team, int radius, Inkling owner) {
        if (radius == 0) { paint(center, team, owner); return; }
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++)
                if (dx * dx + dz * dz <= radius * radius + radius)
                    for (int dy = -1; dy <= 1; dy++) paint(center.add(dx, dy, dz), team, owner);
    }

    void paint(Pos pos, Team team, Inkling owner) {
        if (!map.blueprint().paintable().contains(pos)) return;
        Team previous = paint.put(pos, team);
        if (previous == team) return;
        if (map.blueprint().turf().contains(pos)) {
            if (previous != null) turf.merge(previous, -1, Integer::sum);
            turf.merge(team, 1, Integer::sum);
            if (owner != null && owner.team == team) {
                owner.painted++;
                if (owner.splashdownAt < 0 && owner.booyahAt < 0 && owner.trizookaShots <= 0)
                    owner.special = Math.min(SplatRules.SPECIAL_MAX, owner.special + SplatRules.specialPerTurf(owner.kit.main) * outnumbered(owner.team));
            }
        }
        world.getBlockAt(pos.x(), pos.y(), pos.z()).setType(team.ink, false);
        objective.onPaint(pos, previous, team);
    }

    // ------------------------------------------------------------------ helpers

    List<Player> online() {
        // Ink shots, specials and objectives all ask for this many times per tick; build it once per tick.
        int tick = Bukkit.getCurrentTick();
        if (onlineTick != tick || onlineSize != players.size()) {
            onlineCache = players.keySet().stream().map(Bukkit::getPlayer).filter(Objects::nonNull).filter(Player::isOnline).toList();
            onlineTick = tick;
            onlineSize = players.size();
        }
        return onlineCache;
    }

    private List<Player> onlineCache = List.of();
    private int onlineTick = -1;
    private int onlineSize = -1;

    /** Explains the boosts to an outnumbered team, and to everyone else why they're so tanky. */
    private void announceUnderdog() {
        Map<Team, Integer> sizes = sizes();
        for (Team team : Team.values()) {
            double boost = SplatRules.outnumbered(team, sizes);
            if (boost <= 1) continue;
            String x = String.format(Locale.ROOT, "%.1f", boost).replace(".0", "");
            String matchup = sizes.get(team) + "v" + sizes.get(team.opponent());
            for (Player p : world.getPlayers()) {
                Inkling in = players.get(p.getUniqueId());
                if (in != null && in.team == team) {
                    p.sendMessage(Component.text("⚡ Underdog boost (" + matchup + "): ", NamedTextColor.GOLD, TextDecoration.BOLD)
                            .append(Component.text("enemy hits do 1/" + x + " damage, you respawn " + x + "× faster, and your ink and special"
                                    + (settings.mode() == SplatMode.TURF_WAR ? "" : " and objective progress") + " build " + x + "× faster.", NamedTextColor.YELLOW)));
                } else {
                    p.sendMessage(text(team.title + " is outnumbered " + matchup + ", so they get a " + x + "× underdog boost."));
                }
            }
        }
    }

    /** Underdog multiplier for a team right now; see {@link SplatRules#outnumbered}. */
    double outnumbered(Team team) { return SplatRules.outnumbered(team, sizes()); }

    Map<Team, Integer> sizes() {
        EnumMap<Team, Integer> sizes = new EnumMap<>(Team.class);
        for (Team team : Team.values()) sizes.put(team, 0);
        for (Inkling in : players.values()) sizes.merge(in.team, 1, Integer::sum);
        return sizes;
    }

    Location spawn(Inkling in) {
        List<Pos> spawns = map.blueprint().spawns().get(in.team);
        Pos s = spawns.get(in.slot % spawns.size());
        return new Location(world, s.x() + 0.5, s.y(), s.z() + 0.5, in.team == Team.ORANGE ? -90 : 90, 0);
    }

    static Pos pos(Block block) { return new Pos(block.getX(), block.getY(), block.getZ()); }

    private static final Particle.DustOptions SPECIAL_READY_DUST = new Particle.DustOptions(Color.fromRGB(0xFFD23F), 1f);
    private static final Map<Team, Particle.DustOptions> DUST = new EnumMap<>(Team.class);
    private static final Map<Team, Particle.DustOptions> TRAIL = new EnumMap<>(Team.class);
    private static final Map<Team, ItemStack> INK_ITEMS = new EnumMap<>(Team.class);

    static Particle.DustOptions dust(Team team) { return DUST.computeIfAbsent(team, t -> new Particle.DustOptions(t.color, 1.3f)); }

    static Particle.DustOptions trail(Team team) { return TRAIL.computeIfAbsent(team, t -> new Particle.DustOptions(t.color, 0.7f)); }

    static double maxHealth(Player p) {
        AttributeInstance max = p.getAttribute(Attribute.MAX_HEALTH);
        return Math.min(SplatRules.MAX_HEALTH, max == null ? SplatRules.MAX_HEALTH : max.getValue());
    }

    Weapon weaponOf(ItemStack item) {
        if (item == null || item.isEmpty()) return null;
        // Read-only view of the item's data: getItemMeta() copied the whole meta every call, and this
        // runs for every player every tick.
        String key = item.getPersistentDataContainer().get(weaponKey, PersistentDataType.STRING);
        if (key == null) return null;
        try {
            return Weapon.valueOf(key);
        } catch (IllegalArgumentException unknown) {
            return null;
        }
    }

    ItemStack weaponItem(Weapon weapon, boolean glint) {
        ItemStack item = ItemStack.of(weapon.base);
        ItemMeta meta = item.getItemMeta();
        NamedTextColor color = switch (weapon.kind) {
            case SPECIAL, OBJECTIVE -> NamedTextColor.GOLD;
            case SUB -> NamedTextColor.GREEN;
            default -> NamedTextColor.AQUA;
        };
        meta.displayName(Component.text(weapon.title, color).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text(weapon.help, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        modelString(meta, weapon.model);
        meta.getPersistentDataContainer().set(weaponKey, PersistentDataType.STRING, weapon.name());
        if (glint) meta.setEnchantmentGlintOverride(true);
        item.setItemMeta(meta);
        return item;
    }

    /** Kit selector: the main weapon's item, describing the sub and special too. */
    ItemStack kitItem(Kit kit, boolean selected) {
        ItemStack item = weaponItem(kit.main, selected);
        ItemMeta meta = item.getItemMeta();
        meta.lore(List.of(
                Component.text(kit.main.help, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("Sub: " + kit.sub.title, NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false),
                Component.text("  " + kit.sub.help, NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("Special: " + kit.special.title, NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false),
                Component.text("  " + kit.special.help, NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text(selected ? "✔ Selected" : "Click or hold to pick", selected ? NamedTextColor.GREEN : NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false)));
        item.setItemMeta(meta);
        return item;
    }

    /** Charge weapons can be "used" like a bow, so Java reports exactly when right-click is released. */
    private ItemStack chargeItem(Weapon weapon) {
        ItemStack item = weaponItem(weapon, weapon == Weapon.RAINMAKER);
        item.setData(DataComponentTypes.CONSUMABLE, Consumable.consumable().consumeSeconds(3600).animation(ItemUseAnimation.BOW)
                .hasConsumeParticles(false).sound(net.kyori.adventure.key.Key.key("minecraft", "intentionally_empty")));
        return item;
    }

    /** The ink shot's look; built once per team (every shot used to rebuild the item and its meta). */
    static ItemStack inkItem(Team team) {
        return INK_ITEMS.computeIfAbsent(team, t -> {
            ItemStack item = ItemStack.of(Weapon.PROJECTILE);
            ItemMeta meta = item.getItemMeta();
            modelString(meta, Weapon.inkModel(t));
            item.setItemMeta(meta);
            return item;
        }).clone();
    }

    /** A dropped item that never merges with other drops, for clams, bombs and gadgets. */
    ItemStack uniqueItem(Weapon weapon) {
        ItemStack item = weaponItem(weapon, false);
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(uniqueKey, PersistentDataType.STRING, UUID.randomUUID().toString());
        item.setItemMeta(meta);
        return item;
    }

    Item dropStill(Location at, ItemStack stack, boolean gravity) {
        Item item = world.dropItem(at, stack, i -> {
            i.setVelocity(new Vector());
            i.setCanPlayerPickup(false);
            i.setCanMobPickup(false);
            i.setUnlimitedLifetime(true);
            i.setWillAge(false);
            i.setGravity(gravity);
            i.setPickupDelay(Integer.MAX_VALUE);
        });
        track(item);
        return item;
    }

    static void modelString(ItemMeta meta, String model) {
        CustomModelDataComponent data = meta.getCustomModelDataComponent();
        data.setStrings(List.of(model));
        meta.setCustomModelDataComponent(data);
    }

    private void giveSelectors(Player p, Inkling in) {
        PlayerInventory inventory = p.getInventory();
        inventory.clear();
        Kit[] kits = Kit.values();
        for (int i = 0; i < kits.length && i < LOCKER_SLOT; i++) inventory.setItem(i, kitItem(kits[i], kits[i] == in.kit));
        inventory.setItem(LOCKER_SLOT, weaponItem(Weapon.LOCKER, false));
        armor(p, in);
    }

    private void equip(Player p, Inkling in) {
        p.getInventory().clear();
        in.specialAnnounced = false;
        refreshHotbar(p, in);
        p.getInventory().setHeldItemSlot(MAIN_SLOT);
        armor(p, in);
    }

    /** Rebuilds the in-match hotbar from state, only touching slots that changed so a held charge survives. */
    void refreshHotbar(Player p, Inkling in) {
        if (phase != Phase.PLAY || !in.alive()) return;
        Weapon main = in.main();
        set(p, MAIN_SLOT, main.charges() ? chargeItem(main) : weaponItem(main, main == Weapon.TRIZOOKA));
        ItemStack sub;
        if (in.powerClam) sub = weaponItem(Weapon.POWER_CLAM, true);
        else if (in.clams > 0) { sub = weaponItem(Weapon.CLAM, false); sub.setAmount(in.clams); }
        else if (in.rainmaker) sub = null;
        else sub = weaponItem(in.kit.sub, false);
        set(p, SUB_SLOT, sub);
        set(p, SPECIAL_SLOT, in.special >= SplatRules.SPECIAL_MAX && !in.rainmaker ? weaponItem(in.kit.special, true) : null);
        set(p, JUMP_SLOT, weaponItem(Weapon.SUPER_JUMP, false));
    }

    private static void set(Player p, int slot, ItemStack item) {
        ItemStack current = p.getInventory().getItem(slot);
        if (item == null) { if (current != null) p.getInventory().setItem(slot, null); return; }
        if (current == null || !current.isSimilar(item) || current.getAmount() != item.getAmount()) p.getInventory().setItem(slot, item);
    }

    void armor(Player p, Inkling in) {
        Material[] pieces = {Material.LEATHER_BOOTS, Material.LEATHER_LEGGINGS, Material.LEATHER_CHESTPLATE, Material.LEATHER_HELMET};
        ItemStack[] contents = new ItemStack[4];
        for (int i = 0; i < pieces.length; i++) {
            ItemStack item = ItemStack.of(i == 3 && in.rainmaker ? Material.GOLDEN_HELMET : pieces[i]);
            ItemMeta meta = item.getItemMeta();
            if (meta instanceof LeatherArmorMeta leather) leather.setColor(in.team.color);
            meta.setUnbreakable(true);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_DYE);
            item.setItemMeta(meta);
            contents[i] = item;
        }
        p.getInventory().setArmorContents(contents);
    }

    private void reset(Player p) {
        p.closeInventory();
        p.getInventory().clear();
        p.getActivePotionEffects().forEach(effect -> p.removePotionEffect(effect.getType()));
        clearModifiers(p);
        p.setGameMode(GameMode.ADVENTURE);
        p.setAllowFlight(false);
        p.setCollidable(false);
        p.setGlowing(false);
        p.setHealth(maxHealth(p));
        p.setFoodLevel(20);
        p.setSaturation(20);
        p.setFireTicks(0);
        p.setFallDistance(0);
        p.setVelocity(new Vector());
        p.setExp(0);
        p.setLevel(0);
        p.setWorldBorder(null);
    }

    private void detach(Player p) {
        hud.hide(p);
        viewers.remove(p.getUniqueId());
        clearModifiers(p);
        p.setCollidable(true);
        p.setGlowing(false);
        p.setWorldBorder(null);
        p.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        p.setExp(0);
        p.setLevel(0);
        if (packed.remove(p.getUniqueId()) && p.isOnline()) p.removeResourcePacks(SplatPack.PACK_ID);
    }

    void markViewer(Player p) { viewers.add(p.getUniqueId()); }

    Set<UUID> viewers() { return viewers; }

    void forgetViewer(Player p) { detach(p); }

    private void moveSpectators() {
        for (Player p : world.getPlayers()) {
            if (!isPlaying(p)) { p.setGameMode(GameMode.SPECTATOR); p.teleport(getSpectateLocation()); }
        }
    }

    public void move(PlayerMoveEvent event) {
        Player p = event.getPlayer();
        Inkling in = players.get(p.getUniqueId());
        if (in == null || event.getTo() == null) return;
        boolean frozen = phase == Phase.JUDGING || phase == Phase.RESULTS;
        boolean leavingBase = phase == Phase.COUNTDOWN && !map.inBase(in.team, event.getTo().getX());
        if (frozen || leavingBase) {
            Location held = event.getFrom().clone();
            held.setYaw(event.getTo().getYaw());
            held.setPitch(event.getTo().getPitch());
            event.setTo(held);
        }
    }

    void track(Entity e) { e.addScoreboardTag(ENTITY_TAG); entities.add(e); }

    private void clearProjectiles() {
        weapons.clear();
        for (Entity e : new HashSet<>(entities)) e.remove();
        entities.clear();
        for (Entity e : world.getEntities()) if (e instanceof Projectile || e.getScoreboardTags().contains(ENTITY_TAG)) e.remove();
    }

    private void cleanup() {
        objective.cleanup();
        clearProjectiles();
        for (Pos p : paint.keySet()) world.getBlockAt(p.x(), p.y(), p.z()).setType(SplatArena.TURF, false);
        paint.clear();
        resetCounts();
    }

    private void resetCounts() { for (Team team : Team.values()) turf.put(team, 0); }

    private void fireworks() {
        List<Color> colors = winner == null ? List.of(Team.ORANGE.color, Team.BLUE.color) : List.of(winner.color, Color.WHITE);
        for (int i = -1; i <= 1; i++) {
            Firework f = world.spawn(new Location(world, map.offsetX() + i * 8 + 0.5, 108, 0.5), Firework.class);
            var meta = f.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder().withColor(colors).withFlicker().build());
            meta.setPower(1);
            f.setFireworkMeta(meta);
            track(f);
        }
    }

    void broadcast(String message) { for (Player p : world.getPlayers()) p.sendMessage(text(message)); }

    /** Team-relative announcer line: 'ours' to that team, 'theirs' to the other, 'neutral' to spectators. */
    void callout(Team team, String ours, String theirs, String neutral) {
        for (Player p : world.getPlayers()) {
            Inkling in = players.get(p.getUniqueId());
            boolean mine = in != null && in.team == team;
            String line = in == null ? neutral : mine ? ours : theirs;
            NamedTextColor color = in == null ? team.text : mine ? NamedTextColor.GREEN : NamedTextColor.RED;
            p.showTitle(Title.title(Component.empty(), Component.text(line, color, TextDecoration.BOLD),
                    Title.Times.times(Duration.ZERO, Duration.ofMillis(1400), Duration.ofMillis(300))));
            p.sendMessage(Component.text("» " + line, color));
            if (in == null) p.playSound(p, Sound.BLOCK_NOTE_BLOCK_BELL, 0.7f, 1.2f);
            else if (mine) { p.playSound(p, Sound.BLOCK_NOTE_BLOCK_PLING, 0.9f, 1.8f); p.playSound(p, Sound.BLOCK_NOTE_BLOCK_PLING, 0.6f, 1.35f); }
            else { p.playSound(p, Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.7f); p.playSound(p, Sound.BLOCK_NOTE_BLOCK_DIDGERIDOO, 0.6f, 0.8f); }
        }
    }

    /** Relative teleport that keeps the player's own view and momentum smooth. */
    static void nudge(Player p, double dx, double dy, double dz) {
        p.teleport(p.getLocation().add(dx, dy, dz), SMOOTH);
    }
}
