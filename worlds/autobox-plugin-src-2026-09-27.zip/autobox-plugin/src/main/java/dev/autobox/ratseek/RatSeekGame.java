package dev.autobox.ratseek;

import dev.autobox.util.Sidebar;
import dev.autobox.AutoBoxPlugin;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * Rat and Seek: up to three humans hunt half-sized rats through a house full of
 * crawlspaces. Rats score by stealing cheese and using noisy taunts, and can
 * trade stolen cheese to rescue one caged teammate or bank automatic escapes.
 */
public final class RatSeekGame implements Listener {
    public static final String WORLD_NAME = "rat_and_seek_arena";

    private static final int BASEMENT_Y = RatSeekHouse.CELLAR;
    private static final int ATTIC_FLOOR_Y = RatSeekHouse.ATTIC;
    private static final int TAUNT_COOLDOWN = 300;
    private static final int DASH_COOLDOWN = 240;
    private static final int SCENT_COOLDOWN = 300;
    private static final int RATTLE_COOLDOWN = 300;
    private static final int COMBO_WINDOW = 240;
    private static final int MAX_PLAYERS = 10;
    private static final int MAX_HUMANS = 3;
    private static final int CHEESE_RESPAWN = 240;
    private static final int CHEESE_RAIN_BONUS = 6;
    private static final int MAX_BANKED_ESCAPES = 1;
    private static final int SECRET_PASSAGE_WARNING = 60;
    private static final int SECRET_PASSAGE_LIMIT = 120;
    private static final int FINAL_FRENZY_TICKS = 1200;

    private static final LocationKey CAGE = locationKey(RatSeekHouse.CAGE);
    private static final LocationKey HUMAN_RELEASE = locationKey(RatSeekHouse.RELEASE);

    private enum Phase { INTRO, HIDING, HUNTING }

    private enum RatState { FREE, CAGED }

    private record LocationKey(double x, double y, double z) { }

    private record SecretPassage(String name, int minX, int maxX, int minY, int maxY, int minZ, int maxZ,
                                 LocationKey exitA, LocationKey exitB) {
        boolean contains(Location location) {
            return location.getBlockX() >= minX && location.getBlockX() <= maxX
                    && location.getBlockY() >= minY && location.getBlockY() <= maxY
                    && location.getBlockZ() >= minZ && location.getBlockZ() <= maxZ;
        }
    }

    private record Room(String name, int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
        boolean contains(Location location) {
            return location.getBlockX() >= minX && location.getBlockX() <= maxX
                    && location.getBlockY() >= minY && location.getBlockY() <= maxY
                    && location.getBlockZ() >= minZ && location.getBlockZ() <= maxZ;
        }
    }

    private final AutoBoxPlugin plugin;
    private final World world;
    private final Location lobby;
    private final NamespacedKey itemKey;
    private final NamespacedKey humanSpeedModifierKey;
    private final Random random = new Random();
    private final Set<UUID> players = new LinkedHashSet<>();
    private final Map<UUID, RatState> rats = new HashMap<>();
    private final Map<UUID, Integer> points = new HashMap<>();
    private final Map<UUID, Integer> carriedCheese = new HashMap<>();
    private final Map<UUID, Integer> tauntCooldowns = new HashMap<>();
    private final Map<UUID, Integer> dashCooldowns = new HashMap<>();
    private final Map<UUID, Integer> rattleCooldowns = new HashMap<>();
    private final Map<UUID, Integer> cheeseCombos = new HashMap<>();
    private final Map<UUID, Integer> comboTicks = new HashMap<>();
    private final Map<UUID, Integer> bankedEscapes = new HashMap<>();
    private final Map<UUID, Integer> secretPassageTicks = new HashMap<>();
    /** How long each rat has sat on a perch no seeker can reach. */
    private final Map<UUID, Integer> perchTicks = new HashMap<>();
    private final Set<UUID> secretPassageOccupants = new HashSet<>();
    private final List<UUID> cageOrder = new ArrayList<>();
    private final Set<Location> arenaBlocks = new HashSet<>();
    private static RatSeekHouse blueprint;
    /** False until the house has been fully placed once since boot (then only match changes are fixed). */
    private boolean houseBuilt;
    private final Map<UUID, Sidebar> sidebars = new HashMap<>();
    private final List<Location> ratSpawns = new ArrayList<>();
    private final List<Location> cheeseSpots = new ArrayList<>();
    private final List<Item> cheeseItems = new ArrayList<>();
    private final List<Integer> cheeseRespawns = new ArrayList<>();
    private final List<Room> rooms = new ArrayList<>();
    private final List<SecretPassage> secretPassages = new ArrayList<>();
    // Per-match highlight counters for the podium awards.
    private final Map<UUID, Integer> catchesBy = new HashMap<>();
    private final Map<UUID, Integer> tauntsBy = new HashMap<>();
    private final Map<UUID, Integer> escapesBy = new HashMap<>();
    private UUID fastestCatcher;
    private String fastestCatchVictim;
    private int fastestCatchTicks;
    private int huntStartTick;
    private String twistBanner;
    private int twistBannerUntil;

    private boolean running;
    private UUID host;
    private final Set<UUID> humans = new LinkedHashSet<>();
    private final RatSeekBots bots;
    private final Map<UUID, Integer> swatCooldowns = new HashMap<>();
    /** The tunnel each free rat is currently inside, to learn which end it leaves by. */
    private final Map<UUID, SecretPassage> passageOf = new HashMap<>();
    private Phase phase;
    private int phaseTicks;
    private int hintTicks;
    private int scentCooldown;
    private int twistTicks;
    private int ticks;
    private boolean lastRatRush;
    private RatSeekSettings.Twist lastTwist;
    private final RatSeekSettings settings = new RatSeekSettings();
    private final RatSeekMenu menu;
    /** Rats whose escape card came from the Starting Escape Card setting, so it can be revoked. */
    private final Set<UUID> startingEscapes = new HashSet<>();
    /** True between a match's result and the delayed teardown; a new match must not start then. */
    private boolean ending;
    private BukkitTask endTask;
    private BukkitTask task;
    private Villager cheeseKeeper;
    private final RatCostume costume;
    private final RatSeekShow show;
    private final RatSeekGadgets gadgets;
    private final RatSeekAbilities abilities;
    private final RatSeekHouseLife houseLife;
    private final RatSeekRecords records;
    private final Map<UUID, Integer> cheeseGrabbed = new HashMap<>();
    private final Map<UUID, Integer> firstCatchTicks = new HashMap<>();
    private Predicate<Player> lobbyHostCheck = player -> false;
    private Predicate<Player> lobbyCanStart = player -> false;
    private Consumer<Player> lobbyStarter = player -> { };
    private Supplier<List<Player>> lobbyRoster = List::of;
    /** Exact humans the lobby host picked for the next match; empty = the Starting Humans setting decides. */
    private final Set<UUID> lobbyHumans = new LinkedHashSet<>();

    public RatSeekGame(AutoBoxPlugin plugin, World world, Location lobby) {
        this.plugin = plugin;
        this.world = world;
        this.lobby = lobby;
        this.itemKey = new NamespacedKey(plugin, "ratseek_item");
        this.humanSpeedModifierKey = new NamespacedKey(plugin, "ratseek_human_speed");
        this.menu = new RatSeekMenu(itemKey);
        this.costume = new RatCostume(itemKey);
        this.show = new RatSeekShow(plugin, world, itemKey);
        this.gadgets = new RatSeekGadgets(this, world, itemKey);
        this.abilities = new RatSeekAbilities(this, world, itemKey);
        this.houseLife = new RatSeekHouseLife(this, world, itemKey);
        this.records = new RatSeekRecords(plugin);
        this.bots = new RatSeekBots(this, plugin, world, itemKey);
    }

    /** Lets the lobby queue open the settings menu and start the match from it. */
    public void setLobbyHooks(Predicate<Player> isQueueHost, Predicate<Player> canStart, Consumer<Player> starter,
                              Supplier<List<Player>> roster) {
        this.lobbyRoster = roster;
        this.lobbyHostCheck = isQueueHost;
        this.lobbyCanStart = canStart;
        this.lobbyStarter = starter;
    }

    public void start(CommandSender sender, List<Player> roster) {
        if (running || ending) {
            sender.sendMessage(Component.text(ending ? "The last Rat and Seek match is still wrapping up."
                    : "Rat and Seek is already running.", NamedTextColor.RED));
            return;
        }
        List<Player> online = roster.stream().filter(Player::isOnline).limit(MAX_PLAYERS).toList();
        if (online.size() < minimumPlayers() || online.size() > MAX_PLAYERS) {
            sender.sendMessage(Component.text("Rat and Seek needs " + minimumPlayers()
                    + "-10 players for these settings.", NamedTextColor.RED));
            return;
        }

        bots.clear();
        resetArena();
        buildArena();
        RatSeekBots.warmUp();
        players.clear();
        humans.clear();
        swatCooldowns.clear();
        rats.clear();
        points.clear();
        carriedCheese.clear();
        tauntCooldowns.clear();
        dashCooldowns.clear();
        rattleCooldowns.clear();
        cheeseCombos.clear();
        comboTicks.clear();
        bankedEscapes.clear();
        secretPassageTicks.clear();
        secretPassageOccupants.clear();
        perchTicks.clear();
        passageOf.clear();
        cageOrder.clear();
        catchesBy.clear();
        cheeseGrabbed.clear();
        firstCatchTicks.clear();
        tauntsBy.clear();
        escapesBy.clear();
        fastestCatcher = null;
        fastestCatchVictim = null;
        fastestCatchTicks = 0;
        huntStartTick = 0;
        twistBanner = null;
        twistBannerUntil = 0;
        ticks = 0;
        phase = settings.cinematic ? Phase.INTRO : Phase.HIDING;
        phaseTicks = settings.cinematic ? RatSeekShow.INTRO_TICKS : settings.hideTicks();
        hintTicks = 400;
        scentCooldown = 0;
        twistTicks = nextTwistDelay();
        lastRatRush = false;
        lastTwist = null;
        startingEscapes.clear();
        running = true;

        host = online.getFirst().getUniqueId();
        // Exact lobby picks win; otherwise scale the opening team so large lobbies stay fun, with
        // AI seekers filling Auto's slots first. The host can still swap roles during hiding.
        int humanRoom = Math.max(0, Math.min(MAX_HUMANS - settings.aiSeekers, online.size() - 1));
        List<Player> picked = online.stream().filter(p -> lobbyHumans.contains(p.getUniqueId())).toList();
        if (!picked.isEmpty()) {
            for (int i = 0; i < Math.min(picked.size(), humanRoom); i++) {
                humans.add(picked.get(i).getUniqueId());
            }
        } else {
            int autoHumans = online.size() >= 10 ? 3 : online.size() >= 7 ? 2 : 1;
            int openingHumans = settings.humanCount > 0 ? settings.humanCount
                    : settings.humanCount < 0 ? 0 : Math.max(0, autoHumans - settings.aiSeekers);
            if (settings.aiSeekers == 0) {
                openingHumans = Math.max(1, openingHumans);
            }
            openingHumans = Math.min(openingHumans, humanRoom);
            List<Player> shuffledRoster = new ArrayList<>(online);
            java.util.Collections.shuffle(shuffledRoster, random);
            for (int i = 0; i < openingHumans; i++) {
                humans.add(shuffledRoster.get(i).getUniqueId());
            }
        }
        for (Player player : online) {
            UUID id = player.getUniqueId();
            players.add(id);
            if (!humans.contains(id)) {
                rats.put(id, RatState.FREE);
                points.put(id, 0);
                carriedCheese.put(id, 0);
            }
        }
        for (Player player : online) {
            player.sendMessage(Component.text("Your Rat and Seek career: ", NamedTextColor.GRAY)
                    .append(Component.text(records.summary(player.getUniqueId()), NamedTextColor.AQUA)));
        }
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setStorm(false);
        world.setTime(settings.cinematic ? 18000 : 6000);

        spawnInitialCheese();
        if (phase == Phase.INTRO) {
            for (Player player : online) {
                preparePlayer(player);
            }
            show.beginIntro(online, (humans.size() + settings.aiSeekers) + " SEEKERS vs "
                    + rats.size() + (rats.size() == 1 ? " RAT" : " RATS"));
        } else {
            beginHiding();
        }
        updateScoreboard();
        updateBossBar();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    /** Places every player for the hiding countdown, after the intro camera if there is one. */
    private void beginHiding() {
        if (phase == Phase.INTRO) {
            show.endIntro(onlinePlayers());
        }
        phase = Phase.HIDING;
        phaseTicks = settings.hideTicks();
        List<Location> shuffledSpawns = new ArrayList<>(ratSpawns);
        java.util.Collections.shuffle(shuffledSpawns, random);
        int spawn = 0;
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            preparePlayer(player);
            if (humans.contains(id)) {
                prepareHuman(player);
            } else {
                prepareRat(player, shuffledSpawns.get(spawn++ % shuffledSpawns.size()));
            }
        }
        syncBotSeekers();
        bots.startHiding(settings);
        giveHostRoleSelector();
        broadcast(Component.text("Welcome to the manor! " + settings.hideSeconds
                + " seconds to hide: 4 floors, 16 furnished rooms, a greenhouse and 4 noisy tunnels!",
                NamedTextColor.GOLD));
        broadcastRules();
        if (settings.rescues) {
            broadcast(Component.text("Trade " + settings.rescueCost
                    + " cheese to rescue a friend, or bank 1 escape when the cage is empty!", NamedTextColor.GOLD));
        }
        broadcast(Component.text("Seekers: " + humans.size() + " player + " + bots.count() + " AI / " + MAX_HUMANS
                + " — the host can tweak settings and roles during hiding.",
                NamedTextColor.RED));
        for (UUID humanId : humans) {
            Player seeker = Bukkit.getPlayer(humanId);
            if (seeker != null) {
                seeker.sendTitle("§c§lYOU ARE THE HUMAN", settings.blindfold
                        ? "§fBlindfolded while the rats hide..." : "§fWait for the rats to hide", 10, 60, 10);
            }
        }
        updateScoreboard();
    }

    private List<Player> onlinePlayers() {
        List<Player> result = new ArrayList<>();
        forEachPlayer(result::add);
        return result;
    }

    /** Also true while a finished match is wrapping up, so the lobby cannot start another. */
    public boolean isRunning() {
        return running || ending;
    }

    /** Opens the host settings from the lobby queue; anyone else gets a read-only view. */
    public void openLobbySettings(Player player) {
        if (running || ending) {
            player.sendMessage(Component.text("Rat and Seek is in progress — settings open again after this round.",
                    NamedTextColor.RED));
            return;
        }
        openMenu(player, RatSeekMenu.Page.MAIN, true);
    }

    /** Short "Normal preset • 30s hide • 4 min hunt" line for lobby chat. */
    public String settingsSummary() {
        return settings.preset().displayName + " preset • " + settings.hideSeconds + "s hide • "
                + settings.huntMinutes + " min hunt • " + settings.aiSeekers + " AI seekers";
    }

    public int minimumPlayers() { return settings.aiSeekers > 0 ? 1 : 2; }

    public boolean isPlaying(Player player) {
        return running && players.contains(player.getUniqueId());
    }

    public boolean isWorld(Player player) {
        return player.getWorld() == world;
    }

    public Location getSpectateLocation() {
        return new Location(world, 0.5, ATTIC_FLOOR_Y + 22, 28.5, 180, 40);
    }

    public void handleHit(EntityDamageByEntityEvent event, Player attacker, Player victim) {
        event.setCancelled(true);
        if (!running || phase != Phase.HUNTING || !humans.contains(attacker.getUniqueId())) {
            return;
        }
        if (isInCobweb(attacker)) {
            attacker.sendActionBar(Component.text("You cannot catch a rat while stuck in a cobweb!",
                    NamedTextColor.RED));
            return;
        }
        if (rats.get(victim.getUniqueId()) != RatState.FREE) {
            return;
        }
        cageRat(victim, attacker);
    }

    /** Reach through an open, one-block furniture gap with a deliberate short sword swing. */
    private void swatUnderFurniture(Player seeker) {
        if (phase != Phase.HUNTING || !humans.contains(seeker.getUniqueId()) || isInCobweb(seeker)) return;
        if (swatCooldowns.getOrDefault(seeker.getUniqueId(), 0) > ticks) return;
        swatCooldowns.put(seeker.getUniqueId(), ticks + 12);
        Player best = null;
        double bestDistance = 2.7 * 2.7;
        Location eye = seeker.getEyeLocation();
        Vector facing = eye.getDirection().normalize();
        for (UUID id : freeRats()) {
            Player rat = Bukkit.getPlayer(id);
            if (rat == null || rat.getWorld() != world) continue;
            Location ratPoint = rat.getLocation().add(0, Math.min(0.35, rat.getHeight() * 0.6), 0);
            Vector toRat = ratPoint.toVector().subtract(eye.toVector());
            double distance = seeker.getLocation().distanceSquared(rat.getLocation());
            if (distance >= bestDistance || toRat.lengthSquared() < 0.01
                    || facing.dot(toRat.normalize()) < 0.82 || !lowLineOfSight(seeker.getLocation(), rat)) continue;
            best = rat;
            bestDistance = distance;
        }
        if (best != null) cageRat(best, seeker);
    }

    private boolean lowLineOfSight(Location from, Player rat) {
        if (from.getWorld() != rat.getWorld() || Math.abs(from.getY() - rat.getLocation().getY()) > 1.2) return false;
        Location origin = from.clone().add(0, 0.38, 0);
        Location target = rat.getLocation().add(0, Math.min(0.36, rat.getHeight() * 0.6), 0);
        Vector ray = target.toVector().subtract(origin.toVector());
        return ray.lengthSquared() < 0.01 || world.rayTraceBlocks(origin, ray, ray.length(),
                FluidCollisionMode.NEVER, true) == null;
    }

    private void syncBotSeekers() {
        bots.sync(Math.min(settings.aiSeekers, MAX_HUMANS - humans.size()), settings, phase == Phase.HUNTING);
    }

    // ------------------------------------------------------------------ AI seeker hooks

    /** True only while a match is actually being played (not while a finished one wraps up). */
    boolean inProgress() {
        return running;
    }

    RatSeekAbilities abilities() {
        return abilities;
    }

    Location botEye(UUID bot) {
        return bots.eyeOf(bot);
    }

    boolean scentReady() {
        return running && phase == Phase.HUNTING && settings.scentPulse && scentCooldown == 0;
    }

    /** An AI seeker's Scent Pulse: same shared cooldown and same glow as a human's. Returns the rat, or null. */
    Player botScentPulse(Location origin) {
        if (!scentReady()) {
            return null;
        }
        Player nearest = nearestFreeRat(origin);
        if (nearest == null) {
            return null;
        }
        scentCooldown = SCENT_COOLDOWN;
        nearest.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 50, 0, false, false, false));
        world.playSound(origin, Sound.ENTITY_SNIFFER_SEARCHING, 1.2f, 1.4f);
        world.spawnParticle(Particle.SNEEZE, origin.clone().add(0, 1.6, 0), 24, 0.8, 0.4, 0.8, 0.03);
        return nearest;
    }

    /** Returns true if the rat went to the cage (false if an escape card saved it). */
    boolean botCatch(String botName, Player rat) {
        boolean escapes = bankedEscapes.getOrDefault(rat.getUniqueId(), 0) > 0;
        if (!escapes) {
            broadcast(Component.text(botName + " caught " + rat.getName() + "!", NamedTextColor.RED));
        }
        cageRat(rat, null);
        return !escapes;
    }

    boolean hasEscapeCard(Player rat) {
        return bankedEscapes.getOrDefault(rat.getUniqueId(), 0) > 0;
    }

    int cagedCount() {
        return cageOrder.size();
    }

    boolean cheeseNear(Location at, double radius) {
        for (Item item : cheeseItems) {
            if (item.isValid() && item.getLocation().distanceSquared(at) < radius * radius) {
                return true;
            }
        }
        return false;
    }

    /** Chat to the match without the game prefix, e.g. an AI seeker talking. */
    void chat(Component message) {
        forEachPlayer(player -> player.sendMessage(message));
    }

    /** Every seeker's name and position, humans and AI. */
    Map<String, Location> seekerMarkers() {
        Map<String, Location> markers = new java.util.LinkedHashMap<>();
        for (Player seeker : humanPlayers()) {
            markers.put(seeker.getName(), seeker.getLocation());
        }
        markers.putAll(bots.markers());
        return markers;
    }

    void chandelierFalling(Location floor, int ticksLeft, Location puller) {
        bots.chandelierFalling(floor, ticksLeft, puller);
    }

    int chandelierHitsBots(Location floor) {
        return bots.chandelierCrash(floor);
    }

    void trapSnapped(UUID owner, Location at, Player rat) {
        bots.trapSnapped(owner, at, rat);
    }

    void baitBitten(UUID owner, Location at, Player rat) {
        bots.baitBitten(owner, at, rat);
    }

    public void handleDeath(Player player) {
        UUID id = player.getUniqueId();
        if (rats.get(id) == RatState.FREE) {
            Bukkit.getScheduler().runTask(plugin, () -> cageRat(player, null));
            return;
        }
        if (rats.get(id) == RatState.CAGED) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (running && rats.get(id) == RatState.CAGED && player.isOnline()) {
                    player.teleport(toLocation(CAGE));
                }
            });
            return;
        }
        if (humans.contains(id)) {
            // Humans never truly die: send them back to the release (or waiting booth).
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!running || !players.contains(id) || !player.isOnline()) {
                    return;
                }
                Location back = phase == Phase.HIDING
                        ? toLocation(locationKey(RatSeekHouse.WAITING)).setDirection(new Vector(0, 0, -1))
                        : toLocation(HUMAN_RELEASE).setDirection(new Vector(0, 0, -1));
                back.add((random.nextDouble() - 0.5) * 2, 0, (random.nextDouble() - 0.5) * 2);
                preparePlayer(player);
                prepareHuman(player);
                player.teleport(back);
                if (id.equals(host)) {
                    giveHostRoleSelector();
                }
            });
        }
    }

    void announce(Component message) {
        broadcast(message);
    }

    boolean isThief(UUID id) {
        return settings.classes && abilities.is(id, RatClass.THIEF);
    }

    void hunterFrenzy() {
        scentCooldown = 0;
        bots.frenzy(100);
        for (Player seeker : humanPlayers()) {
            seeker.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 3, false, false, true));
            seeker.playSound(seeker.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 0.8f, 1.3f);
        }
    }

    RatSeekGadgets gadgets() {
        return gadgets;
    }

    List<Item> cheeseAndBaitItems() {
        List<Item> items = new ArrayList<>(cheeseItems);
        for (Item item : world.getEntitiesByClass(Item.class)) {
            if (gadgets.isBait(item)) {
                items.add(item);
            }
        }
        return items;
    }

    void addPoints(UUID id, int amount) {
        if (rats.containsKey(id)) {
            points.merge(id, amount, Integer::sum);
            updateScoreboard();
        }
    }

    boolean isFreeRat(UUID id) {
        return rats.get(id) == RatState.FREE;
    }

    boolean inSecretPassage(Location location) {
        return secretPassageAt(location) != null;
    }

    /** The cage yard and keeper stay clear of gadgets so rescues are never blocked. */
    boolean nearCageOrKeeper(Location location) {
        return "rescue courtyard".equals(roomAt(location)) || "cage yard".equals(roomAt(location))
                || location.distanceSquared(toLocation(CAGE)) < 36;
    }

    public boolean isHuman(Player player) {
        return player != null && humans.contains(player.getUniqueId());
    }

    public int humanCount() {
        return humans.size();
    }

    List<Player> humanPlayers() {
        List<Player> result = new ArrayList<>();
        for (UUID id : humans) {
            Player seeker = Bukkit.getPlayer(id);
            if (seeker != null && seeker.isOnline()) {
                result.add(seeker);
            }
        }
        return result;
    }

    /** A compass alarm for every seeker; AI seekers treat it as a lead to check out. */
    void pointHumanCompasses(Location target) {
        for (Player seeker : humanPlayers()) {
            seeker.setCompassTarget(target);
        }
        if (running && phase == Phase.HUNTING) {
            bots.alert(target);
        }
    }

    void notifyHumans(Component message) {
        for (Player seeker : humanPlayers()) {
            seeker.sendActionBar(message);
        }
    }

    public void handleQuit(Player player) {
        UUID id = player.getUniqueId();
        sidebars.remove(id);
        if (!players.remove(id)) {
            return;
        }
        restorePlayer(player);
        player.getInventory().clear();
        show.hideBar(player);
        if (player.getGameMode() == GameMode.SPECTATOR) {
            // Leaving during the intro camera must not strand the player in spectator mode.
            player.setSpectatorTarget(null);
            player.setGameMode(GameMode.ADVENTURE);
        }
        if (player.getOpenInventory().getTopInventory().getHolder() instanceof RatSeekMenu.Holder) {
            player.closeInventory();
        }
        boolean wasHuman = humans.remove(id);
        gadgets.forget(id);
        abilities.forget(id);
        startingEscapes.remove(id);
        rats.remove(id);
        points.remove(id);
        carriedCheese.remove(id);
        tauntCooldowns.remove(id);
        dashCooldowns.remove(id);
        rattleCooldowns.remove(id);
        cheeseCombos.remove(id);
        comboTicks.remove(id);
        bankedEscapes.remove(id);
        secretPassageTicks.remove(id);
        secretPassageOccupants.remove(id);
        passageOf.remove(id);
        cageOrder.remove(id);
        if (id.equals(host) && !players.isEmpty()) {
            // Keep the role selector usable when the host leaves mid-match.
            UUID nextHost = players.iterator().next();
            host = nextHost;
            Player nextHostPlayer = Bukkit.getPlayer(nextHost);
            if (nextHostPlayer != null && nextHostPlayer.isOnline() && running) {
                giveHostRoleSelector();
                nextHostPlayer.sendMessage(Component.text("You are now the Rat and Seek host.",
                        NamedTextColor.GOLD));
            }
        }
        if (!running) {
            return;
        }
        if (wasHuman) {
            if (humans.isEmpty() && bots.count() == 0) {
                finish(false, "The seekers fled. The rats win!");
            } else if (rats.isEmpty() || freeRatCount() == 0) {
                finish(true, "Every remaining rat is caged. The humans win!");
            } else {
                broadcast(Component.text(player.getName() + " (human) left the hunt. "
                        + (humans.size() + bots.count()) + " seeker(s) remain.", NamedTextColor.GRAY));
                updateScoreboard();
            }
        } else if (rats.isEmpty() || freeRatCount() == 0) {
            finish(true, "Every remaining rat is caged. The humans win!");
        } else {
            broadcast(Component.text(player.getName() + " scurried away from the match.", NamedTextColor.GRAY));
            updateScoreboard();
        }
    }

    public void endGame() {
        if (!running && !ending) {
            return;
        }
        bots.clear();
        running = false;
        ending = false;
        if (endTask != null) {
            endTask.cancel();
            endTask = null;
        }
        if (task != null) {
            task.cancel();
            task = null;
        }
        show.reset(world.getPlayers());
        costume.clear();
        for (Player player : new ArrayList<>(world.getPlayers())) {
            restorePlayer(player);
            player.getInventory().clear();
            player.setGameMode(GameMode.ADVENTURE);
            player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
            player.teleport(lobby);
        }
        players.clear();
        humans.clear();
        rats.clear();
        secretPassageTicks.clear();
        secretPassageOccupants.clear();
        cageOrder.clear();
        startingEscapes.clear();
        // Host settings deliberately survive the round so "play again" keeps the same rules.
        resetArena();
    }

    public void shutdown() {
        bots.clear();
        if (task != null) {
            task.cancel();
            task = null;
        }
        if (endTask != null) {
            endTask.cancel();
            endTask = null;
        }
        show.reset(world.getPlayers());
        for (Player player : world.getPlayers()) {
            restorePlayer(player);
        }
        costume.clear();
        running = false;
        ending = false;
        resetArena();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!isWorld(player)) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        if (!running || event.getHand() != EquipmentSlot.HAND
                || (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK)) {
            return;
        }
        if (event.getClickedBlock() != null && event.getClickedBlock().getType() == Material.LEVER
                && houseLife.useLever(player, event.getClickedBlock(), settings, humans.contains(player.getUniqueId()),
                rats.get(player.getUniqueId()) == RatState.FREE, phase == Phase.HUNTING)) {
            updateScoreboard();
            return;
        }
        ItemStack item = event.getItem();
        if (item != null) {
            String tag = tagOf(item);
            if ("catcher".equals(tag)) {
                swatUnderFurniture(player);
                return;
            }
            if (gadgets.use(player, tag, event.getClickedBlock(), event.getBlockFace(), settings,
                    phase == Phase.HUNTING)) {
                updateScoreboard();
                return;
            }
            if ("ability".equals(tag)) {
                if (phase == Phase.HUNTING && rats.get(player.getUniqueId()) == RatState.FREE) {
                    abilities.use(player, settings);
                    updateScoreboard();
                } else {
                    player.sendActionBar(Component.text("Abilities work while you're free during the hunt.",
                            NamedTextColor.RED));
                }
            } else if ("class_picker".equals(tag)) {
                openMenu(player, RatSeekMenu.Page.CLASSES, false);
            } else if ("taunt".equals(tag)) {
                taunt(player);
            } else if ("dash".equals(tag)) {
                dash(player);
            } else if ("scent".equals(tag)) {
                scentPulse(player);
            } else if ("rattle".equals(tag)) {
                rattleCage(player);
            } else if ("role_selector".equals(tag)) {
                if (phase != Phase.HIDING) {
                    player.sendActionBar(Component.text("Roles can only be assigned during hiding.", NamedTextColor.RED));
                }
                openMenu(player, phase == Phase.HIDING ? RatSeekMenu.Page.ROLES : RatSeekMenu.Page.MAIN, false);
            } else if ("difficulty_selector".equals(tag)) {
                openMenu(player, RatSeekMenu.Page.MAIN, false);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onMenuClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof RatSeekMenu.Holder holder)) {
            return;
        }
        // Cancel every click, including shift-clicks from the player's own inventory,
        // so ability items can never be moved into (and lost with) a virtual menu.
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)
                || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }
        String tag = menu.tagOf(event.getCurrentItem());
        if (tag == null || "noop".equals(tag)) {
            return;
        }
        switch (tag) {
            case "action:close" -> {
                player.closeInventory();
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 0.8f);
                return;
            }
            case "nav:main", "nav:twists", "nav:roles", "nav:extras" -> {
                RatSeekMenu.Page page = RatSeekMenu.Page.valueOf(tag.substring(4).toUpperCase(Locale.ROOT));
                player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1f, 1.2f);
                Bukkit.getScheduler().runTask(plugin, () -> openMenu(player, page, holder.lobby));
                return;
            }
            case "action:start" -> {
                player.closeInventory();
                if (holder.lobby && canEditSettings(player, true)) {
                    Bukkit.getScheduler().runTask(plugin, () -> lobbyStarter.accept(player));
                }
                return;
            }
            default -> { }
        }
        if (holder.page == RatSeekMenu.Page.CLASSES) {
            if (tag.startsWith("class:") && running && phase == Phase.HIDING && rats.containsKey(player.getUniqueId())) {
                RatClass picked = RatClass.valueOf(tag.substring("class:".length()));
                String failure = abilities.choose(player.getUniqueId(), picked, rats.size());
                if (failure != null) {
                    player.sendActionBar(Component.text(failure, NamedTextColor.RED));
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1.2f);
                } else {
                    player.sendActionBar(Component.text("You are a " + picked.displayName + "! "
                            + picked.abilityName + " unlocks when the hunt starts.", picked.color));
                    player.playSound(player.getLocation(), Sound.ENTITY_RABBIT_AMBIENT, 1f, 1.6f);
                    giveRatKit(player);
                }
            }
            refreshMenu(player, holder);
            return;
        }
        if (!canEditSettings(player, holder.lobby)) {
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1.2f);
            refreshMenu(player, holder);
            return;
        }
        if (holder.page == RatSeekMenu.Page.ROLES && !"set:bots".equals(tag)) {
            if ("action:shuffle".equals(tag) && !holder.lobby) {
                shuffleRoles(player);
            } else if ("action:clearpicks".equals(tag) && holder.lobby) {
                lobbyHumans.clear();
                player.sendActionBar(Component.text("Picks cleared — Starting Humans decides again.", NamedTextColor.AQUA));
            } else if (tag.startsWith("role:")) {
                try {
                    UUID target = UUID.fromString(tag.substring("role:".length()));
                    if (holder.lobby) {
                        toggleLobbyPick(player, target);
                    } else {
                        toggleHumanRole(player, target);
                    }
                } catch (IllegalArgumentException ignored) {
                    // Only game-created player heads are actionable.
                }
            }
        } else {
            String change = applySetting(tag, event.isRightClick() ? -1 : 1);
            if (change != null) {
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f,
                        event.isRightClick() ? 1.0f : 1.4f);
                if (running) {
                    applyLiveSettings();
                    broadcast(Component.text("Host changed ", NamedTextColor.GRAY)
                            .append(Component.text(change, NamedTextColor.AQUA)));
                } else {
                    player.sendActionBar(Component.text(change, NamedTextColor.AQUA));
                }
            }
        }
        refreshMenu(player, holder);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDecoyAttack(io.papermc.paper.event.player.PrePlayerAttackEntityEvent event) {
        if (!isWorld(event.getPlayer()) || !abilities.isDecoy(event.getAttacked())) {
            return;
        }
        event.setCancelled(true);
        if (running && phase == Phase.HUNTING && humans.contains(event.getPlayer().getUniqueId())) {
            abilities.hitDecoy(event.getAttacked(), event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDecoyManipulate(org.bukkit.event.player.PlayerArmorStandManipulateEvent event) {
        if (abilities.isDecoy(event.getRightClicked())) {
            event.setCancelled(true);
        }
    }

    /** Costume armour stays on: no clicking it off, shift-swapping or hotbar-swapping into armour slots. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCostumeClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player && isWorld(player)
                && (event.getSlotType() == InventoryType.SlotType.ARMOR || costume.isCostume(event.getCurrentItem())
                || costume.isCostume(event.getCursor()))) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onMenuDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof RatSeekMenu.Holder) {
            event.setCancelled(true);
        }
    }

    /** Applies one menu setting and returns a human-readable change, or null if nothing changed. */
    private String applySetting(String tag, int direction) {
        RatSeekSettings s = settings;
        if (tag.startsWith("preset:")) {
            RatSeekSettings.Preset preset = RatSeekSettings.Preset.valueOf(tag.substring("preset:".length()));
            s.applyPreset(preset);
            return "preset → " + preset.displayName;
        }
        if (tag.startsWith("twist:")) {
            String name = tag.substring("twist:".length());
            if ("all".equals(name)) {
                s.twists.addAll(java.util.EnumSet.allOf(RatSeekSettings.Twist.class));
                return "twists → all enabled";
            }
            if ("none".equals(name)) {
                s.twists.clear();
                return "twists → all disabled";
            }
            RatSeekSettings.Twist twist = RatSeekSettings.Twist.valueOf(name);
            boolean on = s.twists.add(twist) || !s.twists.remove(twist);
            return twist.displayName + " twist → " + (on ? "ON" : "OFF");
        }
        return switch (tag) {
            case "action:reset" -> {
                s.resetToDefaults();
                yield "every setting → defaults";
            }
            case "set:hide" -> {
                int old = s.hideSeconds;
                s.hideSeconds = RatSeekSettings.cycle(RatSeekSettings.HIDE_SECONDS, s.hideSeconds, direction);
                if (running && phase == Phase.HIDING) {
                    // Keep at least three seconds so a shortened countdown still reads clearly.
                    phaseTicks = Math.max(60, phaseTicks + (s.hideSeconds - old) * 20);
                }
                yield "hide time → " + s.hideSeconds + "s";
            }
            case "set:hunt" -> {
                s.huntMinutes = RatSeekSettings.cycle(RatSeekSettings.HUNT_MINUTES, s.huntMinutes, direction);
                yield "hunt time → " + s.huntMinutes + " min";
            }
            case "set:humans" -> {
                s.humanCount = RatSeekSettings.cycle(RatSeekSettings.HUMAN_COUNTS, s.humanCount, direction);
                yield "starting humans → " + s.humanCountName();
            }
            case "set:bots" -> {
                // Cycle only through counts that fit beside the humans (and keep one seeker in a match).
                int min = running && humans.isEmpty() ? 1 : 0;
                int max = MAX_HUMANS - (running ? humans.size() : lobbyPicks().size());
                s.aiSeekers = max < min ? min
                        : min + Math.floorMod(Math.min(Math.max(s.aiSeekers, min), max) - min + direction, max - min + 1);
                yield "AI seekers → " + s.aiSeekers;
            }
            case "set:size" -> {
                s.ratSize = RatSeekSettings.cycle(s.ratSize, direction);
                yield "rat size → " + s.ratSize.displayName;
            }
            case "set:respawn" -> {
                s.respawnMode = RatSeekSettings.cycle(s.respawnMode, direction);
                yield "rat respawn → " + s.respawnMode.displayName;
            }
            case "set:speed" -> {
                s.humanSpeed = RatSeekSettings.cycle(RatSeekSettings.HUMAN_SPEEDS, s.humanSpeed, direction);
                yield "human speed → " + RatSeekSettings.speedName(s.humanSpeed);
            }
            case "set:rescue" -> {
                s.rescueCost = RatSeekSettings.cycle(RatSeekSettings.RESCUE_COSTS, s.rescueCost, direction);
                yield "rescue price → " + s.rescueCost + " cheese";
            }
            case "set:cheese" -> {
                s.cheese = RatSeekSettings.cycle(s.cheese, direction);
                yield "cheese supply → " + s.cheese.displayName;
            }
            case "set:hints" -> {
                s.hints = RatSeekSettings.cycle(s.hints, direction);
                yield "compass hints → " + s.hints.displayName;
            }
            case "set:twistrate" -> {
                s.twistRate = RatSeekSettings.cycle(s.twistRate, direction);
                twistTicks = nextTwistDelay();
                yield "twist frequency → " + s.twistRate.displayName;
            }
            case "set:glow" -> onOff("glowing rats", s.ratsGlow = !s.ratsGlow);
            case "set:escape" -> onOff("starting escape card", s.startingEscape = !s.startingEscape);
            case "set:finalglow" -> onOff("final minute frenzy", s.finalMinuteGlow = !s.finalMinuteGlow);
            case "set:danger" -> onOff("danger sense", s.dangerSense = !s.dangerSense);
            case "set:scamper" -> onOff("scamper dash", s.scamper = !s.scamper);
            case "set:taunt" -> onOff("squeak taunt", s.taunt = !s.taunt);
            case "set:scent" -> onOff("scent pulse", s.scentPulse = !s.scentPulse);
            case "set:rattle" -> onOff("cage rattle", s.cageRattle = !s.cageRattle);
            case "set:rescues" -> onOff("cheese trading", s.rescues = !s.rescues);
            case "set:tunnels" -> onOff("noisy tunnels", s.tunnelAntiCamp = !s.tunnelAntiCamp);
            case "set:rush" -> onOff("last rat rush", s.lastRatRush = !s.lastRatRush);
            case "set:costumes" -> onOff("rat costumes", s.costumes = !s.costumes);
            case "set:cinematic" -> onOff("cinematic intro & podium", s.cinematic = !s.cinematic);
            case "set:blindfold" -> onOff("blindfolded humans", s.blindfold = !s.blindfold);
            case "set:flashlight" -> onOff("flashlight", s.flashlight = !s.flashlight);
            case "set:mousetraps" -> onOff("snap mousetraps", s.mousetraps = !s.mousetraps);
            case "set:bait" -> onOff("cheese bait", s.bait = !s.bait);
            case "set:classes" -> onOff("rat classes", s.classes = !s.classes);
            case "set:cat" -> {
                s.cat = RatSeekSettings.cycle(s.cat, direction);
                yield "Mr. Whiskers → " + s.cat.displayName;
            }
            case "set:chandeliers" -> onOff("chandeliers", s.chandeliers = !s.chandeliers);
            case "set:botskill" -> {
                s.botSkill = RatSeekSettings.cycle(s.botSkill, direction);
                yield "AI seeker skill → " + s.botSkill.displayName;
            }
            case "set:botlearning" -> onOff("AI learning", s.botLearning = !s.botLearning);
            case "action:forgetai" -> {
                if (running || ending) {
                    yield null;
                }
                bots.forgetEverything();
                yield "AI seekers forgot everything they learned";
            }
            default -> null;
        };
    }

    private static String onOff(String name, boolean on) {
        return name + " → " + (on ? "ON" : "OFF");
    }

    private boolean canEditSettings(Player player, boolean lobbyMenu) {
        if (lobbyMenu) {
            return !running && !ending && lobbyHostCheck.test(player);
        }
        return running && phase == Phase.HIDING && player.getUniqueId().equals(host);
    }

    private void openMenu(Player player, RatSeekMenu.Page page, boolean lobbyMenu) {
        Inventory inventory = renderMenu(player, page, lobbyMenu);
        if (inventory == null) {
            player.closeInventory();
        } else {
            player.openInventory(inventory);
        }
    }

    private Inventory renderMenu(Player player, RatSeekMenu.Page page, boolean lobbyMenu) {
        if (!player.isOnline() || (lobbyMenu ? running || ending
                : !running || !players.contains(player.getUniqueId()))) {
            return null;
        }
        if (page == RatSeekMenu.Page.CLASSES) {
            return !lobbyMenu && phase == Phase.HIDING && settings.classes && rats.containsKey(player.getUniqueId())
                    ? menu.classes(abilities.classOf(player.getUniqueId()), abilities.counts(), RatClass.cap(rats.size()))
                    : null;
        }
        boolean editable = canEditSettings(player, lobbyMenu);
        if (page == RatSeekMenu.Page.ROLES) {
            if (lobbyMenu && editable) {
                List<RatSeekMenu.RoleEntry> roster = new ArrayList<>();
                for (Player target : lobbyRoster.get()) {
                    roster.add(new RatSeekMenu.RoleEntry(target, lobbyHumans.contains(target.getUniqueId())));
                }
                return menu.roles(roster, lobbyPicks().size(), settings.aiSeekers, MAX_HUMANS, true);
            }
            if (!lobbyMenu && editable) {
                List<RatSeekMenu.RoleEntry> roster = new ArrayList<>();
                for (UUID id : players) {
                    Player target = Bukkit.getPlayer(id);
                    if (target != null) {
                        roster.add(new RatSeekMenu.RoleEntry(target, humans.contains(id)));
                    }
                }
                return menu.roles(roster, humans.size(), bots.count(), MAX_HUMANS, false);
            }
            page = RatSeekMenu.Page.MAIN;
        }
        String status;
        NamedTextColor statusColor;
        if (lobbyMenu) {
            status = editable ? "Lobby setup — applies when the match starts" : "Read-only — the queue host picks the rules";
            statusColor = editable ? NamedTextColor.GREEN : NamedTextColor.GRAY;
        } else if (phase == Phase.INTRO) {
            status = "Intro — settings unlock when hiding starts";
            statusColor = NamedTextColor.GRAY;
        } else if (phase == Phase.HIDING) {
            status = editable ? "Hiding — changes apply instantly" : "Read-only — the host picks the rules";
            statusColor = editable ? NamedTextColor.GREEN : NamedTextColor.GRAY;
        } else {
            status = "Hunt in progress — settings are locked";
            statusColor = NamedTextColor.RED;
        }
        RatSeekMenu.View view = new RatSeekMenu.View(lobbyMenu, editable, status, statusColor,
                lobbyMenu && editable && lobbyCanStart.test(player), !lobbyMenu && editable,
                lobbyMenu ? lobbyPicks().size() : 0);
        return switch (page) {
            case TWISTS -> menu.twists(settings, view);
            case EXTRAS -> menu.extras(settings, view);
            default -> menu.main(settings, view);
        };
    }

    /** Redraws an open menu next tick; opening or editing inventories inside their own click is unsafe. */
    private void refreshMenu(Player player, RatSeekMenu.Holder holder) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline() || player.getOpenInventory().getTopInventory().getHolder() != holder) {
                return;
            }
            Inventory fresh = renderMenu(player, holder.page, holder.lobby);
            if (fresh == null) {
                player.closeInventory();
            } else if (fresh.getHolder() instanceof RatSeekMenu.Holder freshHolder && freshHolder.page == holder.page
                    && fresh.getSize() == holder.getInventory().getSize()) {
                holder.getInventory().setContents(fresh.getContents());
            } else {
                player.openInventory(fresh);
            }
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCheeseKeeperInteract(PlayerInteractEntityEvent event) {
        if (cheeseKeeper == null || !event.getRightClicked().getUniqueId().equals(cheeseKeeper.getUniqueId())) {
            return;
        }
        event.setCancelled(true);
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Player player = event.getPlayer();
        if (!running || rats.get(player.getUniqueId()) != RatState.FREE) {
            player.sendActionBar(Component.text("Only a free rat can trade cheese while hiding or during the hunt.",
                    NamedTextColor.RED));
            return;
        }
        if (!settings.rescues) {
            player.sendActionBar(Component.text("The host has disabled cheese trading this round.", NamedTextColor.RED));
            return;
        }
        UUID id = player.getUniqueId();
        if (cageOrder.isEmpty() && bankedEscapes.getOrDefault(id, 0) >= MAX_BANKED_ESCAPES) {
            player.sendActionBar(Component.text("Your escape bank is full (maximum 1).", NamedTextColor.YELLOW));
            return;
        }
        int cheese = carriedCheese.getOrDefault(id, 0);
        if (cheese < settings.rescueCost) {
            player.sendActionBar(Component.text("The keeper needs " + settings.rescueCost + " cheese (you have "
                    + cheese + ").", NamedTextColor.RED));
            return;
        }
        carriedCheese.put(id, cheese - settings.rescueCost);
        if (cageOrder.isEmpty()) {
            bankEscape(player);
        } else {
            rescueRat(player);
        }
    }

    @EventHandler
    public void onCheesePickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player) || !isWorld(player)) {
            return;
        }
        Item item = event.getItem();
        String cheeseType = item.getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
        if ("bait".equals(cheeseType)) {
            event.setCancelled(true);
            if (running && phase == Phase.HUNTING && rats.get(player.getUniqueId()) == RatState.FREE
                    && gadgets.isBait(item)) {
                comboTicks.put(player.getUniqueId(), 0);
                gadgets.biteBait(player, item, settings);
                updateScoreboard();
            }
            return;
        }
        if (!"cheese".equals(cheeseType)) {
            event.setCancelled(true);
            return;
        }
        event.setCancelled(true);
        if (!running || rats.get(player.getUniqueId()) != RatState.FREE) {
            return;
        }
        item.remove();
        cheeseItems.remove(item);
        cheeseRespawns.add(CHEESE_RESPAWN);
        UUID id = player.getUniqueId();
        int combo = comboTicks.getOrDefault(id, 0) > 0
                ? Math.min(3, cheeseCombos.getOrDefault(id, 0) + 1) : 1;
        cheeseCombos.put(id, combo);
        comboTicks.put(id, COMBO_WINDOW);
        int reward = combo + (settings.classes && abilities.is(id, RatClass.THIEF) ? 1 : 0);
        points.merge(id, reward, Integer::sum);
        cheeseGrabbed.merge(id, 1, Integer::sum);
        int cheese = carriedCheese.merge(id, 1, Integer::sum);
        player.sendActionBar(Component.text("Cheese " + cheese
                + (settings.rescues ? "/" + settings.rescueCost : "") + "  |  x" + combo + " combo  |  +" + reward,
                NamedTextColor.GOLD));
        world.playSound(player.getLocation(), Sound.ENTITY_PLAYER_BURP, 1.2f, 1.7f);
        world.spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation().add(0, 0.5, 0), 12, 0.3, 0.3, 0.3, 0);
        bots.noise(player.getLocation(), 14, 0.5, id);
        updateScoreboard();
    }

    private void tick() {
        if (!running) {
            return;
        }
        ticks++;
        phaseTicks--;
        tauntCooldowns.replaceAll((id, value) -> Math.max(0, value - 1));
        dashCooldowns.replaceAll((id, value) -> Math.max(0, value - 1));
        rattleCooldowns.replaceAll((id, value) -> Math.max(0, value - 1));
        comboTicks.replaceAll((id, value) -> Math.max(0, value - 1));
        scentCooldown = Math.max(0, scentCooldown - 1);
        if (ticks % 10 == 0) {
            applyRatVisibility();
        }
        costume.tick(ticks, id -> rats.get(id) == RatState.CAGED);
        gadgets.tick(ticks, settings, phase == Phase.HUNTING);
        abilities.tick(ticks, settings);
        if (phase == Phase.HUNTING) {
            houseLife.tick(ticks, settings);
            bots.tick(ticks, settings);
        }
        if (!running) {
            return;
        }
        tickCheese();
        tickFlair();

        if (phase == Phase.INTRO) {
            show.tickIntro(RatSeekShow.INTRO_TICKS - phaseTicks, onlinePlayers());
            if (phaseTicks <= 0) {
                beginHiding();
            }
        } else {
            tickSafety();
            tickSecretPassages();
            tickPerches();
            if (phase == Phase.HIDING) {
                tickHiding();
            } else {
                tickHunt();
            }
        }
        if (running && ticks % 10 == 0) {
            updateBossBar();
        }
        if (!running) {
            return;
        }
        if (phase == Phase.HUNTING && ticks % 20 == 0 && settings.dangerSense) {
            tickDanger();
        }
        if (ticks % 20 == 0) {
            updateScoreboard();
        }
    }

    private void tickHiding() {
        int seconds = Math.max(0, phaseTicks / 20);
        if (phaseTicks % 20 == 0 && (seconds == 20 || seconds == 10 || seconds <= 5)) {
            forEachPlayer(player -> {
                player.sendTitle("§e§l" + seconds, humans.contains(player.getUniqueId())
                        ? "§7The hunt begins soon" : "§7Find a hiding spot!", 0, 24, 0);
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 0.9f + (5 - Math.min(5, seconds)) * 0.12f);
            });
        }
        if (settings.blindfold && phaseTicks > 0 && phaseTicks % (seconds <= 10 ? 10 : 20) == 0) {
            for (Player seeker : humanPlayers()) {
                seeker.playSound(seeker.getLocation(), Sound.ENTITY_WARDEN_HEARTBEAT, 1f, seconds <= 10 ? 1.3f : 1f);
            }
        }
        if (phaseTicks <= 0) {
            phase = Phase.HUNTING;
            phaseTicks = settings.huntTicks();
            huntStartTick = ticks;
            hintTicks = 280;
            twistTicks = nextTwistDelay();
            for (Player player : new ArrayList<>(Bukkit.getOnlinePlayers())) {
                // The hunt locks the rules; drop anyone still looking at an editable menu.
                if (players.contains(player.getUniqueId())
                        && player.getOpenInventory().getTopInventory().getHolder() instanceof RatSeekMenu.Holder) {
                    player.closeInventory();
                }
            }
            for (Player seeker : humanPlayers()) {
                Location release = toLocation(HUMAN_RELEASE).setDirection(new Vector(0, 0, -1));
                release.add((random.nextDouble() - 0.5) * 2, 0, (random.nextDouble() - 0.5) * 2);
                seeker.teleport(release);
                seeker.removePotionEffect(PotionEffectType.BLINDNESS);
                seeker.sendTitle("§c§lHUNT!", "§fCatch every rat in " + settings.huntMinutes
                        + (settings.huntMinutes == 1 ? " minute" : " minutes"), 5, 45, 10);
                seeker.playSound(seeker.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.7f, 1.4f);
            }
            bots.releaseAll(settings, ticks);
            broadcast(Component.text(humans.size() > 1 ? "The humans are loose! The seeker compass updates with every hint."
                    : "The human is loose! The seeker compass updates with every hint.",
                    NamedTextColor.RED));
            show.play(RatSeekShow.Sting.HUNT, onlinePlayers());
            houseLife.startHunt(settings);
            if (settings.classes) {
                abilities.assignMissing(new ArrayList<>(rats.keySet()), random);
                for (UUID id : rats.keySet()) {
                    Player rat = Bukkit.getPlayer(id);
                    RatClass ratClass = abilities.classOf(id);
                    if (rat != null && ratClass != null) {
                        giveRatKit(rat);
                        rat.sendMessage(Component.text("You are a ", NamedTextColor.GRAY)
                                .append(Component.text(ratClass.displayName, ratClass.color, TextDecoration.BOLD))
                                .append(Component.text(" — " + ratClass.passive + " Slot 5: " + ratClass.abilityName
                                        + ".", NamedTextColor.GRAY)));
                    }
                }
            }
            List<String> tools = new ArrayList<>();
            addIfOn(tools, settings.flashlight, "flashlight");
            addIfOn(tools, settings.mousetraps, "mousetraps");
            addIfOn(tools, settings.bait, "cheese bait");
            if (!tools.isEmpty()) {
                broadcast(Component.text("Humans carry: " + String.join(", ", tools)
                        + ". Rats — watch the floors and check your cheese!", NamedTextColor.GOLD));
            }
            giveHint();
        }
    }

    /** Cosmetic ambience: sparkling cheese and a golden trail for rats on a combo streak. */
    private void tickFlair() {
        if (ticks % 40 == 0) {
            for (Item item : cheeseItems) {
                if (item.isValid()) {
                    world.spawnParticle(Particle.WAX_ON, item.getLocation().add(0, 0.35, 0), 3, 0.15, 0.15, 0.15, 0);
                }
            }
        }
        if (phase == Phase.HUNTING && ticks % 4 == 0) {
            Particle.DustOptions gold = new Particle.DustOptions(org.bukkit.Color.fromRGB(0xFFC83D), 0.8f);
            for (UUID id : freeRats()) {
                Player rat = Bukkit.getPlayer(id);
                if (rat != null && comboTicks.getOrDefault(id, 0) > 0 && cheeseCombos.getOrDefault(id, 1) >= 2) {
                    world.spawnParticle(Particle.DUST, rat.getLocation().add(0, 0.2, 0), 2, 0.12, 0.05, 0.12, 0, gold);
                }
            }
        }
    }

    private void updateBossBar() {
        Component title;
        float progress;
        BossBar.Color color;
        if (phase == Phase.INTRO) {
            title = Component.text("THE CROOKED MANOR", NamedTextColor.GOLD, TextDecoration.BOLD);
            progress = 1f - phaseTicks / (float) RatSeekShow.INTRO_TICKS;
            color = BossBar.Color.PURPLE;
        } else if (phase == Phase.HIDING) {
            int seconds = Math.max(0, phaseTicks / 20);
            title = Component.text("HIDE! ", NamedTextColor.GREEN, TextDecoration.BOLD)
                    .append(Component.text(seconds + "s until the humans are released", NamedTextColor.WHITE));
            progress = phaseTicks / (float) Math.max(1, settings.hideTicks());
            color = BossBar.Color.GREEN;
        } else {
            boolean finalMinute = phaseTicks <= FINAL_FRENZY_TICKS;
            title = Component.text("HUNT " + displayTime(), finalMinute ? NamedTextColor.RED : NamedTextColor.YELLOW,
                            TextDecoration.BOLD)
                    .append(Component.text("  •  " + freeRatCount() + " free  •  " + cageOrder.size() + " caged",
                            NamedTextColor.WHITE));
            if (twistBanner != null && ticks < twistBannerUntil) {
                title = title.append(Component.text("  •  " + twistBanner, NamedTextColor.LIGHT_PURPLE));
            }
            progress = phaseTicks / (float) Math.max(1, settings.huntTicks());
            color = finalMinute ? BossBar.Color.RED : BossBar.Color.YELLOW;
        }
        show.updateBar(world.getPlayers(), title, progress, color);
    }

    private void tickHunt() {
        if (settings.twistRate != RatSeekSettings.TwistRate.OFF && !settings.twists.isEmpty()) {
            twistTicks--;
            if (twistTicks <= 0) {
                triggerHouseTwist();
                twistTicks = nextTwistDelay();
            }
        }
        if (settings.hints != RatSeekSettings.HintRate.OFF) {
            hintTicks--;
            if (hintTicks <= 0) {
                giveHint();
                int base = phaseTicks > 1200 ? 440 : phaseTicks > 600 ? 320 : 220;
                hintTicks = Math.max(60, (int) Math.round(base * settings.hints.intervalScale));
            }
        }
        if (phaseTicks == 1200 || phaseTicks == 600 || phaseTicks == 200) {
            int seconds = phaseTicks / 20;
            broadcast(Component.text(seconds + " seconds left!" + (settings.hints != RatSeekSettings.HintRate.OFF
                    ? " Hints are getting more frequent." : ""), NamedTextColor.YELLOW));
            world.playSound(toLocation(HUMAN_RELEASE), Sound.BLOCK_BELL_USE, 2f, 0.8f);
            if (phaseTicks == FINAL_FRENZY_TICKS) {
                show.play(RatSeekShow.Sting.FINAL_MINUTE, onlinePlayers());
            }
            if (phaseTicks == FINAL_FRENZY_TICKS && settings.finalMinuteGlow) {
                broadcast(Component.text("FINAL MINUTE FRENZY! Every free rat is glowing!", NamedTextColor.RED,
                        TextDecoration.BOLD));
            }
        }
        if (phaseTicks <= 0) {
            for (Map.Entry<UUID, RatState> entry : rats.entrySet()) {
                if (entry.getValue() == RatState.FREE) {
                    points.merge(entry.getKey(), 3, Integer::sum);
                }
            }
            finish(false, freeRatCount() + " rat" + (freeRatCount() == 1 ? " survives" : "s survive")
                    + " the clock. The rats win!");
        }
    }

    private void tickCheese() {
        cheeseItems.removeIf(item -> !item.isValid() || item.isDead());
        for (int i = cheeseRespawns.size() - 1; i >= 0; i--) {
            int left = cheeseRespawns.get(i) - 1;
            if (left <= 0) {
                cheeseRespawns.remove(i);
                if (running && cheeseItems.size() < settings.cheese.maxCheese) {
                    spawnCheese();
                }
            } else {
                cheeseRespawns.set(i, left);
            }
        }
        // Top up lost cheese (failed spawns, removed items, a raised supply) instead of
        // letting the map slowly run dry.
        if (ticks % 20 == 0) {
            for (int i = cheeseItems.size() + cheeseRespawns.size(); i < settings.cheese.maxCheese; i++) {
                cheeseRespawns.add(CHEESE_RESPAWN);
            }
        }
    }

    private void tickSafety() {
        if (ticks % 10 != 0) {
            return;
        }
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || player.getWorld() != world || player.getY() >= BASEMENT_Y - 8) {
                continue;
            }
            if (humans.contains(id)) {
                Location safe = toLocation(HUMAN_RELEASE);
                safe.add((random.nextDouble() - 0.5) * 2, 0, (random.nextDouble() - 0.5) * 2);
                player.teleport(safe);
            } else if (rats.get(id) == RatState.CAGED) {
                player.teleport(toLocation(CAGE));
            } else {
                Location respawn = ratRespawnLocation();
                player.teleport(respawn);
                player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 160, 0, false, false, false));
                player.sendActionBar(Component.text("Drainpipe escape! Glowing 8s!", NamedTextColor.YELLOW));
                world.playSound(respawn, Sound.ENTITY_FOX_SCREECH, 1.2f, 1.5f);
                world.spawnParticle(Particle.CLOUD, respawn.clone().add(0, 0.5, 0), 20, 0.4, 0.5, 0.4, 0.06);
                pointHumanCompasses(respawn);
                notifyHumans(Component.text(player.getName() + " slipped through a drainpipe! Compass updated!", NamedTextColor.RED));
                for (Player seeker : humanPlayers()) {
                    seeker.playSound(seeker.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 1.5f);
                }
            }
            player.setVelocity(new Vector());
        }
    }

    /**
     * A rat parked where no seeker can tag it (the roof, a wardrobe top it bounced onto during
     * the Bouncy House twist) gets a warning, then slips off to the nearest reachable floor.
     */
    private void tickPerches() {
        RatSeekNav nav = RatSeekBots.navIfReady();
        if (ticks % 10 != 0 || nav == null) {
            return;
        }
        if (phase != Phase.HUNTING) {
            perchTicks.clear();
            return;
        }
        for (Map.Entry<UUID, RatState> entry : rats.entrySet()) {
            UUID id = entry.getKey();
            Player rat = Bukkit.getPlayer(id);
            if (rat == null || entry.getValue() != RatState.FREE || rat.getWorld() != world) {
                perchTicks.remove(id);
                continue;
            }
            Location at = rat.getLocation();
            int x = at.getBlockX(), y = (int) Math.floor(at.getY() + 0.01), z = at.getBlockZ();
            if (!nav.unfairPerch(x, y, z)) {
                // Mid-jump or on a stair edge still counts; only real ground clears the clock.
                if (((org.bukkit.entity.Entity) rat).isOnGround()) {
                    perchTicks.remove(id);
                }
                continue;
            }
            int held = perchTicks.merge(id, 10, Integer::sum);
            if (held == 40) {
                rat.sendActionBar(Component.text("The seekers can't reach you up here — you're slipping! Move!",
                        NamedTextColor.YELLOW));
                world.playSound(at, Sound.BLOCK_GRAVEL_STEP, 1f, 1.4f);
            } else if (held >= 100) {
                perchTicks.remove(id);
                int[] cell = nav.landing(x, y, z);
                Location landing = cell == null ? ratRespawnLocation()
                        : new Location(world, cell[0] + 0.5, cell[1], cell[2] + 0.5, at.getYaw(), at.getPitch());
                rat.teleport(landing);
                rat.setVelocity(new Vector());
                rat.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, false, false, false));
                rat.sendActionBar(Component.text("You slipped off! Glowing 3s.", NamedTextColor.RED));
                world.playSound(landing, Sound.ENTITY_RABBIT_HURT, 1f, 1.3f);
                world.spawnParticle(Particle.CLOUD, landing.clone().add(0, 0.4, 0), 12, 0.3, 0.3, 0.3, 0.03);
                bots.noise(landing, 20, 0.7, id);
            }
        }
    }

    private void tickSecretPassages() {
        if (phase != Phase.HUNTING || !settings.tunnelAntiCamp) {
            secretPassageTicks.clear();
            secretPassageOccupants.clear();
            passageOf.clear();
            return;
        }
        for (Map.Entry<UUID, RatState> entry : rats.entrySet()) {
            UUID id = entry.getKey();
            Player rat = Bukkit.getPlayer(id);
            SecretPassage passage = rat == null || entry.getValue() != RatState.FREE
                    ? null : secretPassageAt(rat.getLocation());
            if (passage == null) {
                SecretPassage left = passageOf.remove(id);
                if (left != null && rat != null && entry.getValue() == RatState.FREE) {
                    // Crawled out on their own: which end? (A flush or a catch lands elsewhere.)
                    Location at = rat.getLocation();
                    Location a = toLocation(left.exitA()), b = toLocation(left.exitB());
                    if (Math.min(at.distanceSquared(a), at.distanceSquared(b)) < 9) {
                        bots.tunnelExit(left.name(), at.distanceSquared(a) < at.distanceSquared(b), rat);
                    }
                }
                secretPassageTicks.remove(id);
                secretPassageOccupants.remove(id);
                continue;
            }
            passageOf.put(id, passage);
            if (secretPassageOccupants.add(id)) {
                rat.sendActionBar(Component.text("Secret passage — keep moving; the humans can hear you!",
                        NamedTextColor.YELLOW));
                world.playSound(rat.getLocation(), Sound.BLOCK_GRAVEL_STEP, 1.6f, 0.65f);
                bots.noise(rat.getLocation(), 18, 0.5, id);
            }
            int timeInside = secretPassageTicks.merge(id, 1, Integer::sum);
            if (timeInside == SECRET_PASSAGE_WARNING) {
                Location exit = nearestPassageExit(passage, rat.getLocation());
                rat.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 50, 0, false, false, false));
                rat.sendActionBar(Component.text("The tunnel is rattling — get out!", NamedTextColor.RED));
                world.playSound(exit, Sound.BLOCK_CHAIN_STEP, 2.2f, 0.7f);
                world.spawnParticle(Particle.ASH, exit.clone().add(0, 0.5, 0), 14,
                        0.35, 0.35, 0.35, 0.02);
                pointHumanCompasses(exit);
                notifyHumans(Component.text("Scratching near the " + passage.name() + "!",
                        NamedTextColor.YELLOW));
            } else if (timeInside >= SECRET_PASSAGE_LIMIT) {
                flushRatFromPassage(rat, passage);
            }
        }
    }

    private SecretPassage secretPassageAt(Location location) {
        for (SecretPassage passage : secretPassages) {
            if (passage.contains(location)) {
                return passage;
            }
        }
        return null;
    }

    private Location nearestPassageExit(SecretPassage passage, Location origin) {
        Location exitA = toLocation(passage.exitA());
        Location exitB = toLocation(passage.exitB());
        return exitA.distanceSquared(origin) <= exitB.distanceSquared(origin) ? exitA : exitB;
    }

    private void flushRatFromPassage(Player rat, SecretPassage passage) {
        UUID id = rat.getUniqueId();
        Location exit = nearestPassageExit(passage, rat.getLocation());
        rat.teleport(exit);
        rat.setVelocity(new Vector());
        rat.setFallDistance(0);
        rat.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 100, 0, false, false, false));
        rat.sendTitle("§c§lFLUSHED OUT!", "§fSecret passages cannot be camped", 0, 30, 5);
        world.playSound(exit, Sound.BLOCK_PISTON_EXTEND, 1.5f, 1.5f);
        world.spawnParticle(Particle.CLOUD, exit.clone().add(0, 0.4, 0), 20,
                0.35, 0.35, 0.35, 0.05);
        pointHumanCompasses(exit);
        notifyHumans(Component.text(rat.getName() + " was flushed from the " + passage.name() + "!",
                NamedTextColor.RED));
        secretPassageTicks.remove(id);
        secretPassageOccupants.remove(id);
    }

    private void cageRat(Player rat, Player catcher) {
        UUID id = rat.getUniqueId();
        if (!running || rats.get(id) != RatState.FREE) {
            return;
        }
        if (bankedEscapes.getOrDefault(id, 0) > 0) {
            useBankedEscape(rat);
            return;
        }
        if (rats.replace(id, RatState.CAGED) != RatState.FREE) {
            return;
        }
        cageOrder.remove(id);
        cageOrder.add(id);
        Location caught = rat.getLocation();
        bots.caught(rat, caught);
        world.spawnParticle(Particle.CLOUD, caught.add(0, 0.5, 0), 25, 0.4, 0.5, 0.4, 0.06);
        world.spawnParticle(Particle.CRIT, caught, 30, 0.3, 0.4, 0.3, 0.4);
        world.playSound(caught, Sound.ENTITY_FOX_SCREECH, 1.5f, 1.5f);
        world.playSound(caught, Sound.BLOCK_IRON_TRAPDOOR_CLOSE, 1.6f, 0.7f);
        if (catcher != null) {
            UUID catcherId = catcher.getUniqueId();
            catchesBy.merge(catcherId, 1, Integer::sum);
            int huntTicks = ticks - huntStartTick;
            firstCatchTicks.putIfAbsent(catcherId, huntTicks);
            if (fastestCatcher == null || huntTicks < fastestCatchTicks) {
                fastestCatcher = catcherId;
                fastestCatchVictim = rat.getName();
                fastestCatchTicks = huntTicks;
            }
            catcher.sendActionBar(Component.text("SNAP! " + rat.getName() + " is going to the cage.",
                    NamedTextColor.GOLD, TextDecoration.BOLD));
        }
        show.play(RatSeekShow.Sting.CATCH, onlinePlayers());
        rat.teleport(toLocation(CAGE).add(random.nextDouble() - 0.5, 0, random.nextDouble() - 0.5));
        rat.setVelocity(new Vector());
        world.playSound(toLocation(CAGE), Sound.BLOCK_IRON_DOOR_CLOSE, 1.4f, 0.8f);
        giveRatKit(rat);
        dressRat(rat);
        rat.sendTitle(catcher != null ? "§c§lSNAP! CAGED!" : "§c§lCAGED!", settings.rescues
                ? "§7A free rat can trade " + settings.rescueCost + " cheese to free you"
                : "§7No rescues this round — rattle the bars!", 5, 50, 10);
        broadcast(Component.text("A rat was caught! " + freeRatCount() + " rat(s) remain free.",
                NamedTextColor.RED));
        updateScoreboard();
        if (freeRatCount() == 0) {
            finish(true, "Every rat is in the cage. The humans win!");
        } else if (freeRatCount() == 1 && !lastRatRush && settings.lastRatRush) {
            startLastRatRush();
        }
    }

    private void bankEscape(Player rat) {
        UUID id = rat.getUniqueId();
        int escapes = Math.min(MAX_BANKED_ESCAPES, bankedEscapes.getOrDefault(id, 0) + 1);
        bankedEscapes.put(id, escapes);
        updateEscapeCard(rat, escapes);
        rat.sendTitle("§a§lESCAPE BANKED!", "§fYour next capture is cancelled", 5, 40, 10);
        rat.playSound(rat.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.4f);
        rat.sendActionBar(Component.text("Escapes banked: " + escapes + "/" + MAX_BANKED_ESCAPES,
                NamedTextColor.GREEN));
        updateScoreboard();
    }

    private void useBankedEscape(Player rat) {
        UUID id = rat.getUniqueId();
        int escapes = Math.max(0, bankedEscapes.getOrDefault(id, 0) - 1);
        startingEscapes.remove(id);
        if (escapes == 0) {
            bankedEscapes.remove(id);
        } else {
            bankedEscapes.put(id, escapes);
        }
        Location caught = rat.getLocation();
        escapesBy.merge(id, 1, Integer::sum);
        updateEscapeCard(rat, escapes);
        rat.teleport(ratRespawnLocation());
        rat.setVelocity(new Vector());
        rat.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2, false, false, true));
        rat.sendTitle("§a§lJAIL FREE!", "§fYour banked escape saved you", 5, 40, 10);
        world.spawnParticle(Particle.TOTEM_OF_UNDYING, caught.clone().add(0, 0.5, 0),
                35, 0.4, 0.5, 0.4, 0.12);
        world.playSound(caught, Sound.ITEM_TOTEM_USE, 1.2f, 1.2f);
        broadcast(Component.text(rat.getName() + " used a banked escape!", NamedTextColor.GREEN));
        updateScoreboard();
    }

    private void rescueRat(Player rescuer) {
        if (cageOrder.isEmpty()) {
            return;
        }
        UUID rescuedId = cageOrder.remove(0);
        rats.put(rescuedId, RatState.FREE);
        lastRatRush = false;
        points.merge(rescuer.getUniqueId(), 2, Integer::sum);
        escapesBy.merge(rescuer.getUniqueId(), 1, Integer::sum);
        show.play(RatSeekShow.Sting.RESCUE, onlinePlayers());
        Player rescued = Bukkit.getPlayer(rescuedId);
        if (rescued != null && rescued.isOnline()) {
            rescued.teleport(ratRespawnLocation());
            giveRatKit(rescued);
            dressRat(rescued);
            rescued.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2, false, false, true));
            rescued.sendTitle("§a§lFREED!", "§fA teammate traded cheese for you", 5, 45, 10);
            rescued.playSound(rescued.getLocation(), Sound.BLOCK_IRON_DOOR_OPEN, 1f, 1.4f);
        }
        Location cage = toLocation(CAGE);
        world.playSound(cage, Sound.BLOCK_BEACON_ACTIVATE, 3f, 1.4f);
        world.spawnParticle(Particle.TOTEM_OF_UNDYING, cage.clone().add(0, 1, 0), 45, 1.5, 1, 1.5, 0.2);
        broadcast(Component.text("CAGE ALARM! A rat traded cheese and freed a teammate!", NamedTextColor.GREEN));
        pointHumanCompasses(rescuer.getLocation());
        for (Player seeker : humanPlayers()) {
            seeker.sendTitle("§c§lCAGE ALARM", "§fYour compass points toward the trader", 5, 35, 5);
        }
        updateScoreboard();
    }

    private void taunt(Player rat) {
        UUID id = rat.getUniqueId();
        if (phase != Phase.HUNTING || rats.get(id) != RatState.FREE) {
            rat.sendActionBar(Component.text("You can only taunt while free during the hunt.", NamedTextColor.RED));
            return;
        }
        int cooldown = tauntCooldowns.getOrDefault(id, 0);
        if (cooldown > 0) {
            rat.sendActionBar(Component.text(String.format(Locale.ROOT, "Taunt ready in %.1fs", cooldown / 20.0),
                    NamedTextColor.RED));
            return;
        }
        tauntCooldowns.put(id, TAUNT_COOLDOWN);
        tauntsBy.merge(id, 1, Integer::sum);
        int score = points.merge(id, 1, Integer::sum);
        world.playSound(rat.getLocation(), Sound.ENTITY_FOX_AMBIENT, 3f, 1.8f);
        world.playSound(rat.getLocation(), Sound.BLOCK_NOTE_BLOCK_FLUTE, 2f, 1.8f);
        world.spawnParticle(Particle.NOTE, rat.getLocation().add(0, 0.5, 0), 18, 0.5, 0.5, 0.5, 1);
        rat.sendActionBar(Component.text("Taunt score: " + score + "  |  Run!", NamedTextColor.GOLD));
        pointHumanCompasses(rat.getLocation());
        bots.noise(rat.getLocation(), 40, 0.95, id);
        houseLife.distractCat(rat.getLocation());
        updateScoreboard();
    }

    private void dash(Player rat) {
        UUID id = rat.getUniqueId();
        if (phase != Phase.HUNTING || rats.get(id) != RatState.FREE) {
            rat.sendActionBar(Component.text("Only a free rat can scamper.", NamedTextColor.RED));
            return;
        }
        int cooldown = dashCooldowns.getOrDefault(id, 0);
        if (cooldown > 0) {
            rat.sendActionBar(Component.text(String.format(Locale.ROOT, "Scamper ready in %.1fs", cooldown / 20.0),
                    NamedTextColor.RED));
            return;
        }
        dashCooldowns.put(id, abilities.is(id, RatClass.SCOUT) && settings.classes ? DASH_COOLDOWN * 2 / 3 : DASH_COOLDOWN);
        Vector launch = rat.getLocation().getDirection().setY(0).normalize().multiply(1.25).setY(0.22);
        rat.setVelocity(launch);
        rat.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 45, 2, false, false, true));
        world.spawnParticle(Particle.CLOUD, rat.getLocation().add(0, 0.2, 0), 18, 0.25, 0.15, 0.25, 0.05);
        world.playSound(rat.getLocation(), Sound.ENTITY_RABBIT_JUMP, 1.2f, 1.7f);
        bots.noise(rat.getLocation(), 16, 0.45, id);
    }

    private void scentPulse(Player seeker) {
        if (!humans.contains(seeker.getUniqueId()) || phase != Phase.HUNTING) {
            return;
        }
        if (scentCooldown > 0) {
            seeker.sendActionBar(Component.text(String.format(Locale.ROOT, "Scent pulse ready in %.1fs",
                    scentCooldown / 20.0), NamedTextColor.RED));
            return;
        }
        Player nearest = nearestFreeRat(seeker.getLocation());
        if (nearest == null) {
            return;
        }
        scentCooldown = SCENT_COOLDOWN;
        double distance = seeker.getLocation().distance(nearest.getLocation());
        nearest.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 50, 0, false, false, false));
        seeker.setCompassTarget(nearest.getLocation());
        seeker.sendTitle("§e§lSNIFF!", "§f" + Math.round(distance) + " blocks • " + roomAt(nearest.getLocation()),
                0, 30, 5);
        world.playSound(seeker.getLocation(), Sound.ENTITY_SNIFFER_SEARCHING, 1.2f, 1.4f);
        world.spawnParticle(Particle.SNEEZE, seeker.getEyeLocation(), 24, 0.8, 0.4, 0.8, 0.03);
    }

    private void rattleCage(Player rat) {
        UUID id = rat.getUniqueId();
        if (phase != Phase.HUNTING || rats.get(id) != RatState.CAGED) {
            rat.sendActionBar(Component.text("You need to be caged to rattle the bars.", NamedTextColor.RED));
            return;
        }
        int cooldown = rattleCooldowns.getOrDefault(id, 0);
        if (cooldown > 0) {
            rat.sendActionBar(Component.text(String.format(Locale.ROOT, "Rattle ready in %.1fs", cooldown / 20.0),
                    NamedTextColor.RED));
            return;
        }
        rattleCooldowns.put(id, RATTLE_COOLDOWN);
        points.merge(id, 1, Integer::sum);
        Location cage = toLocation(CAGE);
        world.playSound(cage, Sound.BLOCK_ANVIL_LAND, 2.5f, 1.8f);
        world.spawnParticle(Particle.ELECTRIC_SPARK, cage.clone().add(0, 1, 0), 35, 1.5, 1, 1.5, 0.08);
        for (UUID freeId : freeRats()) {
            Player freeRat = Bukkit.getPlayer(freeId);
            if (freeRat != null) {
                freeRat.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, 1, false, false, true));
                freeRat.sendActionBar(Component.text("CAGE RATTLE — scamper boost!", NamedTextColor.GREEN));
            }
        }
        for (Player seeker : humanPlayers()) {
            seeker.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 80, 0, false, false, false));
            seeker.sendActionBar(Component.text("The prisoners rattled the cage — you are exposed!", NamedTextColor.RED));
        }
        bots.expose(80);
        broadcast(Component.text("The cage erupts in a deafening rattle!", NamedTextColor.LIGHT_PURPLE));
        updateScoreboard();
    }

    private void giveHint() {
        List<UUID> free = freeRats();
        if (free.isEmpty()) {
            return;
        }
        UUID targetId = free.get(random.nextInt(free.size()));
        Player target = Bukkit.getPlayer(targetId);
        List<Player> seekers = humanPlayers();
        if (target == null) {
            return;
        }
        String room = roomAt(target.getLocation());
        for (Player seeker : seekers) {
            seeker.setCompassTarget(target.getLocation());
            seeker.sendActionBar(Component.text("Compass tracking a rat"
                    + " near the " + room, NamedTextColor.YELLOW));
            seeker.playSound(seeker.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 1.5f);
        }
        bots.hint(target.getLocation());
        if (phaseTicks <= 600) {
            target.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 30, 0, false, false, false));
        }
    }

    private void tickDanger() {
        List<Location> seekerLocations = seekerLocations();
        if (seekerLocations.isEmpty()) {
            return;
        }
        for (UUID id : freeRats()) {
            Player rat = Bukkit.getPlayer(id);
            if (rat == null || rat.getWorld() != world || abilities.sensing(id)) {
                continue;
            }
            double distance = seekerLocations.stream()
                    .mapToDouble(seeker -> rat.getLocation().distance(seeker))
                    .min().orElse(Double.MAX_VALUE);
            if (distance <= 5) {
                rat.sendActionBar(Component.text("!!! HUMAN VERY CLOSE !!!", NamedTextColor.RED, TextDecoration.BOLD));
                rat.playSound(rat.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASEDRUM, 0.8f, 1.8f);
            } else if (distance <= 10) {
                rat.sendActionBar(Component.text("! Footsteps nearby — " + Math.round(distance) + "m !",
                        NamedTextColor.YELLOW));
                if (ticks % 40 == 0) {
                    rat.playSound(rat.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASEDRUM, 0.45f, 1.2f);
                }
            }
        }
    }

    private Player nearestFreeRat(Location origin) {
        Player nearest = null;
        double best = Double.MAX_VALUE;
        for (UUID id : freeRats()) {
            Player candidate = Bukkit.getPlayer(id);
            if (candidate == null || candidate.getWorld() != origin.getWorld()) {
                continue;
            }
            double distance = candidate.getLocation().distanceSquared(origin);
            if (distance < best) {
                best = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    private void startLastRatRush() {
        lastRatRush = true;
        Player survivor = nearestFreeRat(toLocation(CAGE));
        if (survivor == null) {
            return;
        }
        dashCooldowns.put(survivor.getUniqueId(), 0);
        abilities.resetCooldown(survivor.getUniqueId());
        survivor.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 140, 2, false, false, true));
        survivor.sendTitle("§6§lLAST RAT!", "§fDash reset • seven-second speed rush", 5, 45, 10);
        world.playSound(survivor.getLocation(), Sound.ITEM_GOAT_HORN_SOUND_3, 1.5f, 1.3f);
        show.play(RatSeekShow.Sting.LAST_RAT, onlinePlayers());
        broadcast(Component.text(survivor.getName() + " is the LAST RAT STANDING!", NamedTextColor.GOLD,
                TextDecoration.BOLD));
    }

    private int nextTwistDelay() {
        RatSeekSettings.TwistRate rate = settings.twistRate;
        return rate == RatSeekSettings.TwistRate.OFF ? Integer.MAX_VALUE
                : rate.minTicks + random.nextInt(rate.spreadTicks + 1);
    }

    private void triggerHouseTwist() {
        List<RatSeekSettings.Twist> twists = new ArrayList<>(settings.twists);
        if (twists.isEmpty()) {
            return;
        }
        if (twists.size() > 1) {
            twists.remove(lastTwist);
        }
        RatSeekSettings.Twist twist = twists.get(random.nextInt(twists.size()));
        lastTwist = twist;
        twistBanner = twist.displayName.toUpperCase(Locale.ROOT);
        twistBannerUntil = ticks + 200;
        switch (twist) {
            case CHEESE_RAIN -> {
                broadcast(Component.text("TWIST: CHEESE RAIN! Bonus cheese just appeared around the manor.",
                        NamedTextColor.GOLD, TextDecoration.BOLD));
                for (int i = 0; i < CHEESE_RAIN_BONUS; i++) {
                    spawnCheese();
                }
                world.playSound(toLocation(HUMAN_RELEASE), Sound.ENTITY_PLAYER_LEVELUP, 3f, 1.6f);
            }
            case HUNTER_FRENZY -> {
                broadcast(Component.text("TWIST: HUNTER'S FRENZY! The humans surge forward — scatter!",
                        NamedTextColor.RED, TextDecoration.BOLD));
                hunterFrenzy();
            }
            case BOUNCY_HOUSE -> {
                broadcast(Component.text("TWIST: BOUNCY HOUSE! Everyone gets super jumps for 10 seconds.",
                        NamedTextColor.GREEN, TextDecoration.BOLD));
                forEachPlayer(player -> {
                    if (rats.get(player.getUniqueId()) != RatState.CAGED) {
                        player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 200, 2, false, false, true));
                    }
                });
                bots.bounce(200);
                world.playSound(toLocation(HUMAN_RELEASE), Sound.BLOCK_SLIME_BLOCK_PLACE, 3f, 0.8f);
            }
            case GHOST_RATS -> {
                broadcast(Component.text("TWIST: GHOST RATS! Free rats fade from sight for 5 seconds.",
                        NamedTextColor.WHITE, TextDecoration.BOLD));
                for (UUID id : freeRats()) {
                    Player rat = Bukkit.getPlayer(id);
                    if (rat != null) {
                        rat.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 100, 0, false, false, true));
                        costume.ghost(rat, 100);
                    }
                }
                world.playSound(toLocation(HUMAN_RELEASE), Sound.ENTITY_PHANTOM_AMBIENT, 3f, 1.2f);
            }
            case SPOTLIGHT -> {
                broadcast(Component.text("TWIST: SPOTLIGHT! Every free rat glows for 3 seconds.",
                        NamedTextColor.YELLOW, TextDecoration.BOLD));
                for (UUID id : freeRats()) {
                    Player rat = Bukkit.getPlayer(id);
                    if (rat != null) {
                        rat.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, false, false, false));
                    }
                }
                world.playSound(toLocation(HUMAN_RELEASE), Sound.BLOCK_BEACON_POWER_SELECT, 3f, 1.5f);
            }
            case BLACKOUT -> {
                broadcast(Component.text("TWIST: BLACKOUT! Rats get night vision and a head start.",
                        NamedTextColor.DARK_PURPLE, TextDecoration.BOLD));
                for (Player seeker : humanPlayers()) {
                    seeker.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 120, 0, false, false, true));
                }
                bots.darkness(120);
                for (UUID id : freeRats()) {
                    Player rat = Bukkit.getPlayer(id);
                    if (rat != null) {
                        rat.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 180, 0, false, false, true));
                        rat.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, 1, false, false, true));
                    }
                }
                world.playSound(toLocation(HUMAN_RELEASE), Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 3f, 0.6f);
            }
            case RAT_RAVE -> {
                broadcast(Component.text("TWIST: RAT RAVE! Every rat's taunt and scamper are instantly recharged.",
                        NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
                for (UUID id : freeRats()) {
                    tauntCooldowns.put(id, 0);
                    dashCooldowns.put(id, 0);
                    abilities.resetCooldown(id);
                    Player rat = Bukkit.getPlayer(id);
                    if (rat != null) {
                        world.spawnParticle(Particle.NOTE, rat.getLocation().add(0, 0.5, 0), 25,
                                0.5, 0.5, 0.5, 1);
                        rat.playSound(rat.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 1f, 1.8f);
                    }
                }
            }
        }
    }

    private void finish(boolean humanWon, String reason) {
        if (!running) {
            return;
        }
        running = false;
        bots.matchOver(humanWon);
        bots.clear();
        // Stay "busy" until teardown so the lobby cannot start a match that the
        // delayed endGame() below would immediately destroy.
        ending = true;
        if (task != null) {
            task.cancel();
            task = null;
        }
        broadcast(Component.text(reason, humanWon ? NamedTextColor.GOLD : NamedTextColor.GREEN));
        costume.clear();
        show.updateBar(world.getPlayers(), Component.text(humanWon ? "THE HUMANS WIN" : "THE RATS WIN",
                humanWon ? NamedTextColor.RED : NamedTextColor.GOLD, TextDecoration.BOLD), 1f,
                humanWon ? BossBar.Color.RED : BossBar.Color.YELLOW);
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            boolean winner = humanWon ? humans.contains(id) : rats.containsKey(id);
            player.sendTitle(winner ? "§6§lYOU WIN!" : "§c§lGAME OVER",
                    humanWon ? "§fThe humans caught every rat" : "§fThe rats beat the clock", 10, 70, 10);
            player.playSound(player.getLocation(), winner ? Sound.UI_TOAST_CHALLENGE_COMPLETE
                    : Sound.ENTITY_VILLAGER_NO, 1f, 1f);
        }
        showScores();
        saveRecords(humanWon);
        if (settings.cinematic) {
            show.podium(podiumWinners(humanWon), onlinePlayers(), humanWon ? "THE HUMANS WIN!" : "THE RATS WIN!",
                    humanWon ? NamedTextColor.RED : NamedTextColor.GOLD, awards());
        }
        endTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            endTask = null;
            endGame();
        }, settings.cinematic ? 240L : 100L);
    }

    private void saveRecords(boolean humanWon) {
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            boolean human = humans.contains(id);
            if (!human && !rats.containsKey(id)) {
                continue;
            }
            RatSeekRecords.Match match = new RatSeekRecords.Match(human, human == humanWon,
                    catchesBy.getOrDefault(id, 0), cheeseGrabbed.getOrDefault(id, 0), escapesBy.getOrDefault(id, 0),
                    points.getOrDefault(id, 0),
                    firstCatchTicks.containsKey(id) ? firstCatchTicks.get(id) / 20 : -1);
            for (String best : records.add(id, player.getName(), match)) {
                player.sendMessage(Component.text("★ Personal best — " + best + "!", NamedTextColor.GOLD,
                        TextDecoration.BOLD));
            }
            player.sendMessage(Component.text("Career: ", NamedTextColor.GRAY)
                    .append(Component.text(records.summary(id), NamedTextColor.AQUA)));
        }
        records.save();
    }

    private List<Player> podiumWinners(boolean humanWon) {
        List<UUID> ranking = new ArrayList<>(humanWon ? humans : rats.keySet());
        Map<UUID, Integer> score = humanWon ? catchesBy : points;
        ranking.sort(Comparator.comparingInt((UUID id) -> score.getOrDefault(id, 0)).reversed());
        List<Player> result = new ArrayList<>();
        for (UUID id : ranking) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline() && result.size() < 3) {
                result.add(player);
            }
        }
        return result;
    }

    private List<RatSeekShow.Award> awards() {
        List<RatSeekShow.Award> awards = new ArrayList<>();
        UUID cheese = topOf(points, rats.keySet());
        if (cheese != null) {
            awards.add(new RatSeekShow.Award("Big Cheese", nameOf(cheese), points.get(cheese) + " pts",
                    NamedTextColor.GOLD));
        }
        UUID exterminator = topOf(catchesBy, humans);
        if (exterminator != null) {
            int count = catchesBy.get(exterminator);
            awards.add(new RatSeekShow.Award("Exterminator", nameOf(exterminator),
                    count + (count == 1 ? " catch" : " catches"), NamedTextColor.RED));
        }
        if (fastestCatcher != null) {
            int seconds = fastestCatchTicks / 20;
            awards.add(new RatSeekShow.Award("Speed Trap", nameOf(fastestCatcher), "caught " + fastestCatchVictim
                    + " at " + String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60), NamedTextColor.AQUA));
        }
        UUID loudmouth = topOf(tauntsBy, tauntsBy.keySet());
        if (loudmouth != null) {
            awards.add(new RatSeekShow.Award("Loudmouth", nameOf(loudmouth), tauntsBy.get(loudmouth) + " squeaks",
                    NamedTextColor.LIGHT_PURPLE));
        }
        UUID houdini = topOf(escapesBy, escapesBy.keySet());
        if (houdini != null) {
            awards.add(new RatSeekShow.Award("Houdini", nameOf(houdini), escapesBy.get(houdini) + " escapes & rescues",
                    NamedTextColor.GREEN));
        }
        return awards;
    }

    /** The id with the highest positive count among {@code candidates}, or null. */
    private static UUID topOf(Map<UUID, Integer> counts, java.util.Collection<UUID> candidates) {
        UUID best = null;
        int bestCount = 0;
        for (UUID id : candidates) {
            int count = counts.getOrDefault(id, 0);
            if (count > bestCount) {
                best = id;
                bestCount = count;
            }
        }
        return best;
    }

    private void showScores() {
        List<UUID> ranking = new ArrayList<>(rats.keySet());
        ranking.sort(Comparator.comparingInt((UUID id) -> points.getOrDefault(id, 0)).reversed());
        broadcast(Component.text("Rat scoreboard:", NamedTextColor.GOLD, TextDecoration.BOLD));
        int place = 1;
        for (UUID id : ranking) {
            Player player = Bukkit.getPlayer(id);
            String name = player != null ? player.getName() : "Rat";
            broadcast(Component.text("#" + place++ + " " + name + " - " + points.getOrDefault(id, 0) + " points",
                    NamedTextColor.YELLOW));
        }
    }

    private void preparePlayer(Player player) {
        costume.undress(player);
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        removeHumanSpeedModifier(player);
        player.setGameMode(GameMode.ADVENTURE);
        player.setGlowing(false);
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20);
        player.setFireTicks(0);
        setScale(player, 1.0);
    }

    private void prepareHuman(Player player) {
        // Spread seekers inside the booth so up to 3 humans never suffocate stacked.
        Location waiting = toLocation(locationKey(RatSeekHouse.WAITING)).setDirection(new Vector(0, 0, -1));
        waiting.add((random.nextDouble() - 0.5) * 1.6, 0, (random.nextDouble() - 0.5) * 1.6);
        player.teleport(waiting);
        giveHumanKit(player);
        applyHumanSpeedModifier(player);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION,
                1, false, false, true));
        applyBlindfold(player);
    }

    private void applyBlindfold(Player seeker) {
        if (running && phase == Phase.HIDING && settings.blindfold) {
            seeker.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, PotionEffect.INFINITE_DURATION,
                    0, false, false, false));
        } else {
            seeker.removePotionEffect(PotionEffectType.BLINDNESS);
        }
    }

    /** Puts on, refreshes or removes the rat costume to match the setting and the rat's state. */
    private void dressRat(Player rat) {
        RatState state = rats.get(rat.getUniqueId());
        if (settings.costumes && state != null) {
            costume.dress(rat, settings.ratSize.scale, state == RatState.CAGED);
        } else {
            costume.undress(rat);
        }
    }

    private void applyHumanSpeedModifier(Player player) {
        removeHumanSpeedModifier(player);
        AttributeInstance movementSpeed = player.getAttribute(Attribute.MOVEMENT_SPEED);
        if (movementSpeed != null) {
            double modifier = settings.humanSpeedModifier();
            movementSpeed.addTransientModifier(new AttributeModifier(humanSpeedModifierKey, modifier,
                    AttributeModifier.Operation.ADD_SCALAR));
        }
    }

    private void giveHostRoleSelector() {
        Player hostPlayer = Bukkit.getPlayer(host);
        if (hostPlayer == null || !hostPlayer.isOnline()) {
            return;
        }
        RatSeekSettings.Preset preset = settings.preset();
        hostPlayer.getInventory().setItem(7, taggedItem(Material.COMPARATOR, "difficulty_selector",
                "Host Settings (" + preset.displayName + ")", preset.color,
                "Right-click: timers, presets, abilities and twists"));
        hostPlayer.getInventory().setItem(8, taggedItem(Material.PLAYER_HEAD, "role_selector",
                "Assign Roles (Host)", NamedTextColor.GOLD,
                "Right-click during hiding to choose human seekers"));
    }

    private void toggleHumanRole(Player assigningHost, UUID targetId) {
        if (!players.contains(targetId)) {
            return;
        }
        boolean makeHuman = !humans.contains(targetId);
        if (!makeHuman && humans.size() + bots.count() <= 1) {
            assigningHost.sendActionBar(Component.text("There must be at least 1 seeker.", NamedTextColor.RED));
            return;
        }
        if (makeHuman && humans.size() + bots.count() >= MAX_HUMANS) {
            assigningHost.sendActionBar(Component.text("There can be at most " + MAX_HUMANS + " seekers.",
                    NamedTextColor.RED));
            return;
        }
        if (makeHuman && rats.size() <= 1) {
            // Without a rat the round would just run out the clock and hand the rats a win.
            assigningHost.sendActionBar(Component.text("There must be at least 1 rat.", NamedTextColor.RED));
            return;
        }
        setRole(targetId, makeHuman);
        broadcast(Component.text("The host made " + nameOf(targetId) + (makeHuman ? " a HUMAN (" : " a RAT (")
                + humans.size() + "/" + MAX_HUMANS + " humans).", NamedTextColor.GOLD));
        afterRoleChange();
    }

    /** Lobby picks of players still queued, in pick order. */
    private List<UUID> lobbyPicks() {
        Set<UUID> queued = new HashSet<>();
        for (Player player : lobbyRoster.get()) {
            queued.add(player.getUniqueId());
        }
        return lobbyHumans.stream().filter(queued::contains).toList();
    }

    private void toggleLobbyPick(Player lobbyHost, UUID targetId) {
        List<Player> roster = lobbyRoster.get();
        if (roster.stream().noneMatch(p -> p.getUniqueId().equals(targetId))) {
            return;
        }
        lobbyHumans.retainAll(roster.stream().map(Player::getUniqueId).toList());
        if (lobbyHumans.remove(targetId)) {
            lobbyHost.sendActionBar(Component.text(nameOf(targetId) + " → RAT", NamedTextColor.GOLD));
            return;
        }
        if (lobbyHumans.size() + settings.aiSeekers >= MAX_HUMANS) {
            lobbyHost.sendActionBar(Component.text("At most " + MAX_HUMANS + " seekers — lower AI Seekers first.",
                    NamedTextColor.RED));
            return;
        }
        if (lobbyHumans.size() + 1 >= roster.size()) {
            lobbyHost.sendActionBar(Component.text("There must be at least 1 rat.", NamedTextColor.RED));
            return;
        }
        lobbyHumans.add(targetId);
        lobbyHost.sendActionBar(Component.text(nameOf(targetId) + " → HUMAN", NamedTextColor.RED));
    }

    private void shuffleRoles(Player assigningHost) {
        List<UUID> roster = new ArrayList<>(players);
        if (roster.size() < 2) {
            assigningHost.sendActionBar(Component.text("Not enough players to shuffle.", NamedTextColor.RED));
            return;
        }
        java.util.Collections.shuffle(roster, random);
        Set<UUID> chosen = new HashSet<>(roster.subList(0, Math.min(humans.size(), roster.size() - 1)));
        for (UUID id : roster) {
            if (chosen.contains(id) != humans.contains(id)) {
                setRole(id, chosen.contains(id));
            }
        }
        List<String> names = chosen.stream().map(this::nameOf).toList();
        broadcast(Component.text("The host shuffled the roles! Humans: " + String.join(", ", names),
                NamedTextColor.GOLD));
        world.playSound(toLocation(locationKey(RatSeekHouse.WAITING)), Sound.BLOCK_NOTE_BLOCK_PLING, 2f, 1.6f);
        afterRoleChange();
    }

    private void setRole(UUID id, boolean human) {
        Player target = Bukkit.getPlayer(id);
        if (human) {
            humans.add(id);
            rats.remove(id);
            abilities.forget(id);
            cageOrder.remove(id);
            carriedCheese.remove(id);
            bankedEscapes.remove(id);
            startingEscapes.remove(id);
            secretPassageTicks.remove(id);
            secretPassageOccupants.remove(id);
            if (target != null && target.isOnline()) {
                preparePlayer(target);
                prepareHuman(target);
                target.sendTitle("§c§lYOU ARE THE HUMAN", "§fWait for the rats to hide", 5, 45, 10);
            }
        } else {
            humans.remove(id);
            gadgets.forget(id);
            rats.put(id, RatState.FREE);
            points.putIfAbsent(id, 0);
            carriedCheese.putIfAbsent(id, 0);
            tauntCooldowns.put(id, 0);
            dashCooldowns.put(id, 0);
            lastRatRush = false;
            if (target != null && target.isOnline()) {
                preparePlayer(target);
                // While hiding, "closest to humans" would drop the new rat beside the waiting booth.
                prepareRat(target, phase == Phase.HIDING && !ratSpawns.isEmpty()
                        ? randomRatSpawn() : ratRespawnLocation());
            }
        }
    }

    private void afterRoleChange() {
        // A role swap clears the host's inventory when it hits the host themselves.
        giveHostRoleSelector();
        updateScoreboard();
        if (running && freeRatCount() == 0 && !rats.isEmpty()) {
            finish(true, "Every rat is in the cage. The humans win!");
        }
    }

    /** Pushes in-match effects of a settings change to everyone (only reachable during hiding). */
    private void applyLiveSettings() {
        if (!running) {
            return;
        }
        settings.aiSeekers = Math.max(humans.isEmpty() ? 1 : 0,
                Math.min(settings.aiSeekers, MAX_HUMANS - humans.size()));
        syncBotSeekers();
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            if (humans.contains(id)) {
                applyHumanSpeedModifier(player);
                giveHumanKit(player);
                applyBlindfold(player);
            } else if (rats.containsKey(id)) {
                setScale(player, settings.ratSize.scale);
                dressRat(player);
                syncStartingEscape(player);
                giveRatKit(player);
            }
        }
        applyRatVisibility();
        syncCheeseSupply();
        updateKeeperName();
        giveHostRoleSelector();
        updateScoreboard();
    }

    private void broadcastRules() {
        RatSeekSettings.Preset preset = settings.preset();
        broadcast(Component.text("Rules: ", NamedTextColor.GRAY)
                .append(Component.text(preset.displayName, preset.color, TextDecoration.BOLD))
                .append(Component.text(" — " + preset.description + ".", NamedTextColor.GRAY)));
        broadcast(Component.text(settings.hideSeconds + "s hide • " + settings.huntMinutes + " min hunt • "
                + settings.ratSize.displayName + " rats • humans " + RatSeekSettings.speedName(settings.humanSpeed)
                + " • respawn " + settings.respawnMode.displayName, NamedTextColor.AQUA));
        List<String> off = new ArrayList<>();
        addIfOff(off, settings.scamper, "scamper");
        addIfOff(off, settings.taunt, "taunts");
        addIfOff(off, settings.scentPulse, "scent pulse");
        addIfOff(off, settings.cageRattle, "cage rattle");
        addIfOff(off, settings.rescues, "cheese trading");
        addIfOff(off, settings.tunnelAntiCamp, "noisy tunnels");
        addIfOff(off, settings.dangerSense, "danger sense");
        addIfOff(off, settings.lastRatRush, "last rat rush");
        addIfOff(off, settings.hints != RatSeekSettings.HintRate.OFF, "compass hints");
        addIfOff(off, settings.twistRate != RatSeekSettings.TwistRate.OFF && !settings.twists.isEmpty(), "twists");
        if (!off.isEmpty()) {
            broadcast(Component.text("Disabled this round: " + String.join(", ", off) + ".", NamedTextColor.DARK_GRAY));
        }
    }

    private static void addIfOn(List<String> on, boolean enabled, String name) {
        if (enabled) {
            on.add(name);
        }
    }

    private static void addIfOff(List<String> off, boolean enabled, String name) {
        if (!enabled) {
            off.add(name);
        }
    }

    private String nameOf(UUID id) {
        Player target = Bukkit.getPlayer(id);
        return target != null ? target.getName() : "A player";
    }

    private void prepareRat(Player player, Location spawn) {
        setScale(player, settings.ratSize.scale);
        dressRat(player);
        player.setGlowing(shouldGlow(player.getUniqueId()));
        syncStartingEscape(player);
        player.teleport(spawn);
        giveRatKit(player);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION,
                0, false, false, true));
        player.sendTitle("§6§lYOU ARE A RAT", "§f100+ hiding spots • 4 tunnels"
                + (settings.rescues ? " • rescues" : ""), 10, 60, 10);
    }

    /** Sets the rat ability slots from its state and the host settings, leaving other slots alone. */
    private void giveRatKit(Player rat) {
        boolean caged = rats.get(rat.getUniqueId()) == RatState.CAGED;
        rat.getInventory().setItem(0, settings.taunt ? taggedItem(Material.BONE, "taunt", "Squeak Taunt",
                NamedTextColor.LIGHT_PURPLE, "Right-click: send a decoy message for +1 point") : null);
        rat.getInventory().setItem(1, settings.scamper ? taggedItem(Material.RABBIT_FOOT, "dash", "Scamper",
                NamedTextColor.AQUA, "Right-click: burst forward • 12 second cooldown") : null);
        rat.getInventory().setItem(2, caged && settings.cageRattle ? taggedItem(Material.TRIPWIRE_HOOK, "rattle",
                "Rattle the Cage", NamedTextColor.RED, "Right-click: expose the humans and boost free rats") : null);
        boolean classesLive = running && settings.classes;
        rat.getInventory().setItem(4, classesLive && !caged && phase == Phase.HUNTING
                ? abilities.abilityItem(rat.getUniqueId()) : null);
        RatClass picked = abilities.classOf(rat.getUniqueId());
        rat.getInventory().setItem(6, classesLive && phase == Phase.HIDING ? taggedItem(
                picked == null ? Material.NAME_TAG : picked.icon, "class_picker",
                picked == null ? "Choose Your Class" : "Class: " + picked.displayName,
                picked == null ? NamedTextColor.YELLOW : picked.color, "Right-click: pick Scout, Thief, Trickster or Tinkerer")
                : null);
    }

    private void giveHumanKit(Player seeker) {
        seeker.getInventory().setItem(0, taggedItem(Material.IRON_SWORD, "catcher", "Rat Catcher",
                NamedTextColor.RED, "Hit a rat, or right-click to swat into low gaps"));
        seeker.getInventory().setItem(1, taggedItem(Material.COMPASS, "compass", "Seeker's Compass",
                NamedTextColor.YELLOW, settings.hints == RatSeekSettings.HintRate.OFF
                        ? "Hints are off — trust your ears" : "Updates whenever you receive a hint"));
        seeker.getInventory().setItem(2, settings.scentPulse ? taggedItem(Material.SNIFFER_EGG, "scent", "Scent Pulse",
                NamedTextColor.GOLD, "Right-click: reveal the nearest rat for 2.5 seconds") : null);
        gadgets.giveKit(seeker, settings);
    }

    private boolean shouldGlow(UUID id) {
        RatState state = rats.get(id);
        if (state == null) {
            return false;
        }
        return settings.ratsGlow || (settings.finalMinuteGlow && state == RatState.FREE
                && phase == Phase.HUNTING && phaseTicks <= FINAL_FRENZY_TICKS);
    }

    private void applyRatVisibility() {
        for (UUID id : rats.keySet()) {
            Player rat = Bukkit.getPlayer(id);
            boolean glow = shouldGlow(id);
            if (rat != null && rat.isGlowing() != glow) {
                rat.setGlowing(glow);
            }
        }
    }

    /** Grants or revokes the setting's free escape card without touching cards bought with cheese. */
    private void syncStartingEscape(Player rat) {
        UUID id = rat.getUniqueId();
        if (settings.startingEscape) {
            if (bankedEscapes.getOrDefault(id, 0) == 0) {
                bankedEscapes.put(id, 1);
                startingEscapes.add(id);
                updateEscapeCard(rat, 1);
            }
        } else if (startingEscapes.remove(id)) {
            bankedEscapes.remove(id);
            updateEscapeCard(rat, 0);
        }
    }

    private void syncCheeseSupply() {
        int max = settings.cheese.maxCheese;
        cheeseItems.removeIf(item -> !item.isValid());
        while (cheeseItems.size() > max) {
            cheeseItems.remove(cheeseItems.size() - 1).remove();
        }
        while (!cheeseRespawns.isEmpty() && cheeseItems.size() + cheeseRespawns.size() > max) {
            cheeseRespawns.remove(cheeseRespawns.size() - 1);
        }
        for (int i = cheeseItems.size() + cheeseRespawns.size(); i < max; i++) {
            spawnCheese();
        }
    }

    private void updateKeeperName() {
        if (cheeseKeeper == null) {
            return;
        }
        cheeseKeeper.customName(settings.rescues
                ? Component.text("Rescue / Bank Escape — " + settings.rescueCost + " Cheese", NamedTextColor.GOLD)
                : Component.text("Cheese Keeper (trading closed)", NamedTextColor.GRAY));
    }

    private void restorePlayer(Player player) {
        costume.undress(player);
        player.setExp(0);
        player.setLevel(0);
        setScale(player, 1.0);
        removeHumanSpeedModifier(player);
        player.setGlowing(false);
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        player.setVelocity(new Vector());
        player.setFireTicks(0);
        player.setFallDistance(0);
        if (player.isDead()) {
            return;
        }
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20);
    }

    private void removeHumanSpeedModifier(Player player) {
        AttributeInstance movementSpeed = player.getAttribute(Attribute.MOVEMENT_SPEED);
        if (movementSpeed != null) {
            movementSpeed.removeModifier(humanSpeedModifierKey);
        }
    }

    private void setScale(Player player, double scale) {
        AttributeInstance attribute = player.getAttribute(Attribute.SCALE);
        if (attribute != null) {
            attribute.setBaseValue(scale);
        }
    }

    ItemStack taggedItem(Material material, String tag, String name, NamedTextColor color, String lore) {
        ItemStack item = ItemStack.of(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text(lore, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private String tagOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        return item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
    }

    private int freeRatCount() {
        return (int) rats.values().stream().filter(state -> state == RatState.FREE).count();
    }

    List<UUID> freeRats() {
        return rats.entrySet().stream().filter(entry -> entry.getValue() == RatState.FREE)
                .map(Map.Entry::getKey).filter(id -> Bukkit.getPlayer(id) != null).toList();
    }

    private Location randomRatSpawn() {
        return ratSpawns.get(random.nextInt(ratSpawns.size())).clone();
    }

    private Location ratSpawnFarFromHuman() {
        List<Location> seekerLocations = seekerLocations();
        if (seekerLocations.isEmpty()) {
            return randomRatSpawn();
        }
        return ratSpawns.stream()
                .max(Comparator.comparingDouble(spawn -> seekerLocations.stream()
                        .mapToDouble(seeker -> spawn.distanceSquared(seeker)).min().orElse(0)))
                .orElseGet(this::randomRatSpawn)
                .clone();
    }

    private Location ratSpawnClosestToHuman() {
        List<Location> seekerLocations = seekerLocations();
        if (seekerLocations.isEmpty()) {
            return randomRatSpawn();
        }
        return ratSpawns.stream()
                .min(Comparator.comparingDouble(spawn -> seekerLocations.stream()
                        .mapToDouble(seeker -> spawn.distanceSquared(seeker)).min().orElse(0)))
                .orElseGet(this::randomRatSpawn)
                .clone();
    }

    /**
     * Every rat respawn (rescue, banked escape, drainpipe slip, host role-swap)
     * honours the host-configured respawn mode. Furthest is the default.
     */
    private Location ratRespawnLocation() {
        if (ratSpawns.isEmpty()) {
            return new Location(world, 0.5, 81, 0.5);
        }
        return switch (settings.respawnMode) {
            case RANDOM -> randomRatSpawn();
            case CLOSEST -> ratSpawnClosestToHuman();
            case FURTHEST -> ratSpawnFarFromHuman();
        };
    }

    private List<Location> seekerLocations() {
        List<Location> locations = new ArrayList<>();
        for (Player seeker : humanPlayers()) if (seeker.getWorld() == world) locations.add(seeker.getLocation());
        locations.addAll(bots.locations());
        return locations;
    }

    private void updateEscapeCard(Player rat, int escapes) {
        if (escapes <= 0) {
            rat.getInventory().setItem(3, null);
            return;
        }
        ItemStack card = taggedItem(Material.PAPER, "escape_card", "Get Out of Jail Free",
                NamedTextColor.GREEN, "Automatically consumed the next time a human catches you");
        card.setAmount(escapes);
        rat.getInventory().setItem(3, card);
    }

    String roomAt(Location location) {
        SecretPassage passage = secretPassageAt(location);
        if (passage != null) {
            return passage.name();
        }
        for (Room room : rooms) {
            if (room.contains(location)) {
                return room.name();
            }
        }
        if (location.getZ() >= 17) {
            return "front garden";
        }
        if (location.getX() >= 21) {
            return "cage yard";
        }
        return "house exterior";
    }

    private void updateScoreboard() {
        if (!running) {
            return;
        }
        Set<String> ratNames = new HashSet<>();
        for (UUID playerId : rats.keySet()) {
            Player hiddenPlayer = Bukkit.getPlayer(playerId);
            if (hiddenPlayer != null) {
                ratNames.add(hiddenPlayer.getName());
            }
        }
        Set<String> humanNames = new HashSet<>();
        for (UUID humanId : humans) {
            Player humanPlayer = Bukkit.getPlayer(humanId);
            if (humanPlayer != null) {
                humanNames.add(humanPlayer.getName());
            }
        }
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) {
                continue;
            }
            // Each viewer keeps one board for the session; only changed lines and team members are sent.
            Sidebar sidebar = sidebars.computeIfAbsent(id, key -> {
                Sidebar created = new Sidebar("ratseek", Component.text("RAT AND SEEK", NamedTextColor.GOLD, TextDecoration.BOLD));
                created.team("hidden_names").setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.NEVER);
                created.team("visible_human").setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.ALWAYS);
                return created;
            });
            syncTeam(sidebar.team("hidden_names"), ratNames);
            syncTeam(sidebar.team("visible_human"), humanNames);
            List<String> lines = new ArrayList<>();
            List<Integer> scores = new ArrayList<>();
            boolean viewerIsHuman = humans.contains(id);
            String role = viewerIsHuman ? ChatColor.RED + "HUMAN" : ChatColor.GOLD + "RAT";
            lines.add(ChatColor.WHITE + "Role: " + role);
            scores.add(9);
            lines.add(ChatColor.YELLOW + "Time: " + displayTime());
            scores.add(8);
            lines.add(ChatColor.RED + "Seekers: " + humans.size() + "P + " + bots.count() + "AI / " + MAX_HUMANS);
            scores.add(7);
            lines.add(ChatColor.GREEN + "Free rats: " + freeRatCount() + "/" + rats.size());
            scores.add(6);
            lines.add(ChatColor.RED + "Caged: " + cageOrder.size());
            scores.add(5);
            lines.add(ChatColor.GRAY + "At: " + roomAt(player.getLocation()));
            scores.add(4);
            lines.add(ChatColor.DARK_PURPLE + "Mode: " + settings.preset().displayName);
            scores.add(1);
            lines.add(ChatColor.BLUE + "Respawn: " + settings.respawnMode.displayName);
            scores.add(0);
            if (!viewerIsHuman) {
                lines.add(ChatColor.GOLD + "Points: " + points.getOrDefault(id, 0)
                        + ChatColor.YELLOW + " | Cheese: " + carriedCheese.getOrDefault(id, 0)
                        + (settings.rescues ? "/" + settings.rescueCost : "")
                        + (bankedEscapes.getOrDefault(id, 0) > 0 ? ChatColor.GREEN + " | ESCAPE x"
                        + bankedEscapes.get(id) : ""));
                scores.add(3);
                RatState state = rats.get(id);
                lines.add((state == RatState.CAGED ? ChatColor.RED : ChatColor.AQUA)
                        + (state == RatState.CAGED ? "CAGED • Rattle!" : "FREE • Combo x"
                        + (comboTicks.getOrDefault(id, 0) > 0 ? cheeseCombos.getOrDefault(id, 1) : 1))
                        + classHud(id));
                scores.add(2);
            } else {
                lines.add(ChatColor.AQUA + "Scent: " + (!settings.scentPulse ? "OFF"
                        : scentCooldown == 0 ? "READY" : (scentCooldown / 20 + "s")));
                scores.add(3);
                String tools = gadgets.hud(id, settings);
                lines.add(ChatColor.GRAY + (!tools.isEmpty() ? tools
                        : settings.hints == RatSeekSettings.HintRate.OFF ? "Hints: OFF" : "Compass = hints"));
                scores.add(2);
            }
            sidebar.set(lines, scores);
            sidebar.show(player);
        }
    }

    private static void syncTeam(Team team, Set<String> names) {
        for (String entry : new ArrayList<>(team.getEntries())) {
            if (!names.contains(entry)) {
                team.removeEntry(entry);
            }
        }
        for (String name : names) {
            if (!team.hasEntry(name)) {
                team.addEntry(name);
            }
        }
    }

    private String classHud(UUID id) {
        RatClass ratClass = settings.classes ? abilities.classOf(id) : null;
        if (ratClass == null) {
            return "";
        }
        int left = abilities.cooldown(id);
        return ChatColor.GRAY + " • " + ratClass.displayName + " " + (phase != Phase.HUNTING ? ""
                : left == 0 ? ChatColor.GREEN + "READY" : ChatColor.RED + "" + (left + 19) / 20 + "s");
    }

    private String displayTime() {
        int seconds = Math.max(0, phaseTicks / 20);
        if (phase == Phase.INTRO) {
            return "Intro";
        }
        return phase == Phase.HIDING ? "Hide " + seconds + "s"
                : String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
    }

    private boolean isInCobweb(Player player) {
        var box = player.getBoundingBox();
        int minX = (int) Math.floor(box.getMinX());
        int maxX = (int) Math.floor(box.getMaxX());
        int minY = (int) Math.floor(box.getMinY());
        int maxY = (int) Math.floor(box.getMaxY());
        int minZ = (int) Math.floor(box.getMinZ());
        int maxZ = (int) Math.floor(box.getMaxZ());
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (world.getBlockAt(x, y, z).getType() == Material.COBWEB) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void forEachPlayer(java.util.function.Consumer<Player> action) {
        for (UUID id : players) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                action.accept(player);
            }
        }
    }

    private void broadcast(Component message) {
        forEachPlayer(player -> player.sendMessage(Component.text("[Rat and Seek] ", NamedTextColor.GOLD)
                .append(message)));
    }

    private Location toLocation(LocationKey key) {
        return new Location(world, key.x(), key.y(), key.z());
    }

    // ------------------------------------------------------------------ arena

    private void buildArena() {
        bots.purgeStrays();
        costume.purgeStrays(world);
        show.purgeStrays();
        RatSeekHouse house = house();
        rooms.clear();
        ratSpawns.clear();
        cheeseSpots.clear();
        secretPassages.clear();
        // The house stays standing between matches, so after the first build this only touches the
        // handful of blocks a match changed instead of re-placing (and relighting) ~25k blocks in one tick.
        List<Block> changed = new ArrayList<>();
        house.blocks.forEach((pos, material) -> {
            Block block = addBlock(pos.x(), pos.y(), pos.z(), material, changed);
            if (material == Material.POLISHED_ANDESITE_STAIRS
                    && block.getBlockData() instanceof Directional stairs) {
                BlockFace facing = pos.z() < 0 ? BlockFace.SOUTH : BlockFace.NORTH;
                if (stairs.getFacing() != facing) {
                    stairs.setFacing(facing);
                    block.setBlockData(stairs, false);
                }
            }
        });
        for (RatSeekHouse.Room room : house.rooms) {
            rooms.add(new Room(room.name(), room.x1(), room.x2(), room.y1(), room.y2(), room.z1(), room.z2()));
        }
        for (RatSeekHouse.Passage passage : house.passages) {
            secretPassages.add(new SecretPassage(passage.name(), passage.x(), passage.x(),
                    passage.y(), passage.y(), passage.z1(), passage.z2(),
                    locationKey(passage.exitA()), locationKey(passage.exitB())));
        }
        house.spawns.forEach(pos -> addRatSpawn(pos.x(), pos.y(), pos.z()));
        house.cheese.forEach(pos -> addCheeseSpot(pos.x(), pos.y(), pos.z()));
        if (houseBuilt) {
            refreshConnections(changed, true);
        } else {
            refreshConnections(arenaBlocks.stream().map(Location::getBlock).toList(), false);
            houseBuilt = true;
        }
        houseLife.build(house, ratSpawns);
        RatSeekHouse.Pos keeper = RatSeekHouse.KEEPER;
        cheeseKeeper = world.spawn(new Location(world, keeper.x() + 0.5, keeper.y(), keeper.z() + 0.5, -90, 0), Villager.class);
        updateKeeperName();
        cheeseKeeper.setCustomNameVisible(true);
        cheeseKeeper.setAI(false);
        cheeseKeeper.setInvulnerable(true);
        cheeseKeeper.setSilent(true);
        cheeseKeeper.setPersistent(true);
        cheeseKeeper.setRemoveWhenFarAway(false);
        cheeseKeeper.setProfession(Villager.Profession.BUTCHER);
        cheeseKeeper.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, "cheese_keeper");
    }

    private static LocationKey locationKey(RatSeekHouse.Pos pos) {
        return new LocationKey(pos.x() + 0.5, pos.y(), pos.z() + 0.5);
    }

    private void addRatSpawn(double x, double y, double z) {
        ratSpawns.add(new Location(world, x + 0.5, y, z + 0.5));
    }

    private void addCheeseSpot(double x, double y, double z) {
        cheeseSpots.add(new Location(world, x + 0.5, y, z + 0.5));
    }

    private void spawnInitialCheese() {
        for (int i = 0; i < settings.cheese.maxCheese; i++) {
            spawnCheese();
        }
    }

    private Location availableCheeseSpot() {
        List<Location> available = cheeseSpots.stream().filter(spot -> cheeseItems.stream()
                .filter(Item::isValid).noneMatch(item -> item.getLocation().distanceSquared(spot) < 2.25)).toList();
        return available.isEmpty() ? null : available.get(random.nextInt(available.size())).clone();
    }

    private void spawnCheese() {
        if (cheeseSpots.isEmpty()) {
            return;
        }
        Location spot = availableCheeseSpot();
        if (spot == null) return;
        ItemStack stack = taggedItem(Material.GOLD_NUGGET, "cheese", "Stolen Cheese",
                NamedTextColor.GOLD, "Rats earn 1 point by grabbing this");
        Item item = world.dropItem(spot, stack);
        item.setVelocity(new Vector());
        item.setGravity(false);
        item.setPickupDelay(10);
        item.setUnlimitedLifetime(true);
        item.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, "cheese");
        cheeseItems.add(item);
        world.spawnParticle(Particle.WAX_ON, spot.clone().add(0, 0.3, 0), 8, 0.2, 0.2, 0.2, 0);
    }

    /** @param neighbours also re-check the blocks beside each given block (needed when only changes are passed) */
    private void refreshConnections(Collection<Block> around, boolean neighbours) {
        // Blocks are placed without physics for speed, so explicitly join panes, bars,
        // and fences once the final neighbourhood is known.
        BlockFace[] horizontalFaces = {BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST};
        Set<Block> candidates = new LinkedHashSet<>();
        for (Block block : around) {
            candidates.add(block);
            if (neighbours) {
                for (BlockFace face : horizontalFaces) {
                    candidates.add(block.getRelative(face));
                }
            }
        }
        for (Block block : candidates) {
            if (!(block.getBlockData() instanceof MultipleFacing connected)) {
                continue;
            }
            BlockData before = connected.clone();
            for (BlockFace face : horizontalFaces) {
                if (!connected.getAllowedFaces().contains(face)) {
                    continue;
                }
                Block neighbour = block.getRelative(face);
                boolean join = neighbour.getBlockData() instanceof MultipleFacing
                        || (!neighbour.getType().isAir() && !neighbour.isPassable());
                connected.setFace(face, join);
            }
            if (!connected.equals(before)) {
                block.setBlockData(connected, false);
            }
        }
    }

    private Block addBlock(int x, int y, int z, Material material, List<Block> changed) {
        Block block = world.getBlockAt(x, y, z);
        if (block.getType() != material) {
            block.setType(material, false);
            changed.add(block);
        }
        if (material.isAir()) {
            arenaBlocks.remove(block.getLocation());
        } else {
            arenaBlocks.add(block.getLocation());
        }
        return block;
    }

    /** The blueprint is deterministic, so it is generated once instead of on every match start. */
    static synchronized RatSeekHouse house() {
        if (blueprint == null) {
            blueprint = new RatSeekHouse();
        }
        return blueprint;
    }

    private void resetArena() {
        costume.clear();
        gadgets.reset();
        abilities.reset();
        houseLife.reset();
        if (cheeseKeeper != null) {
            cheeseKeeper.remove();
            cheeseKeeper = null;
        }
        cheeseItems.forEach(Item::remove);
        cheeseItems.clear();
        cheeseRespawns.clear();
        ratSpawns.clear();
        cheeseSpots.clear();
        secretPassages.clear();
        secretPassageTicks.clear();
        secretPassageOccupants.clear();
    }
}
