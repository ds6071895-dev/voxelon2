package dev.autobox.lobby;

import dev.autobox.AutoBoxPlugin;
import dev.autobox.holeinwall.HoleInWallGame;
import dev.autobox.ratseek.RatSeekGame;
import dev.autobox.luckypillars.LuckyPillarsGame;
import dev.autobox.chicken.ChickenRunGame;
import dev.autobox.zombie.ZombieApocalypseGame;
import dev.autobox.sumo.BlockSumoGame;
import dev.autobox.splat.SplatGame;
import dev.autobox.util.Sidebar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.GameMode;
import org.bukkit.util.Vector;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class LobbyManager {

    private final AutoBoxPlugin plugin;
    private final LuckyPillarsGame luckyPillars;
    private final BlockSumoGame blockSumo;
    private final ChickenRunGame chickenRun;
    private final HoleInWallGame holeInWall;
    private final SplatGame splat;
    private final ZombieApocalypseGame zombieApocalypse;
    private final RatSeekGame ratSeek;
    private final Location lobbySpawn;
    private final NamespacedKey npcKey;
    private final Map<GameType, LinkedHashSet<UUID>> queues = new EnumMap<>(GameType.class);
    private final Map<UUID, GameType> spectators = new HashMap<>();
    private BukkitTask sidebarTask;
    private final Map<UUID, Sidebar> lobbyBoards = new HashMap<>();
    private final Map<UUID, Integer> lastReturnTick = new HashMap<>();
    private boolean sidebarRefreshQueued;
    private LobbyAttractions attractions;

    public LobbyManager(AutoBoxPlugin plugin, LuckyPillarsGame luckyPillars, BlockSumoGame blockSumo,
                        ChickenRunGame chickenRun, HoleInWallGame holeInWall, SplatGame splat,
                         ZombieApocalypseGame zombieApocalypse, RatSeekGame ratSeek, Location lobbySpawn) {
        this.plugin = plugin;
        this.luckyPillars = luckyPillars;
        this.blockSumo = blockSumo;
        this.chickenRun = chickenRun;
        this.holeInWall = holeInWall;
        this.splat = splat;
        this.zombieApocalypse = zombieApocalypse;
        this.ratSeek = ratSeek;
        this.lobbySpawn = lobbySpawn;
        this.npcKey = new NamespacedKey(plugin, "game_npc");
        for (GameType type : GameType.values()) {
            queues.put(type, new LinkedHashSet<>());
        }
        splat.setLobbyHooks(player -> isQueueHost(player, GameType.SPLAT),
                () -> queuedPlayers(GameType.SPLAT).size(),
                player -> start(GameType.SPLAT, player),
                this::joinSplatQueue);
        ratSeek.setLobbyHooks(player -> isQueueHost(player, GameType.RAT_SEEK),
                player -> queuedPlayers(GameType.RAT_SEEK).size() >= minPlayers(GameType.RAT_SEEK),
                this::startRatSeekFromMenu,
                () -> queuedPlayers(GameType.RAT_SEEK));
    }

    private boolean isQueueHost(Player player, GameType type) {
        LinkedHashSet<UUID> queue = queues.get(type);
        return !queue.isEmpty() && queue.iterator().next().equals(player.getUniqueId());
    }

    /** "Play again" from a Splatoon results card: join the queue without toggling out of it. */
    private void joinSplatQueue(Player player) {
        if (!player.isOnline() || queues.get(GameType.SPLAT).contains(player.getUniqueId())) {
            return;
        }
        select(player, GameType.SPLAT);
    }

    /** "Play again" after a match: join the queue (or spectate) without toggling out if already queued. */
    public void joinAgain(Player player, GameType type) {
        if (!player.isOnline() || queues.get(type).contains(player.getUniqueId())) {
            player.sendMessage(Component.text("You're already in the " + displayName(type) + " queue.", NamedTextColor.GRAY));
            return;
        }
        select(player, type);
    }

    private void startRatSeekFromMenu(Player player) {
        if (!player.isOnline() || !isQueueHost(player, GameType.RAT_SEEK) || isRunning(GameType.RAT_SEEK)) {
            return;
        }
        start(GameType.RAT_SEEK, player);
    }

    public void setAttractions(LobbyAttractions attractions) {
        this.attractions = attractions;
    }

    public void start() {
        spawnNpcs();
        sidebarTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            sweepSpectators();
            updateLobbySidebars();
        }, 1L, 20L);
    }

    public void shutdown() {
        if (sidebarTask != null) {
            sidebarTask.cancel();
        }
    }

    public NamespacedKey getNpcKey() {
        return npcKey;
    }

    public void handleNpc(Player player, Entity entity) {
        String value = entity.getPersistentDataContainer().get(npcKey, PersistentDataType.STRING);
        if (value == null) {
            return;
        }
        select(player, GameType.valueOf(value));
    }

    public void select(Player player, GameType type) {
        if (luckyPillars.isPlaying(player) || blockSumo.isPlaying(player) || chickenRun.isPlaying(player)
                || holeInWall.isPlaying(player) || splat.isPlaying(player)
                || zombieApocalypse.isPlaying(player) || ratSeek.isPlaying(player)) {
            player.sendMessage(Component.text("Leave your current game before joining another.", NamedTextColor.RED));
            return;
        }
        if (isRunning(type)) {
            spectate(player, type);
            return;
        }

        LinkedHashSet<UUID> queue = queues.get(type);
        UUID id = player.getUniqueId();
        int needed = minPlayers(type);
        if (queue.contains(id)) {
            UUID host = queue.iterator().next();
            if (type == GameType.RAT_SEEK && host.equals(id) && player.isSneaking()) {
                ratSeek.openLobbySettings(player);
                return;
            }
            if (type == GameType.SPLAT && host.equals(id) && !player.isSneaking()) {
                splat.openHostMenu(player);
                return;
            }
            if (host.equals(id) && !player.isSneaking()) {
                if (queue.size() < needed) {
                    player.sendMessage(Component.text("You are the host. "
                            + (needed - queue.size()) + " more player" + (needed - queue.size() > 1 ? "s" : "")
                            + " needed." + (type == GameType.RAT_SEEK
                            ? " Sneak-right-click to open the host settings."
                            : " Sneak-right-click to leave."), NamedTextColor.YELLOW));
                } else {
                    start(type, player);
                }
            } else {
                queue.remove(id);
                player.sendMessage(Component.text("You left the " + displayName(type) + " queue.", NamedTextColor.GRAY));
            }
            updateLobbySidebars();
            return;
        }

        if (queue.size() >= type.maxPlayers()) {
            player.sendMessage(Component.text("That queue is full.", NamedTextColor.RED));
            return;
        }
        leaveQueues(player);
        queue.add(id);
        boolean host = queue.size() == 1;
        player.sendMessage(Component.text(host
                ? "You are the " + displayName(type) + " host. Right-click again to start once "
                        + needed + "+ players join." + (type == GameType.RAT_SEEK
                        ? " Sneak-right-click to open the host settings (" + ratSeek.settingsSummary() + ")."
                        : type == GameType.SPLAT
                        ? " Right-click again to pick the mode and map (" + splat.settingsSummary() + ")."
                        : "")
                : "Joined " + displayName(type) + " (" + queue.size() + "/" + type.maxPlayers() + ").", host ? NamedTextColor.GOLD : NamedTextColor.GREEN));
        if (queue.size() >= type.maxPlayers()) {
            start(type, player);
        } else {
            updateLobbySidebars();
        }
    }

    /** Drops a lobby player into a running match as a spectator. */
    public void spectate(Player player, GameType type) {
        Location view = spectateLocation(type);
        if (view == null || view.getWorld() == null) {
            player.sendMessage(Component.text("That game is currently running. Try again after this round.",
                    NamedTextColor.RED));
            return;
        }
        leaveQueues(player);
        spectators.put(player.getUniqueId(), type);
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        player.setGameMode(GameMode.SPECTATOR);
        player.teleport(view);
        player.sendMessage(Component.text("Now spectating " + displayName(type)
                + ". Type /lobby to come back.", NamedTextColor.LIGHT_PURPLE));
        player.sendActionBar(Component.text("Spectating " + displayName(type), NamedTextColor.LIGHT_PURPLE));
    }

    public boolean isSpectating(Player player) {
        return spectators.containsKey(player.getUniqueId());
    }

    private Location spectateLocation(GameType type) {
        return switch (type) {
            case SPLAT -> splat.getSpectateLocation();
            case LUCKY_PILLARS -> luckyPillars.getSpectateLocation();
            case BLOCK_SUMO -> blockSumo.getSpectateLocation();
            case CHICKEN_RUN -> chickenRun.getSpectateLocation();
            case HOLE_IN_THE_WALL -> holeInWall.getSpectateLocation();
            case ZOMBIE_APOCALYPSE -> zombieApocalypse.getSpectateLocation();
            case RAT_SEEK -> ratSeek.getSpectateLocation();
        };
    }

    private boolean isRunning(GameType type) {
        return switch (type) {
            case SPLAT -> splat.isRunning();
            case LUCKY_PILLARS -> luckyPillars.isRunning();
            case BLOCK_SUMO -> blockSumo.isRunning();
            case CHICKEN_RUN -> chickenRun.isRunning();
            case HOLE_IN_THE_WALL -> holeInWall.isRunning();
            case ZOMBIE_APOCALYPSE -> zombieApocalypse.isRunning();
            case RAT_SEEK -> ratSeek.isRunning();
        };
    }

    /** Returns spectators to the lobby once the match they were watching is over. */
    private void sweepSpectators() {
        for (Map.Entry<UUID, GameType> entry : new ArrayList<>(spectators.entrySet())) {
            if (isRunning(entry.getValue())) {
                continue;
            }
            Player player = Bukkit.getPlayer(entry.getKey());
            spectators.remove(entry.getKey());
            if (player != null && player.isOnline()) {
                returnToLobby(player);
                player.sendMessage(Component.text("The match ended - back to the lobby.", NamedTextColor.GRAY));
            }
        }
    }

    public void leave(Player player) {
        spectators.remove(player.getUniqueId());
        leaveQueues(player);
        luckyPillars.handleQuit(player);
        blockSumo.handleQuit(player);
        chickenRun.handleQuit(player);
        holeInWall.handleQuit(player);
        splat.handleQuit(player);
        zombieApocalypse.handleQuit(player);
        ratSeek.handleQuit(player);
        requestSidebarRefresh();
    }

    public void returnToLobby(Player player) {
        lastReturnTick.put(player.getUniqueId(), Bukkit.getCurrentTick());
        leave(player);
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        player.setFireTicks(0);
        player.setFallDistance(0);
        player.setVelocity(new Vector());
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20);
        player.setGameMode(GameMode.ADVENTURE);
        AttributeInstance attackSpeed = player.getAttribute(Attribute.ATTACK_SPEED);
        if (attackSpeed != null) {
            attackSpeed.setBaseValue(64.0);
        }
        // Block Sumo twists resize players and change gravity; never let that leak into the lobby.
        dev.autobox.sumo.SumoMutator.clear(player);
        player.teleport(lobbySpawn);
        if (attractions != null) {
            attractions.giveLobbyItems(player);
        }
        updateLobbySidebar(player);
    }

    public void onJoin(Player player) {
        // A crash mid-round would otherwise save a Giants or Moon Base body into the player file.
        dev.autobox.sumo.SumoMutator.clear(player);
        if (attractions != null) {
            attractions.giveLobbyItems(player);
        }
        updateLobbySidebar(player);
    }

    /** Repairs state after any game teleports a player directly back to the lobby. */
    public void handleLobbyArrival(Player player) {
        if (player.getWorld() != lobbySpawn.getWorld()) {
            return;
        }
        Bukkit.getScheduler().runTask(plugin, () -> {
            // A game that already sent this player back through returnToLobby triggers this via the
            // world change too; doing the whole reset twice per player made match ends spike.
            Integer returned = lastReturnTick.get(player.getUniqueId());
            if (returned != null && Bukkit.getCurrentTick() - returned <= 1) {
                return;
            }
            if (player.isOnline() && player.getWorld() == lobbySpawn.getWorld()) {
                returnToLobby(player);
            }
        });
    }

    public void onQuit(Player player) {
        lobbyBoards.remove(player.getUniqueId());
        lastReturnTick.remove(player.getUniqueId());
        leave(player);
    }

    private void start(GameType type, Player sender) {
        LinkedHashSet<UUID> queue = queues.get(type);
        List<Player> roster = queue.stream().map(Bukkit::getPlayer).filter(player -> player != null && player.isOnline()).toList();
        int needed = minPlayers(type);
        if (roster.size() < needed) {
            sender.sendMessage(Component.text("Need at least " + needed + " online queued player" + (needed > 1 ? "s" : "") + ".", NamedTextColor.RED));
            return;
        }
        try {
            switch (type) {
                case SPLAT -> splat.start(sender, roster);
                case LUCKY_PILLARS -> luckyPillars.start(sender, roster);
                case BLOCK_SUMO -> blockSumo.start(sender, roster);
                case CHICKEN_RUN -> chickenRun.start(sender, roster);
                case HOLE_IN_THE_WALL -> holeInWall.start(sender, roster);
                case ZOMBIE_APOCALYPSE -> zombieApocalypse.start(sender, roster);
                case RAT_SEEK -> ratSeek.start(sender, roster);
            }
            // Never discard a healthy queue before the game has actually accepted it.
            if (isRunning(type)) {
                queue.clear();
            }
        } catch (Throwable failure) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE,
                    "Could not start " + displayName(type) + "; keeping " + roster.size() + " players queued", failure);
            sender.sendMessage(Component.text("That game could not start. Your party is still queued; an admin can retry after a restart.",
                    NamedTextColor.RED));
        }
        updateLobbySidebars();
    }

    public List<Player> queuedPlayers(GameType type) {
        return queues.get(type).stream().map(Bukkit::getPlayer).filter(java.util.Objects::nonNull).filter(Player::isOnline).toList();
    }

    private int minPlayers(GameType type) {
        return type == GameType.RAT_SEEK ? ratSeek.minimumPlayers() : type.minPlayers();
    }

    private void leaveQueues(Player player) {
        for (Set<UUID> queue : queues.values()) {
            queue.remove(player.getUniqueId());
        }
    }

    private void spawnNpcs() {
        World world = lobbySpawn.getWorld();
        for (Entity entity : new ArrayList<>(world.getEntities())) {
            if (entity.getPersistentDataContainer().has(npcKey, PersistentDataType.STRING)) {
                entity.remove();
            }
        }
        spawnNpc(new Location(world, -5.5, 103, -2.5), GameType.SPLAT.name(),
                Component.text("Splatoon", NamedTextColor.GOLD, TextDecoration.BOLD));
        spawnNpc(new Location(world, -2.5, 103, -2.5), GameType.CHICKEN_RUN.name(),
                Component.text("ChickenRun Pro+ Ultra", NamedTextColor.YELLOW, TextDecoration.BOLD));
        spawnNpc(new Location(world, 0.5, 103, -2.5), GameType.LUCKY_PILLARS.name(),
                Component.text("Lucky Pillars", NamedTextColor.GOLD, TextDecoration.BOLD));
        spawnNpc(new Location(world, 3.5, 103, -2.5), GameType.BLOCK_SUMO.name(),
                Component.text("Block Sumo", NamedTextColor.AQUA, TextDecoration.BOLD));
        spawnNpc(new Location(world, 6.5, 103, -2.5), GameType.HOLE_IN_THE_WALL.name(),
                Component.text("Hole in the Wall", NamedTextColor.BLUE, TextDecoration.BOLD));
        spawnNpc(new Location(world, -8.5, 103, -2.5), GameType.ZOMBIE_APOCALYPSE.name(),
                Component.text("Zombie Apocalypse", NamedTextColor.DARK_GREEN, TextDecoration.BOLD));
        spawnNpc(new Location(world, 9.5, 103, -2.5), GameType.RAT_SEEK.name(),
                Component.text("Rat and Seek", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
    }

    private void spawnNpc(Location location, String key, Component name) {
        Villager villager = location.getWorld().spawn(location, Villager.class);
        villager.setAI(false);
        villager.setInvulnerable(true);
        villager.setSilent(true);
        villager.setCollidable(false);
        villager.setRemoveWhenFarAway(false);
        villager.setProfession(key.equals("RAT_SEEK") ? Villager.Profession.FARMER
                : key.equals("ZOMBIE_APOCALYPSE") ? Villager.Profession.ARMORER : Villager.Profession.LIBRARIAN);
        villager.getPersistentDataContainer().set(npcKey, PersistentDataType.STRING, key);
        spawnNpcLabel(location.clone().add(0, 2.55, 0), key, name);
        spawnNpcLabel(location.clone().add(0, 2.25, 0), key,
                Component.text("Right-click to join / watch", NamedTextColor.GREEN));
    }

    private void spawnNpcLabel(Location location, String key, Component text) {
        ArmorStand label = location.getWorld().spawn(location, ArmorStand.class);
        label.setInvisible(true);
        label.setMarker(true);
        label.setGravity(false);
        label.setInvulnerable(true);
        label.setSilent(true);
        label.customName(text);
        label.setCustomNameVisible(true);
        label.getPersistentDataContainer().set(npcKey, PersistentDataType.STRING, key);
    }

    private void updateLobbySidebars() {
        for (Player player : lobbySpawn.getWorld().getPlayers()) {
            updateLobbySidebar(player);
        }
    }

    private void updateLobbySidebar(Player player) {
        // One board per player for as long as they are online; only changed lines get sent.
        Sidebar sidebar = lobbyBoards.computeIfAbsent(player.getUniqueId(), id -> new Sidebar("worlds",
                Component.text("WORLDS", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD)));
        List<String> lines = new ArrayList<>(11);
        lines.add(ChatColor.GRAY + "Fun Minigame Server");
        lines.add(" ");
        lines.add(ChatColor.GOLD + "Splatoon: " + status(GameType.SPLAT, splat.isRunning())
                + (splat.isRunning() ? "" : ChatColor.GRAY + " " + splat.modeShort()));
        lines.add(ChatColor.DARK_AQUA + "Lucky Pillars: " + status(GameType.LUCKY_PILLARS, luckyPillars.isRunning()));
        lines.add(ChatColor.AQUA + "Block Sumo: " + status(GameType.BLOCK_SUMO, blockSumo.isRunning()));
        lines.add(ChatColor.YELLOW + "ChickenRun: " + status(GameType.CHICKEN_RUN, chickenRun.isRunning()));
        lines.add(ChatColor.BLUE + "Hole Wall: " + status(GameType.HOLE_IN_THE_WALL, holeInWall.isRunning()));
        lines.add(ChatColor.GREEN + "Zombie Apocalypse: " + status(GameType.ZOMBIE_APOCALYPSE, zombieApocalypse.isRunning()));
        lines.add(ChatColor.LIGHT_PURPLE + "Rat and Seek: " + status(GameType.RAT_SEEK, ratSeek.isRunning()));
        lines.add("  ");
        lines.add(ChatColor.GREEN + queuedGame(player));
        sidebar.lines(lines, 13);
        sidebar.show(player);
    }

    /** Coalesces refresh requests (queue changes, a whole match returning at once) into one pass next tick. */
    private void requestSidebarRefresh() {
        if (sidebarRefreshQueued) {
            return;
        }
        sidebarRefreshQueued = true;
        Bukkit.getScheduler().runTask(plugin, () -> {
            sidebarRefreshQueued = false;
            updateLobbySidebars();
        });
    }

    private String status(GameType type, boolean running) {
        return running ? "Playing (watch)" : queues.get(type).size() + "/" + type.maxPlayers();
    }

    private String queuedGame(Player player) {
        for (Map.Entry<GameType, LinkedHashSet<UUID>> entry : queues.entrySet()) {
            if (entry.getValue().contains(player.getUniqueId())) {
                boolean host = entry.getValue().iterator().next().equals(player.getUniqueId());
                return (host ? "Host: " : "Queued: ") + displayName(entry.getKey());
            }
        }
        return "Right-click an NPC";
    }

    private String displayName(GameType type) {
        return switch (type) {
            case SPLAT -> "Splatoon";
            case LUCKY_PILLARS -> "Lucky Pillars";
            case BLOCK_SUMO -> "Block Sumo";
            case CHICKEN_RUN -> "ChickenRun";
            case HOLE_IN_THE_WALL -> "Hole in the Wall";
            case ZOMBIE_APOCALYPSE -> "Zombie Apocalypse";
            case RAT_SEEK -> "Rat and Seek";
        };
    }
}
