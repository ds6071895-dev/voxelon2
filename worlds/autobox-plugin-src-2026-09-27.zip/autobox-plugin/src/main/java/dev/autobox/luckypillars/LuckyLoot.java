package dev.autobox.luckypillars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;

/**
 * The Lucky Pillars loot table: a hand-picked list of useful items, each with its own weight. Junk never appears.
 * Item factories only run on the server; the headless checks just read names, rarities and weights.
 */
public final class LuckyLoot {

    public enum Rarity {
        COMMON("Common", NamedTextColor.WHITE, 0),
        UNCOMMON("Uncommon", NamedTextColor.GREEN, 0.5),
        RARE("Rare", NamedTextColor.AQUA, 1),
        EPIC("Epic", NamedTextColor.LIGHT_PURPLE, 1),
        LEGENDARY("Legendary", NamedTextColor.GOLD, 1);

        public final String label;
        public final NamedTextColor color;
        /** How strongly the late-game and Lucky Streak boost scales this tier's weight. */
        public final double boostExponent;

        Rarity(String label, NamedTextColor color, double boostExponent) {
            this.label = label;
            this.color = color;
            this.boostExponent = boostExponent;
        }
    }

    /** One loot table line. {@code starter} marks building blocks, used for the guaranteed first drop. */
    public record Entry(String name, Rarity rarity, int weight, boolean starter, Supplier<List<ItemStack>> make) {
        public double weight(double boost) {
            return weight * Math.pow(Math.max(1.0, boost), rarity.boostExponent);
        }
    }

    public static final List<Entry> TABLE = new ArrayList<>();

    private static final Material[] WOOL = {
            Material.WHITE_WOOL, Material.ORANGE_WOOL, Material.MAGENTA_WOOL, Material.LIGHT_BLUE_WOOL,
            Material.YELLOW_WOOL, Material.LIME_WOOL, Material.PINK_WOOL, Material.CYAN_WOOL,
            Material.PURPLE_WOOL, Material.BLUE_WOOL, Material.RED_WOOL
    };

    static {
        // ---------------------------------------------------------------- common: blocks
        add("Cobblestone", Rarity.COMMON, 40, true, () -> one(Material.COBBLESTONE, 16));
        add("Oak Planks", Rarity.COMMON, 35, true, () -> one(Material.OAK_PLANKS, 16));
        add("Wool", Rarity.COMMON, 35, true, () -> one(WOOL[ThreadLocalRandom.current().nextInt(WOOL.length)], 16));
        add("Sandstone", Rarity.COMMON, 20, true, () -> one(Material.SANDSTONE, 12));
        add("End Stone", Rarity.COMMON, 15, true, () -> one(Material.END_STONE, 10));
        add("Glass", Rarity.COMMON, 12, false, () -> one(Material.GLASS, 10));
        add("Ladders", Rarity.COMMON, 12, false, () -> one(Material.LADDER, 6));
        add("Scaffolding", Rarity.COMMON, 12, false, () -> one(Material.SCAFFOLDING, 6));
        add("Sand", Rarity.COMMON, 10, false, () -> one(Material.SAND, 6));
        add("Hay Bales", Rarity.COMMON, 8, false, () -> one(Material.HAY_BLOCK, 6));
        // ---------------------------------------------------------------- common: food
        add("Steak", Rarity.COMMON, 20, false, () -> one(Material.COOKED_BEEF, 3));
        add("Bread", Rarity.COMMON, 15, false, () -> one(Material.BREAD, 4));
        add("Golden Carrots", Rarity.COMMON, 12, false, () -> one(Material.GOLDEN_CARROT, 3));
        add("Apples", Rarity.COMMON, 10, false, () -> one(Material.APPLE, 4));
        add("Baked Potatoes", Rarity.COMMON, 10, false, () -> one(Material.BAKED_POTATO, 4));
        add("Pumpkin Pie", Rarity.COMMON, 8, false, () -> one(Material.PUMPKIN_PIE, 2));
        // ---------------------------------------------------------------- common: gear
        add("Wooden Sword", Rarity.COMMON, 12, false, () -> one(Material.WOODEN_SWORD, 1));
        add("Stone Sword", Rarity.COMMON, 18, false, () -> one(Material.STONE_SWORD, 1));
        add("Stone Axe", Rarity.COMMON, 10, false, () -> one(Material.STONE_AXE, 1));
        add("Stone Pickaxe", Rarity.COMMON, 12, false, () -> one(Material.STONE_PICKAXE, 1));
        add("Shears", Rarity.COMMON, 6, false, () -> one(Material.SHEARS, 1));
        add("Snowballs", Rarity.COMMON, 22, false, () -> one(Material.SNOWBALL, 8));
        add("Eggs", Rarity.COMMON, 14, false, () -> one(Material.EGG, 8));
        add("Arrows", Rarity.COMMON, 18, false, () -> one(Material.ARROW, 8));
        add("Leather Cap", Rarity.COMMON, 8, false, () -> one(Material.LEATHER_HELMET, 1));
        add("Leather Tunic", Rarity.COMMON, 8, false, () -> one(Material.LEATHER_CHESTPLATE, 1));
        add("Leather Pants", Rarity.COMMON, 8, false, () -> one(Material.LEATHER_LEGGINGS, 1));
        add("Leather Boots", Rarity.COMMON, 8, false, () -> one(Material.LEATHER_BOOTS, 1));
        add("Fishing Rod", Rarity.COMMON, 12, false, () -> one(Material.FISHING_ROD, 1));

        // ---------------------------------------------------------------- uncommon
        add("Iron Sword", Rarity.UNCOMMON, 14, false, () -> one(Material.IRON_SWORD, 1));
        add("Iron Axe", Rarity.UNCOMMON, 8, false, () -> one(Material.IRON_AXE, 1));
        add("Iron Pickaxe", Rarity.UNCOMMON, 6, false, () -> one(Material.IRON_PICKAXE, 1));
        add("Bow", Rarity.UNCOMMON, 14, false, () -> List.of(new ItemStack(Material.BOW), new ItemStack(Material.ARROW, 6)));
        add("Crossbow", Rarity.UNCOMMON, 8, false, () -> List.of(new ItemStack(Material.CROSSBOW), new ItemStack(Material.ARROW, 6)));
        add("Chainmail Chestplate", Rarity.UNCOMMON, 7, false, () -> one(Material.CHAINMAIL_CHESTPLATE, 1));
        add("Chainmail Helmet", Rarity.UNCOMMON, 6, false, () -> one(Material.CHAINMAIL_HELMET, 1));
        add("Iron Helmet", Rarity.UNCOMMON, 6, false, () -> one(Material.IRON_HELMET, 1));
        add("Iron Boots", Rarity.UNCOMMON, 6, false, () -> one(Material.IRON_BOOTS, 1));
        add("Iron Leggings", Rarity.UNCOMMON, 5, false, () -> one(Material.IRON_LEGGINGS, 1));
        add("Ender Pearl", Rarity.UNCOMMON, 12, false, () -> one(Material.ENDER_PEARL, 1));
        add("Golden Apple", Rarity.UNCOMMON, 12, false, () -> one(Material.GOLDEN_APPLE, 1));
        add("Water Bucket", Rarity.UNCOMMON, 10, false, () -> one(Material.WATER_BUCKET, 1));
        add("Lava Bucket", Rarity.UNCOMMON, 8, false, () -> one(Material.LAVA_BUCKET, 1));
        add("TNT", Rarity.UNCOMMON, 10, false, () -> List.of(named(new ItemStack(Material.TNT, 2), "Instant TNT",
                NamedTextColor.RED, "Lights itself the moment you place it")));
        add("Wind Charges", Rarity.UNCOMMON, 10, false, () -> one(Material.WIND_CHARGE, 4));
        add("Cobwebs", Rarity.UNCOMMON, 8, false, () -> one(Material.COBWEB, 3));
        add("Slime Blocks", Rarity.UNCOMMON, 6, false, () -> one(Material.SLIME_BLOCK, 4));
        add("Honey Blocks", Rarity.UNCOMMON, 4, false, () -> one(Material.HONEY_BLOCK, 4));
        add("Knockback Stick", Rarity.UNCOMMON, 10, false, () -> List.of(enchant(named(new ItemStack(Material.STICK),
                "Knockback Stick", NamedTextColor.GREEN, null), Enchantment.KNOCKBACK, 2)));
        add("Splash Harming", Rarity.UNCOMMON, 6, false, () -> List.of(potion(Material.SPLASH_POTION, PotionType.HARMING)));
        add("Splash Poison", Rarity.UNCOMMON, 5, false, () -> List.of(potion(Material.SPLASH_POTION, PotionType.POISON)));
        add("Splash Slowness", Rarity.UNCOMMON, 5, false, () -> List.of(potion(Material.SPLASH_POTION, PotionType.SLOWNESS)));
        add("Splash Healing", Rarity.UNCOMMON, 6, false, () -> List.of(potion(Material.SPLASH_POTION, PotionType.HEALING)));
        add("Swiftness Potion", Rarity.UNCOMMON, 5, false, () -> List.of(potion(Material.POTION, PotionType.SWIFTNESS)));
        add("Leaping Potion", Rarity.UNCOMMON, 4, false, () -> List.of(potion(Material.POTION, PotionType.LEAPING)));
        add("Fire Charges", Rarity.UNCOMMON, 5, false, () -> one(Material.FIRE_CHARGE, 3));
        add("Flint and Steel", Rarity.UNCOMMON, 5, false, () -> one(Material.FLINT_AND_STEEL, 1));
        add("Anvil", Rarity.UNCOMMON, 4, false, () -> List.of(named(new ItemStack(Material.ANVIL), "Anvil",
                NamedTextColor.GREEN, "Drop it on someone's head")));
        add("Chorus Fruit", Rarity.UNCOMMON, 6, false, () -> List.of(named(new ItemStack(Material.CHORUS_FRUIT, 3),
                "Chorus Fruit", NamedTextColor.GREEN, "Eat to teleport somewhere random nearby")));
        add("Shield", Rarity.UNCOMMON, 6, false, () -> one(Material.SHIELD, 1));
        add("Spectral Arrows", Rarity.UNCOMMON, 5, false, () -> one(Material.SPECTRAL_ARROW, 8));
        add("Milk Bucket", Rarity.UNCOMMON, 3, false, () -> one(Material.MILK_BUCKET, 1));
        add("Zombie Egg", Rarity.UNCOMMON, 4, false, () -> one(Material.ZOMBIE_SPAWN_EGG, 1));
        add("Silverfish Eggs", Rarity.UNCOMMON, 4, false, () -> one(Material.SILVERFISH_SPAWN_EGG, 2));
        add("Powder Snow", Rarity.UNCOMMON, 4, false, () -> one(Material.POWDER_SNOW_BUCKET, 1));

        // ---------------------------------------------------------------- rare
        add("Diamond Sword", Rarity.RARE, 10, false, () -> one(Material.DIAMOND_SWORD, 1));
        add("Diamond Axe", Rarity.RARE, 6, false, () -> one(Material.DIAMOND_AXE, 1));
        add("Diamond Chestplate", Rarity.RARE, 6, false, () -> one(Material.DIAMOND_CHESTPLATE, 1));
        add("Diamond Helmet", Rarity.RARE, 6, false, () -> one(Material.DIAMOND_HELMET, 1));
        add("Diamond Leggings", Rarity.RARE, 5, false, () -> one(Material.DIAMOND_LEGGINGS, 1));
        add("Diamond Boots", Rarity.RARE, 6, false, () -> one(Material.DIAMOND_BOOTS, 1));
        add("Power Bow", Rarity.RARE, 7, false, () -> List.of(enchant(new ItemStack(Material.BOW), Enchantment.POWER, 2),
                new ItemStack(Material.ARROW, 10)));
        add("Yeet Bow", Rarity.RARE, 6, false, () -> List.of(enchant(named(new ItemStack(Material.BOW), "Yeet Bow",
                NamedTextColor.AQUA, "Punch II"), Enchantment.PUNCH, 2), new ItemStack(Material.ARROW, 8)));
        add("Ender Pearls", Rarity.RARE, 6, false, () -> one(Material.ENDER_PEARL, 3));
        add("Golden Apples", Rarity.RARE, 5, false, () -> one(Material.GOLDEN_APPLE, 3));
        add("Creeper Eggs", Rarity.RARE, 6, false, () -> one(Material.CREEPER_SPAWN_EGG, 2));
        add("Skeleton Egg", Rarity.RARE, 4, false, () -> one(Material.SKELETON_SPAWN_EGG, 1));
        add("Guard Dogs", Rarity.RARE, 5, false, () -> List.of(named(new ItemStack(Material.WOLF_SPAWN_EGG, 2),
                "Guard Dog", NamedTextColor.AQUA, "Hatches already tamed to you")));
        add("Loyal Trident", Rarity.RARE, 5, false, () -> List.of(enchant(new ItemStack(Material.TRIDENT), Enchantment.LOYALTY, 3)));
        add("Firework Crossbow", Rarity.RARE, 4, false, LuckyLoot::fireworkCrossbow);
        add("Strength Potion", Rarity.RARE, 5, false, () -> List.of(potion(Material.POTION, PotionType.STRENGTH)));
        add("Invisibility Potion", Rarity.RARE, 4, false, () -> List.of(potion(Material.POTION, PotionType.INVISIBILITY)));
        add("Splash Levitation", Rarity.RARE, 5, false, () -> List.of(customPotion(Material.SPLASH_POTION,
                "Splash Levitation", Color.fromRGB(0xCEFFFF), new PotionEffect(PotionEffectType.LEVITATION, 60, 2))));
        add("Splash Harming II", Rarity.RARE, 4, false, () -> {
            ItemStack stack = potion(Material.SPLASH_POTION, PotionType.STRONG_HARMING);
            stack.setAmount(2);
            return List.of(stack);
        });
        add("Fire Poker", Rarity.RARE, 4, false, () -> List.of(enchant(enchant(named(new ItemStack(Material.BLAZE_ROD),
                "Fire Poker", NamedTextColor.AQUA, null), Enchantment.FIRE_ASPECT, 2), Enchantment.KNOCKBACK, 1)));
        add("Lingering Poison", Rarity.RARE, 3, false, () -> List.of(potion(Material.LINGERING_POTION, PotionType.STRONG_POISON)));

        // ---------------------------------------------------------------- epic
        add("Enchanted Golden Apple", Rarity.EPIC, 6, false, () -> one(Material.ENCHANTED_GOLDEN_APPLE, 1));
        add("Totem of Undying", Rarity.EPIC, 6, false, () -> one(Material.TOTEM_OF_UNDYING, 1));
        add("Mace", Rarity.EPIC, 5, false, () -> List.of(new ItemStack(Material.MACE), new ItemStack(Material.WIND_CHARGE, 3)));
        add("Elytra", Rarity.EPIC, 5, false, () -> List.of(new ItemStack(Material.ELYTRA), rockets(5)));
        add("Wolf Pack", Rarity.EPIC, 4, false, () -> List.of(named(new ItemStack(Material.WOLF_SPAWN_EGG, 4),
                "Guard Dog", NamedTextColor.LIGHT_PURPLE, "Hatches already tamed to you")));
        add("End Crystals", Rarity.EPIC, 4, false, () -> List.of(named(new ItemStack(Material.END_CRYSTAL, 2),
                "End Crystal", NamedTextColor.LIGHT_PURPLE, "Place on bedrock or obsidian, then hit it")));
        add("Sharp Diamond Sword", Rarity.EPIC, 5, false, () -> List.of(enchant(new ItemStack(Material.DIAMOND_SWORD),
                Enchantment.SHARPNESS, 3)));
        add("Iron Kit", Rarity.EPIC, 4, false, () -> List.of(new ItemStack(Material.IRON_HELMET),
                new ItemStack(Material.IRON_CHESTPLATE), new ItemStack(Material.IRON_LEGGINGS), new ItemStack(Material.IRON_BOOTS)));
        add("Pearl Stash", Rarity.EPIC, 3, false, () -> one(Material.ENDER_PEARL, 8));

        // ---------------------------------------------------------------- legendary
        add("Excalibur", Rarity.LEGENDARY, 2, false, () -> List.of(enchant(enchant(named(
                new ItemStack(Material.NETHERITE_SWORD), "Excalibur", NamedTextColor.GOLD, "Sharpness V · Fire Aspect II"),
                Enchantment.SHARPNESS, 5), Enchantment.FIRE_ASPECT, 2)));
        add("Thor's Hammer", Rarity.LEGENDARY, 2, false, () -> List.of(enchant(enchant(named(new ItemStack(Material.MACE),
                "Thor's Hammer", NamedTextColor.GOLD, "Density V · Wind Burst III"), Enchantment.DENSITY, 5),
                Enchantment.WIND_BURST, 3), new ItemStack(Material.WIND_CHARGE, 6)));
        add("Juggernaut Armor", Rarity.LEGENDARY, 2, false, LuckyLoot::juggernaut);
        add("Ender Storm", Rarity.LEGENDARY, 1, false, () -> one(Material.ENDER_PEARL, 16));
    }

    private LuckyLoot() {
    }

    /**
     * Weighted pick. {@code boost} starts at 1 and grows through the match (and with Lucky Streak), which
     * makes rarer tiers more likely without ever touching the relative odds inside a tier.
     */
    public static Entry roll(Random random, double boost) {
        return pick(random, TABLE, boost);
    }

    /** The guaranteed first drop: a stack of building blocks so everyone can bridge. */
    public static Entry rollStarter(Random random) {
        return pick(random, TABLE.stream().filter(Entry::starter).toList(), 1.0);
    }

    public static double chance(Rarity rarity, double boost) {
        double total = 0;
        double tier = 0;
        for (Entry entry : TABLE) {
            double weight = entry.weight(boost);
            total += weight;
            if (entry.rarity() == rarity) {
                tier += weight;
            }
        }
        return tier / total;
    }

    private static Entry pick(Random random, List<Entry> entries, double boost) {
        double total = 0;
        for (Entry entry : entries) {
            total += entry.weight(boost);
        }
        double roll = random.nextDouble() * total;
        for (Entry entry : entries) {
            roll -= entry.weight(boost);
            if (roll <= 0) {
                return entry;
            }
        }
        return entries.get(entries.size() - 1);
    }

    private static void add(String name, Rarity rarity, int weight, boolean starter, Supplier<List<ItemStack>> make) {
        TABLE.add(new Entry(name, rarity, weight, starter, make));
    }

    // ---------------------------------------------------------------- item helpers

    private static List<ItemStack> one(Material material, int amount) {
        return List.of(new ItemStack(material, amount));
    }

    private static ItemStack named(ItemStack item, String name, NamedTextColor color, String lore) {
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        if (lore != null) {
            meta.lore(List.of(Component.text(lore, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
        }
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack enchant(ItemStack item, Enchantment enchantment, int level) {
        item.addUnsafeEnchantment(enchantment, level);
        return item;
    }

    private static ItemStack potion(Material kind, PotionType type) {
        ItemStack item = new ItemStack(kind);
        PotionMeta meta = (PotionMeta) item.getItemMeta();
        meta.setBasePotionType(type);
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack customPotion(Material kind, String name, Color color, PotionEffect effect) {
        ItemStack item = new ItemStack(kind);
        PotionMeta meta = (PotionMeta) item.getItemMeta();
        meta.addCustomEffect(effect, true);
        meta.setColor(color);
        meta.displayName(Component.text(name, NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack rockets(int amount) {
        ItemStack item = new ItemStack(Material.FIREWORK_ROCKET, amount);
        FireworkMeta meta = (FireworkMeta) item.getItemMeta();
        meta.setPower(1);
        item.setItemMeta(meta);
        return item;
    }

    private static List<ItemStack> fireworkCrossbow() {
        ItemStack crossbow = enchant(new ItemStack(Material.CROSSBOW), Enchantment.MULTISHOT, 1);
        ItemStack ammo = new ItemStack(Material.FIREWORK_ROCKET, 4);
        FireworkMeta meta = (FireworkMeta) ammo.getItemMeta();
        meta.addEffect(org.bukkit.FireworkEffect.builder().withColor(Color.RED, Color.ORANGE)
                .with(org.bukkit.FireworkEffect.Type.BALL_LARGE).build());
        meta.setPower(1);
        ammo.setItemMeta(meta);
        CrossbowMeta bowMeta = (CrossbowMeta) crossbow.getItemMeta();
        bowMeta.displayName(Component.text("Firework Crossbow", NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
        crossbow.setItemMeta(bowMeta);
        return List.of(crossbow, ammo);
    }

    private static List<ItemStack> juggernaut() {
        List<ItemStack> kit = new ArrayList<>();
        for (Material piece : new Material[]{Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE,
                Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS}) {
            kit.add(enchant(new ItemStack(piece), Enchantment.PROTECTION, 2));
        }
        return kit;
    }
}
