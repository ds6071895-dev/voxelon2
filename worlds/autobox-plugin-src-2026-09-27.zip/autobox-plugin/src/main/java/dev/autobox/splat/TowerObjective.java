package dev.autobox.splat;

import dev.autobox.splat.SplatArena.Pos;
import dev.autobox.splat.SplatRules.Team;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

import java.util.*;

/**
 * Tower Control: a real-block platform (so Bedrock sees it) that rides a fixed path toward
 * whichever team stands on it alone, pausing at checkpoints. Furthest push wins.
 */
final class TowerObjective implements Objective {
    static final int MOVE_TICKS = 16, CHECKPOINT_PAUSE = 100, RETURN_DELAY = 60, RETURN_TICKS = 30;

    private final SplatGame g;
    private final int goal;
    private final EnumMap<Team, Double> best = new EnumMap<>(Team.class);
    private final EnumMap<Team, Set<Integer>> passed = new EnumMap<>(Team.class);
    private Map<Pos, Material> placed = new LinkedHashMap<>();
    private int step, moveTimer, pauseUntil, idleSince, lastCallout = -1000;
    private Team pusher, lastPusher;
    private boolean contested;
    private ArmorStand label;

    TowerObjective(SplatGame g) {
        this.g = g;
        this.goal = g.map.towerGoal();
        for (Team team : Team.values()) { best.put(team, 0.0); passed.put(team, new HashSet<>()); }
    }

    /** Platform, a glass pillar in team colour and a lantern on top. */
    static Map<Pos, Material> blocks(Pos centre, Team rider) {
        Map<Pos, Material> blocks = new LinkedHashMap<>();
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) blocks.put(centre.add(dx, 0, dz), Material.PURPLE_CONCRETE);
        Material glass = rider == null ? Material.PURPLE_STAINED_GLASS : rider.glass;
        blocks.put(centre.add(0, 1, 0), glass);
        blocks.put(centre.add(0, 2, 0), glass);
        blocks.put(centre.add(0, 3, 0), Material.SEA_LANTERN);
        return blocks;
    }

    @Override
    public void start() {
        place(g.map.towerAt(0), null);
        idleSince = g.elapsed;
        Pos c = g.map.towerAt(0);
        label = g.world.spawn(new Location(g.world, c.x() + 0.5, c.y() + 4.6, c.z() + 0.5), ArmorStand.class, s -> {
            s.setInvisible(true); s.setMarker(true); s.setGravity(false); s.setPersistent(false); s.setCustomNameVisible(true);
        });
        g.track(label);
        relabel();
    }

    private void place(Pos centre, Team rider) {
        Map<Pos, Material> next = blocks(centre, rider);
        for (Pos p : placed.keySet()) if (!next.containsKey(p)) g.world.getBlockAt(p.x(), p.y(), p.z()).setType(g.map.blueprint().at(p), false);
        for (Map.Entry<Pos, Material> e : next.entrySet()) {
            if (placed.get(e.getKey()) != e.getValue()) g.world.getBlockAt(e.getKey().x(), e.getKey().y(), e.getKey().z()).setType(e.getValue(), false);
        }
        placed = next;
    }

    private List<Player> riders(Pos c) {
        List<Player> riders = new ArrayList<>();
        for (Player p : g.online()) {
            Inkling in = g.players.get(p.getUniqueId());
            if (!in.alive() || in.jump != null) continue;
            Location l = p.getLocation();
            if (Math.abs(l.getX() - (c.x() + 0.5)) < 1.75 && Math.abs(l.getZ() - (c.z() + 0.5)) < 1.75
                    && l.getY() >= c.y() + 0.9 && l.getY() <= c.y() + 2.6) riders.add(p);
        }
        return riders;
    }

    @Override
    public void tick() {
        Pos c = g.map.towerAt(step);
        List<Player> riders = riders(c);
        boolean orange = false, blue = false;
        for (Player p : riders) {
            if (g.players.get(p.getUniqueId()).team == Team.ORANGE) orange = true;
            else blue = true;
        }
        contested = orange && blue;
        pusher = contested ? null : orange ? Team.ORANGE : blue ? Team.BLUE : null;
        if (pusher != lastPusher) {
            if (pusher != null && g.elapsed - lastCallout > 60) {
                g.callout(pusher, "We've got the tower!", "They've got the tower!", pusher.title + " has the tower!");
                lastCallout = g.elapsed;
            }
            lastPusher = pusher;
            place(c, pusher);
        }
        if (pusher != null) {
            idleSince = g.elapsed;
            if (g.elapsed >= pauseUntil && ++moveTimer >= MOVE_TICKS / g.outnumbered(pusher)) {
                moveTimer = 0;
                int next = step + (pusher == Team.ORANGE ? 1 : -1);
                if (Math.abs(next) <= goal) move(next, riders);
            }
        } else {
            moveTimer = 0;
            if (!contested && step != 0 && g.elapsed - idleSince > RETURN_DELAY && g.elapsed % RETURN_TICKS == 0) {
                move(step + (step > 0 ? -1 : 1), riders);
            }
        }
        if (g.elapsed % 5 == 0) effects();
        if (g.elapsed % 10 == 0) relabel();
    }

    private void move(int next, List<Player> riders) {
        Pos from = g.map.towerAt(step), to = g.map.towerAt(next);
        int dx = to.x() - from.x(), dy = to.y() - from.y();
        place(to, pusher);
        step = next;
        for (Player p : riders) SplatGame.nudge(p, dx, dy, 0);
        // Anyone the platform moved into gets lifted on top instead of stuck inside.
        for (Player p : g.online()) {
            if (riders.contains(p) || !g.players.get(p.getUniqueId()).alive()) continue;
            BoundingBox body = p.getBoundingBox();
            for (Pos block : placed.keySet()) {
                if (body.overlaps(new BoundingBox(block.x(), block.y(), block.z(), block.x() + 1, block.y() + 1, block.z() + 1))) {
                    SplatGame.nudge(p, 0, to.y() + 1.01 - p.getLocation().getY(), 0);
                    break;
                }
            }
        }
        if (step != 0) {
            Team side = step > 0 ? Team.ORANGE : Team.BLUE;
            best.put(side, Math.max(best.get(side), Math.abs(step) / (double) goal));
            int reached = Math.abs(step);
            if (g.map.anchors().checkpoints().contains(reached) && passed.get(side).add(reached)) {
                pauseUntil = g.elapsed + CHECKPOINT_PAUSE;
                g.callout(side, "Checkpoint! Hold the tower!", "They reached a checkpoint!", side.title + " reached a checkpoint!");
            }
        }
        Location at = new Location(g.world, to.x() + 0.5, to.y() + 1, to.z() + 0.5);
        g.world.playSound(at, Sound.BLOCK_PISTON_EXTEND, 0.6f, 1.3f);
    }

    private void effects() {
        Pos c = g.map.towerAt(step);
        Color color = contested ? Color.WHITE : pusher == null ? Color.fromRGB(0xA040FF) : pusher.color;
        Particle.DustOptions dust = new Particle.DustOptions(color, 1.5f);
        for (int i = 0; i < 6; i++) g.world.spawnParticle(Particle.DUST, c.x() + 0.5, c.y() + 4.5 + i * 0.8, c.z() + 0.5, 1, 0.05, 0.1, 0.05, 0, dust);
        if (g.elapsed < pauseUntil) {
            for (int i = 0; i < 12; i++) {
                double a = i * Math.PI / 6 + g.elapsed * 0.1;
                g.world.spawnParticle(Particle.DUST, c.x() + 0.5 + Math.cos(a) * 2, c.y() + 1.2, c.z() + 0.5 + Math.sin(a) * 2, 1, 0, 0, 0, 0,
                        new Particle.DustOptions(Color.YELLOW, 1f));
            }
        }
    }

    private void relabel() {
        if (label == null) return;
        Pos c = g.map.towerAt(step);
        label.teleport(new Location(g.world, c.x() + 0.5, c.y() + 4.6, c.z() + 0.5));
        int left = goal - Math.abs(step);
        Component name;
        if (contested) name = Component.text("▲ TOWER ▲ contested!", NamedTextColor.WHITE, TextDecoration.BOLD);
        else if (g.elapsed < pauseUntil) name = Component.text("▲ TOWER ▲ checkpoint " + (pauseUntil - g.elapsed + 19) / 20 + "s", NamedTextColor.YELLOW, TextDecoration.BOLD);
        else if (step == 0) name = Component.text("▲ TOWER ▲ ride it!", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD);
        else {
            Team side = step > 0 ? Team.ORANGE : Team.BLUE;
            name = Component.text("▲ TOWER ▲ " + side.title + " · " + left + " to go", side.text, TextDecoration.BOLD);
        }
        label.customName(name);
    }

    @Override
    public double count(Team team) { return RankedRules.progressCount(best.get(team)); }

    @Override
    public Team advantage() { return pusher; }

    @Override
    public Team winner() { return RankedRules.winner(count(Team.ORANGE), count(Team.BLUE)); }

    @Override
    public void sidebar(List<String> lines) {
        String state = contested ? "§fcontested" : pusher == null ? "§7nobody" : (pusher == Team.ORANGE ? "§6" : "§9") + pusher.title;
        lines.add("§fTower: " + state);
        int toGo = goal - Math.abs(step);
        lines.add(step == 0 ? "§7At the centre" : (step > 0 ? "§6" : "§9") + toGo + " blocks from goal");
    }

    @Override
    public String hint(Inkling in) {
        int ours = in.team == Team.ORANGE ? step : -step;
        if (ours > 0) return "Tower " + (goal - ours) + " to their base";
        if (ours < 0) return "Tower " + (goal + ours) + " from OUR base!";
        return "Ride the tower!";
    }

    @Override
    public void cleanup() {
        for (Pos p : placed.keySet()) g.world.getBlockAt(p.x(), p.y(), p.z()).setType(g.map.blueprint().at(p), false);
        placed.clear();
        if (label != null) label.remove();
    }
}
