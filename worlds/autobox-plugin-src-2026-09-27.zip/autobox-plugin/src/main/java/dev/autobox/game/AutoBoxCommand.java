package dev.autobox.game;

import dev.autobox.AutoBoxPlugin;
import dev.autobox.luckypillars.LuckyPillarsGame;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import dev.autobox.lobby.GameType;

import java.util.ArrayList;
import java.util.List;

public class AutoBoxCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBCOMMANDS = List.of("start", "again", "stop", "lobby", "settings", "help");

    private final AutoBoxPlugin plugin;
    private final LuckyPillarsGame game;

    public AutoBoxCommand(AutoBoxPlugin plugin, LuckyPillarsGame game) {
        this.plugin = plugin;
        this.game = game;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("lobby") || command.getName().equalsIgnoreCase("leave")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(Component.text("Only players can use this command.", NamedTextColor.RED));
                return true;
            }
            returnToLobby(player);
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendHelp(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "start" -> {
                if (sender instanceof Player player) {
                    plugin.getLobbyManager().select(player, GameType.LUCKY_PILLARS);
                } else {
                    sender.sendMessage(Component.text("Players must join Lucky Pillars from the lobby NPC.", NamedTextColor.RED));
                }
            }
            case "again" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(Component.text("Only players can use this command.", NamedTextColor.RED));
                    return true;
                }
                if (game.isPlaying(player)) {
                    sender.sendMessage(Component.text("Hang on, the match is still wrapping up.", NamedTextColor.YELLOW));
                    return true;
                }
                plugin.getLobbyManager().joinAgain(player, GameType.LUCKY_PILLARS);
            }
            case "stop" -> {
                if (!sender.hasPermission("autobox.stop")) {
                    sender.sendMessage(Component.text("You don't have permission to stop Lucky Pillars.", NamedTextColor.RED));
                    return true;
                }
                if (!game.isRunning()) {
                    sender.sendMessage(Component.text("No game is running.", NamedTextColor.RED));
                } else {
                    game.endGame();
                    sender.sendMessage(Component.text("Lucky Pillars stopped.", NamedTextColor.GREEN));
                }
            }
            case "lobby", "leave" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(Component.text("Only players can use this command.", NamedTextColor.RED));
                    return true;
                }
                returnToLobby(player);
            }
            case "settings" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(Component.text("Only players can use this command.", NamedTextColor.RED));
                    return true;
                }
                plugin.openSettings(player);
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void returnToLobby(Player player) {
        plugin.getLobbyManager().returnToLobby(player);
        player.sendMessage(Component.text("You left the game and returned to the lobby.", NamedTextColor.AQUA));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase();
            List<String> result = new ArrayList<>();
            for (String sub : SUBCOMMANDS) {
                if (sub.startsWith(prefix)) {
                    result.add(sub);
                }
            }
            return result;
        }
        return List.of();
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Component.text("=== Lucky Pillars ===", NamedTextColor.GOLD));
        sender.sendMessage(Component.text("/autobox start", NamedTextColor.AQUA)
                .append(Component.text(" - join Lucky Pillars; the host uses it again to start", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/autobox again", NamedTextColor.AQUA)
                .append(Component.text(" - rejoin the queue after a match", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/autobox stop", NamedTextColor.AQUA)
                .append(Component.text(" - end the current game", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/autobox lobby", NamedTextColor.AQUA)
                .append(Component.text(" - teleport back to the lobby", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("Gameplay: ", NamedTextColor.AQUA)
                .append(Component.text("Everyone starts on a bedrock pillar over the void and gets a random item every "
                        + "3 seconds. One twist per game. After 5 minutes a 2 minute deathmatch shrinks the border to the "
                        + "golden crown. Last one standing wins.", NamedTextColor.GRAY)));
    }
}
