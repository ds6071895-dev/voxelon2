package dev.autobox.sumo;

import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;

/** The per-round twist. Pure data plus the attribute changes it makes to a player's body. */
public enum SumoMutator {
    NORMAL("Classic", "No twist. Just shove.", 1.0, 1.0, 0, 0, true),
    GIANTS("Giants", "Everyone is huge and hits harder", 1.2, 1.5, 0, 0, true),
    TINY("Tiny Brawlers", "Everyone is tiny and the arena is huge", 1.0, 0.6, 0, 0, true),
    LOW_GRAVITY("Moon Base", "Low gravity all round: floaty knockouts", 1.0, 1.0, 0.045, 0, true),
    HEAVY_HITTERS("Heavy Hitters", "Every hit knocks 40% further", 1.4, 1.0, 0, 0, true),
    WIND_CHARGES("Wind Riders", "Endless wind charges, weaker punches", 0.75, 1.0, 0, 0, true),
    MOON_SHOES("Moon Shoes", "Super jumps for everyone", 1.0, 1.0, 0, 0.7, true),
    NO_BUILD("Bare Knuckle", "No wool this round: pure fighting", 1.0, 1.0, 0, 0, false);

    public final String label;
    public final String description;
    public final double knockback;
    public final double scale;
    /** Gravity attribute, or 0 for the default. */
    public final double gravity;
    /** Jump strength attribute, or 0 for the default. */
    public final double jump;
    public final boolean building;

    SumoMutator(String label, String description, double knockback, double scale, double gravity, double jump,
                boolean building) {
        this.label = label;
        this.description = description;
        this.knockback = knockback;
        this.scale = scale;
        this.gravity = gravity;
        this.jump = jump;
        this.building = building;
    }

    /** Pairs that make a round miserable are never drawn. */
    public boolean allowedOn(SumoArena.Kind arena) {
        return switch (this) {
            case LOW_GRAVITY, MOON_SHOES -> arena != SumoArena.Kind.BOUNCE;
            case NO_BUILD -> arena != SumoArena.Kind.HEX && arena != SumoArena.Kind.RIFT;
            default -> true;
        };
    }

    public void apply(Player player) {
        set(player, Attribute.SCALE, scale == 1.0 ? -1 : scale);
        set(player, Attribute.GRAVITY, gravity == 0 ? -1 : gravity);
        set(player, Attribute.JUMP_STRENGTH, jump == 0 ? -1 : jump);
    }

    /** Puts a player's body back to vanilla; safe to call on anyone, any time. */
    public static void clear(Player player) {
        set(player, Attribute.SCALE, -1);
        set(player, Attribute.GRAVITY, -1);
        set(player, Attribute.JUMP_STRENGTH, -1);
    }

    private static void set(Player player, Attribute attribute, double value) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance == null) return;
        double target = value < 0 ? instance.getDefaultValue() : value;
        if (instance.getBaseValue() != target) instance.setBaseValue(target);
    }
}
