package dev.autobox.splat;

import dev.autobox.splat.SplatArena.Pos;
import dev.autobox.splat.SplatRules.Team;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Rainmaker: burst the glass shield in the middle, then carry the Rainmaker onto the enemy
 * pedestal. Shield and pedestals are real blocks and the Rainmaker is a dropped item, so
 * Bedrock players see everything.
 */
final class RainmakerObjective implements Objective {
    static final double SHIELD_HEALTH = 100;
    private enum State { SHIELD, LOOSE, CARRIED }

    private final SplatGame g;
    private final Pos shield;
    private final Set<Pos> shieldBlocks = new LinkedHashSet<>();
    private final Map<Pos, Material> placed = new LinkedHashMap<>();
    private final EnumMap<Team, Double> damage = new EnumMap<>(Team.class), best = new EnumMap<>(Team.class);
    private State state = State.SHIELD;
    private Item loose;
    private UUID carrier;
    private Team carrierTeam, winnerByGoal;
    private ArmorStand label;
    private int lastHitSound;

    RainmakerObjective(SplatGame g) {
        this.g = g;
        this.shield = g.map.anchors().shield();
        for (Team team : Team.values()) { damage.put(team, 0.0); best.put(team, 0.0); }
    }

    @Override
    public void start() {
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
                for (int dz = -1; dz <= 1; dz++)
                    if (Math.abs(dx) + Math.abs(dy) + Math.abs(dz) <= 2) shieldBlocks.add(shield.add(dx, dy, dz));
        for (Pos p : shieldBlocks) set(p, Material.WHITE_STAINED_GLASS);
        // Pedestals: a gold 3x3 step in front of each base.
        for (Team team : Team.values()) {
            Pos goal = g.map.anchors().goal().get(team);
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) set(goal.add(dx, 1, dz), Material.GOLD_BLOCK);
        }
        label = g.world.spawn(new Location(g.world, shield.x() + 0.5, shield.y() + 2.4, shield.z() + 0.5), ArmorStand.class, s -> {
            s.setInvisible(true); s.setMarker(true); s.setGravity(false); s.setPersistent(false); s.setCustomNameVisible(true);
        });
        g.track(label);
        relabel();
    }

    private void set(Pos p, Material material) {
        placed.putIfAbsent(p, g.map.blueprint().at(p));
        g.world.getBlockAt(p.x(), p.y(), p.z()).setType(material, false);
    }

    private void restore(Pos p) {
        Material original = placed.remove(p);
        if (original != null) g.world.getBlockAt(p.x(), p.y(), p.z()).setType(original, false);
    }

    // ------------------------------------------------------------------ shield

    @Override
    public boolean hitBlock(Pos pos, Team team, double amount) {
        if (state != State.SHIELD || !shieldBlocks.contains(pos)) return false;
        damageShield(team, amount);
        return true;
    }

    @Override
    public void blast(Location at, Team team, double radius, double amount) {
        if (state != State.SHIELD) return;
        Location centre = new Location(g.world, shield.x() + 0.5, shield.y() + 0.5, shield.z() + 0.5);
        if (at.getWorld() == g.world && at.distance(centre) <= radius + 1.5) damageShield(team, amount);
    }

    private void damageShield(Team team, double amount) {
        amount *= g.outnumbered(team);
        damage.merge(team, amount, Double::sum);
        Location centre = new Location(g.world, shield.x() + 0.5, shield.y() + 0.5, shield.z() + 0.5);
        g.world.spawnParticle(Particle.DUST, centre, 6, 0.8, 0.8, 0.8, 0, SplatGame.dust(team));
        if (g.elapsed - lastHitSound >= 3) {
            lastHitSound = g.elapsed;
            g.world.playSound(centre, Sound.BLOCK_GLASS_HIT, 1f, 0.8f + (float) (damage.get(team) / SHIELD_HEALTH));
        }
        if (damage.get(team) >= SHIELD_HEALTH) burst(team);
        else if (g.elapsed % 2 == 0) relabel();
    }

    private void burst(Team team) {
        state = State.LOOSE;
        for (Pos p : shieldBlocks) restore(p);
        Location centre = new Location(g.world, shield.x() + 0.5, shield.y() + 0.5, shield.z() + 0.5);
        g.weapons.explode(centre, team, null, Weapon.RAINMAKER, 2, 12, 4, 6, 4);
        g.world.playSound(centre, Sound.BLOCK_GLASS_BREAK, 1.5f, 0.7f);
        g.callout(team, "We burst the shield! Grab the Rainmaker!", "They burst the shield! Stop them!", team.title + " burst the shield!");
        drop(centre.clone().add(0, -0.4, 0));
    }

    // ------------------------------------------------------------------ carrying

    private void drop(Location at) {
        state = State.LOOSE;
        carrier = null;
        carrierTeam = null;
        loose = g.dropStill(at, g.uniqueItem(Weapon.RAINMAKER), true);
        loose.setGlowing(true);
        relabel();
    }

    private void carry(Player p, Inkling in) {
        if (loose != null) { loose.remove(); g.entities.remove(loose); loose = null; }
        state = State.CARRIED;
        carrier = in.id;
        carrierTeam = in.team;
        in.rainmaker = true;
        g.setSquid(p, in, false);
        g.weapons.cancelCharge(p, in);
        p.setGlowing(true);
        g.refreshHotbar(p, in);
        g.armor(p, in);
        p.getInventory().setHeldItemSlot(SplatGame.MAIN_SLOT);
        g.world.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_GOLD, 1f, 0.8f);
        g.callout(in.team, "We have the Rainmaker!", "The enemy has the Rainmaker!", in.team.title + " has the Rainmaker!");
        relabel();
    }

    private void release(Player p, Inkling in) {
        in.rainmaker = false;
        if (p != null) {
            p.setGlowing(false);
            if (in.alive() && g.phase == SplatGame.Phase.PLAY && g.players.containsKey(in.id)) { g.refreshHotbar(p, in); g.armor(p, in); }
        }
    }

    @Override
    public void onSplat(Player victim, Inkling in, Location at) {
        if (state != State.CARRIED || !in.id.equals(carrier)) return;
        release(victim, in);
        Location spot = at.getY() < SplatArena.VOID_Y + 3 ? g.map.centre(g.world).add(0, 5, 0) : at.clone().add(0, 0.5, 0);
        drop(spot);
        g.callout(in.team, "We lost the Rainmaker!", "They dropped the Rainmaker!", "The Rainmaker was dropped!");
    }

    @Override
    public void tick() {
        switch (state) {
            case LOOSE -> {
                if (loose == null || !loose.isValid() || loose.getLocation().getY() < SplatArena.VOID_Y) {
                    if (loose != null) loose.remove();
                    drop(g.map.centre(g.world).add(0, 5, 0));
                    return;
                }
                if (g.elapsed % 5 == 0)
                    g.world.spawnParticle(Particle.DUST, loose.getLocation().add(0, 0.6, 0), 4, 0.3, 0.4, 0.3, 0, new Particle.DustOptions(Color.fromRGB(0xFFD23F), 1.2f));
                for (Player p : g.online()) {
                    Inkling in = g.players.get(p.getUniqueId());
                    if (!in.alive() || in.jump != null || in.splashdownAt >= 0 || in.booyahAt >= 0) continue;
                    if (p.getLocation().distanceSquared(loose.getLocation()) < 1.6 * 1.6) { carry(p, in); break; }
                }
            }
            case CARRIED -> {
                Player p = Bukkit.getPlayer(carrier);
                Inkling in = g.players.get(carrier);
                if (p == null || in == null || !in.alive()) {
                    if (in != null) release(p, in);
                    drop(p != null ? p.getLocation() : g.map.centre(g.world).add(0, 5, 0));
                    return;
                }
                Location l = p.getLocation();
                best.put(in.team, Math.max(best.get(in.team), g.map.progress(in.team, l.getX())));
                if (g.elapsed % 4 == 0) g.world.spawnParticle(Particle.DUST, l.clone().add(0, 2.3, 0), 3, 0.3, 0.2, 0.3, 0, new Particle.DustOptions(Color.fromRGB(0xFFD23F), 1.3f));
                Pos goal = g.map.anchors().goal().get(in.team);
                double dx = l.getX() - (goal.x() + 0.5), dz = l.getZ() - (goal.z() + 0.5);
                if (dx * dx + dz * dz < 2.2 && l.getY() >= goal.y() + 1.9 && l.getY() <= goal.y() + 3) {
                    best.put(in.team, 1.0);
                    winnerByGoal = in.team;
                }
                if (g.elapsed % 10 == 0) relabel();
            }
            default -> {}
        }
    }

    private void relabel() {
        if (label == null) return;
        Component name = switch (state) {
            case SHIELD -> {
                double o = damage.get(Team.ORANGE), b = damage.get(Team.BLUE);
                yield Component.text("◈ SHIELD ◈ ", NamedTextColor.WHITE, TextDecoration.BOLD)
                        .append(Component.text((int) Math.min(99, o) + "%", Team.ORANGE.text))
                        .append(Component.text(" / ", NamedTextColor.GRAY))
                        .append(Component.text((int) Math.min(99, b) + "%", Team.BLUE.text));
            }
            case LOOSE -> Component.text("◈ RAINMAKER is loose! ◈", NamedTextColor.GOLD, TextDecoration.BOLD);
            case CARRIED -> Component.text("◈ " + carrierTeam.title + " has the Rainmaker ◈", carrierTeam.text, TextDecoration.BOLD);
        };
        label.customName(name);
    }

    @Override
    public boolean allowSquid(Inkling in) { return !in.rainmaker; }

    @Override
    public boolean allowSuperJump(Inkling in) { return !in.rainmaker; }

    @Override
    public double count(Team team) { return RankedRules.progressCount(best.get(team)); }

    @Override
    public Team knockout() { return winnerByGoal != null ? winnerByGoal : Objective.super.knockout(); }

    @Override
    public Team advantage() { return state == State.CARRIED ? carrierTeam : null; }

    @Override
    public Team winner() { return RankedRules.winner(count(Team.ORANGE), count(Team.BLUE)); }

    @Override
    public void sidebar(List<String> lines) {
        switch (state) {
            case SHIELD -> lines.add("§fShield §6" + (int) Math.min(99, damage.get(Team.ORANGE)) + "% §7/ §9" + (int) Math.min(99, damage.get(Team.BLUE)) + "%");
            case LOOSE -> lines.add("§eRainmaker is loose!");
            case CARRIED -> lines.add((carrierTeam == Team.ORANGE ? "§6" : "§9") + "Carried by " + g.roster.get(carrier).name);
        }
    }

    @Override
    public String hint(Inkling in) {
        if (in.rainmaker) return "♦ Take it to the gold pedestal!";
        return switch (state) {
            case SHIELD -> "Shoot the shield!";
            case LOOSE -> "Grab the Rainmaker!";
            case CARRIED -> carrierTeam == in.team ? "Escort the carrier!" : "Splat the carrier!";
        };
    }

    @Override
    public void cleanup() {
        for (Pos p : new ArrayList<>(placed.keySet())) restore(p);
        if (loose != null) loose.remove();
        if (label != null) label.remove();
        for (Inkling in : g.players.values()) {
            if (!in.rainmaker) continue;
            in.rainmaker = false;
            Player p = Bukkit.getPlayer(in.id);
            if (p != null) p.setGlowing(false);
        }
    }
}
