package dev.autobox.splat;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.Material;

import java.util.*;

/** Pure turf-war rules: no world access, so arenaCheck can simulate them. */
public final class SplatRules {
    public static final int MIN_PLAYERS = 2, MAX_PLAYERS = 10;
    /** Phase lengths in ticks. */
    public static final int COUNTDOWN = 200, PLAY = 3600, JUDGING = 80, RESULTS = 240;
    public static final int RESPAWN = 100, SPAWN_PROTECTION = 40, COMBAT_REGEN_DELAY = 40;
    public static final double MAX_INK = 100, MAX_HEALTH = 20;
    /** A full tank refills in 18 seconds normally and 3 seconds as a squid. */
    public static final double INK_REGEN = MAX_INK / 360, SQUID_REGEN_MULTIPLIER = 6;
    /** Health regained per tick once out of combat (3 HP a second). */
    public static final double HEALTH_REGEN = 0.15;
    /** Player hitboxes are padded for ink shots, so grazing hits count like in Splatoon. */
    public static final double HIT_FORGIVENESS = 0.25;
    /** Special gauge: bonus per splat, and the share kept after being splatted. */
    public static final double SPECIAL_MAX = 100, SPECIAL_PER_SPLAT = 12, SPECIAL_KEPT_ON_SPLAT = 0.5;

    public enum Team {
        ORANGE("Orange", Material.ORANGE_CONCRETE, Material.ORANGE_STAINED_GLASS, Color.fromRGB(0xFF7A00), NamedTextColor.GOLD),
        BLUE("Blue", Material.BLUE_CONCRETE, Material.BLUE_STAINED_GLASS, Color.fromRGB(0x2F55FF), NamedTextColor.BLUE);

        public final String title;
        public final Material ink, glass;
        public final Color color;
        public final NamedTextColor text;

        Team(String title, Material ink, Material glass, Color color, NamedTextColor text) {
            this.title = title; this.ink = ink; this.glass = glass; this.color = color; this.text = text;
        }

        public Team opponent() { return this == ORANGE ? BLUE : ORANGE; }
    }

    private SplatRules() {}

    public static boolean validParty(int size) { return size >= MIN_PLAYERS && size <= MAX_PLAYERS; }

    /** Shuffled alternating split: team sizes never differ by more than one. */
    public static Map<UUID, Team> assign(List<UUID> roster, Random random) {
        List<UUID> order = new ArrayList<>(roster);
        Collections.shuffle(order, random);
        Team first = random.nextBoolean() ? Team.ORANGE : Team.BLUE;
        Map<UUID, Team> teams = new LinkedHashMap<>();
        for (int i = 0; i < order.size(); i++) teams.put(order.get(i), i % 2 == 0 ? first : first.opponent());
        return teams;
    }

    /**
     * How many enemies each player on this team faces per teammate: 2 for the solo in a 2v1, 1.5 in
     * a 3v2, 1 when level or ahead. Every underdog boost scales from it, so a lone player gets
     * double ink and special, half damage taken and half the respawn wait, while 5v4 barely changes.
     */
    public static double outnumbered(Team team, Map<Team, Integer> sizes) {
        int own = sizes.getOrDefault(team, 0), other = sizes.getOrDefault(team.opponent(), 0);
        return own <= 0 || other <= own ? 1 : other / (double) own;
    }

    /** The outnumbered team refills ink faster. */
    public static double regenMultiplier(Team team, Map<Team, Integer> sizes) {
        return outnumbered(team, sizes);
    }

    public static double damageTaken(double damage, Team team, Map<Team, Integer> sizes) {
        return damage / outnumbered(team, sizes);
    }

    public static int respawnTicks(Team team, Map<Team, Integer> sizes) {
        return (int) Math.round(RESPAWN / outnumbered(team, sizes));
    }

    /** Full damage until fullUntil ticks of flight, then a linear fade to damage * minFactor at fadeUntil. */
    public static double falloff(double damage, int age, int fullUntil, int fadeUntil, double minFactor) {
        if (age <= fullUntil) return damage;
        if (age >= fadeUntil) return damage * minFactor;
        double t = (age - fullUntil) / (double) (fadeUntil - fullUntil);
        return damage * (1 - t * (1 - minFactor));
    }

    public static double shotDamage(Weapon weapon, int age) {
        Weapon.Ballistics b = weapon.ballistics;
        return falloff(weapon.damage, age, b.fullUntil(), b.fadeUntil(), b.minFactor());
    }

    /** Only a full charge splats in one hit; partial shots stay below a full health bar. */
    public static double chargerDamage(double charge) {
        return charge >= 1 ? Weapon.CHARGER.damage : Weapon.CHARGER_MIN_DAMAGE + Weapon.CHARGER_PARTIAL_DAMAGE * Math.max(0, charge);
    }

    public static double chargerRange(double charge) {
        return Weapon.CHARGER_MIN_RANGE + (Weapon.CHARGER_RANGE - Weapon.CHARGER_MIN_RANGE) * clamp(charge);
    }

    public static double chargerInk(double charge) {
        return Weapon.CHARGER_MIN_INK + (Weapon.CHARGER.ink - Weapon.CHARGER_MIN_INK) * clamp(charge);
    }

    /** Charge reached after held ticks, capped by what the tank can pay for. */
    public static double charge(int held, double ink) {
        double affordable = (ink - Weapon.CHARGER_MIN_INK) / (Weapon.CHARGER.ink - Weapon.CHARGER_MIN_INK);
        return Math.max(0, Math.min(Math.min(1, held / (double) Weapon.CHARGE_TICKS), affordable));
    }

    public static double specialPerTurf(Weapon weapon) { return weapon.specialTurf <= 0 ? 0 : SPECIAL_MAX / weapon.specialTurf; }

    private static double clamp(double value) { return Math.max(0, Math.min(1, value)); }

    public static double percent(int painted, int total) { return total <= 0 ? 0 : painted * 100.0 / total; }

    /** Both teams share one turf total, so exact block counts decide; null is a draw. */
    public static Team winner(int orange, int blue) {
        return orange == blue ? null : orange > blue ? Team.ORANGE : Team.BLUE;
    }

    public static String format(double percent) { return String.format(Locale.ROOT, "%.1f%%", percent); }

    public static String clock(int ticks) {
        int seconds = Math.max(0, (ticks + 19) / 20);
        return seconds / 60 + ":" + String.format(Locale.ROOT, "%02d", seconds % 60);
    }
}
