package dev.autobox.splat;

import dev.autobox.splat.SplatRules.Team;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.*;

/** Pure Elo, rank letters, XP levels and rating-balanced teams; SplatCheck exercises all of it. */
public final class SplatRating {
    public static final int START = 1000, PROVISIONAL = 5, PLACEMENT = 10, MAX_LEVEL = 99;
    public static final double K_PLACEMENT = 48, K = 32, KNOCKOUT_BONUS = 1.2, MISSING_PLAYER = 60;

    public enum Rank {
        C_MINUS("C-", 0, NamedTextColor.GRAY), C("C", 850, NamedTextColor.GRAY), C_PLUS("C+", 900, NamedTextColor.GRAY),
        B_MINUS("B-", 950, NamedTextColor.GREEN), B("B", 1000, NamedTextColor.GREEN), B_PLUS("B+", 1050, NamedTextColor.GREEN),
        A_MINUS("A-", 1100, NamedTextColor.AQUA), A("A", 1150, NamedTextColor.AQUA), A_PLUS("A+", 1200, NamedTextColor.AQUA),
        S("S", 1300, NamedTextColor.GOLD), S_PLUS("S+", 1400, NamedTextColor.GOLD), X("X", 1500, NamedTextColor.LIGHT_PURPLE);

        public final String label;
        public final int from;
        public final NamedTextColor color;

        Rank(String label, int from, NamedTextColor color) { this.label = label; this.from = from; this.color = color; }
    }

    private SplatRating() {}

    public static Rank rank(int rating) {
        Rank result = Rank.C_MINUS;
        for (Rank rank : Rank.values()) if (rating >= rank.from) result = rank;
        return result;
    }

    /** "?" until a player has finished enough matches in the mode. */
    public static String label(int rating, int matches) { return matches < PROVISIONAL ? "?" : rank(rating).label; }

    /** Win probability for a team; the outnumbered side is treated as stronger by a fixed amount per missing player. */
    public static double expected(double teamAverage, double opponentAverage, int teamSize, int opponentSize) {
        double own = teamAverage + MISSING_PLAYER * Math.max(0, opponentSize - teamSize);
        double other = opponentAverage + MISSING_PLAYER * Math.max(0, teamSize - opponentSize);
        return 1 / (1 + Math.pow(10, (other - own) / 400));
    }

    /** score: 1 win, 0.5 draw, 0 loss. */
    public static int delta(int matchesBefore, double expected, double score, boolean knockoutWin) {
        double k = matchesBefore < PLACEMENT ? K_PLACEMENT : K;
        if (knockoutWin && score >= 1) k *= KNOCKOUT_BONUS;
        return (int) Math.round(k * (score - expected));
    }

    // ------------------------------------------------------------------ XP and levels

    public static long xpToNext(int level) { return 400 + 80L * level; }

    /** Level reached with this much lifetime XP, starting at level 1. */
    public static int level(long xp) {
        int level = 1;
        while (level < MAX_LEVEL && xp >= xpToNext(level)) { xp -= xpToNext(level); level++; }
        return level;
    }

    /** XP already earned inside the current level. */
    public static long xpIntoLevel(long xp) {
        int level = 1;
        while (level < MAX_LEVEL && xp >= xpToNext(level)) { xp -= xpToNext(level); level++; }
        return xp;
    }

    public static int matchXp(boolean win, boolean draw, int turf, int splats, int assists, int specials) {
        return 100 + (win ? 60 : draw ? 30 : 0) + turf / 10 + 15 * splats + 10 * assists + 20 * specials;
    }

    // ------------------------------------------------------------------ teams

    /**
     * Snake draft on rating (best player to a random team, then two and two), so team sizes differ by
     * at most one and the strongest players spread out. Equal ratings are shuffled first.
     */
    public static Map<UUID, Team> draft(List<UUID> roster, Map<UUID, Integer> ratings, Random random) {
        List<UUID> order = new ArrayList<>(roster);
        Collections.shuffle(order, random);
        order.sort(Comparator.comparingInt((UUID id) -> ratings.getOrDefault(id, START)).reversed());
        Team first = random.nextBoolean() ? Team.ORANGE : Team.BLUE;
        Map<UUID, Team> teams = new LinkedHashMap<>();
        for (int i = 0; i < order.size(); i++) {
            // 0 A, 1 B, 2 B, 3 A, 4 A, 5 B, 6 B, 7 A ...
            boolean a = (i % 4 == 0) || (i % 4 == 3);
            teams.put(order.get(i), a ? first : first.opponent());
        }
        // Odd rosters: the snake can hand the last pick to the bigger team; move it so sizes stay within one.
        long firstCount = teams.values().stream().filter(t -> t == first).count(), secondCount = teams.size() - firstCount;
        if (Math.abs(firstCount - secondCount) > 1) {
            Team big = firstCount > secondCount ? first : first.opponent();
            UUID last = order.reversed().stream().filter(id -> teams.get(id) == big).findFirst().orElseThrow();
            teams.put(last, big.opponent());
        }
        return teams;
    }
}
