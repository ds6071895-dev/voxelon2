package dev.autobox.splat;

import dev.autobox.splat.SplatRules.Team;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** One player's state for the current match. */
final class Inkling {
    /** An in-progress Super Jump: target is a teammate id, a beakon/spawn location, launched at launchAt, lands at landAt. */
    record Jump(UUID mate, Location spot, Location from, int launchAt, int landAt) {}

    final UUID id;
    final String name;
    final Team team;
    final int slot;
    final int[] ready = new int[Weapon.values().length];
    Kit kit;
    double ink = SplatRules.MAX_INK, special;
    int painted, splats, assists, splatted, specials, respawnAt = -1, protectedUntil, lastHurt = -1000, lastFire = -1000, heldSlot;
    int chargeStart = -1, lastClick = -1000, splashdownAt = -1, killcamUntil = -1, streak, lastSplatAt = -1000, noticeUntil;
    boolean squid, chargeFull, slamming, specialAnnounced, climbing;
    Weapon chargeWeapon;
    UUID lastAttacker;
    Weapon lastWeapon;
    Location lastPos;
    Vector lastMove = new Vector();
    Component notice;
    /** Everyone who damaged this player recently, for assists. */
    final Map<UUID, Integer> damagedBy = new HashMap<>();

    // Feel: hit markers, damage tint and heartbeat.
    int hitMarkerUntil = -1, nextHeartbeat;
    boolean hitMarkerSplat;
    double tint;

    // Dualies dodge roll.
    int rolls, rollReadyAt, turretUntil = -1;

    // Specials in progress.
    int trizookaShots, trizookaUntil, booyahAt = -1;

    Jump jump;

    // Objectives.
    int clams;
    boolean powerClam, rainmaker;

    Inkling(UUID id, String name, Team team, int slot, Kit kit) {
        this.id = id; this.name = name; this.team = team; this.slot = slot; this.kit = kit;
    }

    boolean alive() { return respawnAt < 0; }

    /** What slot 0 holds right now. */
    Weapon main() { return rainmaker ? Weapon.RAINMAKER : trizookaShots > 0 ? Weapon.TRIZOOKA : kit.main; }

    /** Busy with something that stops normal firing. */
    boolean busy() { return !alive() || squid || splashdownAt >= 0 || booyahAt >= 0 || jump != null; }
}
