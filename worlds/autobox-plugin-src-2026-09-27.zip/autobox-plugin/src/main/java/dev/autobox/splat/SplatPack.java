package dev.autobox.splat;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.HexFormat;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Serves the Splatoon pack on loopback to a dedicated cloudflared quick tunnel
 * (deploy/worlds-pack-tunnel.service). Quick-tunnel hostnames change whenever cloudflared
 * restarts, so the public URL is read from cloudflared's metrics endpoint at every match start.
 * Bukkit-free so PackServeCheck can exercise the same code without a server.
 */
public final class SplatPack {
    public static final UUID PACK_ID = UUID.nameUUIDFromBytes("worlds:splat-pack".getBytes(StandardCharsets.UTF_8));
    /** Must match deploy/worlds-pack-tunnel.service. */
    public static final int LOCAL_PORT = 8765, METRICS_PORT = 20250;
    public static final String PATH = "/splat-pack.zip", RESOURCE = "splat-pack.zip";
    private static final Pattern HOSTNAME = Pattern.compile("\"hostname\"\\s*:\\s*\"([A-Za-z0-9.-]+)\"");

    private final Logger logger;
    private final byte[] zip;
    private final String sha1;
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
    private HttpServer server;
    private ExecutorService executor;
    private volatile String lastUrl;

    public SplatPack(Logger logger, byte[] zip) {
        this.logger = logger;
        this.zip = zip.clone();
        this.sha1 = sha1(zip);
    }

    public static SplatPack fromResource(Logger logger, ClassLoader loader) throws IOException {
        try (InputStream in = loader.getResourceAsStream(RESOURCE)) {
            if (in == null) throw new FileNotFoundException(RESOURCE + " is missing from the plugin jar");
            return new SplatPack(logger, in.readAllBytes());
        }
    }

    public static String sha1(byte[] data) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-1").digest(data));
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(impossible);
        }
    }

    public String sha1() { return sha1; }
    public boolean serving() { return server != null; }

    public void start() {
        if (server != null) return;
        try {
            server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), LOCAL_PORT), 16);
            executor = Executors.newFixedThreadPool(2, task -> {
                Thread thread = new Thread(task, "splat-pack-http");
                thread.setDaemon(true);
                return thread;
            });
            server.createContext("/", this::handle);
            server.setExecutor(executor);
            server.start();
            logger.info("Splatoon pack (" + zip.length + " bytes, sha1 " + sha1 + ") served on 127.0.0.1:" + LOCAL_PORT);
        } catch (IOException failure) {
            logger.log(Level.WARNING, "Splatoon pack server could not bind 127.0.0.1:" + LOCAL_PORT
                    + "; matches will use vanilla visuals", failure);
            stop();
        }
    }

    public void stop() {
        if (server != null) { server.stop(0); server = null; }
        if (executor != null) { executor.shutdownNow(); executor = null; }
    }

    private void handle(HttpExchange exchange) throws IOException {
        try {
            String method = exchange.getRequestMethod();
            if (!exchange.getRequestURI().getPath().equals(PATH) || !(method.equals("GET") || method.equals("HEAD"))) {
                exchange.sendResponseHeaders(404, -1);
                return;
            }
            exchange.getResponseHeaders().set("Content-Type", "application/zip");
            exchange.getResponseHeaders().set("Cache-Control", "no-cache");
            if (method.equals("HEAD")) {
                exchange.sendResponseHeaders(200, -1);
                return;
            }
            exchange.sendResponseHeaders(200, zip.length);
            exchange.getResponseBody().write(zip);
        } finally {
            exchange.close();
        }
    }

    /** The tunnel's current public pack URL; empty when cloudflared is down or has no hostname yet. */
    public CompletableFuture<Optional<String>> resolve() {
        HttpRequest request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + METRICS_PORT + "/quicktunnel"))
                .timeout(Duration.ofSeconds(2)).GET().build();
        return client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).handle((response, failure) -> {
            Optional<String> host = failure == null && response.statusCode() == 200 ? hostname(response.body()) : Optional.empty();
            if (host.isEmpty()) {
                logger.warning("Splatoon pack tunnel unavailable (cloudflared metrics on 127.0.0.1:" + METRICS_PORT
                        + "); this match uses vanilla visuals");
                return Optional.empty();
            }
            String url = "https://" + host.get() + PATH;
            if (!url.equals(lastUrl)) logger.info("Splatoon pack URL is now " + url);
            lastUrl = url;
            return Optional.of(url);
        });
    }

    static Optional<String> hostname(String body) {
        Matcher matcher = HOSTNAME.matcher(body);
        return matcher.find() ? Optional.of(matcher.group(1)) : Optional.empty();
    }

    public ResourcePackRequest request(String url) {
        return ResourcePackRequest.resourcePackRequest()
                .packs(ResourcePackInfo.resourcePackInfo(PACK_ID, URI.create(url), sha1))
                .replace(false)
                .required(false)
                .prompt(Component.text("Splatoon ink textures for this match. They are removed when you leave.",
                        NamedTextColor.GOLD))
                .build();
    }
}
