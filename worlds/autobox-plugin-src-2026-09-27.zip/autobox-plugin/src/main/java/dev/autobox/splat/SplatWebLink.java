package dev.autobox.splat;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Replaces the old in-lobby Splatoon board with a sign pointing at the leaderboard website. Clicking it
 * (right or left, Java or Bedrock) sends a clickable link in chat. Uses the old board's entity tag so
 * any leftovers from it are cleaned up.
 */
public final class SplatWebLink implements Listener {
    public static final String URL = "https://worlds.87-106-96-176.sslip.io:8443";
    private static final String SHORT = "worlds.87-106-96-176.sslip.io:8443";
    private static final TextColor[] INK = {
            TextColor.color(0xFF7A00), TextColor.color(0xFFB000), TextColor.color(0xFF4FD8),
            TextColor.color(0x9B5CFF), TextColor.color(0x2F55FF), TextColor.color(0x00D1FF)};
    private static final double LINE = 0.3;

    private final Plugin plugin;
    private final Location top;
    private final NamespacedKey key;
    private final List<ArmorStand> lines = new ArrayList<>();
    private final Map<UUID, Long> cooldown = new HashMap<>();
    private Interaction hitbox;
    private BukkitTask task;
    private int age;

    public SplatWebLink(Plugin plugin, Location top) {
        this.plugin = plugin;
        this.top = top;
        this.key = new NamespacedKey(plugin, "splat_board");
    }

    public void start() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
        spawn();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 5L);
    }

    public void stop() {
        if (task != null) task.cancel();
        task = null;
        HandlerList.unregisterAll(this);
        removeAll();
    }

    /** Sends the clickable link; also used by /splat top. */
    public static void sendLink(Player player) {
        player.sendMessage(Component.text("Leaderboards » ", NamedTextColor.GOLD, TextDecoration.BOLD)
                .append(Component.text(URL, NamedTextColor.AQUA).decoration(TextDecoration.BOLD, false)
                        .decorate(TextDecoration.UNDERLINED)
                        .clickEvent(ClickEvent.openUrl(URL))
                        .hoverEvent(HoverEvent.showText(Component.text("Open the Worlds leaderboards")))));
    }

    private void spawn() {
        removeAll();
        for (Entity e : top.getWorld().getNearbyEntities(top, 6, 8, 6))
            if (e.getPersistentDataContainer().has(key, PersistentDataType.BYTE)) e.remove();
        Location first = top.clone().subtract(0, 1.0, 0);
        lines.add(label(first, title()));
        lines.add(label(first.clone().subtract(0, LINE, 0), Component.text("Splatoon · Rat and Seek · Zombies · Parkour", NamedTextColor.GRAY)));
        lines.add(label(first.clone().subtract(0, 2 * LINE, 0), Component.text(SHORT, NamedTextColor.AQUA, TextDecoration.UNDERLINED)));
        lines.add(label(first.clone().subtract(0, 3 * LINE, 0), hint()));
        hitbox = top.getWorld().spawn(first.clone().subtract(0, 3 * LINE + 0.3, 0), Interaction.class, i -> {
            i.setInteractionWidth(3.2f);
            i.setInteractionHeight(1.5f);
            i.setResponsive(true);
            tag(i);
        });
    }

    private void tick() {
        if (!top.getWorld().isChunkLoaded(top.getBlockX() >> 4, top.getBlockZ() >> 4)) return;
        if (hitbox == null || !hitbox.isValid() || lines.stream().anyMatch(s -> !s.isValid())) { spawn(); return; }
        if (top.getWorld().getPlayers().isEmpty()) return;
        age++;
        lines.getFirst().customName(title());
        lines.getLast().customName(hint());
    }

    private Component title() {
        String word = "★ LEADERBOARDS ★";
        Component c = Component.empty();
        for (int i = 0; i < word.length(); i++)
            c = c.append(Component.text(word.charAt(i), INK[Math.floorMod(i - age / 2, INK.length)], TextDecoration.BOLD));
        return c;
    }

    private Component hint() {
        return Component.text("» Click for the link «", age / 4 % 2 == 0 ? NamedTextColor.YELLOW : NamedTextColor.GOLD);
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent event) {
        if (event.getRightClicked().equals(hitbox)) { event.setCancelled(true); clicked(event.getPlayer()); }
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (event.getEntity().equals(hitbox) && event.getDamager() instanceof Player p) { event.setCancelled(true); clicked(p); }
    }

    private void clicked(Player player) {
        long now = System.currentTimeMillis();
        Long last = cooldown.get(player.getUniqueId());
        if (last != null && now - last < 1500) return;
        cooldown.put(player.getUniqueId(), now);
        sendLink(player);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.8f, 1.6f);
    }

    private ArmorStand label(Location at, Component text) {
        return at.getWorld().spawn(at, ArmorStand.class, s -> {
            s.setInvisible(true);
            s.setMarker(true);
            s.setGravity(false);
            s.setInvulnerable(true);
            s.setSilent(true);
            s.customName(text);
            s.setCustomNameVisible(true);
            tag(s);
        });
    }

    private void tag(Entity entity) {
        entity.setPersistent(false);
        entity.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
    }

    private void removeAll() {
        lines.forEach(Entity::remove);
        lines.clear();
        if (hitbox != null) hitbox.remove();
        hitbox = null;
    }
}
