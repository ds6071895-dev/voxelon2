package dev.autobox.ratseek;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Class picks, cooldowns and the four class abilities. */
final class RatSeekAbilities {
    private static final int WHISKER_TICKS = 100;
    private static final int DECOY_TICKS = 80;
    private static final double DECOY_SPEED = 0.26;
    private static final String DECOY_TAG = "rat_decoy";

    private final RatSeekGame game;
    private final World world;
    private final NamespacedKey key;
    private final Map<UUID, RatClass> classes = new HashMap<>();
    private final Map<UUID, Integer> cooldowns = new HashMap<>();
    private final Map<UUID, Integer> whiskers = new HashMap<>();
    private final List<Decoy> decoys = new ArrayList<>();

    private static final class Decoy {
        final ArmorStand stand;
        final UUID owner;
        final Vector step;
        int ticks;

        Decoy(ArmorStand stand, UUID owner, Vector step) {
            this.stand = stand;
            this.owner = owner;
            this.step = step;
        }
    }

    RatSeekAbilities(RatSeekGame game, World world, NamespacedKey key) {
        this.game = game;
        this.world = world;
        this.key = key;
    }

    RatClass classOf(UUID rat) {
        return classes.get(rat);
    }

    boolean is(UUID rat, RatClass ratClass) {
        return classes.get(rat) == ratClass;
    }

    int count(RatClass ratClass) {
        return (int) classes.values().stream().filter(c -> c == ratClass).count();
    }

    Map<RatClass, Integer> counts() {
        Map<RatClass, Integer> result = new EnumMap<>(RatClass.class);
        for (RatClass ratClass : RatClass.values()) {
            result.put(ratClass, count(ratClass));
        }
        return result;
    }

    /** Picks a class if its cap allows it; returns a failure message or null on success. */
    String choose(UUID rat, RatClass ratClass, int ratCount) {
        if (classes.get(rat) == ratClass) {
            return null;
        }
        if (count(ratClass) >= RatClass.cap(ratCount)) {
            return "Too many " + ratClass.displayName + "s already (max " + RatClass.cap(ratCount) + ").";
        }
        classes.put(rat, ratClass);
        return null;
    }

    /** Gives every rat without a class the least-picked one (random among ties). */
    void assignMissing(List<UUID> ratIds, java.util.Random random) {
        for (UUID id : ratIds) {
            if (classes.containsKey(id)) {
                continue;
            }
            int fewest = Integer.MAX_VALUE;
            List<RatClass> options = new ArrayList<>();
            for (RatClass ratClass : RatClass.values()) {
                int count = count(ratClass);
                if (count < fewest) {
                    fewest = count;
                    options.clear();
                }
                if (count == fewest) {
                    options.add(ratClass);
                }
            }
            classes.put(id, options.get(random.nextInt(options.size())));
        }
    }

    void forget(UUID id) {
        classes.remove(id);
        cooldowns.remove(id);
        whiskers.remove(id);
    }

    int cooldown(UUID id) {
        return cooldowns.getOrDefault(id, 0);
    }

    void resetCooldown(UUID id) {
        cooldowns.put(id, 0);
    }

    ItemStack abilityItem(UUID rat) {
        RatClass ratClass = classes.get(rat);
        if (ratClass == null) {
            return null;
        }
        return game.taggedItem(ratClass.abilityIcon, "ability", ratClass.abilityName + " (" + ratClass.displayName + ")",
                ratClass.color, "Right-click: " + ratClass.abilityDescription + " • "
                        + ratClass.cooldownTicks / 20 + "s cooldown");
    }

    // ------------------------------------------------------------------ abilities

    void use(Player rat, RatSeekSettings settings) {
        UUID id = rat.getUniqueId();
        RatClass ratClass = classes.get(id);
        if (ratClass == null) {
            return;
        }
        int left = cooldowns.getOrDefault(id, 0);
        if (left > 0) {
            rat.sendActionBar(Component.text(String.format(java.util.Locale.ROOT, "%s ready in %.1fs",
                    ratClass.abilityName, left / 20.0), NamedTextColor.RED));
            return;
        }
        boolean used = switch (ratClass) {
            case SCOUT -> whiskerSense(rat);
            case THIEF -> cheeseMagnet(rat);
            case TRICKSTER -> decoy(rat, settings);
            case TINKERER -> disarm(rat, settings);
        };
        if (used) {
            cooldowns.put(id, ratClass.cooldownTicks);
        }
    }

    private boolean whiskerSense(Player rat) {
        whiskers.put(rat.getUniqueId(), WHISKER_TICKS);
        world.playSound(rat.getLocation(), Sound.ENTITY_RABBIT_AMBIENT, 1f, 1.8f);
        rat.playSound(rat.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.5f);
        world.spawnParticle(Particle.ENCHANT, rat.getLocation().add(0, 0.6, 0), 30, 0.4, 0.3, 0.4, 0.4);
        return true;
    }

    private boolean cheeseMagnet(Player rat) {
        Location at = rat.getLocation().add(0, 0.2, 0);
        List<Item> pulled = new ArrayList<>();
        for (Item item : game.cheeseAndBaitItems()) {
            if (item.isValid() && item.getWorld() == world && item.getLocation().distanceSquared(at) <= 36) {
                pulled.add(item);
            }
        }
        if (pulled.isEmpty()) {
            rat.sendActionBar(Component.text("No cheese within 6 blocks.", NamedTextColor.YELLOW));
            return false;
        }
        Particle.DustOptions gold = new Particle.DustOptions(Color.fromRGB(0xFFC83D), 0.9f);
        for (Item item : pulled) {
            Location from = item.getLocation();
            Vector line = at.toVector().subtract(from.toVector());
            for (double d = 0; d < line.length(); d += 0.5) {
                world.spawnParticle(Particle.DUST, from.clone().add(line.clone().normalize().multiply(d)), 1,
                        0, 0, 0, 0, gold);
            }
            item.setPickupDelay(0);
            item.teleport(at);
        }
        world.playSound(at, Sound.BLOCK_BEACON_POWER_SELECT, 0.8f, 1.9f);
        rat.sendActionBar(Component.text("Cheese Magnet pulled " + pulled.size() + "!", NamedTextColor.GOLD));
        return true;
    }

    private boolean decoy(Player rat, RatSeekSettings settings) {
        Vector step = rat.getLocation().getDirection().setY(0);
        if (step.lengthSquared() < 0.01) {
            step = new Vector(0, 0, 1);
        }
        step.normalize().multiply(DECOY_SPEED);
        Location spawn = rat.getLocation().add(step.clone().multiply(2));
        spawn.setDirection(step);
        if (!clear(spawn, settings.ratSize.scale)) {
            spawn = rat.getLocation();
            spawn.setDirection(step);
        }
        Vector finalStep = step;
        ArmorStand stand = world.spawn(spawn, ArmorStand.class, entity -> {
            entity.setBasePlate(false);
            entity.setArms(true);
            entity.setGravity(false);
            entity.setInvulnerable(false);
            entity.setPersistent(false);
            entity.setSilent(true);
            entity.setDisabledSlots(EquipmentSlot.HAND, EquipmentSlot.OFF_HAND, EquipmentSlot.HEAD,
                    EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET);
            AttributeInstance scale = entity.getAttribute(Attribute.SCALE);
            if (scale != null) {
                scale.setBaseValue(settings.ratSize.scale);
            }
            entity.getEquipment().setHelmet(RatCostume.ratHead(key, Component.text("Rat Face")));
            if (settings.costumes) {
                entity.getEquipment().setChestplate(dyed(Material.LEATHER_CHESTPLATE, 0x6B4A35));
                entity.getEquipment().setLeggings(dyed(Material.LEATHER_LEGGINGS, 0x8A6A55));
                entity.getEquipment().setBoots(dyed(Material.LEATHER_BOOTS, 0xE8A0A8));
            }
            entity.getPersistentDataContainer().set(key, PersistentDataType.STRING, DECOY_TAG);
        });
        decoys.add(new Decoy(stand, rat.getUniqueId(), finalStep));
        world.playSound(spawn, Sound.ENTITY_RABBIT_JUMP, 1.2f, 1.6f);
        world.spawnParticle(Particle.POOF, spawn.clone().add(0, 0.3, 0), 12, 0.2, 0.2, 0.2, 0.02);
        rat.sendActionBar(Component.text("Decoy away!", NamedTextColor.LIGHT_PURPLE));
        return true;
    }

    private static ItemStack dyed(Material material, int rgb) {
        ItemStack item = ItemStack.of(material);
        if (item.getItemMeta() instanceof LeatherArmorMeta meta) {
            meta.setColor(Color.fromRGB(rgb));
            item.setItemMeta(meta);
        }
        return item;
    }

    private boolean disarm(Player rat, RatSeekSettings settings) {
        RatSeekGadgets.Trap trap = game.gadgets().disarmNear(rat.getLocation(), 3);
        if (trap == null) {
            rat.sendActionBar(Component.text("No mousetrap within 3 blocks.", NamedTextColor.YELLOW));
            return false;
        }
        game.gadgets().trapGone(trap, settings);
        game.addPoints(rat.getUniqueId(), 2);
        Location at = trap.block().clone().add(0.5, 0.2, 0.5);
        world.playSound(at, Sound.ENTITY_SHEEP_SHEAR, 1.2f, 1.4f);
        world.spawnParticle(Particle.ELECTRIC_SPARK, at, 20, 0.2, 0.2, 0.2, 0.1);
        rat.sendActionBar(Component.text("Trap disarmed! +2 points", NamedTextColor.GREEN, TextDecoration.BOLD));
        game.notifyHumans(Component.text("A mousetrap in the " + game.roomAt(at) + " was sabotaged!",
                NamedTextColor.YELLOW));
        return true;
    }

    /** A human swatted a decoy: poof, a daze for the human, and a laugh for the rats. */
    boolean hitDecoy(Entity attacked, Player human) {
        for (Iterator<Decoy> iterator = decoys.iterator(); iterator.hasNext(); ) {
            Decoy decoy = iterator.next();
            if (decoy.stand.equals(attacked)) {
                iterator.remove();
                Location at = decoy.stand.getLocation().add(0, 0.4, 0);
                decoy.stand.remove();
                world.spawnParticle(Particle.POOF, at, 25, 0.3, 0.3, 0.3, 0.05);
                world.playSound(at, Sound.ENTITY_WITCH_CELEBRATE, 1.2f, 1.8f);
                human.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 2, false, false, true));
                human.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 60, 0, false, false, false));
                human.sendTitle("§d§lDECOY!", "§fThat wasn't a real rat", 0, 30, 5);
                Player owner = Bukkit.getPlayer(decoy.owner);
                if (owner != null) {
                    game.addPoints(decoy.owner, 1);
                    owner.sendActionBar(Component.text(human.getName() + " fell for your decoy! +1",
                            NamedTextColor.LIGHT_PURPLE));
                }
                return true;
            }
        }
        return isDecoy(attacked);
    }

    /** Live decoys, which AI seekers see (and may chase) just like a rat. */
    List<ArmorStand> decoyStands() {
        List<ArmorStand> result = new ArrayList<>();
        for (Decoy decoy : decoys) {
            if (decoy.stand.isValid()) {
                result.add(decoy.stand);
            }
        }
        return result;
    }

    /** An AI seeker swatted a decoy: same poof and point as a human falling for it. */
    boolean botHitDecoy(ArmorStand stand, String botName) {
        for (Iterator<Decoy> iterator = decoys.iterator(); iterator.hasNext(); ) {
            Decoy decoy = iterator.next();
            if (decoy.stand.equals(stand)) {
                iterator.remove();
                Location at = decoy.stand.getLocation().add(0, 0.4, 0);
                decoy.stand.remove();
                world.spawnParticle(Particle.POOF, at, 25, 0.3, 0.3, 0.3, 0.05);
                world.playSound(at, Sound.ENTITY_WITCH_CELEBRATE, 1.2f, 1.8f);
                Player owner = Bukkit.getPlayer(decoy.owner);
                if (owner != null) {
                    game.addPoints(decoy.owner, 1);
                    owner.sendActionBar(Component.text(botName + " fell for your decoy! +1",
                            NamedTextColor.LIGHT_PURPLE));
                }
                return true;
            }
        }
        return false;
    }

    boolean isDecoy(Entity entity) {
        return DECOY_TAG.equals(entity.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }

    // ------------------------------------------------------------------ tick

    void tick(int ticks, RatSeekSettings settings) {
        cooldowns.replaceAll((id, left) -> Math.max(0, left - 1));
        tickWhiskers(ticks);
        tickDecoys(ticks, settings);
        if (ticks % 10 == 0) {
            tickTinkerSight();
        }
    }

    boolean sensing(UUID rat) {
        return whiskers.getOrDefault(rat, 0) > 0;
    }

    private void tickWhiskers(int ticks) {
        for (Iterator<Map.Entry<UUID, Integer>> iterator = whiskers.entrySet().iterator(); iterator.hasNext(); ) {
            Map.Entry<UUID, Integer> entry = iterator.next();
            int left = entry.getValue() - 1;
            Player rat = Bukkit.getPlayer(entry.getKey());
            if (left <= 0 || rat == null) {
                iterator.remove();
                continue;
            }
            entry.setValue(left);
            if (ticks % 5 != 0) {
                continue;
            }
            List<String> parts = new ArrayList<>();
            for (Map.Entry<String, Location> seeker : game.seekerMarkers().entrySet()) {
                if (seeker.getValue().getWorld() != world) {
                    continue;
                }
                Vector to = seeker.getValue().toVector().subtract(rat.getLocation().toVector());
                parts.add(arrow(rat.getLocation().getYaw(), to) + " " + seeker.getKey() + " "
                        + Math.round(to.length()) + "m");
            }
            rat.sendActionBar(Component.text(parts.isEmpty() ? "No humans nearby" : String.join("   ", parts),
                    NamedTextColor.AQUA, TextDecoration.BOLD));
        }
    }

    /** One of eight arrows pointing from the viewer's facing towards {@code to}. */
    static String arrow(float viewerYaw, Vector to) {
        double target = Math.toDegrees(Math.atan2(-to.getX(), to.getZ()));
        double relative = ((target - viewerYaw) % 360 + 540) % 360 - 180;
        String[] arrows = {"⬆", "⬈", "➡", "⬊", "⬇", "⬋", "⬅", "⬉"};
        int index = (int) Math.floorMod(Math.round(relative / 45.0), 8);
        return arrows[index];
    }

    private void tickDecoys(int ticks, RatSeekSettings settings) {
        for (Iterator<Decoy> iterator = decoys.iterator(); iterator.hasNext(); ) {
            Decoy decoy = iterator.next();
            if (!decoy.stand.isValid()) {
                iterator.remove();
                continue;
            }
            decoy.ticks++;
            Location next = decoy.stand.getLocation().add(decoy.step);
            if (decoy.ticks >= DECOY_TICKS || !clear(next, settings.ratSize.scale)) {
                Location at = decoy.stand.getLocation().add(0, 0.4, 0);
                world.spawnParticle(Particle.POOF, at, 15, 0.2, 0.2, 0.2, 0.03);
                world.playSound(at, Sound.ENTITY_RABBIT_DEATH, 0.8f, 1.6f);
                decoy.stand.remove();
                iterator.remove();
                continue;
            }
            // Bob as it scurries so it reads as running, not sliding.
            next.setY(Math.floor(next.getY()) + (decoy.ticks % 4 < 2 ? 0.06 : 0));
            decoy.stand.teleport(next);
            if (decoy.ticks % 8 == 0) {
                world.playSound(next, Sound.ENTITY_BAT_AMBIENT, 0.9f, 1.9f);
            }
            if (decoy.ticks % 3 == 0) {
                world.spawnParticle(Particle.DUST_PLUME, next.clone().add(0, 0.05, 0), 1, 0.05, 0, 0.05, 0);
            }
        }
    }

    /** A decoy may move into a cell if its body fits and there is floor beneath it. */
    private boolean clear(Location at, double scale) {
        Block feet = at.getBlock();
        Block head = feet.getRelative(0, 1, 0);
        boolean fits = feet.isPassable() && (scale <= 0.5 || head.isPassable());
        return fits && !feet.getRelative(0, -1, 0).isPassable();
    }

    private void tickTinkerSight() {
        List<Location> traps = game.gadgets().trapLocations();
        List<Location> baits = game.gadgets().baitLocations();
        if (traps.isEmpty() && baits.isEmpty()) {
            return;
        }
        Particle.DustOptions red = new Particle.DustOptions(Color.fromRGB(0xFF3030), 1.1f);
        Particle.DustOptions orange = new Particle.DustOptions(Color.fromRGB(0xFF9A1F), 1.0f);
        for (Map.Entry<UUID, RatClass> entry : classes.entrySet()) {
            if (entry.getValue() != RatClass.TINKERER || !game.isFreeRat(entry.getKey())) {
                continue;
            }
            Player rat = Bukkit.getPlayer(entry.getKey());
            if (rat == null || rat.getWorld() != world) {
                continue;
            }
            for (Location trap : traps) {
                if (trap.distanceSquared(rat.getLocation()) <= 144) {
                    rat.spawnParticle(Particle.DUST, trap.clone().add(0.5, 0.35, 0.5), 4, 0.2, 0.1, 0.2, 0, red);
                }
            }
            for (Location bait : baits) {
                if (bait.distanceSquared(rat.getLocation()) <= 144) {
                    rat.spawnParticle(Particle.DUST, bait.clone().add(0, 0.5, 0), 4, 0.15, 0.15, 0.15, 0, orange);
                }
            }
        }
    }

    void reset() {
        decoys.forEach(decoy -> decoy.stand.remove());
        decoys.clear();
        classes.clear();
        cooldowns.clear();
        whiskers.clear();
        for (ArmorStand stand : world.getEntitiesByClass(ArmorStand.class)) {
            if (isDecoy(stand)) {
                stand.remove();
            }
        }
    }
}
