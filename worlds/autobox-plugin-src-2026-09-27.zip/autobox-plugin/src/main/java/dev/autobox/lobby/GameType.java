package dev.autobox.lobby;

public enum GameType {
    SPLAT,
    LUCKY_PILLARS,
    BLOCK_SUMO,
    CHICKEN_RUN,
    HOLE_IN_THE_WALL,
    ZOMBIE_APOCALYPSE,
    RAT_SEEK;

    public int minPlayers() { return 2; }
    public int maxPlayers() { return this == SPLAT || this == RAT_SEEK || this == LUCKY_PILLARS ? 10 : 6; }
}
