package dev.autobox.ratseek;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;

/** Rat specialisations: each adds one passive and one right-click ability on top of the shared kit. */
enum RatClass {
    SCOUT("Scout", Material.FEATHER, NamedTextColor.AQUA,
            "Scamper recharges in 8s instead of 12s.",
            "Whisker Sense", Material.STRING, "Arrows to every human for 5 seconds", 400),
    THIEF("Thief", Material.GOLD_NUGGET, NamedTextColor.GOLD,
            "+1 bonus point per cheese.",
            "Cheese Magnet", Material.LODESTONE, "Pull cheese within 6 blocks straight to you", 500),
    TRICKSTER("Trickster", Material.ARMOR_STAND, NamedTextColor.LIGHT_PURPLE,
            "Humans who swat a decoy are dazed.",
            "Decoy Rat", Material.RABBIT_HIDE, "Send a squeaking fake rat running ahead", 600),
    TINKERER("Tinkerer", Material.SHEARS, NamedTextColor.GREEN,
            "Sees mousetraps and bait sparkle nearby.",
            "Disarm", Material.SHEARS, "Break a mousetrap within 3 blocks for +2 points", 300);

    final String displayName;
    final Material icon;
    final NamedTextColor color;
    final String passive;
    final String abilityName;
    final Material abilityIcon;
    final String abilityDescription;
    final int cooldownTicks;

    RatClass(String displayName, Material icon, NamedTextColor color, String passive,
             String abilityName, Material abilityIcon, String abilityDescription, int cooldownTicks) {
        this.displayName = displayName;
        this.icon = icon;
        this.color = color;
        this.passive = passive;
        this.abilityName = abilityName;
        this.abilityIcon = abilityIcon;
        this.abilityDescription = abilityDescription;
        this.cooldownTicks = cooldownTicks;
    }

    /** Most rats that may share one class, so a lobby can't be all Scouts. */
    static int cap(int ratCount) {
        return Math.max(1, (ratCount + 1) / 2);
    }
}
