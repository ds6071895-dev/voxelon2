package dev.autobox.splat;

import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import io.papermc.paper.event.player.PlayerStopUsingItemEvent;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;

/** World-scoped protections and input routing; unrelated games keep their existing event paths. */
public final class SplatListener implements Listener {
    private final SplatGame game;

    public SplatListener(SplatGame game) { this.game = game; }

    private boolean world(Entity e) { return e.getWorld().equals(game.world()); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void move(PlayerMoveEvent e) { if (game.isWorld(e.getPlayer())) game.move(e); }

    @EventHandler
    public void jump(PlayerJumpEvent e) { if (game.isWorld(e.getPlayer())) game.jumped(e.getPlayer()); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void damage(EntityDamageEvent e) { if (world(e.getEntity())) e.setCancelled(true); }

    /** Swinging at someone fires your weapon, so melee range never beats ink. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void attack(EntityDamageByEntityEvent e) {
        if (!world(e.getEntity()) && !world(e.getDamager())) return;
        e.setCancelled(true);
        if (e.getDamager() instanceof Player attacker) game.click(attacker);
    }

    /** Ink passes through bodies (SplatWeapons sweeps its own padded hitboxes) and splashes on blocks. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void hit(ProjectileHitEvent e) {
        if (!world(e.getEntity())) return;
        e.setCancelled(true);
        if (e.getHitEntity() != null) return;
        game.projectileHit(e);
        e.getEntity().remove();
    }

    /**
     * Right-click (held repeats every 4 ticks on Java) and left-click swings both fire; Bedrock sends either.
     * Charge weapons are the one item allowed to be "used", so Java players can hold them like a bow.
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void interact(PlayerInteractEvent e) {
        if (!game.isWorld(e.getPlayer())) return;
        boolean charge = e.getHand() == EquipmentSlot.HAND && e.getAction().isRightClick() && game.canCharge(e.getPlayer());
        e.setUseInteractedBlock(Event.Result.DENY);
        e.setUseItemInHand(charge ? Event.Result.DEFAULT : Event.Result.DENY);
        if (e.getHand() != EquipmentSlot.HAND || e.getAction() == Action.PHYSICAL) return;
        game.click(e.getPlayer());
    }

    @EventHandler
    public void release(PlayerStopUsingItemEvent e) { if (game.isWorld(e.getPlayer())) game.release(e.getPlayer()); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void consume(PlayerItemConsumeEvent e) { if (game.isWorld(e.getPlayer())) e.setCancelled(true); }

    @EventHandler
    public void held(PlayerItemHeldEvent e) { if (game.isWorld(e.getPlayer())) game.heldChanged(e.getPlayer(), e.getNewSlot()); }

    @EventHandler
    public void pack(PlayerResourcePackStatusEvent e) {
        if (SplatPack.PACK_ID.equals(e.getID())) game.packStatus(e.getPlayer(), e.getStatus());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void interactEntity(PlayerInteractEntityEvent e) {
        if (!game.isWorld(e.getPlayer())) return;
        e.setCancelled(true);
        if (e.getHand() == EquipmentSlot.HAND) game.click(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void armorStand(PlayerArmorStandManipulateEvent e) { if (game.isWorld(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void breakBlock(BlockBreakEvent e) { if (game.isWorld(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void place(BlockPlaceEvent e) { if (game.isWorld(e.getPlayer())) e.setCancelled(true); }

    /** Q: the Dualies dodge roll. Items never leave the inventory. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void drop(PlayerDropItemEvent e) {
        if (!game.isWorld(e.getPlayer())) return;
        e.setCancelled(true);
        game.dropKey(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void pickup(EntityPickupItemEvent e) { if (world(e.getEntity())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void swap(PlayerSwapHandItemsEvent e) {
        if (!game.isWorld(e.getPlayer())) return;
        e.setCancelled(true);
        game.useSpecial(e.getPlayer());
    }

    /** Splatoon menus work anywhere (the host menu opens in the lobby). */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void menu(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof SplatMenu.Holder holder)) return;
        e.setCancelled(true);
        if (e.getWhoClicked() instanceof Player p && e.getClickedInventory() == e.getView().getTopInventory())
            game.menuClick(p, holder, e.getRawSlot());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void menuDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof SplatMenu.Holder) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void inventory(InventoryClickEvent e) { if (world(e.getWhoClicked())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void drag(InventoryDragEvent e) { if (world(e.getWhoClicked())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void food(FoodLevelChangeEvent e) { if (world(e.getEntity())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void explode(EntityExplodeEvent e) { if (world(e.getEntity())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void change(EntityChangeBlockEvent e) { if (world(e.getEntity())) e.setCancelled(true); }

    @EventHandler
    public void quit(PlayerQuitEvent e) { game.handleQuit(e.getPlayer()); }

    @EventHandler
    public void changeWorld(PlayerChangedWorldEvent e) {
        if (e.getFrom().equals(game.world()) && !game.isWorld(e.getPlayer())) game.handleQuit(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void respawn(PlayerRespawnEvent e) { if (game.isPlaying(e.getPlayer())) e.setRespawnLocation(game.getSpectateLocation()); }
}
