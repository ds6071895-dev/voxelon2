package dev.autobox.ratseek;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;

/**
 * Host-configurable match rules. One instance lives for the whole server session so a
 * host's setup carries over between rounds; the settings menu edits it in the lobby
 * queue and during the hiding countdown, and it is read-only once the hunt begins.
 */
final class RatSeekSettings {

    static final int[] HIDE_SECONDS = {15, 30, 45, 60, 90};
    static final int[] HUNT_MINUTES = {2, 3, 4, 5, 6, 8};
    /** Starting humans: 0 = Auto (scaled by lobby size, minus AI seekers), -1 = None. */
    static final int[] HUMAN_COUNTS = {0, -1, 1, 2, 3};
    static final double[] HUMAN_SPEEDS = {1.00, 1.15, 1.30, 1.45};
    static final int[] RESCUE_COSTS = {2, 3, 4, 5};

    enum Preset {
        EASY("Easy", "Rats start with an escape card; humans only 15% faster", NamedTextColor.YELLOW, Material.LIME_DYE),
        NORMAL("Normal", "The classic Crooked Manor ruleset", NamedTextColor.GREEN, Material.EMERALD),
        HARD("Hard", "Every rat glows for the whole round", NamedTextColor.RED, Material.REDSTONE),
        CHAOS("Chaos", "Rapid twists, a cheese feast, fast humans and escape cards", NamedTextColor.LIGHT_PURPLE,
                Material.FIREWORK_ROCKET),
        CUSTOM("Custom", "Hand-tuned by the host", NamedTextColor.AQUA, Material.WRITABLE_BOOK);

        final String displayName;
        final String description;
        final NamedTextColor color;
        final Material icon;

        Preset(String displayName, String description, NamedTextColor color, Material icon) {
            this.displayName = displayName;
            this.description = description;
            this.color = color;
            this.icon = icon;
        }
    }

    /**
     * Where a rat re-appears after a rescue, banked escape, drainpipe slip or host
     * role-swap. Furthest is the default so a fresh spawn is never a free catch.
     */
    enum RespawnMode {
        FURTHEST("Furthest", "Respawn as far from humans as possible", NamedTextColor.GREEN),
        RANDOM("Random", "Respawn at a random rat spot", NamedTextColor.YELLOW),
        CLOSEST("Closest", "Respawn near humans (spicy)", NamedTextColor.RED);

        final String displayName;
        final String description;
        final NamedTextColor color;

        RespawnMode(String displayName, String description, NamedTextColor color) {
            this.displayName = displayName;
            this.description = description;
            this.color = color;
        }
    }

    enum RatSize {
        TINY("Tiny", 0.35, "Mouse-sized and very hard to spot"),
        SMALL("Small", 0.5, "The classic rat size"),
        CHUNKY("Chunky", 0.75, "Too big for one-block crawlspaces");

        final String displayName;
        final double scale;
        final String description;

        RatSize(String displayName, double scale, String description) {
            this.displayName = displayName;
            this.scale = scale;
            this.description = description;
        }
    }

    enum CheeseSupply {
        SCARCE("Scarce", 6), NORMAL("Normal", 14), FEAST("Feast", 24);

        final String displayName;
        final int maxCheese;

        CheeseSupply(String displayName, int maxCheese) {
            this.displayName = displayName;
            this.maxCheese = maxCheese;
        }
    }

    enum HintRate {
        OFF("Off", 0), RARE("Rare", 1.6), NORMAL("Normal", 1.0), FREQUENT("Frequent", 0.6);

        final String displayName;
        final double intervalScale;

        HintRate(String displayName, double intervalScale) {
            this.displayName = displayName;
            this.intervalScale = intervalScale;
        }
    }

    enum TwistRate {
        OFF("Off", 0, 0), RARE("Rare", 900, 400), NORMAL("Normal", 500, 300), CHAOS("Chaos", 260, 160);

        final String displayName;
        final int minTicks;
        final int spreadTicks;

        TwistRate(String displayName, int minTicks, int spreadTicks) {
            this.displayName = displayName;
            this.minTicks = minTicks;
            this.spreadTicks = spreadTicks;
        }
    }

    enum CatMode {
        OFF("Off", "No cat in the house"),
        LAZY("Lazy", "Stalks rats nearby, then naps for 20s"),
        HUNGRY("Hungry", "Faster, and only naps for 10s");

        final String displayName;
        final String description;

        CatMode(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }
    }

    /** How sharp the AI seekers are. None of them ever sees through walls or knows where a rat is. */
    enum BotSkill {
        ROOKIE("Rookie", "Slow to notice, misses often, falls for tricks", NamedTextColor.GREEN,
                10.5, 0.62, 11f, 0.58, 0.95, 26, 0.10),
        REGULAR("Regular", "A decent human player", NamedTextColor.YELLOW,
                14.0, 1.0, 17f, 0.72, 1.0, 36, 0.30),
        VETERAN("Veteran", "Sharp eyes, clean swings, hard to fool", NamedTextColor.RED,
                17.5, 1.35, 24f, 0.84, 1.0, 46, 0.50);

        final String displayName;
        final String description;
        final NamedTextColor color;
        /** How far a bot can pick out a small rat in good light, in blocks. */
        final double sight;
        /** How quickly awareness builds; higher reacts sooner. */
        final double reaction;
        /** Fastest head turn in degrees per tick. */
        final float turn;
        /** Chance a well-aimed swing connects. */
        final double accuracy;
        /** Share of a human seeker's running speed (1.0 = exactly as fast as a player). */
        final double speed;
        /** Ticks a bot keeps chasing a rat it can no longer see before it starts searching. */
        final int patience;
        /** Base chance to see through a decoy before learning anything. */
        final double wits;

        BotSkill(String displayName, String description, NamedTextColor color, double sight, double reaction,
                 float turn, double accuracy, double speed, int patience, double wits) {
            this.displayName = displayName;
            this.description = description;
            this.color = color;
            this.sight = sight;
            this.reaction = reaction;
            this.turn = turn;
            this.accuracy = accuracy;
            this.speed = speed;
            this.patience = patience;
            this.wits = wits;
        }
    }

    enum Twist {
        BLACKOUT("Blackout", Material.BLACK_CANDLE, NamedTextColor.DARK_PURPLE,
                "Humans are plunged into darkness; rats get night vision"),
        RAT_RAVE("Rat Rave", Material.JUKEBOX, NamedTextColor.LIGHT_PURPLE,
                "Every rat's taunt and scamper recharge instantly"),
        CHEESE_RAIN("Cheese Rain", Material.GOLD_NUGGET, NamedTextColor.GOLD,
                "A burst of bonus cheese appears around the manor"),
        HUNTER_FRENZY("Hunter's Frenzy", Material.BLAZE_POWDER, NamedTextColor.RED,
                "Humans get a speed surge and a recharged scent pulse"),
        BOUNCY_HOUSE("Bouncy House", Material.SLIME_BALL, NamedTextColor.GREEN,
                "Everyone gets huge jump boost for ten seconds"),
        GHOST_RATS("Ghost Rats", Material.PHANTOM_MEMBRANE, NamedTextColor.WHITE,
                "Free rats turn invisible for five seconds"),
        SPOTLIGHT("Spotlight", Material.GLOWSTONE_DUST, NamedTextColor.YELLOW,
                "Every free rat glows for three seconds");

        final String displayName;
        final Material icon;
        final NamedTextColor color;
        final String description;

        Twist(String displayName, Material icon, NamedTextColor color, String description) {
            this.displayName = displayName;
            this.icon = icon;
            this.color = color;
            this.description = description;
        }
    }

    int hideSeconds;
    int huntMinutes;
    int humanCount;
    int aiSeekers;
    RatSize ratSize;
    RespawnMode respawnMode;
    double humanSpeed;
    int rescueCost;
    CheeseSupply cheese;
    HintRate hints;
    TwistRate twistRate;
    final Set<Twist> twists = EnumSet.noneOf(Twist.class);
    boolean ratsGlow;
    boolean startingEscape;
    boolean finalMinuteGlow;
    boolean scamper;
    boolean taunt;
    boolean scentPulse;
    boolean cageRattle;
    boolean rescues;
    boolean tunnelAntiCamp;
    boolean dangerSense;
    boolean lastRatRush;
    // Manor extras: presentation and atmosphere, deliberately outside the balance presets.
    boolean costumes;
    boolean cinematic;
    boolean blindfold;
    boolean flashlight;
    boolean mousetraps;
    boolean bait;
    boolean classes;
    CatMode cat;
    boolean chandeliers;
    BotSkill botSkill;
    boolean botLearning;

    RatSeekSettings() {
        resetToDefaults();
    }

    void resetToDefaults() {
        hideSeconds = 30;
        huntMinutes = 4;
        humanCount = 0;
        aiSeekers = 0;
        ratSize = RatSize.SMALL;
        respawnMode = RespawnMode.FURTHEST;
        rescueCost = 3;
        scamper = true;
        taunt = true;
        scentPulse = true;
        cageRattle = true;
        rescues = true;
        tunnelAntiCamp = true;
        dangerSense = true;
        lastRatRush = true;
        costumes = true;
        cinematic = true;
        blindfold = true;
        flashlight = true;
        mousetraps = true;
        bait = true;
        classes = true;
        cat = CatMode.LAZY;
        chandeliers = true;
        botSkill = BotSkill.REGULAR;
        botLearning = true;
        twists.clear();
        twists.addAll(EnumSet.allOf(Twist.class));
        applyPreset(Preset.NORMAL);
    }

    /** Presets only touch balance knobs; timers, team size, rat size and abilities are kept. */
    void applyPreset(Preset preset) {
        switch (preset) {
            case EASY -> setBalance(false, true, 1.15, CheeseSupply.NORMAL, HintRate.NORMAL, TwistRate.NORMAL, false);
            case NORMAL -> setBalance(false, false, 1.30, CheeseSupply.NORMAL, HintRate.NORMAL, TwistRate.NORMAL, false);
            case HARD -> setBalance(true, false, 1.30, CheeseSupply.NORMAL, HintRate.NORMAL, TwistRate.NORMAL, false);
            case CHAOS -> {
                setBalance(false, true, 1.45, CheeseSupply.FEAST, HintRate.FREQUENT, TwistRate.CHAOS, true);
                twists.addAll(EnumSet.allOf(Twist.class));
            }
            case CUSTOM -> { }
        }
    }

    private void setBalance(boolean glow, boolean escape, double speed, CheeseSupply cheeseSupply,
                            HintRate hintRate, TwistRate rate, boolean finalGlow) {
        ratsGlow = glow;
        startingEscape = escape;
        humanSpeed = speed;
        cheese = cheeseSupply;
        hints = hintRate;
        twistRate = rate;
        finalMinuteGlow = finalGlow;
    }

    Preset preset() {
        for (Preset candidate : Preset.values()) {
            if (candidate != Preset.CUSTOM && matches(candidate)) {
                return candidate;
            }
        }
        return Preset.CUSTOM;
    }

    private boolean matches(Preset candidate) {
        RatSeekSettings probe = new RatSeekSettings(this);
        probe.applyPreset(candidate);
        return probe.ratsGlow == ratsGlow && probe.startingEscape == startingEscape
                && probe.humanSpeed == humanSpeed && probe.cheese == cheese && probe.hints == hints
                && probe.twistRate == twistRate && probe.finalMinuteGlow == finalMinuteGlow
                && (candidate != Preset.CHAOS || twists.size() == Twist.values().length);
    }

    private RatSeekSettings(RatSeekSettings source) {
        twists.addAll(source.twists);
    }

    int hideTicks() {
        return hideSeconds * 20;
    }

    int huntTicks() {
        return huntMinutes * 1200;
    }

    /**
     * Humans have Speed II (+40%) and rats Speed I (+20%). This scalar bonus makes the
     * human:rat speed ratio match the host's choice: (1.4 + m) / 1.2 = ratio.
     */
    double humanSpeedModifier() {
        return 1.2 * humanSpeed - 1.4;
    }

    String humanCountName() {
        return humanCount == 0 ? "Auto" : humanCount < 0 ? "None" : Integer.toString(humanCount);
    }

    static String speedName(double ratio) {
        return ratio == 1.0 ? "Same as rats" : String.format(Locale.ROOT, "%.2fx rats", ratio);
    }

    static int cycle(int[] values, int current, int direction) {
        return values[Math.floorMod(indexOf(values, current) + direction, values.length)];
    }

    static double cycle(double[] values, double current, int direction) {
        int index = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i] == current) {
                index = i;
            }
        }
        return values[Math.floorMod(index + direction, values.length)];
    }

    static <E extends Enum<E>> E cycle(E current, int direction) {
        E[] values = current.getDeclaringClass().getEnumConstants();
        return values[Math.floorMod(current.ordinal() + direction, values.length)];
    }

    private static int indexOf(int[] values, int current) {
        for (int i = 0; i < values.length; i++) {
            if (values[i] == current) {
                return i;
            }
        }
        return 0;
    }
}
