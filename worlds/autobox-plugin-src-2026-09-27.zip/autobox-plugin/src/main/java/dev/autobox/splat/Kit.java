package dev.autobox.splat;

/** A main weapon with its fixed sub and special, like a Splatoon weapon kit. */
public enum Kit {
    SPLATTERSHOT(Weapon.SPLATTERSHOT, Weapon.BURST_BOMB, Weapon.TRIZOOKA),
    ROLLER(Weapon.ROLLER, Weapon.SUCTION_BOMB, Weapon.SPLASHDOWN),
    CHARGER(Weapon.CHARGER, Weapon.BOMB, Weapon.INK_STORM),
    DUALIES(Weapon.DUALIES, Weapon.BEAKON, Weapon.BOOYAH),
    SLOSHER(Weapon.SLOSHER, Weapon.SPRINKLER, Weapon.BUBBLER),
    BLASTER(Weapon.BLASTER, Weapon.BOMB, Weapon.SPLASHDOWN),
    INKBRUSH(Weapon.INKBRUSH, Weapon.BURST_BOMB, Weapon.INK_STORM);

    public final Weapon main, sub, special;

    Kit(Weapon main, Weapon sub, Weapon special) { this.main = main; this.sub = sub; this.special = special; }

    public static Kit of(Weapon main) {
        for (Kit kit : values()) if (kit.main == main) return kit;
        return null;
    }

    public static Kit byName(String name) {
        for (Kit kit : values()) if (kit.name().equalsIgnoreCase(name)) return kit;
        return SPLATTERSHOT;
    }
}
