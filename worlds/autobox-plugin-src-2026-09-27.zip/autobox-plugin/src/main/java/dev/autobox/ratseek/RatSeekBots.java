package dev.autobox.ratseek;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * The AI seeker squad: spawns the bots, feeds them the same sounds, hints and alarms human seekers
 * get, splits the house between them so they don't all search one room, and writes what they learn
 * to {@link RatSeekBotMemory}.
 */
final class RatSeekBots {
    /** A sprinting rat with Speed I, in blocks per tick. Human seekers run {@code humanSpeed} times this. */
    static final double RAT_SPRINT = 0.28 * 1.2;
    private static final String[][] NAMES = {
            {"Pest Control Pete", "Pete"}, {"Hunter Hank", "Hank"},
            {"Butler Hobbs", "Hobbs"}, {"Maid Rosa", "Rosa"},
            {"Granny Marge", "Marge"}, {"Cook Delia", "Delia"}};
    /** Built once per boot on a background thread; the blueprint never changes. */
    private static java.util.concurrent.CompletableFuture<RatSeekNav> navigation;

    final RatSeekGame game;
    final NamespacedKey key;
    final Random random = new Random();
    private final World world;
    private final RatSeekBotMemory memory;
    private final List<RatSeekBot> bots = new ArrayList<>();
    private final Map<String, Integer> searchedAt = new HashMap<>();
    private final Map<UUID, Location> lastPositions = new HashMap<>();
    private final Map<UUID, Vector> velocities = new HashMap<>();
    private final List<Sighting> sightings = new ArrayList<>();
    private final Set<String> lessons = new LinkedHashSet<>();
    private final List<RatSeekBot.Style> styleOrder = new ArrayList<>();
    private RatSeekSettings settings;
    int ticks;
    /** Gentle rubber band: bots relax a touch after catches and sharpen up during long droughts. */
    double momentum = 1.0;
    private int lastCatchTick;
    private int nextChatSlot;
    private int nextCallout;
    private int pathBudgetTick = -1;
    private int pathBudget;

    private record Sighting(Location at, int tick) { }

    RatSeekBots(RatSeekGame game, Plugin plugin, World world, NamespacedKey key) {
        this.game = game;
        this.world = world;
        this.key = key;
        this.memory = new RatSeekBotMemory(plugin);
    }

    /** Starts building the navigation grid off the main thread (about half a second of work). */
    static synchronized void warmUp() {
        if (navigation == null) {
            RatSeekHouse house = RatSeekGame.house();
            navigation = java.util.concurrent.CompletableFuture.supplyAsync(() -> new RatSeekNav(house));
        }
    }

    RatSeekNav nav() {
        warmUp();
        return navigation.join();
    }

    /** The navigation grid if it has finished building, without waiting for it. */
    static synchronized RatSeekNav navIfReady() {
        return navigation == null ? null : navigation.getNow(null);
    }

    /** Caps pathfinding at two chase re-plans per tick across the squad. */
    boolean takePathBudget() {
        if (pathBudgetTick != ticks) {
            pathBudgetTick = ticks;
            pathBudget = 2;
        }
        return pathBudget-- > 0;
    }

    RatSeekBotMemory memory() {
        return memory;
    }

    RatSeekGadgets gadgets() {
        return game.gadgets();
    }

    int count() {
        return bots.size();
    }

    // ------------------------------------------------------------------ lifecycle

    /** Matches the number of bots to {@code wanted}, parking new ones in the waiting booth. */
    void sync(int wanted, RatSeekSettings settings, boolean hunting) {
        this.settings = settings;
        for (RatSeekBot bot : bots) {
            bot.label(settings);
        }
        while (bots.size() > wanted) {
            RatSeekBot removed = bots.removeLast();
            gadgets().forget(removed.id());
            removed.remove();
        }
        if (styleOrder.isEmpty()) {
            styleOrder.addAll(List.of(RatSeekBot.Style.values()));
            Collections.shuffle(styleOrder, random);
        }
        while (bots.size() < wanted) {
            int index = bots.size();
            RatSeekBot.Style style = styleOrder.get(index % styleOrder.size());
            String[] name = NAMES[style.ordinal() * 2 + random.nextInt(2)];
            RatSeekBot bot = new RatSeekBot(this, world, index, name[0], name[1], style);
            bot.spawn(waitingSpot(index), settings);
            bots.add(bot);
            if (hunting) {
                release(bot, settings);
            }
        }
    }

    private Location waitingSpot(int index) {
        RatSeekHouse.Pos w = RatSeekHouse.WAITING;
        return new Location(world, w.x() + 0.5 + (index - 1) * 0.7, w.y(), w.z() + 0.5, 180, 0);
    }

    void startHiding(RatSeekSettings settings) {
        this.settings = settings;
        if (!bots.isEmpty()) {
            bots.getFirst().sayNow(settings.blindfold ? "Counting to " + settings.hideSeconds + "... no peeking!"
                    : "Go on, hide. I'm counting!");
        }
    }

    void releaseAll(RatSeekSettings settings, int ticks) {
        this.settings = settings;
        this.ticks = ticks;
        lastCatchTick = ticks;
        for (RatSeekBot bot : bots) {
            release(bot, settings);
        }
        if (!bots.isEmpty()) {
            bots.getFirst().sayNow(random.nextBoolean() ? "Ready or not, here I come!" : "Here comes trouble...");
        }
    }

    private void release(RatSeekBot bot, RatSeekSettings settings) {
        RatSeekHouse.Pos r = RatSeekHouse.RELEASE;
        bot.place(new Location(world, r.x() + 0.5 + (bot.index - 1) * 0.9, r.y(), r.z() + 0.5, 180, 0));
        bot.resetMind();
        gadgets().addBot(bot.id());
    }

    void clear() {
        for (RatSeekBot bot : bots) {
            bot.remove();
        }
        bots.clear();
        searchedAt.clear();
        lastPositions.clear();
        velocities.clear();
        sightings.clear();
        lessons.clear();
        styleOrder.clear();
        momentum = 1.0;
        ticks = 0;
    }

    /** Removes bodies left behind by a crash or an older plugin version (including the old zombie bots). */
    void purgeStrays() {
        for (Mannequin mannequin : world.getEntitiesByClass(Mannequin.class)) {
            String tag = mannequin.getPersistentDataContainer().get(key, PersistentDataType.STRING);
            if (RatSeekBot.BODY_TAG.equals(tag) || "ai_seeker_visual".equals(tag)) {
                mannequin.remove();
            }
        }
        for (Zombie zombie : world.getEntitiesByClass(Zombie.class)) {
            if ("ai_seeker".equals(zombie.getPersistentDataContainer().get(key, PersistentDataType.STRING))) {
                zombie.remove();
            }
        }
    }

    // ------------------------------------------------------------------ tick

    void tick(int ticks, RatSeekSettings settings) {
        this.ticks = ticks;
        this.settings = settings;
        if (bots.isEmpty()) {
            return;
        }
        if (ticks % 2 == 0) {
            trackMotion();
        }
        if (ticks % 20 == 0) {
            // A long drought sharpens the bots a little; it never exceeds +8%.
            int dry = ticks - lastCatchTick;
            double goal = dry > 1800 ? 1.08 : dry > 1200 ? 1.04 : 1.0;
            momentum += Math.max(-0.01, Math.min(0.01, goal - momentum));
            sightings.removeIf(s -> ticks - s.tick() > 2400);
        }
        for (RatSeekBot bot : new ArrayList<>(bots)) {
            // A catch can end the match mid-loop, which clears the squad.
            if (!game.inProgress() || !bots.contains(bot)) {
                return;
            }
            bot.tick(settings);
        }
    }

    private void trackMotion() {
        List<Entity> tracked = new ArrayList<>(freeRatPlayers());
        tracked.addAll(decoys());
        Set<UUID> alive = new java.util.HashSet<>();
        for (Entity entity : tracked) {
            UUID id = entity.getUniqueId();
            alive.add(id);
            Location now = entity.getLocation();
            Location before = lastPositions.put(id, now);
            if (before != null && before.getWorld() == now.getWorld()) {
                Vector step = now.toVector().subtract(before.toVector()).multiply(0.5).setY(0);
                // Teleports (rescues, flushes) are not movement.
                velocities.put(id, step.lengthSquared() > 1.0 ? new Vector() : step);
            }
        }
        lastPositions.keySet().retainAll(alive);
        velocities.keySet().retainAll(alive);
    }

    /** Horizontal speed in blocks per tick. */
    double motion(Entity entity) {
        Vector v = velocities.get(entity.getUniqueId());
        return v == null ? 0 : v.length();
    }

    Vector velocity(Entity entity) {
        Vector v = velocities.get(entity.getUniqueId());
        return v == null ? new Vector() : v.clone();
    }

    List<Player> freeRatPlayers() {
        List<Player> result = new ArrayList<>();
        for (UUID id : game.freeRats()) {
            Player rat = Bukkit.getPlayer(id);
            if (rat != null && rat.getWorld() == world) {
                result.add(rat);
            }
        }
        return result;
    }

    List<ArmorStand> decoys() {
        return game.abilities().decoyStands();
    }

    boolean isFreeRat(Player player) {
        return game.isFreeRat(player.getUniqueId());
    }

    // ------------------------------------------------------------------ what the squad hears

    /** A sound in the house (a squeak, a scamper, a burp...). Everyone in earshot turns to it. */
    void noise(Location at, double radius, double strength, UUID rat) {
        for (RatSeekBot bot : bots) {
            Location here = bot.location();
            double range = Math.abs(here.getY() - at.getY()) > 4 ? radius * 0.5 : radius;
            double distance = here.distance(at);
            if (distance <= range) {
                bot.hear(at, strength * (1 - 0.5 * distance / range), 1.0, rat);
            }
        }
    }

    /** A compass alarm (trap snap, bait, rescue, flush...): the closest free bot answers, maybe one more. */
    void alert(Location at) {
        dispatch(at, 0.9, 0.8, 0.5);
    }

    /** The periodic compass hint: roughly where one rat is. */
    void hint(Location at) {
        dispatch(at, 0.6, 2.5, 0.35);
    }

    private void dispatch(Location at, double strength, double fuzz, double secondChance) {
        List<RatSeekBot> free = new ArrayList<>();
        for (RatSeekBot bot : bots) {
            if (!bot.busy()) {
                free.add(bot);
            }
        }
        free.sort((a, b) -> Double.compare(a.location().distanceSquared(at), b.location().distanceSquared(at)));
        for (int i = 0; i < free.size(); i++) {
            if (i == 0 || (i == 1 && random.nextDouble() < secondChance)) {
                free.get(i).hear(at, strength, fuzz, null);
            }
        }
    }

    /** One bot spotted a rat: like a voice call-out, the others (and human seekers) get a lead. */
    void shareSighting(RatSeekBot spotter, Player rat) {
        Location at = rat.getLocation();
        sightings.add(new Sighting(at, ticks));
        for (RatSeekBot bot : bots) {
            if (bot != spotter && !bot.busy() && bot.location().distance(at) < 40) {
                bot.hear(at, 0.7, 1.5, rat.getUniqueId());
            }
        }
        if (ticks >= nextCallout) {
            nextCallout = ticks + 100;
            game.notifyHumans(Component.text(spotter.shortName + " spotted a rat in the " + game.roomAt(at) + "!",
                    NamedTextColor.RED));
        }
    }

    // ------------------------------------------------------------------ house events

    void frenzy(int ticks) {
        bots.forEach(bot -> bot.frenzy(ticks));
    }

    void darkness(int ticks) {
        bots.forEach(bot -> bot.darkness(ticks));
        if (!bots.isEmpty() && random.nextBoolean()) {
            bots.get(random.nextInt(bots.size())).say("Who turned off the lights?!");
        }
    }

    void expose(int ticks) {
        bots.forEach(bot -> bot.expose(ticks));
    }

    void bounce(int ticks) {
        bots.forEach(bot -> bot.bounce(ticks));
    }

    void chandelierFalling(Location floor, int ticksLeft, Location puller) {
        noise(puller, 20, 0.55, null);
        for (RatSeekBot bot : bots) {
            bot.chandelierWarning(floor, ticksLeft, settings);
        }
    }

    /** Returns how many bots the chandelier landed on. */
    int chandelierCrash(Location floor) {
        int hits = 0;
        for (RatSeekBot bot : bots) {
            if (!bot.under(floor)) {
                continue;
            }
            hits++;
            bot.stun(50);
            bot.sayNow(pick("OW! My head!", "Who dropped the lights?!", "Seeing stars..."));
            if (learning()) {
                memory.hitByChandelier();
                lessons.add(bot.shortName + " now watches the chandelier ropes.");
            }
        }
        return hits;
    }

    boolean hitDecoy(RatSeekBot bot, ArmorStand stand) {
        if (!game.abilities().botHitDecoy(stand, bot.name)) {
            return false;
        }
        if (learning()) {
            memory.fooledByDecoy();
            lessons.add(bot.shortName + " won't fall for decoys so easily next time.");
        }
        return true;
    }

    void botCaught(RatSeekBot bot, Player rat) {
        Location at = rat.getLocation();
        String hide = hideName(at);
        lastCatchTick = ticks;
        momentum = Math.max(0.94, momentum - 0.02);
        bot.particlesOnCatch();
        // Talk first: the catch may end the match, and the parting "GG" should come last.
        if (game.hasEscapeCard(rat)) {
            bot.sayNow(pick("An escape card?! Unbelievable.", "Hey, that's cheating! ...fine."));
        } else {
            bot.sayNow(pick("Gotcha, " + rat.getName() + "!", "Into the cage, " + rat.getName() + ".",
                    "Too slow, " + rat.getName() + "!"));
        }
        if (!game.botCatch(bot.name, rat)) {
            return;
        }
        if (learning() && hide != null) {
            lessons.add(bot.shortName + " will check the " + hide + " sooner — that's where " + rat.getName()
                    + " got caught.");
        }
    }

    /** Any catch (human or bot) teaches the bots where rats like to hide. */
    void caught(Player rat, Location at) {
        learnFound(rat, at);
        sightings.add(new Sighting(at.clone(), ticks));
        lastCatchTick = ticks;
    }

    void trapSnapped(UUID owner, Location at, Player rat) {
        sightings.add(new Sighting(at, ticks));
        RatSeekBot bot = bot(owner);
        if (bot == null) {
            return;
        }
        bot.sayNow(pick("Ha! My trap got " + rat.getName() + "!", "SNAP! Told you traps work."));
        if (learning()) {
            memory.siteWorked("trap", at.getBlockX(), at.getBlockY(), at.getBlockZ());
            lessons.add(bot.shortName + "'s trap in the " + game.roomAt(at) + " worked — expect more there.");
        }
    }

    void baitBitten(UUID owner, Location at, Player rat) {
        sightings.add(new Sighting(at, ticks));
        if (learning()) {
            memory.baitBitten(rat.getUniqueId());
            RatSeekBot bot = bot(owner);
            if (bot != null) {
                memory.siteWorked("bait", at.getBlockX(), at.getBlockY(), at.getBlockZ());
            }
        }
    }

    void tunnelExit(String passage, boolean exitA, Player rat) {
        if (learning() && !bots.isEmpty()) {
            memory.tunnelExit(rat.getUniqueId(), passage, exitA);
        }
    }

    // ------------------------------------------------------------------ learning helpers

    private boolean learning() {
        return settings != null && settings.botLearning;
    }

    void learnFound(Player rat, Location at) {
        if (!learning() || bots.isEmpty()) {
            return;
        }
        String room = nav().roomOf(at.getBlockX(), at.getBlockY(), at.getBlockZ());
        memory.found(rat.getUniqueId(), rat.getName(), room, hideCell(at));
    }

    void learnEscape(Location at) {
        int[] hide = hideCell(at);
        if (learning() && hide != null) {
            memory.escapedAt(hide);
        }
    }

    void learnPlaced(String kind, int[] site, RatSeekSettings settings) {
        if (settings.botLearning) {
            memory.sitePlaced(kind, site);
        }
    }

    private int[] hideCell(Location at) {
        RatSeekNav.Spot spot = spotNear(at, 1.8);
        return spot == null ? null : spot.hide();
    }

    private String hideName(Location at) {
        RatSeekNav.Spot spot = spotNear(at, 1.8);
        return spot == null || spot.name().equals("cheese spot") ? null : spot.name();
    }

    private RatSeekNav.Spot spotNear(Location at, double radius) {
        RatSeekNav.Spot best = null;
        double bestSq = radius * radius;
        for (RatSeekNav.SearchRoom room : nav().searchRooms()) {
            for (RatSeekNav.Spot spot : room.spots()) {
                int[] h = spot.hide();
                double dx = h[0] + 0.5 - at.getX(), dy = h[1] - at.getY(), dz = h[2] + 0.5 - at.getZ();
                double sq = dx * dx + dy * dy * 2 + dz * dz;
                if (sq < bestSq) {
                    bestSq = sq;
                    best = spot;
                }
            }
        }
        return best;
    }

    /** Ends the match: a couple of parting lines, the lessons learned, and the memory saved. */
    void matchOver(boolean humansWon) {
        if (bots.isEmpty()) {
            return;
        }
        RatSeekBot speaker = bots.get(random.nextInt(bots.size()));
        speaker.sayNow(humansWon ? pick("GG! Good hiding, rats.", "Cage is full. GG!")
                : pick("GG... next time, rats.", "I'll find you next round, I swear."));
        if (learning()) {
            List<String> notes = new ArrayList<>(lessons);
            Collections.shuffle(notes, random);
            for (String note : notes.subList(0, Math.min(3, notes.size()))) {
                game.chat(Component.text("AI notebook: ", NamedTextColor.DARK_AQUA)
                        .append(Component.text(note, NamedTextColor.GRAY)));
            }
            memory.finishMatch();
        }
        StringBuilder report = new StringBuilder();
        for (RatSeekBot bot : bots) {
            if (!report.isEmpty()) {
                report.append(" • ");
            }
            report.append(bot.shortName).append(": ").append(bot.catches)
                    .append(bot.catches == 1 ? " catch" : " catches");
        }
        game.chat(Component.text("AI seekers — " + report, NamedTextColor.RED));
    }

    void forgetEverything() {
        memory.forget();
    }

    // ------------------------------------------------------------------ squad planning

    private RatSeekBot bot(UUID id) {
        for (RatSeekBot bot : bots) {
            if (id != null && id.equals(bot.id())) {
                return bot;
            }
        }
        return null;
    }

    boolean isBot(UUID id) {
        return bot(id) != null;
    }

    Location eyeOf(UUID id) {
        RatSeekBot bot = bot(id);
        return bot == null ? null : bot.eye();
    }

    String nameOf(UUID id) {
        RatSeekBot bot = bot(id);
        return bot == null ? null : bot.name;
    }

    void searched(String room) {
        searchedAt.put(room, ticks);
    }

    RatSeekNav.SearchRoom pickRoom(RatSeekBot asker, RatSeekSettings settings) {
        Location here = asker.location();
        String currentRoom = nav().roomOf(here.getBlockX(), here.getBlockY(), here.getBlockZ());
        List<Player> free = freeRatPlayers();
        RatSeekNav.SearchRoom best = null;
        double bestScore = -1;
        for (RatSeekNav.SearchRoom room : nav().searchRooms()) {
            Integer last = searchedAt.get(room.name());
            double stale = last == null ? 1 : Math.min(1, (ticks - last) / 900.0);
            double prior = 1;
            if (settings.botLearning) {
                prior += Math.min(2.5, memory.roomWeight(room.name()) * 0.15);
                for (Player rat : free) {
                    prior += memory.playerRoom(rat.getUniqueId(), room.name()) * 1.2;
                }
            }
            for (Sighting sighting : sightings) {
                if (room.name().equals(game.roomAt(sighting.at()))) {
                    prior += 0.25;
                }
            }
            double claimed = 1;
            for (RatSeekBot other : bots) {
                if (other != asker && other.searchingRoom() == room) {
                    claimed = 0.12;
                }
            }
            int[] c = room.centre();
            double distance = Math.hypot(c[0] + 0.5 - here.getX(), c[2] + 0.5 - here.getZ())
                    + Math.abs(c[1] - here.getY()) * 2.5;
            double near = 1 / (1 + distance / 30);
            double here1 = room.name().equals(currentRoom) && stale > 0.5 ? 1.5 : 1;
            double score = prior * (0.05 + stale) * claimed * near * here1 * (0.75 + random.nextDouble() * 0.5);
            if (score > bestScore) {
                bestScore = score;
                best = room;
            }
        }
        return best;
    }

    double spotScore(RatSeekNav.Spot spot, RatSeekSettings settings) {
        double score = random.nextDouble() * 0.8 + (spot.low() ? 0.2 : 0);
        if (settings.botLearning) {
            score += Math.min(2, memory.hideWeight(spot.hide()) * 0.8);
        }
        return score;
    }

    int[] pickTrapSite(RatSeekBot bot, RatSeekSettings settings) {
        List<int[]> candidates = new ArrayList<>(nav().chokepoints());
        for (RatSeekNav.SearchRoom room : nav().searchRooms()) {
            for (RatSeekNav.Spot spot : room.spots()) {
                if (spot.name().equals("cheese spot")) {
                    candidates.add(spot.hide());
                }
            }
        }
        return bestSite("trap", bot, candidates, settings, false);
    }

    int[] pickBaitSite(RatSeekBot bot, RatSeekSettings settings) {
        List<int[]> candidates = new ArrayList<>();
        for (RatSeekNav.SearchRoom room : nav().searchRooms()) {
            for (RatSeekNav.Spot spot : room.spots()) {
                if (spot.name().equals("cheese spot")) {
                    candidates.add(spot.hide());
                }
            }
        }
        return bestSite("bait", bot, candidates, settings, true);
    }

    private int[] bestSite(String kind, RatSeekBot bot, List<int[]> candidates, RatSeekSettings settings,
                           boolean bait) {
        Location here = bot.location();
        int[] best = null;
        double bestScore = -1e9;
        for (int[] c : candidates) {
            Location at = new Location(world, c[0] + 0.5, c[1], c[2] + 0.5);
            double distance = at.distance(here);
            if (distance > 30) {
                continue;
            }
            Block block = world.getBlockAt(c[0], c[1], c[2]);
            if (!gadgets().canPlaceAt(block, !bait) || (bait && game.cheeseNear(at, 1.4))) {
                continue;
            }
            double score = (settings.botLearning ? memory.siteScore(kind, c) : 0.5) + random.nextDouble() * 0.4
                    - distance / 35;
            for (Sighting sighting : sightings) {
                if (sighting.at().getWorld() == world && sighting.at().distanceSquared(at) < 49) {
                    score += 0.3;
                }
            }
            if (score > bestScore) {
                bestScore = score;
                best = c;
            }
        }
        return best;
    }

    /** At most one bot minds the cheese keeper, only while someone is caged and never for long. */
    boolean shouldGuard(RatSeekBot bot) {
        if (game.cagedCount() == 0 || bots.size() + game.humanCount() < 2 || random.nextDouble() > 0.4) {
            return false;
        }
        for (RatSeekBot other : bots) {
            if (other != bot && other.goal == RatSeekBot.Goal.GUARD) {
                return false;
            }
        }
        return true;
    }

    Location guardPost(RatSeekBot bot) {
        RatSeekHouse.Pos keeper = RatSeekHouse.KEEPER;
        return new Location(world, keeper.x() - 2.5, keeper.y(), keeper.z() + (random.nextBoolean() ? 2.5 : -2.5));
    }

    Location guardWatch() {
        return new Location(world, 20.5, 82, 0.5);
    }

    /** Which end of a duct a rat will pop out of: its heading, past habits, and where teammates already wait. */
    Location predictExit(Player rat, Vector motion, RatSeekSettings settings) {
        Location at = rat.getLocation();
        for (RatSeekHouse.Passage passage : RatSeekGame.house().passages) {
            if (at.getBlockX() != passage.x() || at.getBlockY() != passage.y()
                    || at.getBlockZ() < passage.z1() || at.getBlockZ() > passage.z2()) {
                continue;
            }
            Location a = centre(passage.exitA()), b = centre(passage.exitB());
            double towardsA = motion.getZ() < -0.05 ? 0.9 : motion.getZ() > 0.05 ? 0.1
                    : at.distanceSquared(a) < at.distanceSquared(b) ? 0.65 : 0.35;
            double chanceA = settings.botLearning ? 0.55 * towardsA + 0.45 * memory.exitAChance(passage.name()) : towardsA;
            boolean pickA = settings.botSkill == RatSeekSettings.BotSkill.ROOKIE ? random.nextDouble() < chanceA
                    : chanceA >= 0.5;
            // A teammate already covering one end? Take the other.
            for (RatSeekBot other : bots) {
                if (other.goal == RatSeekBot.Goal.AMBUSH) {
                    Location post = other.location();
                    if (post.distanceSquared(pickA ? a : b) < 9) {
                        pickA = !pickA;
                    }
                }
            }
            return pickA ? a : b;
        }
        return null;
    }

    private Location centre(RatSeekHouse.Pos pos) {
        return new Location(world, pos.x() + 0.5, pos.y(), pos.z() + 0.5);
    }

    // ------------------------------------------------------------------ for the rest of the game

    List<Location> locations() {
        List<Location> result = new ArrayList<>();
        for (RatSeekBot bot : bots) {
            result.add(bot.location());
        }
        return result;
    }

    /** Names and positions, for rat abilities that point at every seeker. */
    Map<String, Location> markers() {
        Map<String, Location> result = new java.util.LinkedHashMap<>();
        for (RatSeekBot bot : bots) {
            result.put(bot.shortName, bot.location());
        }
        return result;
    }

    // ------------------------------------------------------------------ chat

    boolean chatSlot() {
        if (ticks < nextChatSlot) {
            return false;
        }
        nextChatSlot = ticks + 50;
        return true;
    }

    void chat(RatSeekBot bot, String message) {
        game.chat(Component.text("<", NamedTextColor.WHITE)
                .append(Component.text(bot.shortName, NamedTextColor.RED))
                .append(Component.text("> " + message, NamedTextColor.WHITE)));
    }

    String pick(String... options) {
        return options[random.nextInt(options.length)];
    }

    static boolean isBotBody(Entity entity, NamespacedKey key) {
        return RatSeekBot.BODY_TAG.equals(entity.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}
