package dev.autobox.chicken;

import dev.autobox.util.Sidebar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.type.Ladder;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Ravager;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** Core state and arena implementation for the three-round Chicken Run minigame. */
public final class ChickenRunGame {
    public static final String WORLD_NAME = "chicken_run_arena";

    public static final String FINISH_TAG = "chicken_run_finish";
    private static final int BASE_Y = 82;
    private static final int ROUND_COUNT = 3;
    private static final int[] ROUND_LIMIT_TICKS = {20 * 60 * 6, 20 * 60 * 5, 20 * 60 * 5};
    private static final int[] ROUND_POINTS = {6, 5, 4, 3, 2, 1};
    /** Courses get longer as the night goes on. */
    private static final int[] SEGMENTS_PER_ROUND = {14, 17, 20};
    /** Once someone hits the chicken, everyone else gets this long before the next course starts. */
    private static final int FINISH_GRACE_TICKS = 20 * 30;
    private static final int CATCH_UP_DISTANCE = 45;
    private static final int CATCH_UP_COOLDOWN_TICKS = 20 * 15;
    private static final String BLASTER_TAG = "chicken_run_blaster";

    private static final int NARROW_BRIDGE = 0;
    private static final int STEPPING_STONES = 1;
    private static final int CUBES = 2;
    private static final int ZIGZAG = 3;
    private static final int HURDLES = 4;
    private static final int WOOL_GAP = 5;
    private static final int SLALOM = 6;
    private static final int STAIR_CLIMB = 7;
    private static final int STAIR_DROP = 8;
    private static final int TOWER_HOP = 9;
    private static final int BROKEN_FLOOR = 10;
    private static final int ICE_SLIDE = 11;
    private static final int BOUNCE_PADS = 12;
    private static final int HONEY_SWAMP = 13;
    private static final int COBWEB_TUNNEL = 14;
    private static final int LADDER_CLIMB = 15;
    private static final int GLASS_WALK = 16;
    private static final int TIGHTROPE = 17;
    private static final int SPIRAL = 18;
    private static final int LEAP_OF_FAITH = 19;
    private static final int BOOST_LANE = 20;
    private static final int SPLIT_PATH = 21;
    private static final int PYRAMID = 22;
    private static final int ARCH_TUNNEL = 23;
    private static final int GAUNTLET = 24;
    private static final int DROPPER = 25;
    private static final int VANISHING_PLATFORMS = 26;
    private static final int BLASTERS = 27;
    private static final int BOSS_ARENA = 28;
    private static final int TARGET_SHOOTOUT = 29;
    private static final int GIANT_WELL = 30;
    private static final int GIANT_WALLS = 31;
    private static final int CUBE_DROP = 32;
    private static final int SKY_ISLANDS = 33;
    private static final int PILLAR_GROVE = 34;
    private static final int LAVA_CAUSEWAY = 35;
    private static final int CHECKER_SPRINT = 36;
    private static final int BALLOON_HOP = 37;
    private static final int CAGE_MAZE = 38;
    private static final int GRAND_CANYON = 39;
    private static final int SHRINK_CORRIDOR = 40;
    private static final int BLITZ_LANE = 41;
    private static final int LEAP_DUCK = 42;
    private static final int VINE_PLUNGE = 43;

    private static final int[] ROUND_ONE_POOL = {
            NARROW_BRIDGE, STEPPING_STONES, CUBES, ZIGZAG, HURDLES, WOOL_GAP, SLALOM,
            STAIR_CLIMB, STAIR_DROP, BROKEN_FLOOR, BOUNCE_PADS, GLASS_WALK, BOOST_LANE,
            PYRAMID, ARCH_TUNNEL, VANISHING_PLATFORMS, BLASTERS,
            GIANT_WELL, CHECKER_SPRINT, LEAP_DUCK, SHRINK_CORRIDOR, PILLAR_GROVE,
            LAVA_CAUSEWAY, SKY_ISLANDS
    };
    private static final int[] ROUND_TWO_POOL = {
            NARROW_BRIDGE, STEPPING_STONES, CUBES, ZIGZAG, HURDLES, WOOL_GAP, SLALOM,
            STAIR_CLIMB, STAIR_DROP, BROKEN_FLOOR, BOUNCE_PADS, GLASS_WALK, BOOST_LANE,
            PYRAMID, ARCH_TUNNEL, TOWER_HOP, ICE_SLIDE, HONEY_SWAMP, TIGHTROPE,
            SPIRAL, SPLIT_PATH, GAUNTLET, DROPPER, VANISHING_PLATFORMS, BLASTERS,
            BOSS_ARENA, TARGET_SHOOTOUT,
            GIANT_WELL, GIANT_WALLS, CUBE_DROP, SKY_ISLANDS, PILLAR_GROVE, LAVA_CAUSEWAY,
            CHECKER_SPRINT, BALLOON_HOP, CAGE_MAZE, GRAND_CANYON, SHRINK_CORRIDOR,
            BLITZ_LANE, LEAP_DUCK
    };
    private static final int[] ROUND_THREE_POOL = {
            NARROW_BRIDGE, STEPPING_STONES, CUBES, ZIGZAG, HURDLES, WOOL_GAP, SLALOM,
            STAIR_CLIMB, STAIR_DROP, BROKEN_FLOOR, BOUNCE_PADS, GLASS_WALK, BOOST_LANE,
            PYRAMID, ARCH_TUNNEL, TOWER_HOP, ICE_SLIDE, HONEY_SWAMP, TIGHTROPE,
            SPIRAL, SPLIT_PATH, GAUNTLET, COBWEB_TUNNEL, LADDER_CLIMB, LEAP_OF_FAITH,
            DROPPER, VANISHING_PLATFORMS, BLASTERS, BOSS_ARENA, TARGET_SHOOTOUT,
            GIANT_WELL, GIANT_WALLS, CUBE_DROP, SKY_ISLANDS, PILLAR_GROVE, LAVA_CAUSEWAY,
            CHECKER_SPRINT, BALLOON_HOP, CAGE_MAZE, GRAND_CANYON, SHRINK_CORRIDOR,
            BLITZ_LANE, LEAP_DUCK, VINE_PLUNGE
    };

    /** A course skin: floor, trim, glass, lighting and pillar blocks that read as one place. */
    private record Theme(String name, Material floor, Material edge, Material accent,
                         Material light, Material pillar) { }

    private static final Theme[] THEMES = {
            new Theme("Neon City", Material.LIGHT_BLUE_CONCRETE, Material.PURPLE_CONCRETE,
                    Material.MAGENTA_STAINED_GLASS, Material.SEA_LANTERN, Material.POLISHED_BLACKSTONE),
            new Theme("Candy Kingdom", Material.PINK_CONCRETE, Material.MAGENTA_WOOL,
                    Material.WHITE_STAINED_GLASS, Material.GLOWSTONE, Material.PINK_TERRACOTTA),
            new Theme("Ice Palace", Material.PACKED_ICE, Material.LIGHT_BLUE_CONCRETE,
                    Material.LIGHT_BLUE_STAINED_GLASS, Material.SEA_LANTERN, Material.BLUE_ICE),
            new Theme("Jungle Temple", Material.MOSS_BLOCK, Material.JUNGLE_PLANKS,
                    Material.LIME_STAINED_GLASS, Material.OCHRE_FROGLIGHT, Material.JUNGLE_LOG),
            new Theme("Volcano Run", Material.BLACKSTONE, Material.NETHER_BRICKS,
                    Material.RED_STAINED_GLASS, Material.SHROOMLIGHT, Material.POLISHED_BASALT),
            new Theme("Sky Temple", Material.QUARTZ_BLOCK, Material.PRISMARINE,
                    Material.WHITE_STAINED_GLASS, Material.SEA_LANTERN, Material.PRISMARINE_BRICKS),
            new Theme("Circuit Board", Material.BLACK_CONCRETE, Material.LIME_CONCRETE,
                    Material.LIME_STAINED_GLASS, Material.GLOWSTONE, Material.DEEPSLATE_TILES),
            new Theme("Mushroom Grove", Material.MYCELIUM, Material.BROWN_MUSHROOM_BLOCK,
                    Material.RED_STAINED_GLASS, Material.SHROOMLIGHT, Material.RED_MUSHROOM_BLOCK),
            new Theme("Desert Ruins", Material.SMOOTH_SANDSTONE, Material.CUT_SANDSTONE,
                    Material.YELLOW_STAINED_GLASS, Material.GLOWSTONE, Material.CHISELED_SANDSTONE)
    };

    private static final Material[] WOOL = {
            Material.RED_WOOL, Material.BLUE_WOOL, Material.LIME_WOOL,
            Material.YELLOW_WOOL, Material.PURPLE_WOOL, Material.ORANGE_WOOL
    };

    private enum Phase {
        IDLE, COUNTDOWN, RACING, BETWEEN_ROUNDS, PODIUM
    }

    private record Checkpoint(Location spawn) { }

    private record Blaster(Location muzzle, Vector direction, int offset) { }

    private static final class TargetShootout {
        private final Set<Location> remaining = new HashSet<>();
        private final List<Location> gate = new ArrayList<>();
        private final int minX;
        private final int maxX;
        private final int minZ;
        private final int maxZ;
        private final int gateZ;
        private final Location returnLocation;
        private boolean open;

        private TargetShootout(int minX, int maxX, int minZ, int maxZ, int gateZ, Location returnLocation) {
            this.minX = minX;
            this.maxX = maxX;
            this.minZ = minZ;
            this.maxZ = maxZ;
            this.gateZ = gateZ;
            this.returnLocation = returnLocation;
        }
    }

    private final JavaPlugin plugin;
    private final World world;
    private final Location lobby;
    private final NamespacedKey finishKey;
    private final Random random = new Random();
    private final Set<UUID> roster = new LinkedHashSet<>();
    private final Set<UUID> active = new HashSet<>();
    private final Set<UUID> roundFinishers = new HashSet<>();
    private final Map<UUID, Integer> points = new HashMap<>();
    private final Map<UUID, Integer> placeTotal = new HashMap<>();
    private final Map<UUID, Integer> roundPlace = new HashMap<>();
    private final Map<UUID, Integer> checkpointIndex = new HashMap<>();
    private final Map<UUID, String> status = new HashMap<>();
    private final Set<Location> generatedBlocks = new HashSet<>();
    private final Set<Long> courseChunks = new HashSet<>();
    private Sidebar sidebar;
    private final Map<Location, UUID> placedWool = new HashMap<>();
    private final Set<Location> launchPads = new HashSet<>();
    private final Set<Location> speedPads = new HashSet<>();
    private final Map<UUID, Integer> padCooldown = new HashMap<>();
    private final Map<UUID, Integer> hitCooldown = new HashMap<>();
    private final Map<UUID, Integer> catchUpCooldown = new HashMap<>();
    private final Set<Location> vanishingBlocks = new HashSet<>();
    private final Map<Location, Integer> vanishingAt = new HashMap<>();
    private final Map<Location, Integer> respawningAt = new HashMap<>();
    private final List<Blaster> blasters = new ArrayList<>();
    private final List<TargetShootout> targetShootouts = new ArrayList<>();
    private final List<Location> bossGate = new ArrayList<>();
    private final Set<BukkitTask> tasks = new HashSet<>();
    private final List<Checkpoint> checkpoints = new ArrayList<>();

    private Phase phase = Phase.IDLE;
    private int round;
    private int roundTicks;
    private int firstFinishTick = -1;
    private Location roundSpawn;
    private Chicken finishChicken;
    private Ravager boss;
    private BossBar bossBar;
    private int bossGateZ = Integer.MAX_VALUE;
    private Location bossReturnLocation;
    private Theme theme = THEMES[0];

    public ChickenRunGame(JavaPlugin plugin, World world, Location lobby) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.world = Objects.requireNonNull(world, "world");
        this.lobby = Objects.requireNonNull(lobby, "lobby").clone();
        if (!WORLD_NAME.equals(world.getName())) {
            throw new IllegalArgumentException("Chicken Run requires world " + WORLD_NAME);
        }
        this.finishKey = new NamespacedKey(plugin, "chicken_run_finish");
        configureWorld();
    }

    /** Starts with the first 2-6 distinct online players in roster order. */
    public void start(CommandSender sender, List<Player> requestedRoster) {
        if (isRunning()) {
            sender.sendMessage(Component.text("Chicken Run is already running.", NamedTextColor.RED));
            return;
        }
        List<Player> online = requestedRoster.stream()
                .filter(Objects::nonNull)
                .filter(Player::isOnline)
                .filter(player -> player.getWorld() != null)
                .distinct()
                .limit(6)
                .toList();
        if (online.size() < 2) {
            sender.sendMessage(Component.text("Need 2-6 players to start Chicken Run.", NamedTextColor.RED));
            return;
        }

        enforceWorldBorder();
        cancelTasks();
        clearArena();
        roster.clear();
        active.clear();
        points.clear();
        placeTotal.clear();
        roundPlace.clear();
        checkpointIndex.clear();
        status.clear();
        round = 0;
        for (Player player : online) {
            UUID id = player.getUniqueId();
            roster.add(id);
            active.add(id);
            points.put(id, 0);
            placeTotal.put(id, 0);
            status.put(id, "Ready");
        }
        phase = Phase.BETWEEN_ROUNDS;
        broadcast(Component.text("Three courses. Hit the chicken to finish!", NamedTextColor.YELLOW));
        beginNextRound();
    }

    public boolean isRunning() {
        return phase != Phase.IDLE;
    }

    public boolean isPlaying(Player player) {
        return isRunning() && active.contains(player.getUniqueId());
    }

    public boolean isWorld(Player player) {
        return isWorld(player.getWorld());
    }

    public boolean isWorld(World candidate) {
        return candidate == world;
    }

    /** Where a lobby spectator is dropped in to watch the current race. */
    public Location getSpectateLocation() {
        return roundSpawn == null
                ? new Location(world, 0.5, BASE_Y + 6, 0.5)
                : roundSpawn.clone().add(0, 5, -4);
    }

    public Location getRespawnLocation(Player player) {
        int index = checkpointIndex.getOrDefault(player.getUniqueId(), 0);
        if (checkpoints.isEmpty()) {
            return getSpectateLocation();
        }
        return checkpoints.get(Math.min(index, checkpoints.size() - 1)).spawn().clone();
    }

    /** Accepts only participant wool during an active race. */
    public boolean onPlace(Player player, Block block) {
        if (phase != Phase.RACING || !isPlaying(player) || block.getWorld() != world
                || block.getType() != woolFor(player)) {
            return false;
        }
        Location location = block.getLocation();
        if (location.getY() < BASE_Y - 8 || location.getY() > BASE_Y + 28
                || location.getZ() < -8 || location.getZ() > finishZ() + 12
                || Math.abs(location.getX()) > 24 || isProtectedBuildLocation(location)) {
            return false;
        }
        placedWool.put(location, player.getUniqueId());
        return true;
    }

    /** Allows participants to remove only wool placed during the current round. */
    public boolean onBreak(Player player, Block block) {
        UUID owner = placedWool.get(block.getLocation());
        if (!isPlaying(player) || block.getWorld() != world || block.getType() != woolFor(player)
                || !player.getUniqueId().equals(owner)) {
            return false;
        }
        placedWool.remove(block.getLocation());
        player.getInventory().addItem(ItemStack.of(woolFor(player)));
        return true;
    }

    /** Cancels normal damage and applies race-only player knockback. */
    public void handleMelee(EntityDamageByEntityEvent event, Player attacker, Player victim) {
        event.setCancelled(true);
        if (phase != Phase.RACING || !isPlaying(attacker) || !isPlaying(victim)) {
            return;
        }
        if (roundTicks - hitCooldown.getOrDefault(attacker.getUniqueId(), -20) < 10) {
            return;
        }
        hitCooldown.put(attacker.getUniqueId(), roundTicks);
        Vector push = victim.getLocation().toVector().subtract(attacker.getLocation().toVector()).setY(0);
        if (push.lengthSquared() < 0.01) {
            push.setX(1);
        }
        push.normalize().multiply(attacker.isSprinting() ? 0.85 : 0.60)
                .setY(attacker.isSprinting() ? 0.36 : 0.28);
        victim.setVelocity(push);
        attacker.resetCooldown();
        world.playSound(victim.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 0.9f, 1.15f);
    }

    /** Allows racers to damage only the active Chicken Run boss. */
    public boolean handleBossHit(EntityDamageByEntityEvent event, Player attacker) {
        if (event.getEntity() != boss || boss == null || boss.isDead()) {
            return false;
        }
        event.setCancelled(phase != Phase.RACING || !isPlaying(attacker));
        if (!event.isCancelled()) {
            event.setDamage(3.0);
            attacker.resetCooldown();
            world.playSound(boss.getLocation(), Sound.ENTITY_RAVAGER_HURT, 0.7f, 1.3f);
        }
        return true;
    }

    /** Handles blaster knockback and shared target-shootout hits. */
    public void handleProjectileHit(ProjectileHitEvent event) {
        if (phase != Phase.RACING || event.getEntity().getWorld() != world) {
            return;
        }
        if (event.getEntity().getScoreboardTags().contains(BLASTER_TAG)) {
            if (event.getHitEntity() instanceof Player victim && isPlaying(victim)
                    && !roundFinishers.contains(victim.getUniqueId())) {
                Vector push = event.getEntity().getVelocity().setY(0);
                if (push.lengthSquared() < 0.01) {
                    push = new Vector(1, 0, 0);
                }
                victim.setVelocity(push.normalize().multiply(0.9).setY(0.34));
                victim.playSound(victim.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 0.8f, 1.5f);
                Particle.CRIT.builder().location(victim.getLocation().add(0, 1, 0)).count(12)
                        .offset(0.35, 0.5, 0.35).receivers(48, true).spawn();
            }
            event.getEntity().remove();
            return;
        }
        if (!(event.getEntity() instanceof Arrow arrow)
                || !(arrow.getShooter() instanceof Player shooter)
                || !isPlaying(shooter) || event.getHitBlock() == null) {
            return;
        }
        Location hit = event.getHitBlock().getLocation();
        for (TargetShootout shootout : targetShootouts) {
            if (shootout.open || !shootout.remaining.remove(hit)) {
                continue;
            }
            hit.getBlock().setType(Material.LIME_CONCRETE, false);
            world.playSound(hit, Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.9f);
            Particle.ELECTRIC_SPARK.builder().location(hit.clone().add(0.5, 0.5, 0.5)).count(18)
                    .offset(0.3, 0.3, 0.3).receivers(64, true).spawn();
            arrow.remove();
            if (shootout.remaining.isEmpty()) {
                shootout.open = true;
                for (Location gateBlock : shootout.gate) {
                    gateBlock.getBlock().setType(Material.AIR, false);
                }
                broadcast(Component.text("Bullseye! The shootout gate is open.", NamedTextColor.GREEN));
                world.playSound(hit, Sound.BLOCK_BEACON_ACTIVATE, 1.1f, 1.25f);
            } else {
                shooter.sendActionBar(Component.text(shootout.remaining.size() + " targets left", NamedTextColor.YELLOW));
            }
            return;
        }
    }

    /** Public listener entry point for the tagged finish chicken. */
    public boolean handleChickenHit(EntityDamageByEntityEvent event, Player player, Chicken chicken) {
        if (chicken.getWorld() != world || !chicken.getScoreboardTags().contains(FINISH_TAG)) {
            return false;
        }
        event.setCancelled(true);
        if (phase != Phase.RACING || chicken != finishChicken || !isPlaying(player)
                || roundFinishers.contains(player.getUniqueId())) {
            return true;
        }
        int checkpoint = checkpointIndex.getOrDefault(player.getUniqueId(), 0);
        if (checkpoint != checkpoints.size() - 1 || player.getLocation().distanceSquared(chicken.getLocation()) > 16) {
            player.sendActionBar(Component.text("Reach every gold checkpoint before finishing.", NamedTextColor.RED));
            return true;
        }
        finish(player);
        return true;
    }

    /** Warps a trailing racer near the leader once the course gap is large enough. */
    public void teleportToLeader(Player player) {
        if (phase != Phase.RACING || !isPlaying(player) || roundFinishers.contains(player.getUniqueId())) {
            player.sendMessage(Component.text("Catch-up teleport is only available while you are racing.", NamedTextColor.RED));
            return;
        }
        Player leader = furthestRacer(player);
        if (leader == null || leader.getLocation().getZ() - player.getLocation().getZ() < CATCH_UP_DISTANCE) {
            player.sendMessage(Component.text("The leader is not far enough ahead yet.", NamedTextColor.RED));
            return;
        }
        int lastUse = catchUpCooldown.getOrDefault(player.getUniqueId(), -CATCH_UP_COOLDOWN_TICKS);
        int remaining = CATCH_UP_COOLDOWN_TICKS - (roundTicks - lastUse);
        if (remaining > 0) {
            player.sendMessage(Component.text("Catch-up teleport recharges in " + ((remaining + 19) / 20) + "s.",
                    NamedTextColor.RED));
            return;
        }
        Location destination = safeCatchUpLocation(leader);
        checkpointIndex.put(player.getUniqueId(), checkpointIndex.getOrDefault(leader.getUniqueId(), 0));
        catchUpCooldown.put(player.getUniqueId(), roundTicks);
        Particle.PORTAL.builder().location(player.getLocation().add(0, 1, 0)).count(35)
                .offset(0.5, 0.8, 0.5).receivers(64, true).spawn();
        player.teleport(destination);
        player.setFallDistance(0);
        player.setVelocity(new Vector());
        player.playSound(destination, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.15f);
        status.put(player.getUniqueId(), "Caught up");
        player.sendMessage(Component.text("Warped near " + leader.getName() + ".", NamedTextColor.GREEN));
    }

    private Player furthestRacer(Player excluding) {
        Player furthest = null;
        for (UUID id : active) {
            if (id.equals(excluding.getUniqueId()) || roundFinishers.contains(id)) {
                continue;
            }
            Player candidate = Bukkit.getPlayer(id);
            if (candidate != null && candidate.isOnline()
                    && (furthest == null || candidate.getLocation().getZ() > furthest.getLocation().getZ())) {
                furthest = candidate;
            }
        }
        return furthest;
    }

    private Location safeCatchUpLocation(Player leader) {
        Location at = leader.getLocation();
        int topY = Math.min(world.getMaxHeight() - 3, at.getBlockY() + 2);
        int bottomY = Math.max(world.getMinHeight(), at.getBlockY() - 5);
        for (int dz = -2; dz >= -5; dz--) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int y = topY; y >= bottomY; y--) {
                    Block floor = world.getBlockAt(at.getBlockX() + dx, y, at.getBlockZ() + dz);
                    if (floor.getType().isSolid() && floor.getRelative(BlockFace.UP).isPassable()
                            && floor.getRelative(BlockFace.UP, 2).isPassable()) {
                        return floor.getLocation().add(0.5, 1.1, 0.5);
                    }
                }
            }
        }
        int index = checkpointIndex.getOrDefault(leader.getUniqueId(), 0);
        return checkpoints.get(Math.min(index, checkpoints.size() - 1)).spawn().clone();
    }

    public void handleQuit(Player player) {
        UUID id = player.getUniqueId();
        if (!active.remove(id)) {
            return;
        }
        roster.remove(id);
        roundFinishers.remove(id);
        points.remove(id);
        placeTotal.remove(id);
        roundPlace.remove(id);
        checkpointIndex.remove(id);
        status.remove(id);
        if (active.isEmpty()) {
            endGame();
            return;
        }
        updateScoreboard();
        if (phase == Phase.RACING) {
            checkRoundComplete();
        }
    }

    public void endGame() {
        if (!isRunning()) {
            return;
        }
        phase = Phase.IDLE;
        cancelTasks();
        removeFinishChicken();
        for (UUID id : new ArrayList<>(roster)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            resetPlayer(player);
            player.teleport(lobby);
            player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        }
        clearArena();
        releaseCourseChunks();
        roster.clear();
        active.clear();
        roundFinishers.clear();
        checkpoints.clear();
        points.clear();
        placeTotal.clear();
        roundPlace.clear();
        checkpointIndex.clear();
        status.clear();
    }

    public void shutdown() {
        phase = Phase.IDLE;
        cancelTasks();
        removeFinishChicken();
        clearArena();
        releaseCourseChunks();
        roster.clear();
        active.clear();
    }

    private void beginNextRound() {
        if (!isRunning()) {
            return;
        }
        if (round >= ROUND_COUNT) {
            showPodium();
            return;
        }
        round++;
        phase = Phase.COUNTDOWN;
        roundTicks = 0;
        firstFinishTick = -1;
        roundFinishers.clear();
        roundPlace.clear();
        checkpointIndex.clear();
        clearArena();
        generateCourse();

        int slot = 0;
        for (UUID id : roster) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline() || !active.contains(id)) {
                continue;
            }
            preparePlayer(player, slot++);
            checkpointIndex.put(id, 0);
            status.put(id, "Starting");
        }
        updateScoreboard();
        broadcast(Component.text("Round " + round + "/3 - " + theme.name(), NamedTextColor.AQUA));
        forEachActive(player -> player.sendTitle("§6§l" + theme.name(),
                "§fRound " + round + " of 3", 5, 40, 10));
        countdown(5);
    }

    private void countdown(int seconds) {
        if (seconds <= 0) {
            phase = Phase.RACING;
            if (boss != null && boss.isValid()) {
                boss.setAI(true);
            }
            forEachActive(player -> {
                player.setGameMode(GameMode.SURVIVAL);
                status.put(player.getUniqueId(), "Racing");
                player.sendTitle("§a§lGO!", "§fReach and hit the chicken", 0, 25, 5);
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.8f);
            });
            updateScoreboard();
            track(Bukkit.getScheduler().runTaskTimer(plugin, this::tickRace, 1L, 1L));
            return;
        }
        forEachActive(player -> player.sendTitle("§e§l" + seconds,
                "§7Build with wool when needed", 0, 18, 2));
        schedule(() -> countdown(seconds - 1), 20L);
    }

    private void tickRace() {
        if (phase != Phase.RACING) {
            return;
        }
        roundTicks++;
        tickVanishingPlatforms();
        tickBlasters();
        tickBoss();
        supplyShootoutBows();
        enforceLockedGates();
        for (UUID id : new ArrayList<>(active)) {
            if (roundFinishers.contains(id)) {
                continue;
            }
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            if (player.getLocation().getY() < BASE_Y - 14) {
                resetToCheckpoint(player);
                continue;
            }
            advanceCheckpoint(player);
            applyPads(player);
            if (roundTicks % 20 == 0) {
                refillWool(player);
                showCatchUpHint(player);
            }
        }
        if (roundTicks % 20 == 0) {
            updateScoreboard();
            showFinishCountdown();
        }
        if (firstFinishTick >= 0 && roundTicks - firstFinishTick >= FINISH_GRACE_TICKS) {
            broadcast(Component.text("Time's up - on to the next course!", NamedTextColor.RED));
            completeRound();
            return;
        }
        if (roundTicks >= roundLimitTicks()) {
            broadcast(Component.text("Round time limit reached.", NamedTextColor.RED));
            completeRound();
        }
    }

    private void finish(Player player) {
        UUID id = player.getUniqueId();
        int place = roundFinishers.size() + 1;
        roundFinishers.add(id);
        roundPlace.put(id, place);
        placeTotal.merge(id, place, Integer::sum);
        int awarded = place <= ROUND_POINTS.length ? ROUND_POINTS[place - 1] : 0;
        points.merge(id, awarded, Integer::sum);
        status.put(id, ordinal(place) + " (finished)");
        player.setGameMode(GameMode.SPECTATOR);
        player.sendTitle("§6§l" + ordinal(place) + " PLACE", "§a+" + awarded + " points", 5, 45, 10);
        world.playSound(player.getLocation(), Sound.ENTITY_CHICKEN_HURT, 1.4f, 0.8f);
        Particle.FIREWORK.builder().location(chickenLocation()).count(35).offset(1, 1, 1)
                .extra(0.08).receivers(64, true).spawn();
        broadcast(Component.text(player.getName() + " finished " + ordinal(place) + "!", NamedTextColor.GOLD));
        if (firstFinishTick < 0 && !roundFinishers.containsAll(active)) {
            firstFinishTick = roundTicks;
            broadcast(Component.text("Everyone else has " + FINISH_GRACE_TICKS / 20
                    + "s to finish before the next course!", NamedTextColor.YELLOW));
        }
        updateScoreboard();
        checkRoundComplete();
    }

    /** Tells finished racers when the next course starts, and warns everyone still running. */
    private void showFinishCountdown() {
        if (firstFinishTick < 0) {
            return;
        }
        int left = Math.max(0, (FINISH_GRACE_TICKS - (roundTicks - firstFinishTick) + 19) / 20);
        forEachActive(player -> player.sendActionBar(roundFinishers.contains(player.getUniqueId())
                ? Component.text("Next course in " + left + "s", NamedTextColor.GREEN)
                : Component.text(left + "s left to reach the chicken!", NamedTextColor.RED)));
    }

    private void checkRoundComplete() {
        if (roundFinishers.containsAll(active)) {
            completeRound();
        }
    }

    private void completeRound() {
        if (phase != Phase.RACING) {
            return;
        }
        phase = Phase.BETWEEN_ROUNDS;
        cancelTasks();
        removeBoss();
        for (UUID id : active) {
            if (!roundFinishers.contains(id)) {
                status.put(id, "DNF");
                placeTotal.merge(id, roster.size() + 1, Integer::sum);
            }
        }
        updateScoreboard();
        broadcast(Component.text("Round " + round + " complete."
                + (round < ROUND_COUNT ? " Next course in 5s." : ""), NamedTextColor.GREEN));
        schedule(this::beginNextRound, 100L);
    }

    private void generateCourse() {
        checkpoints.clear();
        launchPads.clear();
        speedPads.clear();
        theme = pickTheme();
        int segments = SEGMENTS_PER_ROUND[Math.min(Math.max(round, 1), SEGMENTS_PER_ROUND.length) - 1];
        int x = 0;
        int y = BASE_Y;
        int z = 0;
        buildStartPlatform(x, y, z, theme);
        roundSpawn = new Location(world, 0.5, y + 1.2, 1.5, 0, 0);
        checkpoints.add(new Checkpoint(roundSpawn.clone()));

        int[] pool = templatePool(round);
        int previousTemplate = -1;
        Set<Integer> usedSpecials = new HashSet<>();
        for (int segment = 0; segment < segments; segment++) {
            // Seed the first stretch with a build-a-bridge gap and a cube climb so
            // everyone learns the two core mechanics before the wild stuff starts.
            int template = segment == 2 ? WOOL_GAP : pool[random.nextInt(pool.length)];
            for (int attempt = 0; attempt < 12
                    && (template == previousTemplate || isUniqueSpecial(template) && usedSpecials.contains(template));
                    attempt++) {
                template = pool[random.nextInt(pool.length)];
            }
            previousTemplate = template;
            if (isUniqueSpecial(template)) {
                usedSpecials.add(template);
            }
            int minLength = 7 + round * 2;
            int length = minLength + random.nextInt(4);
            y = buildSegment(template, x, y, z, length, theme);
            y = Math.max(BASE_Y, Math.min(BASE_Y + 20, y));
            decorateSegment(x, y, z, length, theme);
            z += length + 2;
            x += random.nextInt(5) - 2;
            x = Math.max(-16, Math.min(16, x));
            if ((segment + 1) % 4 == 0) {
                buildCheckpoint(x, y, z, theme);
                Location spawn = new Location(world, x + 0.5, y + 1.2, z + 1.5, 0, 0);
                checkpoints.add(new Checkpoint(spawn));
                z += 7;
            } else {
                bridgeConnection(x, y, z - 2, 4, theme.floor());
                z += 3;
            }
        }
        buildFinishPlatform(x, y, z, theme);
        finishChicken = world.spawn(new Location(world, x + 0.5, y + 2, z + 5.5), Chicken.class, chicken -> {
            chicken.setAI(false);
            // NOTE: not invulnerable - an invulnerable entity never fires EntityDamageByEntityEvent
            // (LivingEntity#hurtServer returns early), so the finish hit would be undetectable.
            // Damage is cancelled instead in handleChickenHit / GameListener#onDamage.
            chicken.setCollidable(false);
            chicken.setGravity(false);
            chicken.setSilent(true);
            chicken.setPersistent(true);
            chicken.setRemoveWhenFarAway(false);
            chicken.customName(Component.text("FINISH", NamedTextColor.GOLD, TextDecoration.BOLD));
            chicken.setCustomNameVisible(true);
            chicken.addScoreboardTag(FINISH_TAG);
            chicken.getPersistentDataContainer().set(finishKey, PersistentDataType.BYTE, (byte) 1);
        });
    }

    /** Picks a fresh look for the round, never the same one twice in a row. */
    private Theme pickTheme() {
        Theme picked = THEMES[random.nextInt(THEMES.length)];
        for (int attempt = 0; attempt < 8 && picked == theme; attempt++) {
            picked = THEMES[random.nextInt(THEMES.length)];
        }
        return picked;
    }

    /** Later rounds unlock the nastier segment types. */
    private int[] templatePool(int roundNumber) {
        return switch (roundNumber) {
            case 1 -> ROUND_ONE_POOL;
            case 2 -> ROUND_TWO_POOL;
            default -> ROUND_THREE_POOL;
        };
    }

    private int buildSegment(int template, int cx, int y, int z, int length, Theme theme) {
        return switch (template) {
            case NARROW_BRIDGE -> buildNarrowBridge(cx, y, z, length, theme);
            case STEPPING_STONES -> buildSteppingStones(cx, y, z, length, theme);
            case CUBES -> buildCubes(cx, y, z, length, theme);
            case ZIGZAG -> buildZigzag(cx, y, z, length, theme);
            case HURDLES -> buildHurdles(cx, y, z, length, theme);
            case WOOL_GAP -> buildWoolGap(cx, y, z, length, theme);
            case SLALOM -> buildSlalom(cx, y, z, length, theme);
            case STAIR_CLIMB -> buildStairClimb(cx, y, z, length, theme);
            case STAIR_DROP -> buildStairDrop(cx, y, z, length, theme);
            case TOWER_HOP -> buildTowerHop(cx, y, z, length, theme);
            case ICE_SLIDE -> buildIceSlide(cx, y, z, length, theme);
            case BOUNCE_PADS -> buildBouncePads(cx, y, z, length, theme);
            case HONEY_SWAMP -> buildHoneySwamp(cx, y, z, length, theme);
            case COBWEB_TUNNEL -> buildCobwebTunnel(cx, y, z, length, theme);
            case LADDER_CLIMB -> buildLadderClimb(cx, y, z, length, theme);
            case GLASS_WALK -> buildGlassWalk(cx, y, z, length, theme);
            case TIGHTROPE -> buildTightrope(cx, y, z, length, theme);
            case SPIRAL -> buildSpiral(cx, y, z, length, theme);
            case LEAP_OF_FAITH -> buildLeapOfFaith(cx, y, z, length, theme);
            case BOOST_LANE -> buildBoostLane(cx, y, z, length, theme);
            case SPLIT_PATH -> buildSplitPath(cx, y, z, length, theme);
            case PYRAMID -> buildPyramid(cx, y, z, length, theme);
            case ARCH_TUNNEL -> buildArchTunnel(cx, y, z, length, theme);
            case GAUNTLET -> buildGauntlet(cx, y, z, length, theme);
            case DROPPER -> buildDropper(cx, y, z, length, theme);
            case VANISHING_PLATFORMS -> buildVanishingPlatforms(cx, y, z, length, theme);
            case BLASTERS -> buildBlasters(cx, y, z, length, theme);
            case BOSS_ARENA -> buildBossArena(cx, y, z, length, theme);
            case TARGET_SHOOTOUT -> buildTargetShootout(cx, y, z, length, theme);
            case GIANT_WELL -> buildGiantWell(cx, y, z, length, theme);
            case GIANT_WALLS -> buildGiantWalls(cx, y, z, length, theme);
            case CUBE_DROP -> buildCubeDrop(cx, y, z, length, theme);
            case SKY_ISLANDS -> buildSkyIslands(cx, y, z, length, theme);
            case PILLAR_GROVE -> buildPillarGrove(cx, y, z, length, theme);
            case LAVA_CAUSEWAY -> buildLavaCauseway(cx, y, z, length, theme);
            case CHECKER_SPRINT -> buildCheckerSprint(cx, y, z, length, theme);
            case BALLOON_HOP -> buildBalloonHop(cx, y, z, length, theme);
            case CAGE_MAZE -> buildCageMaze(cx, y, z, length, theme);
            case GRAND_CANYON -> buildGrandCanyon(cx, y, z, length, theme);
            case SHRINK_CORRIDOR -> buildShrinkCorridor(cx, y, z, length, theme);
            case BLITZ_LANE -> buildBlitzLane(cx, y, z, length, theme);
            case LEAP_DUCK -> buildLeapDuck(cx, y, z, length, theme);
            case VINE_PLUNGE -> buildVinePlunge(cx, y, z, length, theme);
            default -> buildBrokenFloor(cx, y, z, length, theme);
        };
    }

    private static boolean isUniqueSpecial(int template) {
        return template == BOSS_ARENA || template == TARGET_SHOOTOUT;
    }

    // ===================== platforms =====================

    private void buildStartPlatform(int cx, int y, int z, Theme theme) {
        fill(cx - 7, cx + 7, y, y, z - 3, z + 5, theme.pillar());
        fill(cx - 6, cx + 6, y - 1, y - 1, z - 2, z + 4, theme.accent());
        for (int lane = -5; lane <= 5; lane += 2) {
            fill(cx + lane, cx + lane, y + 1, y + 1, z, z + 2, theme.edge());
        }
        for (int side : new int[]{-7, 7}) {
            fill(cx + side, cx + side, y + 1, y + 4, z + 4, z + 4, theme.light());
        }
        fill(cx - 7, cx + 7, y + 5, y + 5, z + 4, z + 4, theme.accent());
    }

    private void buildCheckpoint(int cx, int y, int z, Theme theme) {
        fill(cx - 4, cx + 4, y, y, z - 1, z + 5, Material.GOLD_BLOCK);
        fill(cx - 3, cx + 3, y - 1, y - 1, z, z + 4, Material.YELLOW_STAINED_GLASS);
        for (int side : new int[]{-4, 4}) {
            fill(cx + side, cx + side, y + 1, y + 4, z + 2, z + 2, theme.light());
        }
        fill(cx - 4, cx + 4, y + 4, y + 4, z + 2, z + 2, Material.YELLOW_STAINED_GLASS);
    }

    private void buildFinishPlatform(int cx, int y, int z, Theme theme) {
        fill(cx - 6, cx + 6, y, y, z - 2, z + 9, Material.QUARTZ_BLOCK);
        fill(cx - 5, cx + 5, y - 1, y - 1, z - 1, z + 8, Material.PINK_STAINED_GLASS);
        for (int side : new int[]{-6, 6}) {
            fill(cx + side, cx + side, y + 1, y + 6, z + 4, z + 4, Material.GOLD_BLOCK);
        }
        fill(cx - 6, cx + 6, y + 6, y + 6, z + 4, z + 4, Material.GOLD_BLOCK);
        for (int side : new int[]{-5, 5}) {
            fill(cx + side, cx + side, y + 1, y + 1, z + 6, z + 8, theme.light());
        }
    }

    // ===================== segment builders =====================

    private int buildNarrowBridge(int cx, int y, int z, int length, Theme theme) {
        int width = 1 + random.nextInt(2);
        for (int dz = 0; dz < length; dz++) {
            if (random.nextInt(6) != 0) {
                fill(cx - width, cx + width, y, y, z + dz, z + dz, theme.floor());
            }
            if (dz % 4 == 0) {
                setBlock(cx - width - 1, y, z + dz, theme.edge());
                setBlock(cx + width + 1, y, z + dz, theme.edge());
            }
        }
        return y;
    }

    private int buildSteppingStones(int cx, int y, int z, int length, Theme theme) {
        int dx = 0;
        int spacing = round == 1 ? 3 : 4;
        for (int dz = 0; dz < length; dz += spacing) {
            if (dz > 0 && dz + spacing < length) {
                dx = Math.max(-3, Math.min(3, dx + random.nextInt(3) - 1));
            } else {
                dx = 0;
            }
            fill(cx + dx - 1, cx + dx + 1, y, y, z + dz, z + Math.min(length - 1, dz + 1), theme.floor());
            setBlock(cx + dx, y - 1, z + dz, theme.light());
        }
        return y;
    }

    private int buildCubes(int cx, int y, int z, int length, Theme theme) {
        int dx = 0;
        int height = 1;
        for (int dz = 0; dz < length; dz += 3) {
            dx = Math.max(-4, Math.min(4, dx + random.nextInt(3) - 1));
            int size = 3 + random.nextInt(2);
            if (dz > 0 && dz + 3 < length) {
                height = Math.max(1, Math.min(4, height + random.nextInt(3) - 1));
            } else {
                height = 1;
                dx = 0;
            }
            fill(cx + dx - 1, cx + dx + size - 2, y, y + height,
                    z + dz, z + dz + size - 1, theme.floor());
        }
        return y;
    }

    private int buildZigzag(int cx, int y, int z, int length, Theme theme) {
        int dx = random.nextBoolean() ? -3 : 3;
        for (int dz = 0; dz < length; dz++) {
            if (dz > 0 && dz % 4 == 0) {
                dx = -dx;
            }
            fill(cx + dx - 1, cx + dx + 1, y, y, z + dz, z + dz, theme.floor());
            if (dz % 4 == 0) {
                fill(cx - 3, cx + 3, y, y, z + dz, z + dz, theme.floor());
            }
        }
        return y;
    }

    private int buildHurdles(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 2, cx + 2, y, y, z, z + length - 1, theme.floor());
        for (int dz = 3; dz < length; dz += 3) {
            int opening = random.nextInt(3) - 1;
            for (int dx = -2; dx <= 2; dx++) {
                if (dx == opening) {
                    continue;
                }
                setBlock(cx + dx, y + 1, z + dz, Material.POLISHED_BLACKSTONE_WALL);
            }
            setBlock(cx + opening, y, z + dz, theme.light());
        }
        return y;
    }

    private int buildWoolGap(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 2, cx + 2, y, y, z, z + 2, theme.floor());
        fill(cx - 2, cx + 2, y, y, z + length - 3, z + length - 1, theme.floor());
        // A couple of teasing half-steps so a good builder can shortcut the gap.
        for (int dz = 5; dz < length - 4; dz += 5) {
            int side = random.nextBoolean() ? -3 : 3;
            setBlock(cx + side, y, z + dz, theme.floor());
            setBlock(cx + side + 1, y, z + dz, theme.floor());
        }
        setBlock(cx, y + 2, z + 1, theme.light());
        return y;
    }

    private int buildSlalom(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 3, cx + 3, y, y, z, z + length - 1, theme.floor());
        for (int dz = 2; dz < length; dz += 3) {
            int side = (dz / 3 & 1) == 0 ? -2 : 2;
            int height = 3 + random.nextInt(3);
            fill(cx + side, cx + side, y + 1, y + height, z + dz, z + dz, theme.pillar());
            setBlock(cx + side, y + height + 1, z + dz, theme.light());
        }
        return y;
    }

    private int buildStairClimb(int cx, int y, int z, int length, Theme theme) {
        int stepY = y;
        for (int dz = 0; dz < length; dz += 4) {
            fill(cx - 1, cx + 1, stepY, stepY + 1, z + dz, z + dz + 2, theme.floor());
            stepY = Math.min(BASE_Y + 20, stepY + 1);
        }
        return stepY;
    }

    private int buildStairDrop(int cx, int y, int z, int length, Theme theme) {
        int stepY = y;
        for (int dz = 0; dz < length; dz += 5) {
            int drop = 1 + random.nextInt(2);
            int nextY = Math.max(BASE_Y, stepY - drop);
            fill(cx - 1, cx + 1, nextY, nextY, z + dz, z + dz + 2, theme.floor());
            stepY = nextY;
        }
        return stepY;
    }

    private int buildTowerHop(int cx, int y, int z, int length, Theme theme) {
        int px = cx;
        int top = y;
        for (int dz = 0; dz < length; dz += 4) {
            px = Math.max(cx - 4, Math.min(cx + 4, px + random.nextInt(3) - 1));
            int towerY = Math.min(BASE_Y + 20, top + 1);
            if (dz + 4 >= length) {
                px = cx;
            }
            int base = Math.max(BASE_Y, top - 2);
            for (int yy = base; yy <= towerY; yy++) {
                fill(px, px + 1, yy, yy, z + dz, z + dz + 1, yy == towerY ? theme.floor() : theme.pillar());
            }
            top = towerY;
        }
        return top;
    }

    private int buildBrokenFloor(int cx, int y, int z, int length, Theme theme) {
        for (int dz = 0; dz < length; dz++) {
            for (int dx = -3; dx <= 3; dx++) {
                if (random.nextInt(5) != 0 || Math.abs(dx) == 3) {
                    int layer = dz / 4 % 3;
                    setBlock(cx + dx, y + layer, z + dz, theme.floor());
                }
            }
        }
        return y;
    }

    /** A blue-ice chute that drops away under you - lean on the rails or overshoot. */
    private int buildIceSlide(int cx, int y, int z, int length, Theme theme) {
        int slideY = y;
        for (int dz = 0; dz < length; dz++) {
            if (dz % 4 == 3 && slideY > BASE_Y + 1) {
                slideY--;
            }
            fill(cx - 2, cx + 2, slideY, slideY, z + dz, z + dz, Material.BLUE_ICE);
            setBlock(cx - 3, slideY, z + dz, theme.edge());
            setBlock(cx + 3, slideY, z + dz, theme.edge());
            setBlock(cx - 3, slideY + 1, z + dz, theme.accent());
            setBlock(cx + 3, slideY + 1, z + dz, theme.accent());
            if (dz % 5 == 0) {
                setBlock(cx - 3, slideY + 2, z + dz, theme.light());
                setBlock(cx + 3, slideY + 2, z + dz, theme.light());
            }
        }
        return slideY;
    }

    /** Slime launchers over open air - land on the next pad or start bridging. */
    private int buildBouncePads(int cx, int y, int z, int length, Theme theme) {
        int dx = 0;
        for (int dz = 0; dz < length; dz += 4) {
            if (dz > 0 && dz + 4 < length) {
                dx = Math.max(-2, Math.min(2, dx + random.nextInt(3) - 1));
            } else {
                dx = 0;
            }
            fill(cx + dx - 1, cx + dx + 1, y, y, z + dz, z + dz + 1, theme.floor());
            launchPad(cx + dx, y, z + dz);
            setBlock(cx + dx, y - 1, z + dz, theme.light());
        }
        return y;
    }

    /** Honey drags you to a crawl - find the dry lane weaving through it. */
    private int buildHoneySwamp(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 3, cx + 3, y, y, z, z + length - 1, Material.HONEY_BLOCK);
        int lane = 0;
        for (int dz = 0; dz < length; dz++) {
            if (dz % 3 == 0) {
                lane = Math.max(-2, Math.min(2, lane + random.nextInt(3) - 1));
            }
            setBlock(cx + lane, y, z + dz, theme.floor());
            if (dz % 4 == 0) {
                setBlock(cx + lane, y - 1, z + dz, theme.light());
            }
        }
        return y;
    }

    /** A cobweb-choked corridor: slow, dark, and every second counts. */
    private int buildCobwebTunnel(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 2, cx + 2, y, y, z, z + length - 1, theme.floor());
        fill(cx - 3, cx - 3, y + 1, y + 3, z, z + length - 1, theme.accent());
        fill(cx + 3, cx + 3, y + 1, y + 3, z, z + length - 1, theme.accent());
        fill(cx - 3, cx + 3, y + 4, y + 4, z, z + length - 1, theme.pillar());
        for (int dz = 1; dz < length - 1; dz++) {
            for (int dx = -2; dx <= 2; dx++) {
                if (random.nextInt(4) == 0) {
                    setBlock(cx + dx, y + 1, z + dz, Material.COBWEB);
                }
            }
            if (dz % 4 == 0) {
                setBlock(cx, y + 4, z + dz, theme.light());
            }
        }
        return y;
    }

    /** Ladder shaft up a tower wall, then a high catwalk out the far side. */
    private int buildLadderClimb(int cx, int y, int z, int length, Theme theme) {
        int top = Math.max(y, Math.min(BASE_Y + 20, y + 5 + random.nextInt(4)));
        fill(cx - 2, cx + 2, y, y, z, z + 2, theme.floor());
        for (int yy = y; yy <= top; yy++) {
            fill(cx - 1, cx + 1, yy, yy, z + 3, z + 3, theme.pillar());
        }
        for (int yy = y + 1; yy <= top + 1; yy++) {
            ladder(cx, yy, z + 2, BlockFace.NORTH);
        }
        fill(cx - 2, cx + 2, top, top, z + 3, z + length - 1, theme.floor());
        setBlock(cx, top + 3, z + length - 1, theme.light());
        return top;
    }

    /** Clear glass over the void - you can see exactly how far the drop is. */
    private int buildGlassWalk(int cx, int y, int z, int length, Theme theme) {
        for (int dz = 0; dz < length; dz++) {
            for (int dx = -2; dx <= 2; dx++) {
                if (random.nextInt(6) == 0) {
                    continue;
                }
                setBlock(cx + dx, y, z + dz, random.nextInt(5) == 0 ? theme.accent() : Material.GLASS);
            }
        }
        return y;
    }

    /** Fence-post tightrope with a landing pad at each end. */
    private int buildTightrope(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 2, cx + 2, y, y, z, z + 1, theme.floor());
        fill(cx - 2, cx + 2, y, y, z + length - 2, z + length - 1, theme.floor());
        int lane = 0;
        for (int dz = 2; dz < length - 2; dz++) {
            if (dz % 4 == 0) {
                lane = Math.max(-2, Math.min(2, lane + random.nextInt(3) - 1));
            }
            setBlock(cx + lane, y, z + dz, Material.OAK_FENCE);
            if (dz % 5 == 0) {
                setBlock(cx + lane, y - 2, z + dz, theme.light());
            }
        }
        return y;
    }

    /** A helix of floating steps winding up around a lit pillar. */
    private int buildSpiral(int cx, int y, int z, int length, Theme theme) {
        int pivotZ = z + length / 2;
        int top = Math.max(y, Math.min(BASE_Y + 20, y + 5));
        fill(cx + 2, cx + 4, y, y, z, pivotZ, theme.floor());
        for (int yy = y; yy <= top + 2; yy++) {
            setBlock(cx, yy, pivotZ, theme.pillar());
        }
        setBlock(cx, top + 3, pivotZ, theme.light());

        int steps = (top - y) * 4 + 4;
        int lastX = cx + 3;
        int lastZ = pivotZ;
        for (int i = 0; i <= steps; i++) {
            double angle = i * (Math.PI / 6);
            int sx = cx + (int) Math.round(Math.cos(angle) * 3);
            int sz = pivotZ + (int) Math.round(Math.sin(angle) * 3);
            int sy = Math.min(top, y + i / 4);
            fill(sx - 1, sx, sy, sy, sz, sz, theme.floor());
            lastX = sx;
            lastZ = sz;
        }
        fill(lastX - 1, lastX + 1, top, top, lastZ, z + length - 1, theme.floor());
        fill(Math.min(lastX, cx) - 1, Math.max(lastX, cx) + 1, top, top,
                z + length - 2, z + length - 1, theme.floor());
        return top;
    }

    /** Run off the edge and trust the landing pad below. */
    private int buildLeapOfFaith(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 2, cx + 2, y, y, z, z + 2, theme.floor());
        for (int dx = -2; dx <= 2; dx++) {
            setBlock(cx + dx, y + 1, z + 2, theme.accent());
        }
        int bottom = Math.max(BASE_Y, y - (3 + random.nextInt(4)));
        fill(cx - 4, cx + 4, bottom, bottom, z + 5, z + length - 1, theme.floor());
        for (int side : new int[]{-4, 4}) {
            fill(cx + side, cx + side, bottom + 1, bottom + 1, z + 5, z + length - 1, theme.light());
        }
        return bottom;
    }

    /** Ice runway with speed plates and a launcher at the lip. */
    private int buildBoostLane(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 2, cx + 2, y, y, z, z + length - 1, Material.PACKED_ICE);
        fill(cx - 3, cx - 3, y, y, z, z + length - 1, theme.edge());
        fill(cx + 3, cx + 3, y, y, z, z + length - 1, theme.edge());
        for (int dz = 2; dz < length - 2; dz += 4) {
            speedPad(cx, y, z + dz);
        }
        launchPad(cx, y, z + length - 1);
        setBlock(cx, y - 1, z + length - 1, theme.light());
        return y;
    }

    /** Two ways through: a bare beam for the brave, a hurdled ramp for the rest. */
    private int buildSplitPath(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 4, cx + 4, y, y, z, z + 1, theme.floor());
        for (int dz = 2; dz < length - 2; dz++) {
            setBlock(cx - 3, y, z + dz, theme.floor());
            fill(cx + 1, cx + 3, y, y, z + dz, z + dz, theme.floor());
            if (dz % 3 == 0) {
                setBlock(cx + 2, y + 1, z + dz, Material.POLISHED_BLACKSTONE_WALL);
                setBlock(cx + 3, y + 1, z + dz, Material.POLISHED_BLACKSTONE_WALL);
            }
        }
        for (int dz = 2; dz < length - 2; dz += 4) {
            setBlock(cx - 3, y - 1, z + dz, theme.light());
        }
        fill(cx - 4, cx + 4, y, y, z + length - 2, z + length - 1, theme.floor());
        return y;
    }

    /** Up one side of a stepped pyramid and down the other. */
    private int buildPyramid(int cx, int y, int z, int length, Theme theme) {
        int peak = Math.max(y, Math.min(BASE_Y + 20, y + 4));
        int half = Math.max(2, length / 2);
        for (int dz = 0; dz < length; dz++) {
            int distance = Math.min(dz, length - 1 - dz);
            int level = Math.min(peak, y + Math.min(distance, peak - y));
            int width = 3 - Math.min(2, distance / Math.max(1, half / 3));
            fill(cx - width, cx + width, level, level, z + dz, z + dz, theme.floor());
            if (dz == half) {
                setBlock(cx, level + 2, z + dz, theme.light());
            }
        }
        return y;
    }

    /** An enclosed lit arcade with low arches to hop through. */
    private int buildArchTunnel(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 2, cx + 2, y, y, z, z + length - 1, theme.floor());
        for (int dz = 0; dz < length; dz++) {
            if (dz % 4 == 0) {
                fill(cx - 3, cx - 3, y + 1, y + 4, z + dz, z + dz, theme.pillar());
                fill(cx + 3, cx + 3, y + 1, y + 4, z + dz, z + dz, theme.pillar());
                fill(cx - 3, cx + 3, y + 5, y + 5, z + dz, z + dz, theme.accent());
                setBlock(cx, y + 5, z + dz, theme.light());
            }
            if (dz % 4 == 2) {
                setBlock(cx - 2, y + 1, z + dz, theme.edge());
                setBlock(cx + 2, y + 1, z + dz, theme.edge());
            }
        }
        return y;
    }

    /** Staggered walls that force a weave, with a hole to vault at every step. */
    private int buildGauntlet(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 3, cx + 3, y, y, z, z + length - 1, theme.floor());
        for (int dz = 2; dz < length; dz += 3) {
            boolean leftOpen = (dz / 3 & 1) == 0;
            int from = leftOpen ? cx - 1 : cx - 3;
            int to = leftOpen ? cx + 3 : cx + 1;
            fill(from, to, y + 1, y + 2, z + dz, z + dz, theme.pillar());
            setBlock(leftOpen ? cx - 3 : cx + 3, y - 1, z + dz, theme.light());
        }
        return y;
    }

    /** A glass-walled free fall with ledges to dodge and a water landing. */
    private int buildDropper(int cx, int y, int z, int length, Theme theme) {
        int bottom = Math.max(BASE_Y - 8, y - 11);
        fill(cx - 3, cx + 3, y, y, z, z + 2, theme.floor());
        for (int yy = bottom; yy <= y + 2; yy++) {
            fill(cx - 3, cx - 3, yy, yy, z + 3, z + 8, theme.accent());
            fill(cx + 3, cx + 3, yy, yy, z + 3, z + 8, theme.accent());
            fill(cx - 3, cx + 3, yy, yy, z + 8, z + 8, theme.accent());
        }
        for (int yy = y - 3, side = -1; yy > bottom + 2; yy -= 3, side = -side) {
            int from = side < 0 ? cx - 2 : cx + 1;
            int to = side < 0 ? cx - 1 : cx + 2;
            fill(from, to, yy, yy, z + 3, z + 6, theme.pillar());
            setBlock(side < 0 ? cx + 2 : cx - 2, yy, z + 5, theme.light());
        }
        fill(cx - 2, cx + 2, bottom - 1, bottom - 1, z + 3, z + 7, theme.pillar());
        fill(cx - 2, cx + 2, bottom, bottom, z + 3, z + 7, Material.WATER);
        fill(cx - 2, cx + 2, bottom, bottom, z + 8, z + length - 1, theme.floor());
        fill(cx - 3, cx + 3, bottom + 3, bottom + 3, z + 8, z + length - 1, theme.accent());
        for (int yy = bottom + 1; yy <= bottom + 2; yy++) {
            fill(cx - 2, cx + 2, yy, yy, z + 8, z + 8, Material.AIR);
        }
        return bottom;
    }

    /** Amethyst tiles crack after one second, then reappear for trailing racers. */
    private int buildVanishingPlatforms(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 3, cx + 3, y, y, z, z + 1, theme.floor());
        fill(cx - 3, cx + 3, y, y, z + length - 2, z + length - 1, theme.floor());
        int lane = 0;
        for (int dz = 2; dz < length - 2; dz += 2) {
            lane = Math.max(-2, Math.min(2, lane + random.nextInt(3) - 1));
            for (int dx = lane - 1; dx <= lane + 1; dx++) {
                Location location = new Location(world, cx + dx, y, z + dz);
                setBlock(location.getBlockX(), location.getBlockY(), location.getBlockZ(), Material.AMETHYST_BLOCK);
                vanishingBlocks.add(location);
            }
            setBlock(cx + lane, y - 2, z + dz, theme.light());
        }
        return y;
    }

    /** A protected runway crossed by alternating arrow cannons. */
    private int buildBlasters(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 3, cx + 3, y, y, z, z + length - 1, theme.floor());
        fill(cx - 4, cx - 4, y + 1, y + 2, z, z + length - 1, theme.edge());
        fill(cx + 4, cx + 4, y + 1, y + 2, z, z + length - 1, theme.edge());
        int number = 0;
        for (int dz = 2; dz < length - 1; dz += 3) {
            boolean fromLeft = number++ % 2 == 0;
            int x = cx + (fromLeft ? -4 : 4);
            BlockFace facing = fromLeft ? BlockFace.EAST : BlockFace.WEST;
            directionalBlock(x, y + 1, z + dz, Material.DISPENSER, facing);
            Location muzzle = new Location(world, x + 0.5, y + 1.5, z + dz + 0.5)
                    .add(facing.getDirection().multiply(0.7));
            blasters.add(new Blaster(muzzle, facing.getDirection(), number * 7 % 36));
            setBlock(x, y + 2, z + dz, theme.light());
        }
        return y;
    }

    /** A shared mini-boss blocks the route until the racers defeat it. */
    private int buildBossArena(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 5, cx + 5, y, y, z, z + length - 1, theme.floor());
        fill(cx - 6, cx - 6, y + 1, y + 3, z, z + length - 1, theme.pillar());
        fill(cx + 6, cx + 6, y + 1, y + 3, z, z + length - 1, theme.pillar());
        int gateZ = z + length - 2;
        bossGateZ = gateZ;
        bossReturnLocation = new Location(world, cx + 0.5, y + 1.1, gateZ - 2.5, 180, 0);
        for (int x = cx - 5; x <= cx + 5; x++) {
            for (int yy = y + 1; yy <= y + 5; yy++) {
                Location gateBlock = new Location(world, x, yy, gateZ);
                setBlock(x, yy, gateZ, Material.IRON_BARS);
                bossGate.add(gateBlock);
            }
        }
        fill(cx - 6, cx + 6, y + 6, y + 6, gateZ, gateZ, theme.accent());
        boss = world.spawn(new Location(world, cx + 0.5, y + 1, z + length / 2.0), Ravager.class, ravager -> {
            ravager.customName(Component.text("CLUCKZILLA", NamedTextColor.RED, TextDecoration.BOLD));
            ravager.setCustomNameVisible(true);
            ravager.setPersistent(true);
            ravager.setRemoveWhenFarAway(false);
            ravager.setAI(false);
            AttributeInstance health = ravager.getAttribute(Attribute.MAX_HEALTH);
            if (health != null) {
                health.setBaseValue(35 + active.size() * 8);
                ravager.setHealth(health.getBaseValue());
            }
        });
        bossBar = Bukkit.createBossBar("CLUCKZILLA", BarColor.RED, BarStyle.SEGMENTED_10);
        return y;
    }

    /** Hit every target with the supplied bow to lower the glass gate. */
    private int buildTargetShootout(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 4, cx + 4, y, y, z, z + length - 1, theme.floor());
        fill(cx - 5, cx - 5, y + 1, y + 4, z, z + length - 1, theme.edge());
        fill(cx + 5, cx + 5, y + 1, y + 4, z, z + length - 1, theme.edge());
        int gateZ = z + length - 2;
        TargetShootout shootout = new TargetShootout(cx - 6, cx + 6, z - 2, z + length, gateZ,
                new Location(world, cx + 0.5, y + 1.1, gateZ - 2.5, 180, 0));
        int[][] targets = {
                {-4, 2, 2}, {4, 3, 3}, {-4, 4, 5}, {4, 2, 6}
        };
        for (int[] target : targets) {
            int targetZ = z + Math.min(length - 4, target[2]);
            Location location = new Location(world, cx + target[0], y + target[1], targetZ);
            setBlock(location.getBlockX(), location.getBlockY(), location.getBlockZ(), Material.TARGET);
            shootout.remaining.add(location);
        }
        for (int x = cx - 4; x <= cx + 4; x++) {
            for (int yy = y + 1; yy <= y + 4; yy++) {
                Location gateBlock = new Location(world, x, yy, gateZ);
                setBlock(x, yy, gateZ, Material.RED_STAINED_GLASS);
                shootout.gate.add(gateBlock);
            }
        }
        targetShootouts.add(shootout);
        return y;
    }

    // ===================== new segment builders =====================

    /** A giant stone well astride the track - hop the rim, or drop in and climb out. */
    private int buildGiantWell(int cx, int y, int z, int length, Theme theme) {
        int centerZ = z + Math.max(5, length / 2);
        int rim = Math.min(BASE_Y + 12, y + 3);
        for (int i = 0; i <= rim - y; i++) {
            fill(cx - 2, cx + 2, y + i, y + i, z + i, z + i + 1, theme.pillar());
        }
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                int distSq = dx * dx + dz * dz;
                if (distSq > 9 || distSq < 4) {
                    continue;
                }
                fill(cx + dx, cx + dx, y - 2, rim, centerZ + dz, centerZ + dz, theme.pillar());
            }
        }
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx * dx + dz * dz > 2) {
                    continue;
                }
                setBlock(cx + dx, y - 3, centerZ + dz, theme.pillar());
                setBlock(cx + dx, y - 2, centerZ + dz, Material.WATER);
                setBlock(cx + dx, y - 1, centerZ + dz, Material.WATER);
            }
        }
        for (int yy = y - 1; yy < rim; yy++) {
            ladder(cx, yy, centerZ - 1, BlockFace.SOUTH);
        }
        for (int side : new int[]{-3, 3}) {
            fill(cx + side, cx + side, rim + 1, rim + 3, centerZ, centerZ, theme.edge());
        }
        fill(cx - 3, cx + 3, rim + 4, rim + 4, centerZ, centerZ, theme.accent());
        setBlock(cx, rim + 5, centerZ, theme.light());
        for (int i = 0; i <= rim - y; i++) {
            int stepZ = z + Math.min(length - 2 - i, centerZ - z + 4);
            fill(cx - 2, cx + 2, rim - i, rim - i, stepZ, stepZ + 1, theme.pillar());
        }
        return y;
    }

    /** Scale a giant wall by ladder, leap the sky chasm plank-to-plank, then flush
     *  down the far giant wall through a glass water chute. */
    private int buildGiantWalls(int cx, int y, int z, int length, Theme theme) {
        int h = 6 + random.nextInt(3);
        int top = y + h;
        fill(cx - 3, cx + 3, y, y, z, z + 4, theme.floor());
        fill(cx - 5, cx + 5, y + 1, top, z + 3, z + 4, theme.pillar());
        for (int yy = y + 1; yy < top; yy++) {
            ladder(cx, yy, z + 2, BlockFace.NORTH);
        }
        fill(cx - 4, cx + 4, top, top, z + 3, z + 6, theme.floor());
        setBlock(cx - 4, top + 1, z + 3, theme.light());
        setBlock(cx + 4, top + 1, z + 3, theme.light());
        for (int dz = 7; dz <= length - 7; dz++) {
            if (dz % 3 == 1) {
                fill(cx - 1, cx + 1, top, top, z + dz, z + dz, theme.edge());
            } else if (dz % 3 == 2) {
                setBlock(cx, top - 1, z + dz, theme.light());
            }
        }
        fill(cx - 5, cx + 5, y + 1, top, z + length - 3, z + length - 2, theme.pillar());
        fill(cx - 4, cx + 4, top, top, z + length - 6, z + length - 3, theme.floor());
        setBlock(cx - 4, top + 1, z + length - 3, theme.light());
        setBlock(cx + 4, top + 1, z + length - 3, theme.light());
        fill(cx - 2, cx + 2, y - 1, y - 1, z + length - 1, z + length + 1, theme.pillar());
        fill(cx - 1, cx + 1, y, top, z + length - 1, z + length + 1, Material.WATER);
        fill(cx - 2, cx - 2, y, top, z + length - 1, z + length + 1, Material.GLASS);
        fill(cx + 2, cx + 2, y, top, z + length - 1, z + length + 1, Material.GLASS);
        return y;
    }

    /** A glass free-fall shaft onto floating cube steps - ride the cubes down to the exit. */
    private int buildCubeDrop(int cx, int y, int z, int length, Theme theme) {
        int top = Math.min(BASE_Y + 18, y + 8);
        for (int zz = z; zz < z + length; zz++) {
            fill(cx - 4, cx - 4, y + 1, zz == z ? top - 1 : top + 2, zz, zz, theme.accent());
            fill(cx + 4, cx + 4, y + 1, zz == z ? top - 1 : top + 2, zz, zz, theme.accent());
        }
        fill(cx - 3, cx + 3, top, top, z, z + 3, theme.floor());
        fill(cx - 4, cx + 4, top + 3, top + 3, z, z + length - 1, theme.accent());
        for (int yy = y + 1; yy <= top - 1; yy++) {
            ladder(cx, yy, z - 1, BlockFace.NORTH);
        }
        fill(cx - 3, cx + 3, y, y, z + 1, z + length - 1, theme.floor());
        boolean left = random.nextBoolean();
        int zi = 4;
        int levels = Math.max(1, (top - y - 2) / 2);
        for (int lvl = top - 2; lvl > y + 1; lvl -= 2) {
            int off = left ? -1 : 1;
            left = !left;
            int cubeZ = Math.min(z + length - 3, z + zi);
            fill(cx + off - 1, cx + off, lvl, lvl, cubeZ, cubeZ + 1, theme.floor());
            setBlock(cx + off * 2, lvl - 1, cubeZ, theme.light());
            zi += Math.max(1, (length - 6) / levels);
        }
        fill(cx - 1, cx + 1, y + 1, y + 2, z + length - 1, z + length - 1, Material.AIR);
        return y;
    }

    /** Chunky floating islands drifting up and down over open sky. */
    private int buildSkyIslands(int cx, int y, int z, int length, Theme theme) {
        int iy = y;
        for (int dz = 0; dz < length; dz += 5) {
            int dx = dz == 0 ? 0 : random.nextInt(7) - 3;
            if (dz > 0) {
                iy = Math.max(BASE_Y, Math.min(BASE_Y + 16, iy + random.nextInt(7) - 3));
            }
            int size = 2 + random.nextInt(2);
            int depth = Math.min(2, length - 1 - dz);
            fill(cx + dx - size, cx + dx + size, iy, iy, z + dz, z + dz + depth, theme.floor());
            fill(cx + dx - size + 1, cx + dx + size - 1, iy - 1, iy - 1, z + dz, z + dz + depth,
                    theme.edge());
            setBlock(cx + dx, iy - 2, z + dz + depth / 2, theme.light());
            setBlock(cx + dx - size, iy, z + dz + depth, theme.edge());
            setBlock(cx + dx + size, iy, z + dz + depth, theme.edge());
        }
        return iy;
    }

    /** Pillar-hopping across a grove of floating stone columns at mixed heights. */
    private int buildPillarGrove(int cx, int y, int z, int length, Theme theme) {
        int px = 0;
        int py = y;
        for (int dz = 0; dz < length; dz += 3) {
            px = dz == 0 ? 0 : Math.max(-3, Math.min(3, px + random.nextInt(5) - 2));
            py = dz == 0 ? y
                    : Math.max(BASE_Y + 1, Math.min(BASE_Y + 15, py + random.nextInt(5) - 2));
            int capZ = Math.min(z + dz + 1, z + length - 1);
            if (dz + 3 >= length) {
                px = 0;
                py = y;
            }
            fill(cx + px, cx + px + 1, py - 3, py, z + dz, capZ, theme.pillar());
            fill(cx + px - 1, cx + px + 2, py, py, z + dz, capZ, theme.floor());
            if (random.nextInt(3) == 0) {
                setBlock(cx + px, py + 1, z + dz, theme.light());
            }
        }
        return py;
    }

    /** A glowing lava lake crossed on staggered stones - falls are harmless but toasty. */
    private int buildLavaCauseway(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 4, cx + 4, y - 2, y - 2, z, z + length - 1, Material.MAGMA_BLOCK);
        fill(cx - 4, cx + 4, y - 1, y - 1, z, z + length - 1, Material.LAVA);
        int lane = 0;
        for (int dz = 0; dz < length; dz++) {
            if (dz % 3 == 0 && dz > 0) {
                lane = Math.max(-2, Math.min(2, lane + random.nextInt(3) - 1));
            }
            if (dz % 3 == 2 && random.nextInt(3) > 0) {
                continue;
            }
            fill(cx + lane - 1, cx + lane + 1, y, y, z + dz, z + dz, theme.floor());
            if (dz % 4 == 0) {
                setBlock(cx + lane, y - 2, z + dz, theme.light());
            }
        }
        return y;
    }

    /** A broad checkerboard sprint riddled with missing tiles - pick your line. */
    private int buildCheckerSprint(int cx, int y, int z, int length, Theme theme) {
        for (int dz = 0; dz < length; dz++) {
            for (int dx = -4; dx <= 4; dx++) {
                boolean dark = (dx + dz) % 2 == 0;
                if (!dark && random.nextInt(4) == 0) {
                    continue;
                }
                setBlock(cx + dx, y, z + dz, dark ? theme.pillar() : theme.floor());
            }
            if (dz % 3 == 0) {
                setBlock(cx - 5, y, z + dz, theme.light());
                setBlock(cx + 5, y, z + dz, theme.light());
            }
        }
        return y;
    }

    /** Climb floating wool balloons ever upward, then plunge into the splash pool. */
    private int buildBalloonHop(int cx, int y, int z, int length, Theme theme) {
        int by = y;
        int bx = 0;
        for (int dz = 1; dz < length - 3; dz += 3) {
            bx = dz == 1 ? 0 : Math.max(-3, Math.min(3, bx + random.nextInt(3) - 1));
            by = Math.min(BASE_Y + 16, by + (random.nextBoolean() ? 2 : 1));
            Material color = WOOL[random.nextInt(WOOL.length)];
            fill(cx + bx - 1, cx + bx + 1, by, by, z + dz, z + dz + 1, color);
            setBlock(cx + bx, by - 1, z + dz, theme.light());
        }
        int pool = Math.max(BASE_Y, y - 3);
        fill(cx - 3, cx + 3, pool - 1, pool - 1, z + length - 3, z + length - 1, theme.pillar());
        fill(cx - 3, cx + 3, pool, pool, z + length - 3, z + length - 1, Material.WATER);
        fill(cx - 4, cx - 4, pool, pool + 4, z + length - 3, z + length - 1, Material.GLASS);
        fill(cx + 4, cx + 4, pool, pool + 4, z + length - 3, z + length - 1, Material.GLASS);
        return pool;
    }

    /** Sprint the caged corridor, squeezing through alternating iron-bar gates. */
    private int buildCageMaze(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 3, cx + 3, y, y, z, z + length - 1, theme.floor());
        fill(cx - 4, cx + 4, y + 3, y + 3, z, z + length - 1, Material.IRON_BARS);
        for (int dz = 2; dz < length; dz += 3) {
            boolean openLeft = ((dz / 3) & 1) == 0;
            for (int dx = -3; dx <= 3; dx++) {
                if (openLeft ? dx <= 0 : dx >= 0) {
                    continue;
                }
                setBlock(cx + dx, y + 1, z + dz, Material.IRON_BARS);
                setBlock(cx + dx, y + 2, z + dz, Material.IRON_BARS);
            }
            setBlock(openLeft ? cx + 3 : cx - 3, y, z + dz, theme.light());
        }
        return y;
    }

    /** Ledge-by-ledge along a towering canyon wall while the void yawns on your left. */
    private int buildGrandCanyon(int cx, int y, int z, int length, Theme theme) {
        int wallX = cx + 4;
        fill(wallX, wallX + 1, y - 8, y + 8, z, z + length - 1, theme.pillar());
        int ly = y;
        for (int dz = 0; dz < length; dz++) {
            if (dz % 4 == 0 && dz > 0) {
                ly = Math.max(BASE_Y, Math.min(BASE_Y + 12, ly + random.nextInt(3) - 1));
            }
            int jut = dz % 8 < 5 ? 2 : 1;
            fill(wallX - jut, wallX - 1, ly, ly, z + dz, z + dz, theme.floor());
            if (dz % 5 == 2) {
                setBlock(wallX - 1, ly + 2, z + dz, theme.light());
            }
        }
        return ly;
    }

    /** The walls close in until you are tip-toeing a one-block seam of light. */
    private int buildShrinkCorridor(int cx, int y, int z, int length, Theme theme) {
        for (int dz = 0; dz < length; dz++) {
            int span = 2 - Math.min(2, (dz * 3) / Math.max(1, length - 1));
            fill(cx - span - 1, cx + span + 1, y, y, z + dz, z + dz, theme.floor());
            fill(cx - span - 2, cx - span - 2, y + 1, y + 4, z + dz, z + dz, theme.pillar());
            fill(cx + span + 2, cx + span + 2, y + 1, y + 4, z + dz, z + dz, theme.pillar());
            fill(cx - span - 1, cx + span + 1, y + 5, y + 5, z + dz, z + dz, theme.accent());
            if (span == 0) {
                setBlock(cx, y + 4, z + dz, theme.light());
            }
        }
        return y;
    }

    /** An ice speedway crossfired by dense dispensers with hurdles mid-slide. */
    private int buildBlitzLane(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 3, cx + 3, y, y, z, z + length - 1, Material.PACKED_ICE);
        fill(cx - 4, cx - 4, y + 1, y + 2, z, z + length - 1, theme.edge());
        fill(cx + 4, cx + 4, y + 1, y + 2, z, z + length - 1, theme.edge());
        int number = 0;
        for (int dz = 1; dz < length; dz += 2) {
            boolean fromLeft = number++ % 2 == 0;
            int x = cx + (fromLeft ? -4 : 4);
            BlockFace facing = fromLeft ? BlockFace.EAST : BlockFace.WEST;
            directionalBlock(x, y + 1, z + dz, Material.DISPENSER, facing);
            Location muzzle = new Location(world, x + 0.5, y + 1.5, z + dz + 0.5)
                    .add(facing.getDirection().multiply(0.7));
            blasters.add(new Blaster(muzzle, facing.getDirection(), number * 5 % 36));
            if (number % 2 == 0) {
                setBlock(x, y + 2, z + dz, theme.light());
            }
        }
        for (int dz = 3; dz < length - 1; dz += 4) {
            fill(cx - 1, cx + 1, y + 1, y + 1, z + dz, z + dz, Material.POLISHED_BLACKSTONE_WALL);
        }
        launchPad(cx, y, z + length - 1);
        return y;
    }

    /** Rhythm gates: hurdle the low walls, then squeeze under the beams. */
    private int buildLeapDuck(int cx, int y, int z, int length, Theme theme) {
        fill(cx - 2, cx + 2, y, y, z, z + length - 1, theme.floor());
        for (int dz = 2; dz < length; dz += 3) {
            boolean hurdle = ((dz / 3) & 1) == 0;
            if (hurdle) {
                fill(cx - 2, cx + 2, y + 1, y + 1, z + dz, z + dz, Material.POLISHED_BLACKSTONE_WALL);
                setBlock(cx - 3, y, z + dz, theme.light());
            } else {
                fill(cx - 2, cx + 2, y + 3, y + 4, z + dz, z + dz, theme.pillar());
                setBlock(cx - 3, y + 2, z + dz, theme.light());
                setBlock(cx + 3, y + 2, z + dz, theme.light());
            }
        }
        return y;
    }

    /** Climb the tower steps, then plunge a ladder-lined shaft to the depths below. */
    private int buildVinePlunge(int cx, int y, int z, int length, Theme theme) {
        int top = Math.min(BASE_Y + 17, y + 5);
        int bottom = Math.max(BASE_Y - 6, y - 6);
        int shaftZ = Math.min(z + length - 4, z + top - y + 1);
        for (int i = 0; i <= top - y; i++) {
            fill(cx - 2, cx + 2, y + i, y + i, z + i, z + i + 1, theme.pillar());
        }
        for (int yy = bottom; yy <= top; yy++) {
            for (int xx = cx - 2; xx <= cx + 2; xx++) {
                setBlock(xx, yy, shaftZ, theme.pillar());
                setBlock(xx, yy, shaftZ + 2, theme.pillar());
            }
            for (int zz = shaftZ; zz <= shaftZ + 2; zz++) {
                setBlock(cx - 2, yy, zz, theme.pillar());
                setBlock(cx + 2, yy, zz, theme.pillar());
            }
        }
        for (int xx = cx - 2; xx <= cx + 2; xx++) {
            setBlock(xx, top + 1, shaftZ, theme.accent());
            setBlock(xx, top + 1, shaftZ + 2, theme.accent());
        }
        setBlock(cx - 2, top + 1, shaftZ + 1, theme.accent());
        setBlock(cx + 2, top + 1, shaftZ + 1, theme.accent());
        setBlock(cx, top + 2, shaftZ + 1, theme.light());
        boolean west = random.nextBoolean();
        for (int yy = bottom + 2; yy < top; yy++) {
            west = !west;
            if (west) {
                ladder(cx - 1, yy, shaftZ + 1, BlockFace.EAST);
            } else {
                ladder(cx + 1, yy, shaftZ + 1, BlockFace.WEST);
            }
        }
        fill(cx - 1, cx + 1, bottom - 1, bottom - 1, shaftZ, shaftZ + 2, theme.pillar());
        fill(cx - 1, cx + 1, bottom, bottom + 1, shaftZ + 1, shaftZ + 1, Material.WATER);
        fill(cx - 1, cx + 1, bottom + 1, bottom + 2, shaftZ + 2, shaftZ + 2, Material.AIR);
        fill(cx - 2, cx + 2, bottom, bottom, shaftZ + 3, Math.min(shaftZ + 5, z + length - 1),
                theme.floor());
        return bottom;
    }

    private void decorateSegment(int cx, int y, int z, int length, Theme theme) {
        int middle = z + length / 2;
        for (int side : new int[]{-5, 5}) {
            setBlock(cx + side, y - 2, middle, theme.accent());
            setBlock(cx + side, y - 1, middle, theme.light());
            setBlock(cx + side, y, middle, theme.accent());
        }
        for (int dz = 1; dz < length; dz += 5) {
            setBlock(cx - 4, y - 1, z + dz, theme.accent());
            setBlock(cx + 4, y - 1, z + dz, theme.accent());
        }
    }

    private void bridgeConnection(int cx, int y, int z, int length, Material material) {
        fill(cx - 1, cx + 1, y, y, z, z + length, material);
    }

    // ===================== pads =====================

    private void launchPad(int x, int y, int z) {
        setBlock(x, y, z, Material.SLIME_BLOCK);
        launchPads.add(new Location(world, x, y, z));
    }

    private void speedPad(int x, int y, int z) {
        setBlock(x, y, z, Material.EMERALD_BLOCK);
        speedPads.add(new Location(world, x, y, z));
    }

    /** Fires the pad the player is standing on, if any. */
    private void applyPads(Player player) {
        UUID id = player.getUniqueId();
        if (roundTicks - padCooldown.getOrDefault(id, -100) < 10) {
            return;
        }
        Location below = player.getLocation().getBlock().getRelative(BlockFace.DOWN).getLocation();
        if (launchPads.contains(below)) {
            padCooldown.put(id, roundTicks);
            player.setVelocity(new Vector(player.getVelocity().getX() * 0.25, 0.62, 0.38));
            player.playSound(player.getLocation(), Sound.ENTITY_SLIME_SQUISH, 1f, 1.4f);
            Particle.CLOUD.builder().location(below.clone().add(0.5, 1, 0.5)).count(12)
                    .offset(0.3, 0.1, 0.3).extra(0.02).receivers(48, true).spawn();
        } else if (speedPads.contains(below)) {
            padCooldown.put(id, roundTicks);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 1, false, false, true));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.8f, 1.9f);
        }
    }

    private void tickVanishingPlatforms() {
        for (UUID id : active) {
            if (roundFinishers.contains(id)) {
                continue;
            }
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            Location below = player.getLocation().clone().subtract(0, 0.2, 0).getBlock().getLocation();
            if (vanishingBlocks.contains(below) && !vanishingAt.containsKey(below)
                    && !respawningAt.containsKey(below)) {
                vanishingAt.put(below, roundTicks + 20);
                player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_BREAK, 0.6f, 1.7f);
            }
        }
        for (Map.Entry<Location, Integer> entry : new ArrayList<>(vanishingAt.entrySet())) {
            if (entry.getValue() > roundTicks) {
                continue;
            }
            Location location = entry.getKey();
            location.getBlock().setType(Material.AIR, false);
            Particle.POOF.builder().location(location.clone().add(0.5, 0.7, 0.5)).count(12)
                    .offset(0.35, 0.15, 0.35).receivers(48, true).spawn();
            world.playSound(location, Sound.BLOCK_GLASS_BREAK, 0.7f, 1.3f);
            vanishingAt.remove(location);
            respawningAt.put(location, roundTicks + 100);
        }
        for (Map.Entry<Location, Integer> entry : new ArrayList<>(respawningAt.entrySet())) {
            if (entry.getValue() > roundTicks) {
                continue;
            }
            Location location = entry.getKey();
            location.getBlock().setType(Material.AMETHYST_BLOCK, false);
            world.playSound(location, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.45f, 1.8f);
            respawningAt.remove(location);
        }
    }

    private void tickBlasters() {
        for (Blaster blaster : blasters) {
            if (roundTicks % 36 != blaster.offset()) {
                continue;
            }
            Arrow arrow = world.spawnArrow(blaster.muzzle(), blaster.direction(), 1.25f, 0);
            arrow.addScoreboardTag(BLASTER_TAG);
            arrow.setDamage(0);
            arrow.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
            arrow.setSilent(true);
            world.playSound(blaster.muzzle(), Sound.ENTITY_ARROW_SHOOT, 0.55f, 1.45f);
        }
        if (roundTicks % 20 == 0) {
            for (Arrow arrow : world.getEntitiesByClass(Arrow.class)) {
                if (arrow.getScoreboardTags().contains(BLASTER_TAG) && arrow.getTicksLived() > 60) {
                    arrow.remove();
                }
            }
        }
    }

    private void tickBoss() {
        if (boss == null) {
            return;
        }
        if (!boss.isValid() || boss.isDead()) {
            boss = null;
            for (Location location : bossGate) {
                location.getBlock().setType(Material.AIR, false);
            }
            world.playSound(bossGate.isEmpty() ? roundSpawn : bossGate.getFirst(),
                    Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.2f, 0.85f);
            broadcast(Component.text("CLUCKZILLA defeated - the gate is open!", NamedTextColor.GREEN));
            if (bossBar != null) {
                bossBar.removeAll();
                bossBar = null;
            }
            return;
        }
        if (bossBar != null) {
            AttributeInstance health = boss.getAttribute(Attribute.MAX_HEALTH);
            double maximum = health == null ? boss.getHealth() : health.getValue();
            bossBar.setProgress(Math.max(0, Math.min(1, boss.getHealth() / Math.max(1, maximum))));
        }
    }

    private void supplyShootoutBows() {
        for (TargetShootout shootout : targetShootouts) {
            if (shootout.open) {
                continue;
            }
            for (UUID id : active) {
                Player player = Bukkit.getPlayer(id);
                if (player == null || !player.isOnline() || roundFinishers.contains(id)) {
                    continue;
                }
                Location at = player.getLocation();
                if (at.getBlockX() < shootout.minX || at.getBlockX() > shootout.maxX
                        || at.getBlockZ() < shootout.minZ || at.getBlockZ() > shootout.maxZ) {
                    continue;
                }
                if (!player.getInventory().contains(Material.BOW)) {
                    player.getInventory().setItem(1, ItemStack.of(Material.BOW));
                    player.sendActionBar(Component.text("Shoot all four targets to open the gate!", NamedTextColor.YELLOW));
                }
                if (!player.getInventory().contains(Material.ARROW, 8)) {
                    player.getInventory().setItem(2, ItemStack.of(Material.ARROW, 64));
                }
            }
        }
    }

    private void enforceLockedGates() {
        for (UUID id : active) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline() || roundFinishers.contains(id)) {
                continue;
            }
            if (boss != null && bossReturnLocation != null && player.getLocation().getZ() > bossGateZ) {
                player.teleport(bossReturnLocation);
                player.sendActionBar(Component.text("Defeat CLUCKZILLA first!", NamedTextColor.RED));
                continue;
            }
            for (TargetShootout shootout : targetShootouts) {
                if (!shootout.open && player.getLocation().getZ() > shootout.gateZ) {
                    player.teleport(shootout.returnLocation);
                    player.sendActionBar(Component.text("Hit every target first!", NamedTextColor.RED));
                    break;
                }
            }
        }
    }

    private void ladder(int x, int y, int z, BlockFace facing) {
        Location location = new Location(world, x, y, z);
        Block block = location.getBlock();
        block.setType(Material.LADDER, false);
        if (block.getBlockData() instanceof Ladder data) {
            data.setFacing(facing);
            block.setBlockData(data, false);
        }
        generatedBlocks.add(location);
    }

    private void directionalBlock(int x, int y, int z, Material material, BlockFace facing) {
        Location location = new Location(world, x, y, z);
        Block block = location.getBlock();
        block.setType(material, false);
        if (block.getBlockData() instanceof Directional data) {
            data.setFacing(facing);
            block.setBlockData(data, false);
        }
        generatedBlocks.add(location);
    }

    private void preparePlayer(Player player, int slot) {
        resetPlayer(player);
        Location spawn = roundSpawn.clone().add((slot - (roster.size() - 1) / 2.0) * 1.8, 0, 0);
        // Finishers watch as spectators; leave spectator (and any camera they attached to the
        // now-removed finish chicken or another racer) before moving them, or the warp can fail.
        if (player.getGameMode() == GameMode.SPECTATOR) {
            player.setSpectatorTarget(null);
        }
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(spawn);
        player.getInventory().setItemInMainHand(ItemStack.of(woolFor(player), 64));
        if (bossBar != null) {
            bossBar.addPlayer(player);
        }
    }

    private void resetToCheckpoint(Player player) {
        int index = checkpointIndex.getOrDefault(player.getUniqueId(), 0);
        Checkpoint checkpoint = checkpoints.get(Math.min(index, checkpoints.size() - 1));
        Location spawn = checkpoint.spawn().clone();
        for (int x = spawn.getBlockX() - 1; x <= spawn.getBlockX() + 1; x++) {
            for (int y = spawn.getBlockY(); y <= spawn.getBlockY() + 2; y++) {
                for (int z = spawn.getBlockZ() - 1; z <= spawn.getBlockZ() + 1; z++) {
                    Location location = new Location(world, x, y, z);
                    if (placedWool.remove(location) != null) {
                        location.getBlock().setType(Material.AIR, false);
                    }
                }
            }
        }
        player.teleport(spawn);
        player.setFallDistance(0);
        player.setVelocity(new Vector());
        player.playSound(player.getLocation(), Sound.ENTITY_CHICKEN_EGG, 1f, 0.75f);
        status.put(player.getUniqueId(), "Respawned CP" + index);
    }

    private void advanceCheckpoint(Player player) {
        int current = checkpointIndex.getOrDefault(player.getUniqueId(), 0);
        if (current + 1 >= checkpoints.size()) {
            return;
        }
        Checkpoint next = checkpoints.get(current + 1);
        Location at = player.getLocation();
        Location spawn = next.spawn();
        Material below = at.clone().subtract(0, 0.2, 0).getBlock().getType();
        if (below == Material.GOLD_BLOCK && Math.abs(at.getX() - spawn.getX()) <= 4.5
                && Math.abs(at.getZ() - spawn.getZ()) <= 3.5 && Math.abs(at.getY() - spawn.getY()) <= 2) {
            checkpointIndex.put(player.getUniqueId(), current + 1);
            status.put(player.getUniqueId(), "Racing CP" + (current + 1));
            player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.7f, 1.6f);
        }
    }

    private void showPodium() {
        phase = Phase.PODIUM;
        cancelTasks();
        clearArena();
        List<UUID> ranking = roster.stream()
                .sorted(Comparator.<UUID>comparingInt(id -> points.getOrDefault(id, 0)).reversed()
                        .thenComparingInt(id -> placeTotal.getOrDefault(id, Integer.MAX_VALUE)))
                .toList();
        buildPodium();
        int[][] spots = {{0, 3}, {-4, 2}, {4, 1}, {-7, 0}, {0, 0}, {7, 0}};
        for (int i = 0; i < ranking.size(); i++) {
            Player player = Bukkit.getPlayer(ranking.get(i));
            if (player == null || !player.isOnline()) {
                continue;
            }
            resetPlayer(player);
            player.setGameMode(GameMode.ADVENTURE);
            if (i < spots.length) {
                player.teleport(new Location(world, spots[i][0] + 0.5, BASE_Y + spots[i][1] + 1.1, 0.5));
                status.put(player.getUniqueId(), ordinal(i + 1) + " overall");
            }
        }
        updateScoreboard();
        schedule(() -> {
            if (ranking.isEmpty()) {
                broadcast(Component.text("Chicken Run complete.", NamedTextColor.GOLD));
                return;
            }
            Player winner = Bukkit.getPlayer(ranking.getFirst());
            String name = winner == null ? "The leader" : winner.getName();
            broadcast(Component.text(name + " wins Chicken Run with "
                    + points.getOrDefault(ranking.getFirst(), 0) + " points!", NamedTextColor.GOLD,
                    TextDecoration.BOLD));
            if (winner != null) {
                winner.sendTitle("§6§lCHICKEN RUN CHAMPION", "§f" + points.get(ranking.getFirst()) + " points", 10, 80, 10);
            }
            world.playSound(new Location(world, 0.5, BASE_Y + 3, 0.5),
                    Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.5f, 1f);
        }, 40L);
        schedule(this::endGame, 180L);
    }

    private void buildPodium() {
        fill(-8, 8, BASE_Y, BASE_Y, -5, 10, Material.POLISHED_BLACKSTONE);
        fill(-2, 2, BASE_Y + 1, BASE_Y + 3, -2, 2, Material.GOLD_BLOCK);
        fill(-6, -3, BASE_Y + 1, BASE_Y + 2, -2, 2, Material.IRON_BLOCK);
        fill(3, 6, BASE_Y + 1, BASE_Y + 1, -2, 2, Material.COPPER_BLOCK);
    }

    private void updateScoreboard() {
        if (sidebar == null) {
            sidebar = new Sidebar("chickenrun", Component.text("CHICKEN RUN", NamedTextColor.GOLD, TextDecoration.BOLD));
        }
        List<String> lines = new ArrayList<>();
        List<Integer> scores = new ArrayList<>();
        lines.add(ChatColor.YELLOW + "Round: " + Math.min(round, ROUND_COUNT) + "/3");
        scores.add(100);
        if (phase == Phase.RACING && firstFinishTick >= 0) {
            lines.add(ChatColor.RED + "Finish in: " + formatTime(
                    Math.max(0, (FINISH_GRACE_TICKS - (roundTicks - firstFinishTick)) / 20)));
        } else if (phase == Phase.RACING) {
            lines.add(ChatColor.GRAY + "Time: " + formatTime(roundTicks / 20));
        } else {
            lines.add(ChatColor.GRAY + "Status: " + phaseName());
        }
        scores.add(99);
        lines.add(ChatColor.GOLD + theme.name());
        scores.add(98);
        int score = 90;
        int color = 0;
        ChatColor[] unique = {
                ChatColor.RED, ChatColor.BLUE, ChatColor.GREEN,
                ChatColor.YELLOW, ChatColor.LIGHT_PURPLE, ChatColor.GOLD
        };
        List<UUID> ranking = roster.stream()
                .sorted(Comparator.<UUID>comparingInt(id -> points.getOrDefault(id, 0)).reversed()
                        .thenComparingInt(id -> placeTotal.getOrDefault(id, Integer.MAX_VALUE)))
                .toList();
        for (UUID id : roster) {
            Player player = Bukkit.getPlayer(id);
            String name = player == null ? "Offline" : player.getName();
            String line = unique[color++ % unique.length] + "#" + (ranking.indexOf(id) + 1) + " " + name
                    + ChatColor.WHITE + " "
                    + points.getOrDefault(id, 0) + "pt " + ChatColor.GRAY + status.getOrDefault(id, "Waiting");
            if (line.length() > 40) {
                line = line.substring(0, 40);
            }
            lines.add(line);
            scores.add(score--);
        }
        // Updated in place rather than rebuilt, so only changed lines are sent and nothing flickers.
        sidebar.set(lines, scores);
        for (UUID id : roster) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                sidebar.show(player);
            }
        }
    }

    private void configureWorld() {
        world.setAutoSave(false);
        world.setPVP(true);
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        world.setGameRule(GameRule.DO_TILE_DROPS, false);
        world.setGameRule(GameRule.KEEP_INVENTORY, true);
        world.setGameRule(GameRule.DO_IMMEDIATE_RESPAWN, true);
        world.setGameRule(GameRule.DO_FIRE_TICK, false);
        world.setGameRule(GameRule.RANDOM_TICK_SPEED, 0);
        world.setTime(6000);
        world.setStorm(false);
        enforceWorldBorder();
    }

    /** Forces the world border to the maximum (59999968 = ~30,000,000 blocks per side) so
     *  the race course is never clipped, including on already-existing worlds. */
    private void enforceWorldBorder() {
        world.getWorldBorder().setCenter(0, 0);
        world.getWorldBorder().setSize(59999968);
        world.getWorldBorder().setWarningDistance(0);
        world.getWorldBorder().setWarningTime(15);
        world.getWorldBorder().setDamageAmount(0);
        world.getWorldBorder().setDamageBuffer(0);
    }

    private void fill(int minX, int maxX, int minY, int maxY, int minZ, int maxZ, Material material) {
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    setBlock(x, y, z, material);
                }
            }
        }
    }

    private void setBlock(int x, int y, int z, Material material) {
        // Keep every course chunk loaded for the whole match, so building, racing over and clearing the
        // ~400-block course never has to load chunks synchronously between rounds.
        if (courseChunks.add(Chunk.getChunkKey(x >> 4, z >> 4))) {
            world.addPluginChunkTicket(x >> 4, z >> 4, plugin);
        }
        Location location = new Location(world, x, y, z);
        location.getBlock().setType(material, false);
        generatedBlocks.add(location);
    }

    private void releaseCourseChunks() {
        world.removePluginChunkTickets(plugin);
        courseChunks.clear();
    }

    private void clearArena() {
        removeFinishChicken();
        removeBoss();
        for (Arrow arrow : world.getEntitiesByClass(Arrow.class)) {
            if (arrow.getScoreboardTags().contains(BLASTER_TAG)) {
                arrow.remove();
            }
        }
        for (Location location : generatedBlocks) {
            location.getBlock().setType(Material.AIR, false);
        }
        for (Location location : placedWool.keySet()) {
            location.getBlock().setType(Material.AIR, false);
        }
        generatedBlocks.clear();
        placedWool.clear();
        launchPads.clear();
        speedPads.clear();
        padCooldown.clear();
        catchUpCooldown.clear();
        vanishingBlocks.clear();
        vanishingAt.clear();
        respawningAt.clear();
        blasters.clear();
        targetShootouts.clear();
        bossGate.clear();
        bossGateZ = Integer.MAX_VALUE;
        bossReturnLocation = null;
        checkpoints.clear();
        hitCooldown.clear();
    }

    private boolean isProtectedBuildLocation(Location location) {
        for (Checkpoint checkpoint : checkpoints) {
            if (Math.abs(location.getX() - checkpoint.spawn().getX()) <= 3
                    && Math.abs(location.getY() - checkpoint.spawn().getY()) <= 3
                    && Math.abs(location.getZ() - checkpoint.spawn().getZ()) <= 3) {
                return true;
            }
        }
        return finishChicken != null && location.distanceSquared(finishChicken.getLocation()) <= 16;
    }

    private int roundLimitTicks() {
        return ROUND_LIMIT_TICKS[Math.min(Math.max(round, 1), ROUND_LIMIT_TICKS.length) - 1];
    }

    private void removeFinishChicken() {
        if (finishChicken != null) {
            finishChicken.remove();
            finishChicken = null;
        }
        for (Entity entity : world.getEntitiesByClass(Chicken.class)) {
            if (entity.getScoreboardTags().contains(FINISH_TAG)) {
                entity.remove();
            }
        }
    }

    private void removeBoss() {
        if (boss != null) {
            boss.remove();
            boss = null;
        }
        if (bossBar != null) {
            bossBar.removeAll();
            bossBar = null;
        }
    }

    private void resetPlayer(Player player) {
        player.getInventory().clear();
        player.setHealth(20.0);
        player.setFoodLevel(20);
        player.setSaturation(20);
        player.setFallDistance(0);
        player.setVelocity(new Vector());
    }

    private Material woolFor(Player player) {
        int index = new ArrayList<>(roster).indexOf(player.getUniqueId());
        return WOOL[Math.floorMod(index, WOOL.length)];
    }

    private void refillWool(Player player) {
        Material wool = woolFor(player);
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == wool) {
                item.setAmount(64);
                return;
            }
        }
        player.getInventory().addItem(ItemStack.of(wool, 64));
    }

    private void showCatchUpHint(Player player) {
        Player leader = furthestRacer(player);
        if (leader != null && leader.getLocation().getZ() - player.getLocation().getZ() >= CATCH_UP_DISTANCE) {
            player.sendActionBar(Component.text("Far behind? Type ", NamedTextColor.YELLOW)
                    .append(Component.text("/crtp", NamedTextColor.GOLD, TextDecoration.BOLD))
                    .append(Component.text(" to warp near the leader", NamedTextColor.YELLOW)));
        }
    }

    private int finishZ() {
        return finishChicken == null ? 600 : finishChicken.getLocation().getBlockZ();
    }

    private Location chickenLocation() {
        return finishChicken == null ? roundSpawn.clone() : finishChicken.getLocation().clone().add(0, 0.7, 0);
    }

    private void forEachActive(java.util.function.Consumer<Player> action) {
        for (UUID id : new ArrayList<>(active)) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                action.accept(player);
            }
        }
    }

    private void broadcast(Component message) {
        for (UUID id : roster) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                player.sendMessage(Component.text("[Chicken Run] ", NamedTextColor.GOLD).append(message));
            }
        }
    }

    private void track(BukkitTask task) {
        tasks.add(task);
    }

    private void schedule(Runnable action, long delay) {
        BukkitTask[] holder = new BukkitTask[1];
        holder[0] = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            tasks.remove(holder[0]);
            if (isRunning()) {
                action.run();
            }
        }, delay);
        track(holder[0]);
    }

    private void cancelTasks() {
        for (BukkitTask task : new ArrayList<>(tasks)) {
            task.cancel();
        }
        tasks.clear();
    }

    private String phaseName() {
        return switch (phase) {
            case COUNTDOWN -> "Starting";
            case RACING -> "Racing";
            case BETWEEN_ROUNDS -> "Results";
            case PODIUM -> "Podium";
            default -> "Idle";
        };
    }

    private static String ordinal(int value) {
        return switch (value) {
            case 1 -> "1st";
            case 2 -> "2nd";
            case 3 -> "3rd";
            default -> value + "th";
        };
    }

    private static String formatTime(int seconds) {
        return "%d:%02d".formatted(seconds / 60, seconds % 60);
    }
}
