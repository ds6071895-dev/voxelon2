package dev.autobox.ratseek;

import org.bukkit.Material;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

/**
 * Human-sized navigation over the manor blueprint, used by the AI seekers. It reads only the
 * deterministic {@link RatSeekHouse}, so it is built once per boot and can be checked offline.
 * A cell is where a seeker's feet stand: solid floor below and two passable blocks above.
 * Seekers climb stairs, jump up one block like a player and drop off ledges up to three high.
 * It also marks rat perches no seeker can tag from anywhere it can stand, so the game can make
 * rats slip off them (the Bouncy House twist otherwise strands rats on top of the furniture).
 */
final class RatSeekNav {
    static final int MIN_X = -25, MAX_X = 34, MIN_Y = 74, MAX_Y = 100, MIN_Z = -21, MAX_Z = 34;
    private static final int SX = MAX_X - MIN_X + 1, SY = MAX_Y - MIN_Y + 1, SZ = MAX_Z - MIN_Z + 1;
    private static final int[][] STEPS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
    private static final int MAX_EXPANSIONS = 9000;
    private static final int MAX_DROP = 3;
    /** Attack reach, matched to a player's 3 blocks from the eye. */
    private static final double TAG_REACH = 3.0;

    /** A room-sized search target: the hides inside it and a middle point to look around from. */
    record SearchRoom(String name, int[] centre, List<Spot> spots) { }

    /** Somewhere a rat may hide, and the walkable cell a seeker checks it from. */
    record Spot(String name, int[] hide, int[] from, boolean low) { }

    private final RatSeekHouse house;
    private final BitSet walk = new BitSet(SX * SY * SZ);
    /** Cells standing on a stair block (the only place a seeker steps up). */
    private final BitSet stairs = new BitSet(SX * SY * SZ);
    /** Cells with room above the head to jump or climb from. */
    private final BitSet headroom = new BitSet(SX * SY * SZ);
    /** Walkable cells right beside a wall, which paths slightly avoid so seekers don't scrape along them. */
    private final BitSet wallside = new BitSet(SX * SY * SZ);
    /** Rat-sized standing spots that no seeker can tag from any cell it can reach. */
    private final BitSet unfairPerch = new BitSet(SX * SY * SZ);
    private final List<SearchRoom> searchRooms = new ArrayList<>();
    // A* scratch space, reused between searches through a generation stamp.
    private final float[] cost = new float[SX * SY * SZ];
    private final int[] parent = new int[SX * SY * SZ];
    private final int[] stamp = new int[SX * SY * SZ];
    private final BitSet closed = new BitSet(SX * SY * SZ);
    private int generation;
    // Open set as a plain binary heap, so a search allocates nothing per step.
    private int[] heapNode = new int[1024];
    private float[] heapKey = new float[1024];
    private int heapSize;

    RatSeekNav(RatSeekHouse house) {
        this.house = house;
        BitSet candidate = new BitSet(SX * SY * SZ);
        for (int y = MIN_Y + 1; y < MAX_Y; y++) {
            for (int z = MIN_Z; z <= MAX_Z; z++) {
                for (int x = MIN_X; x <= MAX_X; x++) {
                    Material below = house.at(new RatSeekHouse.Pos(x, y - 1, z));
                    if (y + 2 <= MAX_Y && passable(house.at(new RatSeekHouse.Pos(x, y + 2, z)))) {
                        headroom.set(index(x, y, z));
                    }
                    if (floor(below) && passable(house.at(new RatSeekHouse.Pos(x, y, z)))
                            && passable(house.at(new RatSeekHouse.Pos(x, y + 1, z)))) {
                        candidate.set(index(x, y, z));
                        if (below == Material.POLISHED_ANDESITE_STAIRS) {
                            stairs.set(index(x, y, z));
                        }
                    }
                }
            }
        }
        // Keep only what a released seeker can walk to (not the booth interior, the cage or rooftops).
        RatSeekHouse.Pos start = RatSeekHouse.RELEASE;
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        int first = index(start.x(), start.y(), start.z());
        walk.set(first);
        queue.add(first);
        while (!queue.isEmpty()) {
            int from = queue.removeFirst();
            int fx = xOf(from), fy = yOf(from), fz = zOf(from);
            for (int[] step : STEPS) {
                for (int dy = -MAX_DROP; dy <= 1; dy++) {
                    int tx = fx + step[0], ty = fy + dy, tz = fz + step[1];
                    if (!inside(tx, ty, tz) || !candidate.get(index(tx, ty, tz)) || walk.get(index(tx, ty, tz))) {
                        continue;
                    }
                    if (!moveAllowed(candidate, fx, fy, fz, tx, ty, tz)) {
                        continue;
                    }
                    walk.set(index(tx, ty, tz));
                    queue.addLast(index(tx, ty, tz));
                }
            }
        }
        for (int i = walk.nextSetBit(0); i >= 0; i = walk.nextSetBit(i + 1)) {
            int x = xOf(i), y = yOf(i), z = zOf(i);
            for (int[] step : STEPS) {
                if (step[0] != 0 && step[1] != 0) {
                    continue;
                }
                if (!walkable(x + step[0], y, z + step[1]) && !walkable(x + step[0], y + 1, z + step[1])
                        && !walkable(x + step[0], y - 1, z + step[1])) {
                    wallside.set(i);
                }
            }
        }
        buildSearchRooms();
        markUnfairPerches();
    }

    // ------------------------------------------------------------------ materials

    static boolean passable(Material material) {
        return material == Material.AIR || material == Material.LEVER
                || material == Material.HEAVY_WEIGHTED_PRESSURE_PLATE;
    }

    private static boolean floor(Material material) {
        return !passable(material) && material != Material.IRON_BARS && material != Material.STONE_BRICK_WALL
                && material != Material.LANTERN && material != Material.FLOWER_POT && material != Material.GLASS;
    }

    // ------------------------------------------------------------------ cells

    static boolean inside(int x, int y, int z) {
        return x >= MIN_X && x <= MAX_X && y >= MIN_Y && y <= MAX_Y && z >= MIN_Z && z <= MAX_Z;
    }

    private static int index(int x, int y, int z) {
        return ((y - MIN_Y) * SZ + (z - MIN_Z)) * SX + (x - MIN_X);
    }

    private static int xOf(int index) {
        return index % SX + MIN_X;
    }

    private static int zOf(int index) {
        return (index / SX) % SZ + MIN_Z;
    }

    private static int yOf(int index) {
        return index / (SX * SZ) + MIN_Y;
    }

    boolean walkable(int x, int y, int z) {
        return inside(x, y, z) && walk.get(index(x, y, z));
    }

    int walkableCount() {
        return walk.cardinality();
    }

    /**
     * Diagonals may not cut a wall corner or change level. Up one block is a stair step or a jump
     * (the jump needs a third block of headroom over the take-off, like a player's). Down is a
     * drop of up to three blocks with the target column open for the body to fall through.
     */
    private boolean moveAllowed(BitSet cells, int fx, int fy, int fz, int tx, int ty, int tz) {
        int dx = tx - fx, dz = tz - fz, dy = ty - fy;
        if (dx != 0 && dz != 0) {
            if (dy != 0) {
                return false;
            }
            return inside(fx + dx, fy, fz) && cells.get(index(fx + dx, fy, fz))
                    && inside(fx, fy, fz + dz) && cells.get(index(fx, fy, fz + dz));
        }
        if (dy > 0) {
            return stairs.get(index(tx, ty, tz)) || headroom.get(index(fx, fy, fz));
        }
        for (int y = ty + 2; y <= fy + 1; y++) {
            if (!passable(house.at(new RatSeekHouse.Pos(tx, y, tz)))) {
                return false;
            }
        }
        return true;
    }

    /** True if stepping onto this cell is a stair step rather than a jump. */
    boolean onStairs(int x, int y, int z) {
        return inside(x, y, z) && stairs.get(index(x, y, z));
    }

    /** The walkable cell nearest to a point, searching up to {@code radius} blocks; null if none. */
    int[] nearest(double x, double y, double z, int radius) {
        int bx = (int) Math.floor(x), by = (int) Math.floor(y + 0.01), bz = (int) Math.floor(z);
        int[] best = null;
        double bestScore = Double.MAX_VALUE;
        for (int dy : new int[]{0, 1, -1, 2, -2, -3, -4}) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    int cx = bx + dx, cy = by + dy, cz = bz + dz;
                    if (!walkable(cx, cy, cz)) {
                        continue;
                    }
                    double ddx = cx + 0.5 - x, ddz = cz + 0.5 - z;
                    double score = ddx * ddx + ddz * ddz + dy * dy * 3.0;
                    if (score < bestScore) {
                        bestScore = score;
                        best = new int[]{cx, cy, cz};
                    }
                }
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ paths

    /**
     * A* from one cell to another. Returns smoothed waypoints (block-centre x, feet y, z),
     * the first being the start, or null if the goal can't be reached within the search budget.
     */
    List<double[]> path(int[] from, int[] to) {
        if (from == null || to == null || !walkable(from[0], from[1], from[2]) || !walkable(to[0], to[1], to[2])) {
            return null;
        }
        int start = index(from[0], from[1], from[2]);
        int goal = index(to[0], to[1], to[2]);
        if (++generation == Integer.MAX_VALUE) {
            java.util.Arrays.fill(stamp, 0);
            generation = 1;
        }
        closed.clear();
        heapSize = 0;
        stamp[start] = generation;
        cost[start] = 0;
        parent[start] = -1;
        push(start, (float) heuristic(start, goal));
        int expansions = 0;
        boolean found = false;
        while (heapSize > 0 && expansions < MAX_EXPANSIONS) {
            int current = pop();
            if (closed.get(current)) {
                continue;
            }
            if (current == goal) {
                found = true;
                break;
            }
            closed.set(current);
            expansions++;
            int cx = xOf(current), cy = yOf(current), cz = zOf(current);
            for (int[] step : STEPS) {
                for (int dy = -MAX_DROP; dy <= 1; dy++) {
                    int nx = cx + step[0], ny = cy + dy, nz = cz + step[1];
                    if (!walkable(nx, ny, nz)) {
                        continue;
                    }
                    int next = index(nx, ny, nz);
                    if (closed.get(next) || !moveAllowed(walk, cx, cy, cz, nx, ny, nz)) {
                        continue;
                    }
                    // Jumps and big drops cost a little extra, so seekers use the stairs when they can.
                    float stepCost = (step[0] != 0 && step[1] != 0 ? 1.414f : 1f)
                            + (dy == 0 ? 0f : dy > 0 && !stairs.get(next) ? 1.2f : 0.4f * Math.abs(dy))
                            + (wallside.get(next) ? 0.35f : 0f);
                    float total = cost[current] + stepCost;
                    if (stamp[next] == generation && total >= cost[next]) {
                        continue;
                    }
                    stamp[next] = generation;
                    cost[next] = total;
                    parent[next] = current;
                    push(next, (float) (total + heuristic(next, goal)));
                }
            }
        }
        if (!found) {
            return null;
        }
        List<int[]> cells = new ArrayList<>();
        for (int at = goal; at != -1; at = parent[at]) {
            cells.add(new int[]{xOf(at), yOf(at), zOf(at)});
        }
        java.util.Collections.reverse(cells);
        return smooth(cells);
    }

    /** Path length in blocks, or a large number when unreachable. */
    static double length(List<double[]> path) {
        if (path == null) {
            return 1e6;
        }
        double total = 0;
        for (int i = 1; i < path.size(); i++) {
            double[] a = path.get(i - 1), b = path.get(i);
            total += Math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[2] - b[2]) * (a[2] - b[2])) + Math.abs(a[1] - b[1]);
        }
        return total;
    }

    private void push(int node, float key) {
        if (heapSize == heapNode.length) {
            heapNode = java.util.Arrays.copyOf(heapNode, heapSize * 2);
            heapKey = java.util.Arrays.copyOf(heapKey, heapSize * 2);
        }
        int at = heapSize++;
        while (at > 0) {
            int up = (at - 1) >> 1;
            if (heapKey[up] <= key) {
                break;
            }
            heapNode[at] = heapNode[up];
            heapKey[at] = heapKey[up];
            at = up;
        }
        heapNode[at] = node;
        heapKey[at] = key;
    }

    private int pop() {
        int top = heapNode[0];
        int lastNode = heapNode[--heapSize];
        float lastKey = heapKey[heapSize];
        int at = 0;
        while (true) {
            int child = at * 2 + 1;
            if (child >= heapSize) {
                break;
            }
            if (child + 1 < heapSize && heapKey[child + 1] < heapKey[child]) {
                child++;
            }
            if (heapKey[child] >= lastKey) {
                break;
            }
            heapNode[at] = heapNode[child];
            heapKey[at] = heapKey[child];
            at = child;
        }
        heapNode[at] = lastNode;
        heapKey[at] = lastKey;
        return top;
    }

    private static double heuristic(int from, int to) {
        double dx = xOf(from) - xOf(to), dz = zOf(from) - zOf(to), dy = yOf(from) - yOf(to);
        return Math.sqrt(dx * dx + dz * dz) + Math.abs(dy) * 1.2;
    }

    /** Pulls the grid path taut wherever a straight, level walk fits a seeker's width. */
    private List<double[]> smooth(List<int[]> cells) {
        List<double[]> points = new ArrayList<>();
        int anchor = 0;
        points.add(centre(cells.get(0)));
        while (anchor < cells.size() - 1) {
            int furthest = anchor + 1;
            for (int probe = anchor + 2; probe < cells.size(); probe++) {
                if (cells.get(probe)[1] != cells.get(anchor)[1] || !straightWalk(cells.get(anchor), cells.get(probe))) {
                    break;
                }
                furthest = probe;
            }
            points.add(centre(cells.get(furthest)));
            anchor = furthest;
        }
        return points;
    }

    /** Samples the centre line and both shoulders (0.3 blocks out) against walkable cells. */
    boolean straightWalk(int[] a, int[] b) {
        double ax = a[0] + 0.5, az = a[2] + 0.5, bx = b[0] + 0.5, bz = b[2] + 0.5;
        double dx = bx - ax, dz = bz - az;
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 0.01) {
            return true;
        }
        double px = -dz / length * 0.3, pz = dx / length * 0.3;
        for (double t = 0; t <= length; t += 0.25) {
            double sx = ax + dx * t / length, sz = az + dz * t / length;
            for (int side = -1; side <= 1; side++) {
                if (!walkable((int) Math.floor(sx + px * side), a[1], (int) Math.floor(sz + pz * side))) {
                    return false;
                }
            }
        }
        return true;
    }

    private static double[] centre(int[] cell) {
        return new double[]{cell[0] + 0.5, cell[1], cell[2] + 0.5};
    }

    // ------------------------------------------------------------------ perches

    /**
     * True if a rat standing in this cell is somewhere no seeker could ever tag it: on the roof,
     * or on a perch that no reachable standing cell covers with a hit or a crouched swat.
     */
    boolean unfairPerch(int x, int y, int z) {
        if (y > MAX_Y) {
            return x >= MIN_X && x <= MAX_X && z >= MIN_Z && z <= MAX_Z;
        }
        return inside(x, y, z) && unfairPerch.get(index(x, y, z));
    }

    /** The seeker-reachable cell a rat slipping off a perch lands on: close, and at or below it. */
    int[] landing(int x, int y, int z) {
        for (int down = 0; down <= 12; down++) {
            int[] best = null;
            double bestScore = Double.MAX_VALUE;
            for (int dx = -4; dx <= 4; dx++) {
                for (int dz = -4; dz <= 4; dz++) {
                    int cx = x + dx, cy = Math.min(y, MAX_Y) - down, cz = z + dz;
                    double score = dx * dx + dz * dz;
                    if (score < bestScore && walkable(cx, cy, cz)) {
                        bestScore = score;
                        best = new int[]{cx, cy, cz};
                    }
                }
            }
            if (best != null) {
                return best;
            }
        }
        return null;
    }

    private void markUnfairPerches() {
        for (int y = MIN_Y + 1; y <= MAX_Y; y++) {
            for (int z = MIN_Z; z <= MAX_Z; z++) {
                for (int x = MIN_X; x <= MAX_X; x++) {
                    int i = index(x, y, z);
                    if (walk.get(i) || !ratFits(x, y, z) || inPassage(x, y, z)) {
                        continue;
                    }
                    if (!tagable(x, y, z)) {
                        unfairPerch.set(i);
                    }
                }
            }
        }
    }

    /** A rat (under a block tall) can stand here. Wall and bar tops are too narrow to count. */
    private boolean ratFits(int x, int y, int z) {
        Material below = house.at(new RatSeekHouse.Pos(x, y - 1, z));
        return passable(house.at(new RatSeekHouse.Pos(x, y, z))) && !passable(below)
                && below != Material.IRON_BARS && below != Material.STONE_BRICK_WALL;
    }

    private boolean inPassage(int x, int y, int z) {
        for (RatSeekHouse.Passage passage : house.passages) {
            if (y == passage.y() && z >= passage.z1() && z <= passage.z2()
                    && (x == passage.x() || x == passage.x() - Integer.signum(passage.x()))) {
                return true;
            }
        }
        return false;
    }

    /** Every spot a rat could press into within the cell must be taggable from somewhere. */
    private boolean tagable(int x, int y, int z) {
        double[] offsets = {0.5, 0.15, 0.85};
        for (double ox : offsets) {
            for (double oz : offsets) {
                if (!tagableAt(x + ox, y, z + oz)) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean tagableAt(double rx, double ry, double rz) {
        int bx = (int) Math.floor(rx), by = (int) Math.floor(ry), bz = (int) Math.floor(rz);
        for (int hy = by - 4; hy <= by + 3; hy++) {
            for (int hx = bx - 4; hx <= bx + 4; hx++) {
                for (int hz = bz - 4; hz <= bz + 4; hz++) {
                    if (!walkable(hx, hy, hz)) {
                        continue;
                    }
                    // A seeker can stand anywhere in its cell, 0.3 blocks in from the edges.
                    double ex = Math.max(hx + 0.3, Math.min(hx + 0.7, rx));
                    double ez = Math.max(hz + 0.3, Math.min(hz + 0.7, rz));
                    if (hits(ex, hy + 1.62, ez, rx, ry, rz) || hits(ex, hy + 1.27, ez, rx, ry, rz)) {
                        return true;
                    }
                    if (Math.abs(hy - ry) <= 1.2 && Math.hypot(ex - rx, ez - rz) < 2.7
                            && clearLine(ex, hy + 0.38, ez, rx, ry + 0.3, rz)) {
                        return true; // Crouched swat into a low gap.
                    }
                }
            }
        }
        return false;
    }

    private boolean hits(double ex, double ey, double ez, double rx, double ry, double rz) {
        for (double py : new double[]{ry + 0.1, ry + 0.45, ry + 0.8}) {
            for (double[] o : new double[][]{{0, 0}, {-0.14, 0}, {0.14, 0}, {0, -0.14}, {0, 0.14}}) {
                double px = rx + o[0], pz = rz + o[1];
                double dx = px - ex, dy = py - ey, dz = pz - ez;
                if (dx * dx + dy * dy + dz * dz <= TAG_REACH * TAG_REACH && clearLine(ex, ey, ez, px, py, pz)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean clearLine(double ax, double ay, double az, double bx, double by, double bz) {
        double length = Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay) + (bz - az) * (bz - az));
        int steps = Math.max(1, (int) (length / 0.05));
        for (int s = 1; s < steps; s++) {
            double t = (double) s / steps;
            Material m = house.at(new RatSeekHouse.Pos((int) Math.floor(ax + (bx - ax) * t),
                    (int) Math.floor(ay + (by - ay) * t), (int) Math.floor(az + (bz - az) * t)));
            if (!passable(m) && m != Material.IRON_BARS && m != Material.LANTERN && m != Material.FLOWER_POT) {
                return false;
            }
        }
        return true;
    }

    int unfairPerchCount() {
        return unfairPerch.cardinality();
    }

    // ------------------------------------------------------------------ rooms

    /** The blueprint room containing a block, or null (walls, stairs between rooms, outside). */
    String roomOf(int x, int y, int z) {
        for (RatSeekHouse.Room room : house.rooms) {
            if (x >= room.x1() && x <= room.x2() && y >= room.y1() && y <= room.y2()
                    && z >= room.z1() && z <= room.z2()) {
                return room.name();
            }
        }
        return null;
    }

    List<SearchRoom> searchRooms() {
        return searchRooms;
    }

    SearchRoom searchRoom(String name) {
        for (SearchRoom room : searchRooms) {
            if (room.name().equals(name)) {
                return room;
            }
        }
        return null;
    }

    private void buildSearchRooms() {
        for (RatSeekHouse.Room room : house.rooms) {
            if (room.name().equals("rescue courtyard")) {
                continue;
            }
            int cx = (room.x1() + room.x2()) / 2, cz = (room.z1() + room.z2()) / 2;
            int[] centre = nearest(cx + 0.5, room.y1(), cz + 0.5, 6);
            if (centre == null || !room.name().equals(roomOf(centre[0], centre[1], centre[2]))) {
                continue;
            }
            List<Spot> spots = new ArrayList<>();
            for (RatSeekHouse.Hide hide : house.hides) {
                RatSeekHouse.Pos p = hide.position();
                int[] from = nearest(p.x() + 0.5, p.y(), p.z() + 0.5, 3);
                if (from == null || !room.name().equals(roomOf(from[0], from[1], from[2]))) {
                    continue;
                }
                spots.add(new Spot(hide.name(), new int[]{p.x(), p.y(), p.z()}, from, true));
            }
            for (RatSeekHouse.Pos p : house.cheese) {
                int[] from = nearest(p.x() + 0.5, p.y(), p.z() + 0.5, 2);
                if (from != null && room.name().equals(roomOf(from[0], from[1], from[2]))) {
                    spots.add(new Spot("cheese spot", new int[]{p.x(), p.y(), p.z()}, from, false));
                }
            }
            searchRooms.add(new SearchRoom(room.name(), centre, spots));
        }
    }

    /** Cells in front of every mousehole and doorway — where rats must pass and traps pay off. */
    List<int[]> chokepoints() {
        List<int[]> result = new ArrayList<>();
        for (RatSeekHouse.Hide hide : house.hides) {
            if (hide.name().equals("mousehole")) {
                RatSeekHouse.Pos p = hide.position();
                // The trap goes in the hole itself: a rat running through it can't avoid the plate.
                if (floor(house.at(p.offset(0, -1, 0))) && passable(house.at(p))
                        && nearest(p.x() + 0.5, p.y(), p.z() + 0.5, 2) != null) {
                    result.add(new int[]{p.x(), p.y(), p.z()});
                }
            }
        }
        return result;
    }
}
