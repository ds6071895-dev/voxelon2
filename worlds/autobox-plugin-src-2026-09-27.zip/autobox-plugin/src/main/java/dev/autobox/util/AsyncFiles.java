package dev.autobox.util;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/** Keeps disk writes off the main thread; a stall on disk must never become a stall in the game. */
public final class AsyncFiles {

    private static final Object LOCK = new Object();
    private static final Map<String, Long> LATEST = new ConcurrentHashMap<>();
    private static long sequence;

    private AsyncFiles() {
    }

    /**
     * Snapshots {@code yaml} now (on the caller's thread) and writes it off the main thread through a
     * temp file and rename, so a crash can't truncate it. An older snapshot never overwrites a newer
     * one. While the plugin is disabling the write happens immediately instead.
     */
    public static void writeYaml(Plugin plugin, YamlConfiguration yaml, File file) {
        String text = yaml.saveToString();
        String key = file.getAbsolutePath();
        long ticket;
        synchronized (LOCK) {
            ticket = ++sequence;
            LATEST.put(key, ticket);
        }
        Runnable write = () -> {
            synchronized (LOCK) {
                if (LATEST.getOrDefault(key, 0L) != ticket) {
                    return;
                }
                try {
                    File parent = file.getAbsoluteFile().getParentFile();
                    Files.createDirectories(parent.toPath());
                    File temp = new File(parent, file.getName() + ".tmp");
                    Files.writeString(temp.toPath(), text, StandardCharsets.UTF_8);
                    Files.move(temp.toPath(), file.toPath(),
                            StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (IOException failure) {
                    plugin.getLogger().log(Level.WARNING, "Could not save " + file.getName(), failure);
                }
            }
        };
        if (plugin.isEnabled()) {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, write);
        } else {
            write.run();
        }
    }
}
