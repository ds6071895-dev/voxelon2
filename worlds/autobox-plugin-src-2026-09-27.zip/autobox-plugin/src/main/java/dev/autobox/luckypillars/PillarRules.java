package dev.autobox.luckypillars;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

/** Timings, pillar layouts, twists and schedules, shared with the headless gameplay checks. */
public final class PillarRules {
    /** Pillar tops sit here; players stand one block above. */
    public static final int TOP_Y = 100;
    public static final int PILLAR_DEPTH = 28;
    public static final int BOTTOM_Y = TOP_Y - PILLAR_DEPTH;
    /** The golden crown in the middle stands this far above the pillar tops. */
    public static final int CROWN_RISE = 3;
    public static final int MAX_BUILD_Y = TOP_Y + 24;
    /** Everything the game can touch lies inside this box; the reset sweep clears it. */
    public static final int SWEEP_RADIUS = 56;
    public static final int SWEEP_MIN_Y = BOTTOM_Y - 20;
    public static final int SWEEP_MAX_Y = MAX_BUILD_Y + 6;

    public static final int COUNTDOWN_TICKS = 6 * 20;
    public static final int MAIN_TICKS = 5 * 60 * 20;
    public static final int DEATHMATCH_TICKS = 2 * 60 * 20;
    public static final int OVER_TICKS = 8 * 20;
    public static final int LOOT_INTERVAL = 3 * 20;
    public static final int FRENZY_INTERVAL = 30;
    public static final int DEATHMATCH_INTERVAL = 2 * 20;
    public static final int KILL_CREDIT_TICKS = 15 * 20;
    public static final int BORDER_MARGIN = 9;
    public static final int DEATHMATCH_PLATFORM_RADIUS = 3;
    /** Deathmatch border: shrink to MID_BORDER over the first stretch, then to FINAL_BORDER by the end. */
    public static final int MID_BORDER = 12;
    public static final int FINAL_BORDER = 3;
    public static final int MID_BORDER_SECONDS = 80;
    public static final int RECENT_TWIST_MEMORY = 4;
    public static final double LUCKY_STREAK_BOOST = 4.0;

    public enum Layout {
        RING("Ring"),
        STAGGERED("Staggered"),
        SPIRAL("Spiral Stairs"),
        STAR("Star");

        public final String label;

        Layout(String label) {
            this.label = label;
        }
    }

    public enum Twist {
        SLIME_FLOOR("Bouncy Floor", "A slime floor catches you. Falling is safe; fighting isn't.", Material.SLIME_BLOCK),
        RISING_LAVA("Rising Lava", "Lava climbs toward the pillar tops. Build up or burn.", Material.LAVA_BUCKET),
        MOON_GRAVITY("Moon Gravity", "Low gravity and soft landings.", Material.END_STONE),
        SUGAR_RUSH("Sugar Rush", "Everyone has Speed II and Haste II.", Material.SUGAR),
        TNT_RAIN("TNT Rain", "Lit TNT keeps dropping out of the sky.", Material.TNT),
        METEOR_SHOWER("Meteor Shower", "Fireballs rain down on the arena.", Material.FIRE_CHARGE),
        THUNDERSTORM("Thunderstorm", "Lightning strikes near random players.", Material.LIGHTNING_ROD),
        GIANTS("Giants", "Everyone is huge, has 5 extra hearts and longer reach.", Material.IRON_BLOCK),
        TINY_TOWN("Tiny Town", "Everyone is tiny and hard to hit.", Material.RABBIT_FOOT),
        LOOT_FRENZY("Loot Frenzy", "Items every 1.5 seconds instead of 3.", Material.CHEST),
        LUCKY_STREAK("Lucky Streak", "Rare, epic and legendary loot is far more common.", Material.GOLD_INGOT),
        MIRROR_LOOT("Mirror Loot", "Everyone gets the exact same item at the same time.", Material.GLASS),
        SHUFFLE("Shuffle", "Every 40 seconds everyone swaps places.", Material.ENDER_PEARL),
        VAMPIRES("Vampires", "No natural healing. Melee hits heal you; kills heal a lot.", Material.REDSTONE),
        BOUNCY_CASTLE("Bouncy Castle", "Huge knockback and no fall damage.", Material.SLIME_BALL),
        SKY_GLIDERS("Sky Gliders", "Everyone starts with an elytra and rockets.", Material.ELYTRA),
        GLASS_CANNON("Glass Cannon", "Everyone has only 5 hearts.", Material.GLASS_PANE);

        public final String label;
        public final String description;
        public final Material icon;

        Twist(String label, String description, Material icon) {
            this.label = label;
            this.description = description;
            this.icon = icon;
        }
    }

    /** One pillar: block column x/z and the y of its top block. */
    public record Pillar(int x, int z, int topY) {
    }

    private PillarRules() {
    }

    /** Pillars sit about twenty blocks apart along the ring: 2 players → radius 15, 6 → 19, 10 → 32. */
    public static int ringRadius(int players) {
        return Math.max(15, (int) Math.round(20.0 * players / (2 * Math.PI)));
    }

    /** Star layouts push every other pillar this much further out. */
    public static int outerRadius(Layout layout, int players) {
        return ringRadius(players) + (layout == Layout.STAR && players >= 4 ? 5 : 0);
    }

    public static int borderSize(Layout layout, int players) {
        return 2 * (outerRadius(layout, players) + BORDER_MARGIN);
    }

    public static List<Pillar> pillars(Layout layout, int players, double angleOffset) {
        List<Pillar> pillars = new ArrayList<>();
        int radius = ringRadius(players);
        for (int i = 0; i < players; i++) {
            double angle = angleOffset + Math.PI * 2 * i / players;
            int r = layout == Layout.STAR && players >= 4 && i % 2 == 1 ? radius + 5 : radius;
            int top = switch (layout) {
                case STAGGERED -> TOP_Y - (i % 2 == 1 ? 4 : 0);
                case SPIRAL -> TOP_Y - (int) Math.round(6.0 * i / Math.max(1, players - 1));
                default -> TOP_Y;
            };
            pillars.add(new Pillar((int) Math.round(Math.cos(angle) * r), (int) Math.round(Math.sin(angle) * r), top));
        }
        return pillars;
    }

    /** Any twist except the last few played, so back-to-back games feel different. */
    public static Twist pickTwist(Random random, Collection<Twist> recent) {
        List<Twist> options = new ArrayList<>();
        for (Twist twist : Twist.values()) {
            if (!recent.contains(twist)) {
                options.add(twist);
            }
        }
        if (options.isEmpty()) {
            options.addAll(List.of(Twist.values()));
        }
        return options.get(random.nextInt(options.size()));
    }

    public static Layout pickLayout(Random random, int players, Layout last) {
        List<Layout> options = new ArrayList<>();
        for (Layout layout : Layout.values()) {
            // A star needs at least four pillars; with fewer it is just a ring.
            if (layout != last && (layout != Layout.STAR || players >= 4)) {
                options.add(layout);
            }
        }
        return options.get(random.nextInt(options.size()));
    }

    /** Ticks between items for one player. Standing on the crown halves it. */
    public static int lootInterval(Twist twist, boolean deathmatch, boolean onCrown) {
        int interval = twist == Twist.LOOT_FRENZY ? FRENZY_INTERVAL : LOOT_INTERVAL;
        if (deathmatch) {
            interval = Math.min(interval, DEATHMATCH_INTERVAL);
        }
        return onCrown ? Math.max(15, interval / 2) : interval;
    }

    /** Rarer loot shows up more as the match goes on: 1.0 at the start, 1.8 by the deathmatch. */
    public static double lootBoost(Twist twist, int mainElapsed, boolean deathmatch) {
        double heat = deathmatch ? 1.8 : 1.0 + 0.8 * Math.min(1.0, Math.max(0, mainElapsed) / (double) MAIN_TICKS);
        return twist == Twist.LUCKY_STREAK ? heat * LUCKY_STREAK_BOOST : heat;
    }

    /** Rising Lava: from the pillar bottoms to two below the tops over the main phase, then to the tops. */
    public static int lavaLevel(int mainElapsed, int deathmatchElapsed) {
        int climb = TOP_Y - 2 - BOTTOM_Y;
        int level = BOTTOM_Y + (int) ((long) climb * Math.min(Math.max(0, mainElapsed), MAIN_TICKS) / MAIN_TICKS);
        if (deathmatchElapsed > 0) {
            level = Math.min(TOP_Y, TOP_Y - 2 + deathmatchElapsed / (30 * 20));
        }
        return level;
    }

    /** Players below this y are out. With the slime floor you can only get there by leaving the floor. */
    public static int voidY(Twist twist) {
        return twist == Twist.SLIME_FLOOR ? BOTTOM_Y - 12 : BOTTOM_Y - 6;
    }

    public static int tntRainInterval(int alive) {
        return Math.max(40, 200 / Math.max(1, alive));
    }

    public static final int METEOR_INTERVAL = 3 * 20;
    public static final int LIGHTNING_INTERVAL = 7 * 20;
    public static final int SHUFFLE_INTERVAL = 40 * 20;
    public static final int SHUFFLE_WARNING = 3 * 20;
    public static final double VAMPIRE_LIFESTEAL = 0.4;
    public static final double VAMPIRE_KILL_HEAL = 12.0;
    public static final double KILL_HEAL = 4.0;

    /** A rotation that moves every player: nobody lands back on their own spot. */
    public static int shuffleShift(Random random, int alive) {
        return alive < 2 ? 0 : 1 + random.nextInt(alive - 1);
    }
}
