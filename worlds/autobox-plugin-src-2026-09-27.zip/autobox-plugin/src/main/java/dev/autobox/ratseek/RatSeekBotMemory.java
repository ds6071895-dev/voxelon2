package dev.autobox.ratseek;

import dev.autobox.util.AsyncFiles;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.util.Locale;
import java.util.UUID;

/**
 * What the AI seekers have learned across matches, kept in {@code ratseek-ai.yml}. It only ever
 * records things a human seeker could have noticed too: where rats were caught or spotted, which
 * tunnel end they came out of, which traps and bait worked, and the tricks that fooled a bot.
 * Every count fades a little after each match, so the bots keep up with the current meta.
 */
final class RatSeekBotMemory {
    private static final double FADE = 0.93;

    private final Plugin plugin;
    private final File file;
    private YamlConfiguration data;

    RatSeekBotMemory(Plugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "ratseek-ai.yml");
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    private static String key(String text) {
        return text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_");
    }

    private static String cell(int x, int y, int z) {
        return x + "_" + y + "_" + z;
    }

    private double get(String path) {
        return data.getDouble(path, 0);
    }

    private void add(String path, double amount) {
        data.set(path, Math.round((get(path) + amount) * 1000) / 1000.0);
    }

    // ------------------------------------------------------------------ where rats hide

    /** A rat was caught or clearly seen here. */
    void found(UUID rat, String name, String room, int[] hide) {
        if (room != null) {
            add("rooms." + key(room), 1);
            add("players." + rat + ".rooms." + key(room), 1);
        }
        if (hide != null) {
            add("hides." + cell(hide[0], hide[1], hide[2]), 1);
        }
        data.set("players." + rat + ".name", name);
    }

    double roomWeight(String room) {
        return get("rooms." + key(room));
    }

    double hideWeight(int[] hide) {
        return get("hides." + cell(hide[0], hide[1], hide[2]));
    }

    /** How strongly this particular player favours a room, from 0 to about 1. */
    double playerRoom(UUID rat, String room) {
        ConfigurationSection rooms = data.getConfigurationSection("players." + rat + ".rooms");
        if (rooms == null) {
            return 0;
        }
        double total = 0;
        for (String each : rooms.getKeys(false)) {
            total += rooms.getDouble(each);
        }
        return total <= 0 ? 0 : rooms.getDouble(key(room)) / total;
    }

    String favouriteRoom(UUID rat) {
        ConfigurationSection rooms = data.getConfigurationSection("players." + rat + ".rooms");
        if (rooms == null) {
            return null;
        }
        String best = null;
        double bestCount = 1.5;
        for (String each : rooms.getKeys(false)) {
            if (rooms.getDouble(each) > bestCount) {
                bestCount = rooms.getDouble(each);
                best = each.replace('_', ' ');
            }
        }
        return best;
    }

    /** A bot lost sight of a rat by this hide: check it sooner next time. */
    void escapedAt(int[] hide) {
        add("hides." + cell(hide[0], hide[1], hide[2]), 0.6);
    }

    // ------------------------------------------------------------------ tunnels

    void tunnelExit(UUID rat, String passage, boolean exitA) {
        add("tunnels." + key(passage) + (exitA ? ".a" : ".b"), 1);
        add("players." + rat + ".tunnels", 1);
    }

    /** Chance (0-1) that a rat in this passage leaves by exit A, from what was seen before. */
    double exitAChance(String passage) {
        double a = get("tunnels." + key(passage) + ".a"), b = get("tunnels." + key(passage) + ".b");
        return (a + 1) / (a + b + 2);
    }

    double tunnelHabit(UUID rat) {
        return get("players." + rat + ".tunnels");
    }

    // ------------------------------------------------------------------ gadgets

    void sitePlaced(String kind, int[] at) {
        add("sites." + kind + "." + cell(at[0], at[1], at[2]) + ".placed", 1);
        add("sites." + kind + ".placed", 1);
    }

    void siteWorked(String kind, int x, int y, int z) {
        add("sites." + kind + "." + cell(x, y, z) + ".worked", 1);
    }

    /** Upper-confidence score: sites that worked rise, untried sites still get explored. */
    double siteScore(String kind, int[] at) {
        String base = "sites." + kind + "." + cell(at[0], at[1], at[2]);
        double placed = get(base + ".placed"), worked = get(base + ".worked");
        double total = get("sites." + kind + ".placed");
        return (worked + 0.5) / (placed + 1.5) + 0.35 * Math.sqrt(Math.log(total + 2) / (placed + 1));
    }

    void baitBitten(UUID rat) {
        add("players." + rat + ".bait", 1);
    }

    // ------------------------------------------------------------------ lessons about tricks

    void fooledByDecoy() {
        add("lessons.decoys", 1);
    }

    /** 0 for a fresh bot, approaching 1 after being fooled many times. */
    double decoyWisdom() {
        double fooled = get("lessons.decoys");
        return fooled / (fooled + 3);
    }

    void hitByChandelier() {
        add("lessons.chandeliers", 1);
    }

    double chandelierWisdom() {
        double hits = get("lessons.chandeliers");
        return hits / (hits + 2);
    }

    int matches() {
        return data.getInt("matches");
    }

    // ------------------------------------------------------------------ lifecycle

    /** Ends a match: older lessons fade a little, then the file is written off the main thread. */
    void finishMatch() {
        fade(data, "rooms");
        fade(data, "hides");
        fade(data, "tunnels");
        fade(data, "sites");
        ConfigurationSection players = data.getConfigurationSection("players");
        if (players != null) {
            for (String id : players.getKeys(false)) {
                fade(data, "players." + id + ".rooms");
            }
        }
        data.set("matches", matches() + 1);
        AsyncFiles.writeYaml(plugin, data, file);
    }

    private static void fade(YamlConfiguration data, String path) {
        ConfigurationSection section = data.getConfigurationSection(path);
        if (section == null) {
            return;
        }
        for (String leaf : section.getKeys(true)) {
            if (section.isDouble(leaf) || section.isInt(leaf)) {
                double faded = Math.round(section.getDouble(leaf) * FADE * 1000) / 1000.0;
                section.set(leaf, faded < 0.05 ? null : faded);
            }
        }
    }

    void forget() {
        data = new YamlConfiguration();
        AsyncFiles.writeYaml(plugin, data, file);
    }
}
