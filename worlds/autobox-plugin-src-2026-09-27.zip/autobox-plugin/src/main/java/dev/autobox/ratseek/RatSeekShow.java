package dev.autobox.ratseek;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Firework;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** Presentation layer: boss bar, intro camera, note-block stings and the results podium. */
final class RatSeekShow {
    static final int INTRO_TICKS = 90;
    private static final String SHOW_TAG = "ratseek_show";

    /** Short note-block phrases. Each step is (pitch, instrument), played every {@code step} ticks. */
    enum Sting {
        INTRO(4, new float[]{0.5f, 0.53f, 0.5f, 0.47f, 0.5f}, Sound.BLOCK_NOTE_BLOCK_BASS),
        HUNT(3, new float[]{0.5f, 0.5f, 0.6f, 0.5f, 0.75f, 0.7f}, Sound.BLOCK_NOTE_BLOCK_DIDGERIDOO),
        CATCH(2, new float[]{1.2f, 1.0f, 0.8f, 0.6f}, Sound.BLOCK_NOTE_BLOCK_PLING),
        RESCUE(2, new float[]{0.8f, 1.0f, 1.2f, 1.6f}, Sound.BLOCK_NOTE_BLOCK_CHIME),
        LAST_RAT(3, new float[]{0.6f, 0.9f, 0.6f, 0.9f, 1.2f}, Sound.BLOCK_NOTE_BLOCK_BIT),
        FINAL_MINUTE(5, new float[]{1.0f, 0.5f, 1.0f, 0.5f, 1.0f, 0.5f}, Sound.BLOCK_NOTE_BLOCK_HAT),
        VICTORY(3, new float[]{0.8f, 1.0f, 1.2f, 1.0f, 1.2f, 1.6f}, Sound.BLOCK_NOTE_BLOCK_BELL),
        DEFEAT(4, new float[]{0.9f, 0.8f, 0.7f, 0.53f}, Sound.BLOCK_NOTE_BLOCK_GUITAR);

        final int step;
        final float[] pitches;
        final Sound instrument;

        Sting(int step, float[] pitches, Sound instrument) {
            this.step = step;
            this.pitches = pitches;
            this.instrument = instrument;
        }
    }

    record Award(String title, String winner, String detail, NamedTextColor color) { }

    private final Plugin plugin;
    private final World world;
    private final NamespacedKey tagKey;
    private final BossBar bar = BossBar.bossBar(Component.text("Rat and Seek"), 1f, BossBar.Color.GREEN,
            BossBar.Overlay.NOTCHED_10);
    private final List<Entity> props = new ArrayList<>();
    private final List<BukkitTask> tasks = new ArrayList<>();
    private final java.util.Set<Player> barViewers = new java.util.HashSet<>();
    private ItemDisplay camera;

    RatSeekShow(Plugin plugin, World world, NamespacedKey tagKey) {
        this.plugin = plugin;
        this.world = world;
        this.tagKey = tagKey;
    }

    // ------------------------------------------------------------------ boss bar

    void updateBar(Collection<Player> viewers, Component title, float progress, BossBar.Color color) {
        bar.name(title);
        bar.progress(Math.max(0f, Math.min(1f, progress)));
        bar.color(color);
        // Spectators come and go through the lobby NPC; drop the bar for anyone who left.
        for (Player previous : new ArrayList<>(barViewers)) {
            if (!viewers.contains(previous)) {
                previous.hideBossBar(bar);
                barViewers.remove(previous);
            }
        }
        for (Player viewer : viewers) {
            if (barViewers.add(viewer)) {
                viewer.showBossBar(bar);
            }
        }
    }

    void hideBar(Player player) {
        player.hideBossBar(bar);
        barViewers.remove(player);
    }

    // ------------------------------------------------------------------ intro

    /** Puts everyone in spectator mode, riding a camera that sweeps around the manor. */
    void beginIntro(Collection<Player> viewers, String matchup) {
        removeCamera();
        Location start = cameraAt(0);
        camera = world.spawn(start, ItemDisplay.class, display -> {
            display.setItemStack(new ItemStack(Material.AIR));
            display.setTeleportDuration(5);
            display.setPersistent(false);
            tag(display);
        });
        for (Player viewer : viewers) {
            viewer.setGameMode(GameMode.SPECTATOR);
            viewer.teleport(start);
            viewer.sendTitle("§6§lTHE CROOKED MANOR", "§7Rat and Seek", 10, 50, 10);
        }
        play(Sting.INTRO, viewers);
        world.playSound(start, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 0.8f);
        later(45, () -> {
            for (Player viewer : viewers) {
                if (viewer.isOnline() && viewer.getWorld() == world) {
                    viewer.sendTitle("§c" + matchup, "§fRats hide. Humans hunt. Cheese is everything.", 5, 40, 5);
                }
            }
        });
    }

    /** Called every tick of the intro with the ticks elapsed. */
    void tickIntro(int elapsed, Collection<Player> viewers) {
        if (camera == null || !camera.isValid()) {
            return;
        }
        if (elapsed % 5 == 0) {
            camera.teleport(cameraAt(elapsed + 5));
        }
        for (Player viewer : viewers) {
            if (viewer.getGameMode() != GameMode.SPECTATOR || viewer.getWorld() != world) {
                continue;
            }
            // Clients need the camera entity before they can ride it; sneaking also drops out.
            if (elapsed >= 3 && viewer.getSpectatorTarget() == null) {
                if (elapsed % 10 == 3) {
                    viewer.setSpectatorTarget(camera);
                }
                if (viewer.getSpectatorTarget() == null && elapsed % 20 == 0) {
                    viewer.teleport(cameraAt(elapsed));
                }
            }
        }
    }

    void endIntro(Collection<Player> viewers) {
        for (Player viewer : viewers) {
            if (viewer.getGameMode() == GameMode.SPECTATOR) {
                viewer.setSpectatorTarget(null);
            }
        }
        removeCamera();
    }

    /** Orbits from the front garden round to the east side, looking at the manor's middle floor. */
    private Location cameraAt(int elapsed) {
        double t = Math.min(1.0, elapsed / (double) INTRO_TICKS);
        double angle = Math.toRadians(-30 + 110 * t);
        double radius = 46 - 10 * t;
        double x = Math.sin(angle) * radius;
        double z = Math.cos(angle) * radius;
        double y = 104 - 8 * t;
        Location at = new Location(world, x, y, z);
        Vector look = new Vector(0, 88, 0).subtract(at.toVector());
        return at.setDirection(look);
    }

    private void removeCamera() {
        if (camera != null) {
            camera.remove();
            camera = null;
        }
    }

    // ------------------------------------------------------------------ stings

    void play(Sting sting, Collection<Player> listeners) {
        List<Player> copy = List.copyOf(listeners);
        for (int i = 0; i < sting.pitches.length; i++) {
            float pitch = sting.pitches[i];
            later(i * sting.step, () -> {
                for (Player listener : copy) {
                    if (listener.isOnline() && listener.getWorld() == world) {
                        listener.playSound(listener.getLocation(), sting.instrument, 0.9f, pitch);
                    }
                }
            });
        }
    }

    // ------------------------------------------------------------------ podium

    /**
     * Stages the winners on the garden podium (first, second, third), gathers everyone
     * else in front of it, shows the award board and sets off fireworks.
     */
    void podium(List<Player> winners, Collection<Player> audience, String headline, NamedTextColor headlineColor,
                List<Award> awards) {
        Location[] steps = {
                blockCentre(RatSeekHouse.PODIUM_FIRST, 0),
                blockCentre(RatSeekHouse.PODIUM_SECOND, 0),
                blockCentre(RatSeekHouse.PODIUM_THIRD, 0)
        };
        for (Player viewer : audience) {
            // Leaving spectator mode also releases the intro camera, if a quit ended the match early.
            viewer.setGameMode(GameMode.ADVENTURE);
            int place = winners.indexOf(viewer);
            Location target;
            if (place >= 0 && place < steps.length) {
                target = steps[place].clone();
            } else {
                RatSeekHouse.Pos crowd = RatSeekHouse.PODIUM_CROWD;
                target = new Location(world, crowd.x() + 0.5 + (Math.random() - 0.5) * 4, crowd.y(),
                        crowd.z() + 0.2 + Math.random() * 0.6, 180, -15);
            }
            viewer.teleport(target);
            viewer.setVelocity(new Vector());
            viewer.setFallDistance(0);
        }
        RatSeekHouse.Pos first = RatSeekHouse.PODIUM_FIRST;
        Location board = new Location(world, first.x() + 0.5, first.y() + 3.2, first.z() - 1.2);
        List<Component> lines = new ArrayList<>();
        lines.add(Component.text(headline, headlineColor, TextDecoration.BOLD));
        for (Award award : awards) {
            lines.add(Component.newline());
            lines.add(Component.text(award.title() + ": ", award.color(), TextDecoration.BOLD)
                    .append(Component.text(award.winner(), NamedTextColor.WHITE))
                    .append(Component.text(award.detail().isEmpty() ? "" : " (" + award.detail() + ")",
                            NamedTextColor.GRAY)));
        }
        props.add(world.spawn(board, TextDisplay.class, display -> {
            display.text(Component.join(net.kyori.adventure.text.JoinConfiguration.noSeparators(), lines));
            display.setBillboard(Display.Billboard.VERTICAL);
            display.setBackgroundColor(Color.fromARGB(150, 20, 12, 6));
            display.setShadowed(true);
            display.setPersistent(false);
            display.setTransformation(new org.bukkit.util.Transformation(new org.joml.Vector3f(),
                    new org.joml.AxisAngle4f(), new org.joml.Vector3f(1.2f, 1.2f, 1.2f), new org.joml.AxisAngle4f()));
            tag(display);
        }));
        String[] labels = {"1st", "2nd", "3rd"};
        NamedTextColor[] colors = {NamedTextColor.GOLD, NamedTextColor.GRAY, NamedTextColor.RED};
        for (int i = 0; i < Math.min(winners.size(), steps.length); i++) {
            Location label = steps[i].clone().add(0, -0.6, 1.05);
            Component name = Component.text(labels[i] + " ", colors[i], TextDecoration.BOLD)
                    .append(Component.text(winners.get(i).getName(), NamedTextColor.WHITE));
            props.add(world.spawn(label, TextDisplay.class, display -> {
                display.text(name);
                display.setBillboard(Display.Billboard.CENTER);
                display.setPersistent(false);
                tag(display);
            }));
        }
        play(Sting.VICTORY, audience);
        for (int burst = 0; burst < 6; burst++) {
            int index = burst;
            later(10 + burst * 14, () -> firework(steps[index % steps.length].clone().add(
                    (Math.random() - 0.5) * 6, 1.5, (Math.random() - 0.5) * 3), index));
        }
    }

    private Location blockCentre(RatSeekHouse.Pos top, float yaw) {
        return new Location(world, top.x() + 0.5, top.y(), top.z() + 0.5, yaw, 0);
    }

    private void firework(Location at, int index) {
        Color[] palette = {Color.ORANGE, Color.YELLOW, Color.fromRGB(0xE8A0A8), Color.AQUA, Color.LIME, Color.WHITE};
        world.spawn(at, Firework.class, firework -> {
            FireworkMeta meta = firework.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder()
                    .with(index % 2 == 0 ? FireworkEffect.Type.BALL_LARGE : FireworkEffect.Type.STAR)
                    .withColor(palette[index % palette.length], palette[(index + 2) % palette.length])
                    .withFade(Color.WHITE).trail(true).flicker(index % 3 == 0).build());
            meta.setPower(0);
            firework.setFireworkMeta(meta);
            firework.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, SHOW_TAG);
            Bukkit.getScheduler().runTaskLater(plugin, firework::detonate, 12L);
        });
    }

    // ------------------------------------------------------------------ lifecycle

    void reset(Collection<? extends Player> players) {
        tasks.forEach(BukkitTask::cancel);
        tasks.clear();
        props.forEach(Entity::remove);
        props.clear();
        removeCamera();
        for (Player player : players) {
            player.hideBossBar(bar);
        }
        for (Player viewer : barViewers) {
            viewer.hideBossBar(bar);
        }
        barViewers.clear();
        purgeStrays();
    }

    /** Removes show entities left by a crash, which are not persisted but may survive in memory. */
    void purgeStrays() {
        for (Entity entity : world.getEntities()) {
            if (SHOW_TAG.equals(entity.getPersistentDataContainer().get(tagKey, PersistentDataType.STRING))) {
                entity.remove();
            }
        }
    }

    private void tag(Entity entity) {
        entity.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, SHOW_TAG);
    }

    private void later(long delay, Runnable action) {
        BukkitTask[] holder = new BukkitTask[1];
        holder[0] = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            tasks.remove(holder[0]);
            action.run();
        }, Math.max(1L, delay));
        tasks.add(holder[0]);
    }
}
