package dev.autobox.lobby;

import dev.autobox.util.AsyncFiles;
import dev.autobox.AutoBoxPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Everything there is to do in the lobby between matches: a timed parkour spiral with
 * checkpoints and a hall of fame, a snowball fight pit, an archery range, a fishing pond,
 * a disco floor with a playable note-block piano, a bounce-pad playground, a mystery
 * machine full of gadgets, plus hats, particle trails and a game-picker menu.
 */
public final class LobbyAttractions implements Listener {

    public static final Component TRAILS_TITLE = Component.text("Particle Trails", NamedTextColor.LIGHT_PURPLE);
    public static final Component HATS_TITLE = Component.text("Hat Rack", NamedTextColor.GOLD);
    public static final Component GAMES_TITLE = Component.text("Play a Game", NamedTextColor.AQUA);

    /** Top of the floor blocks; players walk at FLOOR_Y + 1. */
    private static final int FLOOR_Y = 101;
    private static final int WALK_Y = FLOOR_Y + 1;
    private static final int HUB_R = 6;

    private static final int PK_X = -24, PK_Z = -24, PK_R = 8;
    private static final int SB_X = 24, SB_Z = -24, SB_R = 10;
    private static final int FAME_X = 0, FAME_Z = -26, FAME_R = 6;
    private static final int FISH_X = -28, FISH_Z = 0, FISH_R = 8;
    private static final int MYST_X = 28, MYST_Z = 0, MYST_R = 6;
    private static final int ARC_X = -24, ARC_Z = 24, ARC_R = 10;
    private static final int DISCO_X = 24, DISCO_Z = 24, DISCO_R = 8;
    private static final int BOUNCE_X = 0, BOUNCE_Z = 28, BOUNCE_R = 9;

    private static final int PARKOUR_JUMPS = 18;

    private enum Zone { NONE, PARKOUR, SNOWBALL, ARCHERY, FISHING, DISCO, BOUNCE, MYSTERY, FAME }

    private static final Particle[] TRAILS = {
            null, Particle.FLAME, Particle.HEART, Particle.NOTE, Particle.CLOUD,
            Particle.SOUL_FIRE_FLAME, Particle.HAPPY_VILLAGER, Particle.END_ROD,
            Particle.SNOWFLAKE, Particle.DRAGON_BREATH, Particle.TOTEM_OF_UNDYING
    };
    private static final Material[] TRAIL_ICONS = {
            Material.BARRIER, Material.BLAZE_POWDER, Material.POPPY, Material.NOTE_BLOCK, Material.WHITE_WOOL,
            Material.SOUL_SAND, Material.BONE_MEAL, Material.END_ROD,
            Material.SNOWBALL, Material.DRAGON_BREATH, Material.TOTEM_OF_UNDYING
    };
    private static final String[] TRAIL_NAMES = {
            "No Trail", "Flames", "Hearts", "Music", "Clouds",
            "Souls", "Sparkles", "Starlight", "Snow", "Dragon Breath", "Totem Storm"
    };

    private static final Material[] HATS = {
            Material.BARRIER, Material.CARVED_PUMPKIN, Material.MELON, Material.CAKE, Material.TNT,
            Material.DIAMOND_BLOCK, Material.GLOWSTONE, Material.CHEST, Material.BEACON,
            Material.CREEPER_HEAD, Material.ZOMBIE_HEAD, Material.PIGLIN_HEAD, Material.DRAGON_HEAD,
            Material.SEA_LANTERN, Material.HAY_BLOCK, Material.CAULDRON, Material.SLIME_BLOCK, Material.JACK_O_LANTERN
    };

    private static final Material[] DISCO_WOOL = {
            Material.RED_WOOL, Material.ORANGE_WOOL, Material.YELLOW_WOOL, Material.LIME_WOOL,
            Material.LIGHT_BLUE_WOOL, Material.BLUE_WOOL, Material.PURPLE_WOOL, Material.MAGENTA_WOOL,
            Material.PINK_WOOL, Material.CYAN_WOOL
    };

    private static final String[] FISH_CATCHES = {
            "a suspiciously large boot", "a golden guppy", "a rubber duck", "an old minecart wheel",
            "a message in a bottle", "a glittering pearl", "a very confused squid", "a soggy diamond",
            "an ancient fishing licence", "a tiny treasure chest"
    };

    private final AutoBoxPlugin plugin;
    private final World world;
    private final Location lobbySpawn;
    private final NamespacedKey itemKey;
    private final NamespacedKey decoKey;

    private LobbyManager lobbyManager;
    private BukkitTask tickTask;
    private int ticks;

    private final List<int[]> parkourPads = new ArrayList<>();
    private final List<Integer> parkourCheckpoints = new ArrayList<>();
    private final List<int[]> discoFloor = new ArrayList<>();
    private final List<int[]> archeryTargets = new ArrayList<>();

    private final Map<UUID, Zone> zoneOf = new HashMap<>();
    private final Map<UUID, Integer> trailOf = new HashMap<>();
    private final Map<UUID, Long> parkourStart = new HashMap<>();
    private final Map<UUID, Integer> parkourProgress = new HashMap<>();
    private final Map<UUID, Integer> archeryScore = new HashMap<>();
    private final Map<UUID, Integer> snowballHits = new HashMap<>();
    private final Map<UUID, Long> gadgetCooldown = new HashMap<>();
    private final Map<UUID, Long> bestTimes = new HashMap<>();
    private final Map<UUID, String> bestNames = new HashMap<>();
    private final Random random = new Random();

    private int discoPartyTicks;

    public LobbyAttractions(AutoBoxPlugin plugin, Location lobbySpawn) {
        this.plugin = plugin;
        this.lobbySpawn = lobbySpawn;
        this.world = lobbySpawn.getWorld();
        this.itemKey = new NamespacedKey(plugin, "lobby_item");
        this.decoKey = new NamespacedKey(plugin, "lobby_deco");
        loadTimes();
    }

    public void setLobbyManager(LobbyManager lobbyManager) {
        this.lobbyManager = lobbyManager;
    }

    // ------------------------------------------------------------------ lifecycle

    public void build() {
        for (Entity entity : new ArrayList<>(world.getEntities())) {
            if (entity.getPersistentDataContainer().has(decoKey, PersistentDataType.STRING)) {
                entity.remove();
            }
        }
        bridge(0, -1, FAME_Z);
        bridge(0, 1, BOUNCE_Z);
        bridge(-1, 0, -FISH_X);
        bridge(1, 0, MYST_X);
        bridge(-1, -1, -PK_X);
        bridge(1, -1, SB_X);
        bridge(-1, 1, -ARC_X);
        bridge(1, 1, DISCO_X);

        buildParkour();
        buildSnowballArena();
        buildHallOfFame();
        buildFishingPond();
        buildMysteryGrotto();
        buildArcheryRange();
        buildDiscoFloor();
        buildBouncePlayground();
        updateHallOfFame();
    }

    public void start() {
        tickTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 4L);
    }

    public void shutdown() {
        if (tickTask != null) {
            tickTask.cancel();
        }
    }

    // ------------------------------------------------------------------ world building

    private void set(int x, int y, int z, Material material) {
        world.getBlockAt(x, y, z).setType(material, false);
    }

    private void clearColumn(int x, int z, int fromY, int toY) {
        for (int y = fromY; y <= toY; y++) {
            set(x, y, z, Material.AIR);
        }
    }

    /** A 3-wide walkway from the hub edge out to an island centre. */
    private void bridge(int dx, int dz, int length) {
        for (int step = HUB_R; step <= length; step++) {
            int x = dx * step;
            int z = dz * step;
            for (int ox = -1; ox <= 1; ox++) {
                for (int oz = -1; oz <= 1; oz++) {
                    clearColumn(x + ox, z + oz, FLOOR_Y + 1, FLOOR_Y + 8);
                    boolean centre = ox == 0 && oz == 0;
                    set(x + ox, FLOOR_Y, z + oz, centre ? Material.SMOOTH_QUARTZ : Material.POLISHED_ANDESITE);
                }
            }
            if (step % 5 == 0) {
                set(x + (dz == 0 ? 0 : 2), FLOOR_Y + 1, z + (dx == 0 ? 0 : 2), Material.SEA_LANTERN);
                set(x - (dz == 0 ? 0 : 2), FLOOR_Y + 1, z - (dx == 0 ? 0 : 2), Material.SEA_LANTERN);
            }
        }
    }

    /** Round island with a rim, cleared of anything above it. */
    private void island(int cx, int cz, int radius, Material floor, Material accent, Material rim) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                int dist = dx * dx + dz * dz;
                if (dist > radius * radius) {
                    continue;
                }
                int x = cx + dx;
                int z = cz + dz;
                clearColumn(x, z, FLOOR_Y + 1, FLOOR_Y + 22);
                boolean edge = dist > (radius - 1) * (radius - 1);
                Material material = edge ? rim : (((dx + dz) & 1) == 0 ? floor : accent);
                set(x, FLOOR_Y, z, material);
                set(x, FLOOR_Y - 1, z, Material.POLISHED_BLACKSTONE);
            }
        }
    }

    private void pillar(int x, int z, int height, Material shaft, Material top) {
        for (int y = 1; y <= height; y++) {
            set(x, FLOOR_Y + y, z, shaft);
        }
        set(x, FLOOR_Y + height + 1, z, top);
    }

    private void hologram(double x, double y, double z, Component text) {
        Location location = new Location(world, x, y, z);
        ArmorStand stand = world.spawn(location, ArmorStand.class);
        stand.setInvisible(true);
        stand.setMarker(true);
        stand.setGravity(false);
        stand.setInvulnerable(true);
        stand.setSilent(true);
        stand.customName(text);
        stand.setCustomNameVisible(true);
        stand.getPersistentDataContainer().set(decoKey, PersistentDataType.STRING, "1");
    }

    private void title(int cx, int cz, String name, NamedTextColor color, String subtitle) {
        hologram(cx + 0.5, WALK_Y + 2.6, cz + 0.5, Component.text(name, color, TextDecoration.BOLD));
        hologram(cx + 0.5, WALK_Y + 2.3, cz + 0.5, Component.text(subtitle, NamedTextColor.GRAY));
    }

    private void buildParkour() {
        island(PK_X, PK_Z, PK_R, Material.SMOOTH_QUARTZ, Material.QUARTZ_BRICKS, Material.CHISELED_QUARTZ_BLOCK);
        title(PK_X, PK_Z, "Parkour Peak", NamedTextColor.AQUA, "Step on the lime pad to start the clock");

        int startX = PK_X;
        int startZ = PK_Z + 5;
        set(startX, FLOOR_Y, startZ, Material.LIME_CONCRETE);
        set(startX + 1, FLOOR_Y, startZ, Material.LIME_CONCRETE);
        set(startX - 1, FLOOR_Y, startZ, Material.LIME_CONCRETE);
        hologram(startX + 0.5, WALK_Y + 1.2, startZ + 0.5,
                Component.text("START", NamedTextColor.GREEN, TextDecoration.BOLD));

        parkourPads.clear();
        parkourCheckpoints.clear();
        double angle = Math.PI / 2;
        double radius = 5.5;
        int y = WALK_Y;
        for (int i = 0; i < PARKOUR_JUMPS; i++) {
            angle -= 0.52;
            radius = 5.5 + (i % 3);
            if (i % 2 == 1) {
                y++;
            }
            int x = PK_X + (int) Math.round(Math.cos(angle) * radius);
            int z = PK_Z + (int) Math.round(Math.sin(angle) * radius);
            boolean checkpoint = i > 0 && i % 6 == 0;
            set(x, y, z, checkpoint ? Material.EMERALD_BLOCK : Material.SMOOTH_QUARTZ);
            if (checkpoint) {
                set(x, y + 1, z, Material.LIGHT_WEIGHTED_PRESSURE_PLATE);
                parkourCheckpoints.add(i);
                hologram(x + 0.5, y + 1.8, z + 0.5,
                        Component.text("Checkpoint", NamedTextColor.GREEN));
            }
            parkourPads.add(new int[]{x, y, z});
        }

        int[] last = parkourPads.get(parkourPads.size() - 1);
        int fx = last[0];
        int fz = last[2];
        int fy = last[1] + 1;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                set(fx + dx, fy, fz + dz, Material.GOLD_BLOCK);
            }
        }
        set(fx, fy + 1, fz, Material.SEA_LANTERN);
        parkourPads.add(new int[]{fx, fy, fz});
        hologram(fx + 0.5, fy + 2.2, fz + 0.5,
                Component.text("FINISH", NamedTextColor.GOLD, TextDecoration.BOLD));
    }

    private int[] parkourFinish() {
        return parkourPads.get(parkourPads.size() - 1);
    }

    private void buildSnowballArena() {
        island(SB_X, SB_Z, SB_R, Material.PACKED_ICE, Material.SNOW_BLOCK, Material.BLUE_ICE);
        title(SB_X, SB_Z, "Snowball Pit", NamedTextColor.WHITE, "Endless snowballs - knock your friends around");
        // Cover blocks to duck behind.
        int[][] cover = {{-4, -2}, {4, 2}, {-2, 4}, {2, -4}, {0, 5}, {0, -5}, {5, 0}, {-5, 0}};
        for (int[] spot : cover) {
            for (int y = 1; y <= 2; y++) {
                set(SB_X + spot[0], FLOOR_Y + y, SB_Z + spot[1], Material.SNOW_BLOCK);
                set(SB_X + spot[0] + 1, FLOOR_Y + y, SB_Z + spot[1], Material.SNOW_BLOCK);
            }
            set(SB_X + spot[0], FLOOR_Y + 3, SB_Z + spot[1], Material.PACKED_ICE);
        }
        pillar(SB_X, SB_Z, 4, Material.BLUE_ICE, Material.SEA_LANTERN);
    }

    private void buildHallOfFame() {
        island(FAME_X, FAME_Z, FAME_R, Material.POLISHED_BLACKSTONE, Material.GILDED_BLACKSTONE,
                Material.POLISHED_BLACKSTONE_BRICKS);
        title(FAME_X, FAME_Z, "Hall of Fame", NamedTextColor.GOLD, "Fastest Parkour Peak runs");
        pillar(FAME_X - 3, FAME_Z, 3, Material.POLISHED_BLACKSTONE_BRICKS, Material.GOLD_BLOCK);
        pillar(FAME_X + 3, FAME_Z, 3, Material.POLISHED_BLACKSTONE_BRICKS, Material.GOLD_BLOCK);
        pillar(FAME_X, FAME_Z - 3, 5, Material.POLISHED_BLACKSTONE_BRICKS, Material.BEACON);
    }

    private void buildFishingPond() {
        island(FISH_X, FISH_Z, FISH_R, Material.MOSS_BLOCK, Material.GRASS_BLOCK, Material.SPRUCE_PLANKS);
        title(FISH_X, FISH_Z, "Lazy Lagoon", NamedTextColor.BLUE, "Grab the rod and see what bites");
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                if (dx * dx + dz * dz > 16) {
                    continue;
                }
                set(FISH_X + dx, FLOOR_Y - 1, FISH_Z + dz, Material.STONE);
                set(FISH_X + dx, FLOOR_Y, FISH_Z + dz, Material.WATER);
            }
        }
        for (int dx = -2; dx <= 2; dx++) {
            set(FISH_X + dx, FLOOR_Y, FISH_Z + 5, Material.SPRUCE_PLANKS);
        }
        pillar(FISH_X - 5, FISH_Z - 3, 3, Material.OAK_FENCE, Material.LANTERN);
        pillar(FISH_X + 5, FISH_Z + 3, 3, Material.OAK_FENCE, Material.LANTERN);
        for (int dx = -6; dx <= 6; dx += 3) {
            set(FISH_X + dx, FLOOR_Y + 1, FISH_Z - 6, Material.OAK_LEAVES);
        }
    }

    private void buildMysteryGrotto() {
        island(MYST_X, MYST_Z, MYST_R, Material.DEEPSLATE_TILES, Material.CRACKED_DEEPSLATE_TILES,
                Material.CHISELED_DEEPSLATE);
        title(MYST_X, MYST_Z, "Mystery Machine", NamedTextColor.LIGHT_PURPLE,
                "Right-click the lodestone for a random surprise");
        set(MYST_X, FLOOR_Y + 1, MYST_Z, Material.LODESTONE);
        set(MYST_X, FLOOR_Y + 2, MYST_Z, Material.END_ROD);
        for (int dx = -2; dx <= 2; dx += 4) {
            for (int dz = -2; dz <= 2; dz += 4) {
                pillar(MYST_X + dx, MYST_Z + dz, 3, Material.POLISHED_DEEPSLATE, Material.AMETHYST_BLOCK);
            }
        }
        hologram(MYST_X + 0.5, WALK_Y + 1.4, MYST_Z + 0.5,
                Component.text("? Surprise Me ?", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
    }

    private void buildArcheryRange() {
        island(ARC_X, ARC_Z, ARC_R, Material.SMOOTH_SANDSTONE, Material.CUT_SANDSTONE, Material.CHISELED_SANDSTONE);
        title(ARC_X, ARC_Z, "Archery Range", NamedTextColor.YELLOW, "Hit the targets - a bow is waiting for you");
        archeryTargets.clear();
        // Shooting line at the near edge, target wall at the far edge.
        for (int dx = -4; dx <= 4; dx++) {
            set(ARC_X + dx, FLOOR_Y, ARC_Z - 7, Material.CUT_SANDSTONE);
            set(ARC_X + dx, FLOOR_Y + 1, ARC_Z - 8, Material.SANDSTONE_WALL);
        }
        int wallZ = ARC_Z + 7;
        for (int dx = -6; dx <= 6; dx++) {
            for (int y = 1; y <= 5; y++) {
                set(ARC_X + dx, FLOOR_Y + y, wallZ, Material.SANDSTONE);
            }
        }
        int[][] targets = {{-5, 2}, {-2, 4}, {0, 2}, {2, 4}, {5, 2}, {-3, 1}, {3, 1}};
        for (int[] target : targets) {
            int x = ARC_X + target[0];
            int y = FLOOR_Y + target[1];
            set(x, y, wallZ, Material.TARGET);
            archeryTargets.add(new int[]{x, y, wallZ});
        }
        pillar(ARC_X - 7, ARC_Z, 4, Material.SANDSTONE, Material.SEA_LANTERN);
        pillar(ARC_X + 7, ARC_Z, 4, Material.SANDSTONE, Material.SEA_LANTERN);
    }

    private void buildDiscoFloor() {
        island(DISCO_X, DISCO_Z, DISCO_R, Material.BLACK_CONCRETE, Material.POLISHED_BLACKSTONE,
                Material.CHISELED_POLISHED_BLACKSTONE);
        title(DISCO_X, DISCO_Z, "Disco Dome", NamedTextColor.LIGHT_PURPLE,
                "Play the note blocks - hit the jukebox for a party");
        discoFloor.clear();
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                if (dx * dx + dz * dz > 18) {
                    continue;
                }
                int x = DISCO_X + dx;
                int z = DISCO_Z + dz;
                set(x, FLOOR_Y, z, DISCO_WOOL[random.nextInt(DISCO_WOOL.length)]);
                discoFloor.add(new int[]{x, z});
            }
        }
        // Note-block piano along the back edge.
        for (int i = 0; i < 8; i++) {
            set(DISCO_X - 4 + i, FLOOR_Y + 1, DISCO_Z + 6, Material.NOTE_BLOCK);
            set(DISCO_X - 4 + i, FLOOR_Y, DISCO_Z + 6, Material.POLISHED_BLACKSTONE);
        }
        hologram(DISCO_X + 0.5, WALK_Y + 1.6, DISCO_Z + 6.5,
                Component.text("Piano - right-click the note blocks", NamedTextColor.AQUA));
        set(DISCO_X, FLOOR_Y + 1, DISCO_Z - 6, Material.JUKEBOX);
        hologram(DISCO_X + 0.5, WALK_Y + 1.6, DISCO_Z - 5.5,
                Component.text("Jukebox - right-click to start a party", NamedTextColor.GOLD));
        for (int dx = -6; dx <= 6; dx += 12) {
            pillar(DISCO_X + dx, DISCO_Z, 5, Material.POLISHED_BLACKSTONE, Material.GLOWSTONE);
        }
    }

    private void buildBouncePlayground() {
        island(BOUNCE_X, BOUNCE_Z, BOUNCE_R, Material.LIME_CONCRETE, Material.GREEN_CONCRETE, Material.LIME_TERRACOTTA);
        title(BOUNCE_X, BOUNCE_Z, "Bounce Park", NamedTextColor.GREEN,
                "Slime springs you up - honey launches you sky high");
        int[][] pads = {{-4, -2}, {4, -2}, {-4, 3}, {4, 3}, {0, 5}, {-2, -5}, {2, -5}};
        for (int[] pad : pads) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    set(BOUNCE_X + pad[0] + dx, FLOOR_Y, BOUNCE_Z + pad[1] + dz, Material.SLIME_BLOCK);
                }
            }
        }
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                set(BOUNCE_X + dx, FLOOR_Y, BOUNCE_Z + dz, Material.HONEY_BLOCK);
            }
        }
        hologram(BOUNCE_X + 0.5, WALK_Y + 1.4, BOUNCE_Z + 0.5,
                Component.text("MEGA LAUNCHER", NamedTextColor.YELLOW, TextDecoration.BOLD));
        // Rings to fly through.
        for (int ring = 0; ring < 3; ring++) {
            int ry = FLOOR_Y + 8 + ring * 4;
            int rz = BOUNCE_Z - 2 + ring * 2;
            for (double a = 0; a < Math.PI * 2; a += 0.35) {
                int x = BOUNCE_X + (int) Math.round(Math.cos(a) * 3);
                int y = ry + (int) Math.round(Math.sin(a) * 3);
                set(x, y, rz, ring == 1 ? Material.YELLOW_STAINED_GLASS : Material.LIGHT_BLUE_STAINED_GLASS);
            }
        }
    }

    // ------------------------------------------------------------------ per-tick logic

    private void tick() {
        ticks++;
        if (discoPartyTicks > 0) {
            discoPartyTicks -= 4;
        }
        if (world.getPlayers().isEmpty()) {
            // Nobody is watching: skip the disco floor block changes and per-player checks.
            return;
        }
        if (ticks % 3 == 0) {
            cycleDiscoFloor();
        }
        for (Player player : world.getPlayers()) {
            if (player.getGameMode() != GameMode.ADVENTURE) {
                continue;
            }
            trail(player);
            Zone zone = zoneAt(player.getLocation());
            Zone previous = zoneOf.getOrDefault(player.getUniqueId(), Zone.NONE);
            if (zone != previous) {
                exitZone(player, previous);
                enterZone(player, zone);
                zoneOf.put(player.getUniqueId(), zone);
            }
            refillKit(player, zone);
            if (zone == Zone.PARKOUR || parkourStart.containsKey(player.getUniqueId())) {
                trackParkour(player);
            }
        }
    }

    private void trail(Player player) {
        int index = trailOf.getOrDefault(player.getUniqueId(), 0);
        if (index <= 0 || index >= TRAILS.length) {
            return;
        }
        // Force delivery so trails remain visible with reduced particle settings and
        // through protocol translators such as Geyser.
        TRAILS[index].builder()
                .location(player.getLocation().add(0, 0.2, 0))
                .count(6)
                .offset(0.22, 0.08, 0.22)
                .extra(0.01)
                .receivers(48, true)
                .spawn();
    }

    private void cycleDiscoFloor() {
        if (discoFloor.isEmpty()) {
            return;
        }
        int changes = discoPartyTicks > 0 ? 24 : 6;
        for (int i = 0; i < changes; i++) {
            int[] spot = discoFloor.get(random.nextInt(discoFloor.size()));
            set(spot[0], FLOOR_Y, spot[1], DISCO_WOOL[random.nextInt(DISCO_WOOL.length)]);
        }
        if (discoPartyTicks > 0) {
            Location centre = new Location(world, DISCO_X + 0.5, WALK_Y + 1, DISCO_Z + 0.5);
            world.spawnParticle(Particle.FIREWORK, centre, 30, 4, 2, 4, 0.05);
            if (ticks % 6 == 0) {
                world.playSound(centre, Sound.BLOCK_NOTE_BLOCK_BASS, 1.2f, 0.6f + random.nextFloat() * 0.8f);
            }
            if (ticks % 30 == 0) {
                firework(centre.clone().add(0, 3, 0), randomColor());
            }
        }
    }

    private Zone zoneAt(Location location) {
        if (in(location, PK_X, PK_Z, PK_R + 2)) {
            return Zone.PARKOUR;
        }
        if (in(location, SB_X, SB_Z, SB_R)) {
            return Zone.SNOWBALL;
        }
        if (in(location, ARC_X, ARC_Z, ARC_R)) {
            return Zone.ARCHERY;
        }
        if (in(location, FISH_X, FISH_Z, FISH_R)) {
            return Zone.FISHING;
        }
        if (in(location, DISCO_X, DISCO_Z, DISCO_R)) {
            return Zone.DISCO;
        }
        if (in(location, BOUNCE_X, BOUNCE_Z, BOUNCE_R)) {
            return Zone.BOUNCE;
        }
        if (in(location, MYST_X, MYST_Z, MYST_R)) {
            return Zone.MYSTERY;
        }
        if (in(location, FAME_X, FAME_Z, FAME_R)) {
            return Zone.FAME;
        }
        return Zone.NONE;
    }

    private boolean in(Location location, int cx, int cz, int radius) {
        double dx = location.getX() - (cx + 0.5);
        double dz = location.getZ() - (cz + 0.5);
        return dx * dx + dz * dz <= (radius + 1.5) * (radius + 1.5);
    }

    private void enterZone(Player player, Zone zone) {
        switch (zone) {
            case SNOWBALL -> {
                snowballHits.put(player.getUniqueId(), 0);
                giveKit(player, 3, kitItem(Material.SNOWBALL, 16, "Snowballs", "Throw them at your friends"));
                announce(player, "Snowball Pit", "Unlimited snowballs - no damage, just chaos");
            }
            case ARCHERY -> {
                archeryScore.put(player.getUniqueId(), 0);
                giveKit(player, 3, kitItem(Material.BOW, 1, "Range Bow", "Hit the targets on the wall"));
                giveKit(player, 4, kitItem(Material.ARROW, 32, "Arrows", "They refill automatically"));
                announce(player, "Archery Range", "Hit a target for a point");
            }
            case FISHING -> {
                giveKit(player, 3, kitItem(Material.FISHING_ROD, 1, "Lucky Rod", "Cast into the lagoon"));
                announce(player, "Lazy Lagoon", "Cast a line and see what you pull up");
            }
            case PARKOUR -> announce(player, "Parkour Peak", "Step on the lime pad to start the clock");
            case DISCO -> announce(player, "Disco Dome", "Play the piano, hit the jukebox");
            case BOUNCE -> announce(player, "Bounce Park", "Slime bounces, honey launches");
            case MYSTERY -> announce(player, "Mystery Machine", "Right-click the lodestone");
            case FAME -> announce(player, "Hall of Fame", "The fastest parkour runs on the server");
            case NONE -> { }
        }
    }

    private void exitZone(Player player, Zone zone) {
        if (zone == Zone.SNOWBALL || zone == Zone.ARCHERY || zone == Zone.FISHING) {
            clearKit(player);
        }
        if (zone == Zone.ARCHERY) {
            archeryScore.remove(player.getUniqueId());
        }
        if (zone == Zone.SNOWBALL) {
            snowballHits.remove(player.getUniqueId());
        }
    }

    private void refillKit(Player player, Zone zone) {
        if (zone == Zone.SNOWBALL) {
            ItemStack slot = player.getInventory().getItem(3);
            if (slot == null || slot.getType() != Material.SNOWBALL || slot.getAmount() < 8) {
                giveKit(player, 3, kitItem(Material.SNOWBALL, 16, "Snowballs", "Throw them at your friends"));
            }
        } else if (zone == Zone.ARCHERY) {
            ItemStack arrows = player.getInventory().getItem(4);
            if (arrows == null || arrows.getType() != Material.ARROW || arrows.getAmount() < 8) {
                giveKit(player, 4, kitItem(Material.ARROW, 32, "Arrows", "They refill automatically"));
            }
        }
    }

    private void announce(Player player, String zone, String hint) {
        player.sendActionBar(Component.text(zone + " - " + hint, NamedTextColor.AQUA));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.6f, 1.4f);
    }

    // ------------------------------------------------------------------ parkour

    private void trackParkour(Player player) {
        UUID id = player.getUniqueId();
        Location location = player.getLocation();
        Block below = location.clone().subtract(0, 0.2, 0).getBlock();
        boolean onStart = below.getType() == Material.LIME_CONCRETE
                && Math.abs(below.getX() - PK_X) <= 1 && below.getZ() == PK_Z + 5;

        if (onStart && !parkourStart.containsKey(id)) {
            parkourStart.put(id, System.currentTimeMillis());
            parkourProgress.put(id, -1);
            player.playSound(location, Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.6f);
            player.sendMessage(Component.text("Parkour started - go!", NamedTextColor.GREEN));
            return;
        }
        Long started = parkourStart.get(id);
        if (started == null) {
            return;
        }
        int progress = parkourProgress.getOrDefault(id, -1);
        for (int i = parkourPads.size() - 1; i > progress; i--) {
            int[] pad = parkourPads.get(i);
            if (Math.abs(location.getX() - (pad[0] + 0.5)) < 1.6
                    && Math.abs(location.getZ() - (pad[2] + 0.5)) < 1.6
                    && Math.abs(location.getY() - (pad[1] + 1)) < 2.2) {
                progress = i;
                parkourProgress.put(id, i);
                if (parkourCheckpoints.contains(i)) {
                    player.playSound(location, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.4f);
                    player.sendActionBar(Component.text("Checkpoint " + (i + 1) + "/" + parkourPads.size(),
                            NamedTextColor.GREEN));
                }
                break;
            }
        }

        if (progress == parkourPads.size() - 1) {
            finishParkour(player, started);
            return;
        }

        double elapsed = (System.currentTimeMillis() - started) / 1000.0;
        player.sendActionBar(Component.text(String.format(Locale.ROOT, "Parkour %.1fs  |  %d/%d",
                elapsed, Math.max(progress + 1, 0), parkourPads.size()), NamedTextColor.YELLOW));

        int expectedY = progress >= 0 ? parkourPads.get(progress)[1] : WALK_Y;
        if (location.getY() < expectedY - 3.5 || !in(location, PK_X, PK_Z, PK_R + 4)) {
            Location respawn = checkpointLocation(progress);
            player.teleport(respawn);
            player.setVelocity(new Vector());
            player.playSound(respawn, Sound.ENTITY_ITEM_BREAK, 0.8f, 0.8f);
            player.sendActionBar(Component.text("Back to your checkpoint - clock is still running!",
                    NamedTextColor.RED));
        }
    }

    private Location checkpointLocation(int progress) {
        int best = -1;
        for (int checkpoint : parkourCheckpoints) {
            if (checkpoint <= progress && checkpoint > best) {
                best = checkpoint;
            }
        }
        if (best < 0) {
            return new Location(world, PK_X + 0.5, WALK_Y, PK_Z + 5.5);
        }
        int[] pad = parkourPads.get(best);
        return new Location(world, pad[0] + 0.5, pad[1] + 1, pad[2] + 0.5);
    }

    private void finishParkour(Player player, long started) {
        UUID id = player.getUniqueId();
        long millis = System.currentTimeMillis() - started;
        parkourStart.remove(id);
        parkourProgress.remove(id);
        String time = String.format(Locale.ROOT, "%.2fs", millis / 1000.0);
        Long best = bestTimes.get(id);
        boolean record = best == null || millis < best;
        if (record) {
            bestTimes.put(id, millis);
            bestNames.put(id, player.getName());
            saveTimes();
            updateHallOfFame();
        }
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        firework(player.getLocation().add(0, 1, 0), randomColor());
        firework(player.getLocation().add(0, 1, 0), randomColor());
        Bukkit.broadcast(Component.text("[Parkour] ", NamedTextColor.AQUA)
                .append(Component.text(player.getName(), NamedTextColor.WHITE))
                .append(Component.text(" finished Parkour Peak in ", NamedTextColor.GRAY))
                .append(Component.text(time, NamedTextColor.YELLOW))
                .append(record ? Component.text(" - new personal best!", NamedTextColor.GREEN)
                        : Component.empty()));
        player.teleport(new Location(world, PK_X + 0.5, WALK_Y, PK_Z + 7.5, 0, 0));
    }

    private void updateHallOfFame() {
        for (Entity entity : new ArrayList<>(world.getEntities())) {
            String tag = entity.getPersistentDataContainer().get(decoKey, PersistentDataType.STRING);
            if ("fame".equals(tag)) {
                entity.remove();
            }
        }
        List<Map.Entry<UUID, Long>> ranked = new ArrayList<>(bestTimes.entrySet());
        ranked.sort(Comparator.comparingLong(Map.Entry::getValue));
        double y = WALK_Y + 2.0;
        for (int i = 0; i < Math.min(5, ranked.size()); i++) {
            Map.Entry<UUID, Long> entry = ranked.get(i);
            String name = bestNames.getOrDefault(entry.getKey(), "???");
            String text = "#" + (i + 1) + " " + name + " - "
                    + String.format(Locale.ROOT, "%.2fs", entry.getValue() / 1000.0);
            NamedTextColor color = switch (i) {
                case 0 -> NamedTextColor.GOLD;
                case 1 -> NamedTextColor.WHITE;
                case 2 -> NamedTextColor.YELLOW;
                default -> NamedTextColor.GRAY;
            };
            Location location = new Location(world, FAME_X + 0.5, y - i * 0.32, FAME_Z + 0.5);
            ArmorStand stand = world.spawn(location, ArmorStand.class);
            stand.setInvisible(true);
            stand.setMarker(true);
            stand.setGravity(false);
            stand.setInvulnerable(true);
            stand.setSilent(true);
            stand.customName(Component.text(text, color));
            stand.setCustomNameVisible(true);
            stand.getPersistentDataContainer().set(decoKey, PersistentDataType.STRING, "fame");
        }
        if (ranked.isEmpty()) {
            Location location = new Location(world, FAME_X + 0.5, y, FAME_Z + 0.5);
            ArmorStand stand = world.spawn(location, ArmorStand.class);
            stand.setInvisible(true);
            stand.setMarker(true);
            stand.setGravity(false);
            stand.setInvulnerable(true);
            stand.setSilent(true);
            stand.customName(Component.text("Nobody has finished the parkour yet!", NamedTextColor.GRAY));
            stand.setCustomNameVisible(true);
            stand.getPersistentDataContainer().set(decoKey, PersistentDataType.STRING, "fame");
        }
    }

    private void loadTimes() {
        File file = new File(plugin.getDataFolder(), "parkour.yml");
        if (!file.exists()) {
            return;
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        for (String key : config.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                bestTimes.put(id, config.getLong(key + ".time"));
                bestNames.put(id, config.getString(key + ".name", "???"));
            } catch (IllegalArgumentException ignored) {
                // Skip malformed entries.
            }
        }
    }

    private void saveTimes() {
        File file = new File(plugin.getDataFolder(), "parkour.yml");
        YamlConfiguration config = new YamlConfiguration();
        for (Map.Entry<UUID, Long> entry : bestTimes.entrySet()) {
            config.set(entry.getKey() + ".time", entry.getValue());
            config.set(entry.getKey() + ".name", bestNames.getOrDefault(entry.getKey(), "???"));
        }
        // A personal best is saved mid-run from the lobby tick, so keep the disk write off the main thread.
        AsyncFiles.writeYaml(plugin, config, file);
    }

    // ------------------------------------------------------------------ lobby items

    public void giveLobbyItems(Player player) {
        if (!isLobby(player)) {
            return;
        }
        ItemStack helmet = player.getInventory().getHelmet();
        if ("hats".equals(tagOf(helmet))) {
            player.getInventory().setHelmet(null);
        }
        player.getInventory().setItem(0, lobbyItem(Material.NETHER_STAR, "games",
                "Play a Game", NamedTextColor.AQUA, "Right-click to pick a minigame"));
        player.getInventory().setItem(1, lobbyItem(Material.BLAZE_POWDER, "trails",
                "Particle Trails", NamedTextColor.LIGHT_PURPLE, "Right-click to choose your trail"));
        player.getInventory().setItem(2, lobbyItem(Material.NAME_TAG, "hats",
                "Hat Rack", NamedTextColor.GOLD, "Right-click to wear something silly"));
        player.getInventory().setItem(7, lobbyItem(Material.FIREWORK_ROCKET, "jetpack",
                "Pocket Rocket", NamedTextColor.RED, "Right-click to blast into the sky"));
        player.getInventory().setItem(8, lobbyItem(Material.BOOK, "guide",
                "Lobby Guide", NamedTextColor.YELLOW, "Right-click for the list of attractions"));
        player.getInventory().setHeldItemSlot(0);
        zoneOf.remove(player.getUniqueId());
        parkourStart.remove(player.getUniqueId());
        parkourProgress.remove(player.getUniqueId());
    }

    private ItemStack lobbyItem(Material material, String id, String name, NamedTextColor color, String lore) {
        ItemStack item = ItemStack.of(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text(lore, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack kitItem(Material material, int amount, String name, String lore) {
        ItemStack item = lobbyItem(material, "kit", name, NamedTextColor.WHITE, lore);
        item.setAmount(amount);
        return item;
    }

    private void giveKit(Player player, int slot, ItemStack item) {
        player.getInventory().setItem(slot, item);
    }

    private void clearKit(Player player) {
        for (int slot = 3; slot <= 6; slot++) {
            ItemStack item = player.getInventory().getItem(slot);
            if (item != null && "kit".equals(tagOf(item))) {
                player.getInventory().setItem(slot, null);
            }
        }
    }

    private String tagOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        return item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
    }

    private boolean isLobby(Player player) {
        return player.getWorld().equals(world) && player.getGameMode() == GameMode.ADVENTURE;
    }

    // ------------------------------------------------------------------ events

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!isLobby(player) || event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        // Cancel before handling wearable-looking menu items or interactive blocks.
        // This prevents the client from equipping/placing the item after its menu opens.
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        if ("kit".equals(tagOf(event.getItem()))) {
            event.setCancelled(false);
            event.setUseInteractedBlock(Event.Result.DENY);
            event.setUseItemInHand(Event.Result.ALLOW);
            return;
        }
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null) {
            Block block = event.getClickedBlock();
            switch (block.getType()) {
                case NOTE_BLOCK -> {
                    playPiano(player, block);
                    return;
                }
                case JUKEBOX -> {
                    startDiscoParty(player);
                    return;
                }
                case LODESTONE -> {
                    mysteryGadget(player);
                    return;
                }
                default -> { }
            }
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        String tag = tagOf(event.getItem());
        if (tag == null) {
            return;
        }
        switch (tag) {
            case "games" -> openGamesMenu(player);
            case "trails" -> openTrailsMenu(player);
            case "hats" -> openHatsMenu(player);
            case "jetpack" -> pocketRocket(player);
            case "guide" -> sendGuide(player);
            default -> { }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!isLobby(player) || !player.isOnGround()) {
            return;
        }
        Block below = player.getLocation().clone().subtract(0, 0.2, 0).getBlock();
        if (below.getType() == Material.SLIME_BLOCK) {
            launch(player, 1.05, 0.35, 1.2f);
        } else if (below.getType() == Material.HONEY_BLOCK) {
            launch(player, 2.1, 0.15, 0.7f);
        }
    }

    private void launch(Player player, double up, double forward, float pitch) {
        Vector velocity = player.getLocation().getDirection().setY(0);
        if (velocity.lengthSquared() > 0.01) {
            velocity.normalize().multiply(forward);
        }
        velocity.setY(up);
        player.setVelocity(velocity);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 140, 0, false, false, true));
        player.playSound(player.getLocation(), Sound.BLOCK_SLIME_BLOCK_PLACE, 1f, pitch);
        world.spawnParticle(Particle.CLOUD, player.getLocation(), 20, 0.4, 0.1, 0.4, 0.05);
    }

    private void playPiano(Player player, Block block) {
        int index = Math.floorMod(block.getX() - (DISCO_X - 4), 8);
        float pitch = (float) Math.pow(2, (index * 2 - 6) / 12.0);
        world.playSound(block.getLocation().add(0.5, 0.5, 0.5), Sound.BLOCK_NOTE_BLOCK_HARP, 2f, pitch);
        world.spawnParticle(Particle.NOTE, block.getLocation().add(0.5, 1.2, 0.5), 3, 0.2, 0.1, 0.2, 1);
    }

    private void startDiscoParty(Player player) {
        discoPartyTicks = 400;
        world.playSound(new Location(world, DISCO_X + 0.5, WALK_Y, DISCO_Z + 0.5),
                Sound.BLOCK_NOTE_BLOCK_PLING, 1.5f, 1.6f);
        Bukkit.broadcast(Component.text("[Disco] ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(player.getName() + " started a party at the Disco Dome!",
                        NamedTextColor.GRAY)));
    }

    private void pocketRocket(Player player) {
        if (onCooldown(player, 5000)) {
            return;
        }
        launch(player, 1.6, 0.25, 1.4f);
        firework(player.getLocation(), randomColor());
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1f, 1f);
    }

    private void mysteryGadget(Player player) {
        if (onCooldown(player, 8000)) {
            player.sendActionBar(Component.text("The machine is still recharging...", NamedTextColor.RED));
            return;
        }
        switch (random.nextInt(8)) {
            case 0 -> {
                launch(player, 2.4, 0.0, 1.2f);
                message(player, "WHOOSH! Enjoy the view.");
            }
            case 1 -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 600, 2, false, false, true));
                message(player, "Speed III for 30 seconds - go go go!");
            }
            case 2 -> {
                for (int i = 0; i < 6; i++) {
                    int delay = i * 8;
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (player.isOnline()) {
                            firework(player.getLocation().add(random.nextInt(5) - 2, 0, random.nextInt(5) - 2),
                                    randomColor());
                        }
                    }, delay);
                }
                message(player, "Firework show!");
            }
            case 3 -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 400, 0, false, false, true));
                message(player, "Now you see me... invisible for 20 seconds.");
            }
            case 4 -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 600, 3, false, false, true));
                message(player, "Jump Boost IV - try the parkour like this.");
            }
            case 5 -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 80, 1, false, false, true));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 200, 0, false, false, true));
                message(player, "Up you go!");
            }
            case 6 -> {
                player.getInventory().setItem(3, kitItem(Material.SNOWBALL, 32, "Snowballs", "Go wild"));
                message(player, "32 snowballs. Use them wisely.");
            }
            default -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 600, 0, false, false, true));
                trailOf.put(player.getUniqueId(), 1 + random.nextInt(TRAILS.length - 1));
                message(player, "You are now extremely hard to miss.");
            }
        }
        world.spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 40, 0.6, 1, 0.6, 0.3);
        player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
    }

    private boolean onCooldown(Player player, long millis) {
        long now = System.currentTimeMillis();
        Long until = gadgetCooldown.get(player.getUniqueId());
        if (until != null && until > now) {
            return true;
        }
        gadgetCooldown.put(player.getUniqueId(), now + millis);
        return false;
    }

    @EventHandler
    public void onProjectile(ProjectileHitEvent event) {
        if (!event.getEntity().getWorld().equals(world)) {
            return;
        }
        if (event.getEntity() instanceof Snowball snowball
                && event.getHitEntity() instanceof Player hit
                && snowball.getShooter() instanceof Player shooter
                && isLobby(hit) && !hit.equals(shooter)) {
            Vector direction = snowball.getVelocity();
            double speed = Math.hypot(direction.getX(), direction.getZ());
            if (speed > 0.01) {
                Vector knockback = new Vector(direction.getX() / speed, 0, direction.getZ() / speed).multiply(0.7);
                knockback.setY(0.4);
                hit.setVelocity(knockback);
            }
            hit.playSound(hit.getLocation(), Sound.ENTITY_SNOWBALL_THROW, 1f, 0.8f);
            world.spawnParticle(Particle.SNOWFLAKE, hit.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.05);
            int hits = snowballHits.merge(shooter.getUniqueId(), 1, Integer::sum);
            shooter.sendActionBar(Component.text("Direct hit on " + hit.getName() + "!  Hits: " + hits,
                    NamedTextColor.AQUA));
            return;
        }
        if (event.getEntity() instanceof Arrow arrow) {
            Block block = event.getHitBlock();
            if (block != null && block.getType() == Material.TARGET
                    && arrow.getShooter() instanceof Player shooter) {
                int score = archeryScore.merge(shooter.getUniqueId(), 1, Integer::sum);
                shooter.playSound(shooter.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 1.6f);
                shooter.sendActionBar(Component.text("Target hit!  Score: " + score, NamedTextColor.GOLD));
                world.spawnParticle(Particle.CRIT, block.getLocation().add(0.5, 0.5, 0.5), 25, 0.3, 0.3, 0.3, 0.3);
                if (score % 5 == 0) {
                    firework(block.getLocation().add(0.5, 2, 0.5), randomColor());
                    Bukkit.broadcast(Component.text("[Range] ", NamedTextColor.YELLOW)
                            .append(Component.text(shooter.getName() + " has hit " + score + " targets in a row.",
                                    NamedTextColor.GRAY)));
                }
            }
            arrow.remove();
        }
    }

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        Player player = event.getPlayer();
        if (!isLobby(player) || event.getState() != PlayerFishEvent.State.CAUGHT_FISH) {
            return;
        }
        event.setExpToDrop(0);
        if (event.getCaught() != null) {
            event.getCaught().remove();
        }
        String catchName = FISH_CATCHES[random.nextInt(FISH_CATCHES.length)];
        player.sendMessage(Component.text("You reeled in ", NamedTextColor.AQUA)
                .append(Component.text(catchName, NamedTextColor.YELLOW))
                .append(Component.text("!", NamedTextColor.AQUA)));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
        if (random.nextInt(6) == 0) {
            firework(player.getLocation().add(0, 1, 0), randomColor());
            player.sendMessage(Component.text("A rare catch! Show it off in chat.", NamedTextColor.GOLD));
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (isLobby(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent event) {
        if (isLobby(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        Component title = event.getView().title();
        if (title.equals(TRAILS_TITLE)) {
            event.setCancelled(true);
            int slot = event.getSlot();
            if (slot >= 0 && slot < TRAILS.length) {
                trailOf.put(player.getUniqueId(), slot);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1.4f);
                player.sendMessage(Component.text("Trail set to " + TRAIL_NAMES[slot] + ".",
                        NamedTextColor.LIGHT_PURPLE));
                player.closeInventory();
            }
            return;
        }
        if (title.equals(HATS_TITLE)) {
            event.setCancelled(true);
            int slot = event.getSlot();
            if (slot >= 0 && slot < HATS.length) {
                if (HATS[slot] == Material.BARRIER) {
                    player.getInventory().setHelmet(null);
                    player.sendMessage(Component.text("Hat removed.", NamedTextColor.GRAY));
                } else {
                    player.getInventory().setHelmet(ItemStack.of(HATS[slot]));
                    player.sendMessage(Component.text("Nice hat.", NamedTextColor.GOLD));
                }
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1.4f);
                player.closeInventory();
            }
            return;
        }
        if (title.equals(GAMES_TITLE)) {
            event.setCancelled(true);
            GameType[] types = GameType.values();
            int slot = event.getSlot();
            if (slot >= 0 && slot < types.length && lobbyManager != null) {
                player.closeInventory();
                lobbyManager.select(player, types[slot]);
            }
            return;
        }
        if (isLobby(player) && event.getView().getType() == InventoryType.CRAFTING) {
            event.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ menus

    private void openGamesMenu(Player player) {
        GameType[] types = GameType.values();
        Inventory inventory = Bukkit.createInventory(null, 9, GAMES_TITLE);
        Material[] icons = {Material.ORANGE_CONCRETE, Material.BEDROCK, Material.SLIME_BLOCK, Material.EGG,
                Material.LIME_CONCRETE, Material.ZOMBIE_HEAD, Material.HAY_BLOCK};
        String[] names = {"Splatoon", "Lucky Pillars", "Block Sumo", "ChickenRun Pro+ Ultra", "Hole in the Wall",
                "Zombie Apocalypse", "Rat and Seek"};
        for (int i = 0; i < types.length; i++) {
            ItemStack item = ItemStack.of(icons[i]);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text(names[i], NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(Component.text("Click to join the queue or spectate", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false)));
            item.setItemMeta(meta);
            inventory.setItem(i, item);
        }
        player.openInventory(inventory);
    }

    private void openTrailsMenu(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 18, TRAILS_TITLE);
        int current = trailOf.getOrDefault(player.getUniqueId(), 0);
        for (int i = 0; i < TRAILS.length; i++) {
            ItemStack item = ItemStack.of(TRAIL_ICONS[i]);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text(TRAIL_NAMES[i],
                    i == current ? NamedTextColor.GREEN : NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(Component.text(i == current ? "Selected" : "Click to select",
                    NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
            item.setItemMeta(meta);
            inventory.setItem(i, item);
        }
        player.openInventory(inventory);
    }

    private void openHatsMenu(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 18, HATS_TITLE);
        for (int i = 0; i < HATS.length; i++) {
            ItemStack item = ItemStack.of(HATS[i]);
            ItemMeta meta = item.getItemMeta();
            String name = HATS[i] == Material.BARRIER ? "No Hat" : prettify(HATS[i]);
            meta.displayName(Component.text(name, NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(Component.text("Click to wear", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false)));
            item.setItemMeta(meta);
            inventory.setItem(i, item);
        }
        player.openInventory(inventory);
    }

    private String prettify(Material material) {
        String[] words = material.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder builder = new StringBuilder();
        for (String word : words) {
            builder.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1)).append(' ');
        }
        return builder.toString().trim();
    }

    private void sendGuide(Player player) {
        player.sendMessage(Component.text("=== Lobby Attractions ===", NamedTextColor.LIGHT_PURPLE,
                TextDecoration.BOLD));
        guideLine(player, "Parkour Peak", "north-west", "Timed spiral course with checkpoints");
        guideLine(player, "Snowball Pit", "north-east", "Endless snowballs, pure knockback");
        guideLine(player, "Hall of Fame", "north", "The fastest parkour times on the server");
        guideLine(player, "Lazy Lagoon", "west", "Fishing pond with silly catches");
        guideLine(player, "Mystery Machine", "east", "Right-click the lodestone for a random gadget");
        guideLine(player, "Archery Range", "south-west", "Bow, arrows and seven targets");
        guideLine(player, "Disco Dome", "south-east", "Note-block piano and a jukebox party");
        guideLine(player, "Bounce Park", "south", "Slime pads, a mega launcher and glass rings");
        player.sendMessage(Component.text("Hotbar: game picker, trails, hats and a pocket rocket.",
                NamedTextColor.GRAY));
    }

    private void guideLine(Player player, String name, String direction, String description) {
        player.sendMessage(Component.text(" - ", NamedTextColor.DARK_GRAY)
                .append(Component.text(name, NamedTextColor.AQUA))
                .append(Component.text(" (" + direction + ") ", NamedTextColor.DARK_AQUA))
                .append(Component.text(description, NamedTextColor.GRAY)));
    }

    // ------------------------------------------------------------------ helpers

    private void message(Player player, String text) {
        player.sendMessage(Component.text("[Mystery] ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(text, NamedTextColor.WHITE)));
    }

    private Color randomColor() {
        Color[] colors = {Color.RED, Color.ORANGE, Color.YELLOW, Color.LIME, Color.AQUA, Color.FUCHSIA,
                Color.PURPLE, Color.WHITE};
        return colors[random.nextInt(colors.length)];
    }

    private void firework(Location location, Color color) {
        world.spawn(location, Firework.class, firework -> {
            FireworkMeta meta = firework.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder()
                    .withColor(color)
                    .withFade(Color.WHITE)
                    .with(FireworkEffect.Type.BALL_LARGE)
                    .withFlicker()
                    .build());
            meta.setPower(1);
            firework.setFireworkMeta(meta);
        });
    }
}
