package dev.autobox.sumo;

import dev.autobox.util.Fx;
import dev.autobox.util.Sidebar;
import dev.autobox.AutoBoxPlugin;
import dev.autobox.lobby.GameType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Block Sumo. The default Gauntlet is first to three round wins, with a new arena and twist every
 * round; Marathon is the long five-life match on one arena. Arena layouts live in {@link SumoArenas},
 * events in {@link SumoEvents}, moving map parts in {@link SumoHazards} and crates in {@link SumoCrates}.
 */
public final class BlockSumoGame {
    public static final String WORLD_NAME = "block_sumo_arena";
    /** Tag on every display entity the game spawns, so a sweep can always find leftovers. */
    static final String FX_TAG = "sumo_fx";
    private static final int BASE_Y = SumoArena.BASE_Y;
    private static final int MAX_LIVES = SumoRules.MAX_LIVES;
    private static final int MAX_LEVEL = SumoRules.MAX_LEVEL;
    private static final int ENERGY_DURATION = 10 * 20;
    private static final int HEART_DURATION = 20 * 20;
    private static final int HEART_CLAIM_TICKS = 40;
    private static final int RESPAWN_SHIELD_TICKS = 3 * 20;
    private static final int BUILD_PER_TICK = 600;
    private static final Material[] COLORS = {
            Material.RED_WOOL, Material.BLUE_WOOL, Material.LIME_WOOL,
            Material.YELLOW_WOOL, Material.PURPLE_WOOL, Material.ORANGE_WOOL
    };
    private static final double MIN_SPAWN_SEPARATION = 9.0;
    private static final Particle.DustOptions HEART_RED = new Particle.DustOptions(Color.fromRGB(255, 40, 70), 1.4f);
    private static final int[] ROLL_FRAMES = {44, 47, 50, 53, 57, 61, 66, 72, 79, 87, 96};

    private final AutoBoxPlugin plugin;
    private final World world;
    private final Location lobby;
    private final Random random = new Random();
    private final SumoRecords records;
    private final SumoEvents events = new SumoEvents(this);
    private final SumoHazards hazards = new SumoHazards(this);
    private final SumoCrates crates;
    // Bags live across matches, so back-to-back matches start somewhere new too.
    private final SumoRules.ShuffleBag<SumoArena.Kind> arenaBag =
            new SumoRules.ShuffleBag<>(Arrays.asList(SumoArena.Kind.values()), random);
    private final SumoRules.ShuffleBag<SumoMutator> mutatorBag =
            new SumoRules.ShuffleBag<>(Arrays.asList(SumoMutator.values()), random);
    private final SumoRules.ShuffleBag<SumoRules.Event> eventBag = new SumoRules.ShuffleBag<>(
            Arrays.stream(SumoRules.Event.values()).filter(event -> event != SumoRules.Event.CALM).toList(), random);

    /** Everyone still in the match; {@link #players} is who is alive in the current round. */
    private final Set<UUID> roster = new LinkedHashSet<>();
    private final Set<UUID> players = new HashSet<>();
    private final Set<Location> arenaBlocks = new HashSet<>();
    /** Player wool and the tick it was placed; it crumbles after {@link SumoRules#WOOL_LIFETIME}. */
    private final Map<Location, Integer> placedWool = new HashMap<>();
    private final Map<UUID, Integer> lives = new HashMap<>();
    private final Map<UUID, Integer> levels = new HashMap<>();
    private final Map<UUID, Integer> charge = new HashMap<>();
    private final Map<UUID, Integer> heartCharge = new HashMap<>();
    private final Map<UUID, Integer> respawnShieldUntil = new HashMap<>();
    private final Map<UUID, UUID> lastHitBy = new HashMap<>();
    private final Map<UUID, Integer> lastHitTick = new HashMap<>();
    private final Map<UUID, Integer> meleeReadyAt = new HashMap<>();
    private final Map<UUID, Integer> eliminations = new HashMap<>();
    private final Map<UUID, Integer> falls = new HashMap<>();
    private final Map<UUID, Integer> spheres = new HashMap<>();
    private final Map<UUID, Integer> streaks = new HashMap<>();
    private final Map<UUID, Integer> bestStreaks = new HashMap<>();
    private final Map<UUID, Integer> roundWins = new HashMap<>();
    private final Map<UUID, Material> woolColors = new HashMap<>();
    private final Map<UUID, Integer> vaultCooldownUntil = new HashMap<>();
    private final Map<UUID, Integer> repulsorCooldownUntil = new HashMap<>();
    private final Map<UUID, SumoRules.Mode> votes = new HashMap<>();
    private final Map<UUID, String> participants = new LinkedHashMap<>();
    private final List<UUID> knockedOut = new ArrayList<>();
    private boolean running;
    private boolean ending;
    private boolean suddenDeath;
    private boolean voting;
    private boolean intermission;
    private Sidebar sidebar;
    private SumoRules.Mode mode = SumoRules.Mode.GAUNTLET;
    private SumoArena arena = SumoArenas.get(SumoArena.Kind.RIFT);
    private SumoMutator mutator = SumoMutator.NORMAL;
    private SumoArena nextArena;
    private SumoMutator nextMutator;
    private Iterator<SumoArena.Block> buildQueue;
    private int round;
    private int roundsPlayed;
    private int ticks;
    private int roundTicks;
    private int intermissionTicks;
    private int energyUntil;
    private int heartUntil;
    private int eventUntil;
    private int arenaRadius;
    private int lastCountdownSecond;
    private Location energyCenter;
    private Location heartCenter;
    private BukkitTask task;
    private BukkitTask finishTask;
    private SumoRules.Event arenaEvent = SumoRules.Event.CALM;

    public BlockSumoGame(AutoBoxPlugin plugin, World world, Location lobby) {
        this.plugin = plugin;
        this.world = world;
        this.lobby = lobby;
        this.records = new SumoRecords(plugin);
        this.crates = new SumoCrates(this, plugin);
    }

    public void start(CommandSender sender, List<Player> roster) {
        if (running) {
            sender.sendMessage(Component.text("Block Sumo is already running.", NamedTextColor.RED));
            return;
        }
        List<Player> online = roster.stream().filter(Player::isOnline).limit(COLORS.length).toList();
        if (online.size() < 2) {
            sender.sendMessage(Component.text("Need at least 2 players to start Block Sumo.", NamedTextColor.RED));
            return;
        }
        resetArena(true);
        this.roster.clear();
        players.clear();
        lives.clear();
        levels.clear();
        eliminations.clear();
        falls.clear();
        spheres.clear();
        streaks.clear();
        bestStreaks.clear();
        roundWins.clear();
        woolColors.clear();
        votes.clear();
        participants.clear();
        knockedOut.clear();
        crates.resetStats();
        mode = SumoRules.Mode.GAUNTLET;
        voting = true;
        intermission = false;
        round = 1;
        roundsPlayed = 0;
        ticks = 0;
        arena = SumoArenas.get(arenaBag.next(kind -> true));
        mutator = drawMutator(arena);
        buildNow(arena);
        running = true;
        ending = false;
        for (int i = 0; i < online.size(); i++) {
            Player player = online.get(i);
            UUID id = player.getUniqueId();
            this.roster.add(id);
            participants.put(id, player.getName());
            levels.put(id, 0);
            eliminations.put(id, 0);
            woolColors.put(id, COLORS[i % COLORS.length]);
        }
        beginRound(SumoRules.VOTE_TICKS);
        broadcast(Component.text("Vote with the dyes in your hotbar: ", NamedTextColor.AQUA)
                .append(Component.text("GAUNTLET", NamedTextColor.GREEN, TextDecoration.BOLD))
                .append(Component.text(" (first to 3 rounds, new arena and twist every round) or ", NamedTextColor.AQUA))
                .append(Component.text("MARATHON", NamedTextColor.GOLD, TextDecoration.BOLD))
                .append(Component.text(" (12 minutes, five lives, one arena).", NamedTextColor.AQUA)));
        broadcast(Component.text("Mystery crates drop in all match. Feather = vault, sneak = brace.",
                NamedTextColor.LIGHT_PURPLE));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public boolean isRunning() {
        return running;
    }

    public boolean isPlaying(Player player) {
        return running && players.contains(player.getUniqueId());
    }

    public boolean isWorld(Player player) {
        return player.getWorld() == world;
    }

    public boolean isWorld(World other) {
        return other == world;
    }

    /** Where a lobby spectator is dropped in to watch the current match. */
    public Location getSpectateLocation() {
        return new Location(world, 0.5, BASE_Y + 16, 0.5);
    }

    private Location overview() {
        return new Location(world, 0.5, BASE_Y + 20, 20.5, 180f, 40f);
    }

    // ---- Accessors for the event, hazard and crate helpers --------------------------------------

    World world() { return world; }
    int ticks() { return ticks; }
    int roundTicks() { return roundTicks; }
    Random random() { return random; }
    SumoRules.Mode mode() { return mode; }
    SumoArena arena() { return arena; }
    int arenaRadius() { return arenaRadius; }
    Set<Location> arenaBlocks() { return arenaBlocks; }
    int aliveCount() { return players.size(); }

    boolean isArenaBlock(Location location) {
        return arenaBlocks.contains(location);
    }

    void removeArenaBlock(Location location) {
        location.getBlock().setType(Material.AIR, false);
        arenaBlocks.remove(location);
    }

    List<Player> alivePlayers() {
        List<Player> alive = new ArrayList<>();
        forEachPlayer(alive::add);
        return alive;
    }

    /** Respawn shield or bubble shield: no knockback lands. */
    boolean immune(Player player) {
        return respawnShieldUntil.getOrDefault(player.getUniqueId(), 0) > ticks || crates.bubbled(player);
    }

    /** Applies knockback unless the victim is shielded; credits {@code source} for a knockout. */
    boolean knock(Player victim, Vector velocity, Player source) {
        if (!isPlaying(victim) || immune(victim)) return false;
        victim.setVelocity(velocity);
        if (source != null && !source.equals(victim)) recordHit(victim, source);
        return true;
    }

    void restoreEffects(Player player) {
        if (levels.getOrDefault(player.getUniqueId(), 0) >= 5) applyOverdrive(player);
    }

    /** Places this player's wool (for Bridge Eggs); false if the block is taken or out of bounds. */
    boolean placeWool(Block block, Player owner) {
        if (!block.getType().isAir() || block.getY() < SumoArena.SWEEP_BOTTOM || block.getY() > SumoArena.SWEEP_TOP
                || Math.hypot(block.getX(), block.getZ()) > arenaRadius + 3) {
            return false;
        }
        block.setType(woolColors.getOrDefault(owner.getUniqueId(), Material.WHITE_WOOL), false);
        placedWool.put(block.getLocation(), ticks);
        return true;
    }

    void breakWoolNear(Location center, double radius) {
        for (Iterator<Location> iterator = placedWool.keySet().iterator(); iterator.hasNext(); ) {
            Location wool = iterator.next();
            if (wool.clone().add(0.5, 0.5, 0.5).distanceSquared(center) <= radius * radius) {
                wool.getBlock().setType(Material.AIR, false);
                iterator.remove();
            }
        }
    }

    // ---- Player actions -----------------------------------------------------------------------

    public boolean onWoolPlace(Player player, Block block) {
        String typeName = block.getType().name();
        boolean isPlaceable = typeName.endsWith("_WOOL");
        if (!isPlaying(player) || !isPlaceable) {
            return false;
        }
        if (ending || roundTicks < 0 || !mutator.building || block.getY() < arena.lowestFloor() - 1
                || block.getY() > SumoArena.SWEEP_TOP || Math.hypot(block.getX(), block.getZ()) > arenaRadius + 3) {
            return false;
        }
        block.setType(woolColors.getOrDefault(player.getUniqueId(), Material.WHITE_WOOL), false);
        placedWool.put(block.getLocation(), ticks);
        return true;
    }

    public boolean onBreak(Player player, Block block) {
        if (!isPlaying(player) || ending || roundTicks < 0 || placedWool.remove(block.getLocation()) == null) {
            return false;
        }
        String typeName = block.getType().name();
        return typeName.endsWith("_WOOL");
    }

    public void handleMelee(EntityDamageByEntityEvent event, Player attacker, Player victim) {
        event.setCancelled(true);
        if (!isPlaying(attacker) || !isPlaying(victim)) {
            return;
        }
        if (ending || roundTicks < 0 || isShielded(attacker) || isShielded(victim)
                || meleeReadyAt.getOrDefault(attacker.getUniqueId(), 0) > ticks) {
            return;
        }
        if (crates.bubbled(victim)) {
            world.playSound(victim.getLocation(), Sound.BLOCK_BUBBLE_COLUMN_BUBBLE_POP, 1f, 1.2f);
            return;
        }
        meleeReadyAt.put(attacker.getUniqueId(), ticks + 7);
        Vector knockback = victim.getLocation().toVector().subtract(attacker.getLocation().toVector()).setY(0);
        if (knockback.lengthSquared() < 0.01) {
            knockback.setX(1);
        }
        double strength = attacker.isSprinting() ? 1.05 : 0.78;
        strength += levels.getOrDefault(attacker.getUniqueId(), 0) * 0.045;
        if (SumoRules.isOverdrive(mode, roundTicks)) {
            strength *= 1.2;
        }
        Material held = attacker.getInventory().getItemInMainHand().getType();
        if (held == Material.STICK) {
            strength += 0.45;
        } else if (held == Material.BLAZE_ROD) {
            strength += 0.9;
        }
        double[] bonus = crates.meleeBonus(attacker);
        strength += bonus[0];
        if (arenaEvent == SumoRules.Event.POWER_SURGE) strength *= 1.2;
        strength *= mutator == SumoMutator.WIND_CHARGES ? 0.75 : mutator.knockback;
        if (victim.isSneaking() && victim.isOnGround()) strength *= 0.8;
        knockback.normalize().multiply(strength).setY((attacker.isSprinting() ? 0.5 : 0.38) + bonus[1]);
        victim.setVelocity(knockback);
        recordHit(victim, attacker);
        attacker.resetCooldown();
        world.playSound(victim.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1f, 1.1f);
    }

    /** Every projectile that lands in the Sumo world: crate items first, then Rift Bolts. */
    public void handleProjectileHit(ProjectileHitEvent event) {
        if (!running) return;
        if (crates.onProjectileHit(event)) return;
        if (event.getEntity() instanceof Snowball snowball && event.getHitEntity() instanceof Player victim
                && snowball.getShooter() instanceof Player shooter) {
            handleSnowball(snowball, shooter, victim);
        }
    }

    public void handleFish(PlayerFishEvent event) {
        if (isPlaying(event.getPlayer()) && !ending && roundTicks >= 0) crates.onFish(event);
    }

    private void handleSnowball(Snowball snowball, Player shooter, Player victim) {
        if (!isPlaying(shooter) || !isPlaying(victim)) {
            return;
        }
        if (ending || roundTicks < 0 || isShielded(shooter) || immune(victim)) {
            return;
        }
        Vector direction = snowball.getVelocity().setY(0);
        if (direction.lengthSquared() < 0.01) {
            direction.setX(1);
        }
        int level = levels.getOrDefault(shooter.getUniqueId(), 0);
        double strength = (level >= 1 ? 1.55 : 1.1) * projectileScale();
        knock(victim, direction.normalize().multiply(strength).setY(level >= 1 ? 0.55 : 0.42), shooter);
        Particle.ELECTRIC_SPARK.builder().location(victim.getLocation().add(0, 1, 0))
                .count(level >= 1 ? 18 : 6).receivers(48, true).spawn();
        world.playSound(victim.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8f, level >= 1 ? 1.8f : 1.5f);
    }

    private double projectileScale() {
        return mutator == SumoMutator.WIND_CHARGES ? 1.0 : mutator.knockback;
    }

    /** A wind charge popped: blast rivals away, and rocket-jump the thrower if it was at their feet. */
    void windBurst(Location at, Player shooter) {
        Particle.GUST_EMITTER_SMALL.builder().location(at).count(1).receivers(64, true).spawn();
        world.playSound(at, Sound.ENTITY_WIND_CHARGE_WIND_BURST, 1f, 1f);
        if (ending || roundTicks < 0) return;
        for (Player player : alivePlayers()) {
            Vector offset = player.getLocation().add(0, 0.9, 0).toVector().subtract(at.toVector());
            double distance = offset.length();
            if (distance > 3.2) continue;
            if (player.equals(shooter)) {
                Vector velocity = player.getVelocity().setY(Math.max(player.getVelocity().getY(), 1.05 - distance * 0.15));
                Vector horizontal = offset.clone().setY(0);
                if (horizontal.lengthSquared() > 0.01) velocity.add(horizontal.normalize().multiply(0.35));
                player.setVelocity(velocity);
                player.setFallDistance(0);
                continue;
            }
            Vector horizontal = offset.clone().setY(0);
            if (horizontal.lengthSquared() < 0.01) horizontal = new Vector(random.nextDouble() - 0.5, 0, random.nextDouble() - 0.5);
            double strength = (0.55 + 0.9 * (1 - distance / 3.5)) * projectileScale();
            knock(player, horizontal.normalize().multiply(strength).setY(0.6), shooter);
        }
    }

    /** Handles the vote dyes, crate items and the two reusable Energy Sphere powers. */
    public void handleInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!isPlaying(player) || ending || event.getHand() != EquipmentSlot.HAND
                || (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK)) {
            return;
        }
        Material material = event.getMaterial();
        if (voting && roundTicks < 0 && (material == Material.LIME_DYE || material == Material.ORANGE_DYE)) {
            event.setCancelled(true);
            castVote(player, material == Material.LIME_DYE ? SumoRules.Mode.GAUNTLET : SumoRules.Mode.MARATHON);
            return;
        }
        if (roundTicks < 0) {
            // Nothing fires before GO (wind charges and pearls would otherwise work during the countdown).
            event.setCancelled(true);
            return;
        }
        ItemStack held = player.getInventory().getItemInMainHand();
        if (crates.kind(held) != null) {
            if (crates.use(player, held)) event.setCancelled(true);
            return;
        }
        int level = levels.getOrDefault(player.getUniqueId(), 0);
        if (material == Material.FEATHER) {
            event.setCancelled(true);
            useKineticVault(player);
        } else if (material == Material.HEART_OF_THE_SEA && level >= 3) {
            event.setCancelled(true);
            if (!isShielded(player)) useRepulsor(player);
        }
    }

    private void castVote(Player player, SumoRules.Mode choice) {
        SumoRules.Mode previous = votes.put(player.getUniqueId(), choice);
        if (previous == choice) return;
        broadcast(Component.text(player.getName() + " voted ", NamedTextColor.GRAY)
                .append(Component.text(choice.label.toUpperCase(),
                        choice == SumoRules.Mode.GAUNTLET ? NamedTextColor.GREEN : NamedTextColor.GOLD, TextDecoration.BOLD)));
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1.2f);
        updateScoreboard();
    }

    void recordHit(Player victim, Player attacker) {
        lastHitBy.put(victim.getUniqueId(), attacker.getUniqueId());
        lastHitTick.put(victim.getUniqueId(), ticks);
    }

    public void handleQuit(Player player) {
        if (!running) return;
        UUID id = player.getUniqueId();
        boolean inMatch = roster.remove(id);
        boolean alive = players.remove(id);
        if (!inMatch && !alive) return;
        SumoMutator.clear(player);
        if (alive) knockedOut.add(id);
        lives.remove(id);
        charge.remove(id);
        heartCharge.remove(id);
        respawnShieldUntil.remove(id);
        lastHitBy.remove(id);
        lastHitTick.remove(id);
        meleeReadyAt.remove(id);
        vaultCooldownUntil.remove(id);
        repulsorCooldownUntil.remove(id);
        votes.remove(id);
        if (mode == SumoRules.Mode.GAUNTLET && roster.size() < 2 && !ending) {
            finishMatch(roster.isEmpty() ? null : roster.iterator().next());
            return;
        }
        checkEnd();
        updateScoreboard();
    }

    public void endGame() {
        if (!running) {
            return;
        }
        running = false;
        ending = false;
        intermission = false;
        buildQueue = null;
        if (finishTask != null) {
            finishTask.cancel();
            finishTask = null;
        }
        if (task != null) {
            task.cancel();
            task = null;
        }
        events.clear();
        crates.clear();
        hazards.clear();
        for (Player player : new ArrayList<>(world.getPlayers())) {
            player.getInventory().clear();
            player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
            SumoMutator.clear(player);
            player.setGameMode(GameMode.ADVENTURE);
            player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
            player.setFallDistance(0);
            player.setExp(0);
            player.setLevel(0);
            player.teleport(lobby);
            player.setVelocity(new Vector());
        }
        players.clear();
        roster.clear();
        resetArena(false);
    }

    public void shutdown() {
        if (finishTask != null) {
            finishTask.cancel();
            finishTask = null;
        }
        if (task != null) {
            task.cancel();
        }
        running = false;
        ending = false;
        intermission = false;
        events.clear();
        crates.clear();
        hazards.clear();
        world.getPlayers().forEach(SumoMutator::clear);
        resetArena(false);
    }

    // ---- The match loop -----------------------------------------------------------------------

    private void tick() {
        if (!running || ending) {
            return;
        }
        ticks++;
        if (intermission) {
            tickIntermission();
            return;
        }
        roundTicks++;
        if (roundTicks < 0) {
            tickCountdown();
            forEachPlayer(player -> {
                if (player.getLocation().getY() < arena.lowestFloor() - 4) {
                    player.teleport(spawnFor(player));
                    player.setVelocity(new Vector());
                    player.setFallDistance(0);
                }
            });
            if (ticks % 20 == 0) updateScoreboard();
            return;
        }
        if (roundTicks == 0) {
            if (voting) resolveVote();
            go();
        }
        int collapse = SumoRules.collapseIndex(mode, roundTicks);
        if (collapse >= 0 && !suddenDeath) {
            String[] announcements = {
                    "§eOuter ring collapsing!",
                    "§6Arena collapse — keep moving!",
                    "§c§lOVERDRIVE! §fKnockback increased!"
            };
            collapseTo(arena.radiusAfter(collapse), announcements[collapse]);
            if (mode == SumoRules.Mode.MARATHON) swapMutator();
        }
        int end = SumoRules.matchTicks(mode);
        if (!suddenDeath && roundTicks >= end) {
            resolveTimeUp();
            if (ending || intermission) return;
        }
        if (suddenDeath && roundTicks >= end + SumoRules.suddenDeathTicks(mode)) {
            finishRoundByStandings();
            return;
        }
        announceTimeLeft();
        tickArenaEvent();
        events.tick(arenaEvent);
        hazards.tick();
        crates.tick();
        warnCollapse();
        if (!suddenDeath && SumoRules.isCrateTick(mode, roundTicks)) {
            crates.spawnCrate();
        }
        if (SumoRules.isSphereTick(mode, roundTicks)) {
            spawnEnergyCube();
        }
        if (energyCenter != null && ticks < energyUntil) {
            if (ticks % 4 == 0) {
                drawEnergyCube();
            }
        } else if (energyCenter != null) {
            energyCenter = null;
            charge.clear();
        }
        if (!suddenDeath && SumoRules.isHeartTick(mode, roundTicks)) {
            spawnHeartCrystal();
        }
        if (heartCenter != null && ticks < heartUntil) {
            if (ticks % 4 == 0) {
                drawHeartCrystal();
            }
        } else if (heartCenter != null) {
            heartCenter = null;
            heartCharge.clear();
            broadcast(Component.text("The Heart Crystal shattered unclaimed.", NamedTextColor.GRAY));
        }

        List<Player> riftPlayers = new ArrayList<>();
        List<Player> heartPlayers = new ArrayList<>();
        for (UUID id : new ArrayList<>(players)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            if (player.getWorld() != world) continue;
            double y = player.getLocation().getY();
            if (y < arena.lowestFloor() - 4 && crates.secondWind(player)) {
                rescue(player);
                continue;
            }
            if (y < BASE_Y - 12) {
                loseLife(player);
                if (ending || intermission) return;
                continue;
            }
            boolean unshielded = respawnShieldUntil.getOrDefault(id, 0) <= ticks;
            if (energyCenter != null && insideEnergy(player.getLocation()) && unshielded) {
                riftPlayers.add(player);
            } else {
                charge.remove(id);
            }
            if (heartCenter != null && insideHeart(player.getLocation()) && unshielded) {
                heartPlayers.add(player);
            } else {
                heartCharge.remove(id);
            }
        }
        tickRiftCapture(riftPlayers);
        tickHeartCapture(heartPlayers);
        if (mutator.building && roundTicks % (5 * 20) == 0) {
            replenishWool();
        }
        if (roundTicks > 0 && roundTicks % (12 * 20) == 0) {
            rechargePowerups();
        }
        if (mutator == SumoMutator.WIND_CHARGES && roundTicks % 60 == 0) {
            forEachPlayer(player -> {
                if (countMaterial(player, Material.WIND_CHARGE) < 4) player.getInventory().addItem(ItemStack.of(Material.WIND_CHARGE));
            });
        }
        if (ticks % 10 == 0) {
            decayWool();
        }
        if (ticks % 20 == 0) {
            updateScoreboard();
            updateHud();
        }
    }

    private void beginRound(int countdown) {
        players.clear();
        for (UUID id : roster) {
            Player player = Bukkit.getPlayer(id);
            // The opening round pulls everyone in from the lobby; later rounds skip anyone who has left.
            if (player != null && player.isOnline() && (voting || player.getWorld() == world)) players.add(id);
        }
        int startLives = SumoRules.startLives(mode);
        for (UUID id : players) {
            lives.put(id, startLives);
            if (mode == SumoRules.Mode.GAUNTLET) levels.put(id, 0);
        }
        charge.clear();
        heartCharge.clear();
        respawnShieldUntil.clear();
        lastHitBy.clear();
        lastHitTick.clear();
        meleeReadyAt.clear();
        vaultCooldownUntil.clear();
        repulsorCooldownUntil.clear();
        streaks.clear();
        energyCenter = null;
        energyUntil = 0;
        heartCenter = null;
        heartUntil = 0;
        suddenDeath = false;
        arenaEvent = SumoRules.Event.CALM;
        eventUntil = 0;
        events.clear();
        crates.clear();
        hazards.begin(arena);
        arenaRadius = arena.startRadius();
        roundTicks = -countdown;
        lastCountdownSecond = -1;
        forEachPlayer(player -> {
            player.setGameMode(GameMode.ADVENTURE);
            player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
            mutator.apply(player);
            player.teleport(spawnFor(player));
            player.setVelocity(new Vector());
            player.setFallDistance(0);
            giveBaseKit(player);
            if (voting) giveVoteItems(player);
            String header = mode == SumoRules.Mode.GAUNTLET && !voting ? "§e§lROUND " + round + " §7· " : "";
            player.sendTitle(header + "§b§l" + arena.kind().label, "§dTwist: " + mutator.label + " §7· "
                    + mutator.description, 10, 50, 10);
        });
        broadcast(Component.text((voting ? "" : "Round " + round + ": "), NamedTextColor.YELLOW, TextDecoration.BOLD)
                .append(Component.text(arena.kind().label, NamedTextColor.AQUA, TextDecoration.BOLD))
                .append(Component.text(" · " + arena.kind().description, NamedTextColor.GRAY)
                        .decoration(TextDecoration.BOLD, false)));
        broadcast(Component.text("Twist: ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(mutator.label, NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD))
                .append(Component.text(" · " + mutator.description, NamedTextColor.GRAY)));
        updateScoreboard();
    }

    private void resolveVote() {
        int gauntlet = (int) votes.values().stream().filter(vote -> vote == SumoRules.Mode.GAUNTLET).count();
        int marathon = votes.size() - gauntlet;
        mode = SumoRules.resolveVote(gauntlet, marathon, players.size());
        voting = false;
        forEachPlayer(player -> {
            player.getInventory().remove(Material.LIME_DYE);
            player.getInventory().remove(Material.ORANGE_DYE);
        });
        if (mode == SumoRules.Mode.MARATHON) {
            for (UUID id : players) lives.put(id, MAX_LIVES);
        }
        broadcast(Component.text("Mode: ", NamedTextColor.WHITE)
                .append(Component.text(mode.label.toUpperCase(),
                        mode == SumoRules.Mode.GAUNTLET ? NamedTextColor.GREEN : NamedTextColor.GOLD, TextDecoration.BOLD))
                .append(Component.text(" (" + gauntlet + "–" + marathon + ") · " + mode.description, NamedTextColor.GRAY)));
        if (mode == SumoRules.Mode.MARATHON) {
            broadcast(Component.text("Heart Crystals at 3:00, 6:00 and 9:00 grant an extra life. The twist changes "
                    + "every collapse. Tied on lives at time-up? Sudden death!", NamedTextColor.LIGHT_PURPLE));
        }
    }

    private void go() {
        forEachPlayer(player -> {
            player.setGameMode(GameMode.SURVIVAL);
            String title = mode == SumoRules.Mode.GAUNTLET ? "§a§lROUND " + round + ": GO!" : "§a§lGO!";
            String subtitle = mode == SumoRules.Mode.GAUNTLET
                    ? "§f" + SumoRules.ROUND_LIVES + " lives · first to " + SumoRules.ROUND_WINS + " round wins"
                    : "§fFeather = vault · Sneak = brace against punches";
            player.sendTitle(title, subtitle, 0, 35, 10);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.7f, 1.6f);
        });
    }

    private SumoMutator drawMutator(SumoArena forArena) {
        SumoMutator drawn = mutatorBag.next(candidate -> candidate.allowedOn(forArena.kind()));
        return drawn == null ? SumoMutator.NORMAL : drawn;
    }

    /** Marathon only: a fresh twist with every collapse keeps the long match moving. */
    private void swapMutator() {
        SumoMutator previous = mutator;
        SumoMutator drawn = mutatorBag.next(candidate -> candidate.allowedOn(arena.kind()) && candidate != previous);
        if (drawn == null) return;
        mutator = drawn;
        forEachPlayer(player -> {
            mutator.apply(player);
            player.sendTitle("§d§l" + mutator.label, "§f" + mutator.description, 5, 40, 5);
            if (mutator == SumoMutator.WIND_CHARGES) player.getInventory().addItem(ItemStack.of(Material.WIND_CHARGE, 4));
        });
        broadcast(Component.text("New twist: ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(mutator.label, NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD))
                .append(Component.text(" · " + mutator.description, NamedTextColor.GRAY)));
    }

    private void tickIntermission() {
        int i = ++intermissionTicks;
        if (i == 40) {
            for (UUID id : roster) {
                Player player = Bukkit.getPlayer(id);
                if (player == null || !player.isOnline() || player.getWorld() != world) continue;
                player.getInventory().clear();
                player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
                SumoMutator.clear(player);
                player.setGameMode(GameMode.SPECTATOR);
                player.teleport(overview());
            }
            events.clear();
            crates.clear();
            hazards.clear();
            resetArena(false);
            arena = nextArena;
            mutator = nextMutator;
            arenaRadius = arena.startRadius();
            buildQueue = arena.blocks().iterator();
        }
        if (buildQueue != null) {
            for (int placed = 0; placed < BUILD_PER_TICK && buildQueue.hasNext(); placed++) {
                SumoArena.Block block = buildQueue.next();
                addBlock(block.x(), block.y(), block.z(), block.material());
            }
            if (!buildQueue.hasNext()) buildQueue = null;
        }
        if (Arrays.binarySearch(ROLL_FRAMES, i) >= 0) {
            SumoArena.Kind[] kinds = SumoArena.Kind.values();
            SumoMutator[] twists = SumoMutator.values();
            String name = kinds[random.nextInt(kinds.length)].label;
            String twist = twists[random.nextInt(twists.length)].label;
            float pitch = 0.8f + (i - 44) * 0.018f;
            forEachRoster(player -> {
                player.sendTitle("§7" + name, "§8" + twist, 0, 10, 0);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, pitch);
            });
        }
        if (i == 100) {
            forEachRoster(player -> {
                player.sendTitle("§b§l" + arena.kind().label, "§dTwist: " + mutator.label, 0, 40, 10);
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
            });
        }
        if (i % 20 == 0) updateScoreboard();
        if (i >= SumoRules.INTERMISSION_TICKS && buildQueue == null && nextArena != null) {
            intermission = false;
            round++;
            beginRound(SumoRules.ROUND_COUNTDOWN_TICKS);
        }
    }

    private void forEachRoster(Consumer<Player> action) {
        for (UUID id : new ArrayList<>(roster)) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline() && player.getWorld() == world) action.accept(player);
        }
    }

    private void announceTimeLeft() {
        if (suddenDeath) return;
        int left = SumoRules.matchTicks(mode) - roundTicks;
        if (mode == SumoRules.Mode.MARATHON && (left == 5 * 60 * 20 || left == 60 * 20 || left == 30 * 20)) {
            String text = left >= 60 * 20 ? (left / 1200) + (left == 1200 ? " minute" : " minutes") : "30 seconds";
            broadcast(Component.text(text + " left!", NamedTextColor.YELLOW, TextDecoration.BOLD));
            forEachPlayer(player -> player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.2f));
        } else if (mode == SumoRules.Mode.GAUNTLET && left == 30 * 20) {
            broadcast(Component.text("30 seconds left in the round!", NamedTextColor.YELLOW, TextDecoration.BOLD));
            forEachPlayer(player -> player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.2f));
        } else if (left > 0 && left <= 10 * 20 && left % 20 == 0) {
            int seconds = left / 20;
            String rule = mode == SumoRules.Mode.GAUNTLET ? "§7Most lives takes the round" : "§7Most lives wins · ties go to sudden death";
            forEachPlayer(player -> {
                player.sendTitle("§c" + seconds, rule, 0, 22, 0);
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1.0f + (10 - seconds) * 0.08f);
            });
        }
    }

    private void tickArenaEvent() {
        if (arenaEvent != SumoRules.Event.CALM && (roundTicks >= eventUntil || suddenDeath)) {
            SumoRules.Event previous = arenaEvent;
            arenaEvent = SumoRules.Event.CALM;
            events.stop(previous);
            if (!suddenDeath) broadcast(Component.text("Arena event finished. Keep brawling!", NamedTextColor.GRAY));
        }
        if (suddenDeath || arenaEvent != SumoRules.Event.CALM || !SumoRules.eventStarts(mode, roundTicks)) return;
        SumoRules.Event next = eventBag.next(event -> SumoRules.eventAllowed(event, mode, arena.kind(), mutator));
        if (next == null) return;
        arenaEvent = next;
        eventUntil = roundTicks + SumoRules.EVENT_LENGTH;
        events.start(next);
        if (next == SumoRules.Event.SKY_RUSH) vaultCooldownUntil.clear();
        if (next == SumoRules.Event.DOUBLE_CHARGE && energyCenter == null) spawnEnergyCube();
        String description = events.description(next);
        broadcast(Component.text(description, NamedTextColor.GOLD));
        forEachPlayer(player -> {
            player.sendTitle("§d" + next.label, "§f" + description, 5, 40, 5);
            player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 1.4f);
        });
    }

    private void warnCollapse() {
        if (suddenDeath) return;
        int index = SumoRules.nextCollapseIndex(mode, roundTicks);
        if (index < 0) return;
        int left = SumoRules.nextCollapseTick(mode, roundTicks) - roundTicks;
        int warning = mode == SumoRules.Mode.GAUNTLET ? 100 : 200;
        if (left > warning) return;
        int radius = arena.radiusAfter(index);
        if (left == warning || left == 60) {
            broadcast(Component.text("Collapse in " + left / 20 + "s! Get inside the orange ring!", NamedTextColor.GOLD));
            forEachPlayer(player -> player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 0.7f));
        }
        if (roundTicks % 10 == 0) {
            drawRing(radius);
        }
    }

    private void drawRing(int radius) {
        double y = arena.spawns().stream().mapToInt(spawn -> spawn[1]).max().orElse(BASE_Y + 7) + 0.5;
        for (int i = 0; i < 48; i++) {
            double angle = i * Math.PI * 2 / 48;
            world.spawnParticle(Particle.FLAME, new Location(world, Math.cos(angle) * radius + 0.5,
                    y, Math.sin(angle) * radius + 0.5), 1, 0, 1.5, 0, 0);
        }
    }

    private void updateHud() {
        forEachPlayer(player -> {
            UUID id = player.getUniqueId();
            boolean unshielded = respawnShieldUntil.getOrDefault(id, 0) <= ticks;
            if (unshielded && ((energyCenter != null && insideEnergy(player.getLocation()))
                    || (heartCenter != null && insideHeart(player.getLocation())))) return;
            int shield = respawnShieldUntil.getOrDefault(id, 0) - ticks;
            String vault = abilityStatus(vaultCooldownUntil.getOrDefault(id, 0));
            String repulsor = levels.getOrDefault(id, 0) >= 3
                    ? "  |  Blast " + abilityStatus(repulsorCooldownUntil.getOrDefault(id, 0)) : "";
            String rift = energyCenter == null ? "" : "  |  Rift " + Math.round(player.getLocation().distance(energyCenter)) + "m";
            String heart = heartCenter == null ? "" : "  |  ❤ Crystal " + Math.round(player.getLocation().distance(heartCenter)) + "m";
            String wind = arenaEvent == SumoRules.Event.GALE ? "  |  Wind " + events.galeName() : "";
            String bubble = crates.bubbled(player) ? "  |  BUBBLE" : "";
            int streak = streaks.getOrDefault(id, 0);
            String bounty = streak >= SumoRules.BOUNTY_STREAK ? "  |  BOUNTY x" + streak : "";
            player.sendActionBar(Component.text(shield > 0 ? "SHIELD " + formatCooldown(shield)
                    : "♥ " + lives.getOrDefault(id, 0) + "  |  Vault " + vault + repulsor + rift + heart + wind + bubble + bounty,
                    NamedTextColor.AQUA));
        });
    }

    private String abilityStatus(int until) {
        return until > ticks ? formatCooldown(until - ticks) : "READY";
    }

    /** Second Wind: back to a safe spawn, knockout denied. */
    private void rescue(Player player) {
        UUID id = player.getUniqueId();
        UUID attackerId = lastHitBy.remove(id);
        lastHitTick.remove(id);
        player.teleport(spawnFor(player));
        player.setVelocity(new Vector(0, 0.4, 0));
        player.setFallDistance(0);
        respawnShieldUntil.put(id, ticks + 30);
        player.sendTitle("§b§lSECOND WIND", "§fSaved from the void", 0, 30, 8);
        world.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 0.7f, 1.4f);
        Particle.TOTEM_OF_UNDYING.builder().location(player.getLocation().add(0, 1, 0)).count(30)
                .offset(0.4, 0.8, 0.4).extra(0.3).receivers(64, true).spawn();
        Player attacker = attackerId == null ? null : Bukkit.getPlayer(attackerId);
        if (attacker != null) {
            attacker.sendActionBar(Component.text(player.getName() + " used Second Wind!", NamedTextColor.RED));
        }
        broadcast(Component.text(player.getName() + " was saved by Second Wind!", NamedTextColor.AQUA));
    }

    private void loseLife(Player player) {
        UUID id = player.getUniqueId();
        int remaining = lives.getOrDefault(id, MAX_LIVES) - 1;
        lives.put(id, remaining);
        falls.merge(id, 1, Integer::sum);
        charge.remove(id);
        heartCharge.remove(id);
        vaultCooldownUntil.remove(id);
        repulsorCooldownUntil.remove(id);
        int victimStreak = streaks.getOrDefault(id, 0);
        streaks.remove(id);
        UUID attackerId = lastHitBy.remove(id);
        int hitAt = lastHitTick.getOrDefault(id, -1);
        lastHitTick.remove(id);
        meleeReadyAt.remove(id);
        Player attacker = attackerId == null ? null : Bukkit.getPlayer(attackerId);
        if (attacker != null && players.contains(attackerId) && !attackerId.equals(id)
                && SumoRules.recentHit(ticks, hitAt)) {
            creditKnockout(attacker, player, victimStreak);
        } else {
            broadcast(Component.text(player.getName() + " fell into the void.", NamedTextColor.GRAY));
        }
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        if (remaining <= 0) {
            eliminate(player, mode == SumoRules.Mode.GAUNTLET ? "§7Back next round"
                    : "§7Knocked out with " + eliminations.getOrDefault(id, 0) + " knockouts");
        } else {
            int oldLevel = levels.getOrDefault(id, 0);
            int newLevel = oldLevel;
            if (mode == SumoRules.Mode.MARATHON) {
                int leader = players.stream().filter(other -> !other.equals(id))
                        .mapToInt(other -> levels.getOrDefault(other, 0)).max().orElse(0);
                newLevel = SumoRules.comebackLevel(oldLevel, leader);
                levels.put(id, newLevel);
            }
            player.teleport(spawnFor(player));
            player.setVelocity(new Vector());
            giveBaseKit(player);
            respawnShieldUntil.put(id, ticks + RESPAWN_SHIELD_TICKS);
            player.sendTitle("§c§l-1 LIFE", "§f" + remaining + " left · 3s shield"
                    + (newLevel > oldLevel ? " · Comeback Power +1!" : ""), 5, 40, 5);
        }
        updateScoreboard();
    }

    private void creditKnockout(Player attacker, Player victim, int victimStreak) {
        UUID attackerId = attacker.getUniqueId();
        eliminations.merge(attackerId, 1, Integer::sum);
        int streak = streaks.merge(attackerId, 1, Integer::sum);
        bestStreaks.merge(attackerId, streak, Math::max);
        vaultCooldownUntil.remove(attackerId);
        topUp(attacker, Material.SNOWBALL, 12, 4);
        attacker.playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.6f);
        broadcast(Component.text(attacker.getName() + " knocked " + victim.getName() + " into the void!",
                NamedTextColor.YELLOW));
        if (victimStreak >= SumoRules.BOUNTY_STREAK) {
            claimBounty(attacker, victim, victimStreak);
        } else {
            String callout = SumoRules.streakCallout(streak);
            attacker.sendTitle("§6" + (callout == null ? "KNOCKOUT!" : callout + "!"), "§f+4 bolts · Vault ready", 0, 25, 5);
        }
        String callout = SumoRules.streakCallout(streak);
        if (callout != null) {
            broadcast(Component.text("★ " + attacker.getName() + ": " + callout + " (" + streak + " in a row)",
                    NamedTextColor.GOLD, TextDecoration.BOLD));
        }
        if (streak == SumoRules.BOUNTY_STREAK) {
            attacker.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, true, false, false));
            broadcast(Component.text("A bounty is on " + attacker.getName()
                    + "! Knock them out for a free power level.", NamedTextColor.RED));
            forEachPlayer(player -> player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.35f, 1.8f));
        }
    }

    private void claimBounty(Player hunter, Player target, int targetStreak) {
        UUID id = hunter.getUniqueId();
        int level = levels.getOrDefault(id, 0);
        if (level < MAX_LEVEL) {
            levels.put(id, ++level);
            grantReward(hunter, level);
        } else {
            grantOvercharge(hunter);
        }
        hunter.sendTitle("§c§lBOUNTY CLAIMED", "§fEnded a " + targetStreak + "-knockout streak", 0, 40, 5);
        broadcast(Component.text(hunter.getName() + " ended " + target.getName() + "'s " + targetStreak
                + "-knockout rampage and claimed the bounty!", NamedTextColor.RED, TextDecoration.BOLD));
        forEachPlayer(player -> player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.6f, 1.2f));
    }

    /** Takes a player out: for this round in Gauntlet, for the match in Marathon. */
    private void eliminate(Player player, String subtitle) {
        UUID id = player.getUniqueId();
        players.remove(id);
        lives.put(id, 0);
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        SumoMutator.clear(player);
        player.setVelocity(new Vector());
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20);
        player.setFallDistance(0);
        if (mode == SumoRules.Mode.GAUNTLET) {
            broadcast(Component.text(player.getName() + " is out of the round!", NamedTextColor.RED));
            player.setGameMode(GameMode.SPECTATOR);
            player.teleport(overview());
            player.sendTitle("§c§lOUT THIS ROUND", subtitle, 5, 40, 10);
            checkEnd();
            return;
        }
        knockedOut.add(id);
        broadcast(Component.text(player.getName() + " is out!", NamedTextColor.RED));
        if (!players.isEmpty() && plugin.getLobbyManager() != null) {
            plugin.getLobbyManager().spectate(player, GameType.BLOCK_SUMO);
        } else {
            player.setGameMode(GameMode.ADVENTURE);
            player.teleport(lobby);
            player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        }
        player.sendTitle("§c§lELIMINATED", subtitle, 5, 50, 10);
        checkEnd();
    }

    private void tickCountdown() {
        int seconds = (int) Math.ceil(-roundTicks / 20.0);
        if (seconds != lastCountdownSecond) {
            lastCountdownSecond = seconds;
            String subtitle = voting ? "§7Right-click a dye to vote: §aGauntlet §7or §6Marathon" : "§7Get ready...";
            forEachPlayer(player -> {
                if (!voting || seconds <= 5) player.sendTitle("§b§l" + Math.max(1, seconds), subtitle, 0, 22, 0);
                else player.sendActionBar(Component.text("Vote: lime dye = Gauntlet, orange dye = Marathon · "
                        + seconds + "s", NamedTextColor.YELLOW));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.8f,
                        1.0f + (5 - Math.min(5, Math.max(1, seconds))) * 0.1f);
            });
        }
    }

    private void tickRiftCapture(List<Player> occupants) {
        if (energyCenter == null || occupants.isEmpty()) {
            return;
        }
        if (occupants.size() > 1) {
            occupants.forEach(player -> player.sendActionBar(
                    Component.text("⚔ RIFT CONTESTED ⚔", NamedTextColor.RED, TextDecoration.BOLD)));
            return;
        }
        Player player = occupants.getFirst();
        UUID id = player.getUniqueId();
        int level = levels.getOrDefault(id, 0);
        int needed = SumoRules.captureTicks(level);
        int value = charge.merge(id, arenaEvent == SumoRules.Event.DOUBLE_CHARGE ? 2 : 1, Integer::sum);
        player.sendActionBar(energyBar(level, value, needed));
        if (value >= needed) {
            charge.put(id, 0);
            spheres.merge(id, 1, Integer::sum);
            boolean upgraded = level < MAX_LEVEL;
            if (upgraded) {
                levels.put(id, ++level);
                grantReward(player, level);
            } else {
                grantOvercharge(player);
            }
            energyCenter = null;
            charge.clear();
            world.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.2f, 1.5f);
            broadcast(Component.text(player.getName() + (upgraded
                            ? " captured the sphere and reached Power " + level + "!"
                            : " overloaded the sphere and recharged every power!"),
                    NamedTextColor.LIGHT_PURPLE));
            updateScoreboard();
        }
    }

    /** Pickup spots still standing inside the current radius, as {x, surfaceY, z}. */
    List<int[]> survivingSpots() {
        List<int[]> available = new ArrayList<>();
        for (int[] spot : arena.spots()) {
            if (Math.hypot(spot[0], spot[2]) <= arenaRadius - 1.0
                    && world.getBlockAt(spot[0], spot[1], spot[2]).getType().isSolid()
                    && world.getBlockAt(spot[0], spot[1] + 1, spot[2]).getType().isAir()) {
                available.add(spot.clone());
            }
        }
        return available;
    }

    private void spawnHeartCrystal() {
        List<int[]> available = survivingSpots();
        if (energyCenter != null && available.size() > 1) {
            available.removeIf(spot -> Math.abs(spot[0] + 0.5 - energyCenter.getX()) < 1
                    && Math.abs(spot[2] + 0.5 - energyCenter.getZ()) < 1);
        }
        if (available.isEmpty()) {
            return;
        }
        int[] spot = available.get(random.nextInt(available.size()));
        heartCenter = new Location(world, spot[0] + 0.5, spot[1] + 1.5, spot[2] + 0.5);
        heartUntil = ticks + HEART_DURATION;
        heartCharge.clear();
        world.strikeLightningEffect(heartCenter);
        broadcast(Component.text("❤ A Heart Crystal appeared! Stand on it alone for 2 seconds to gain a life.",
                NamedTextColor.RED, TextDecoration.BOLD));
        forEachPlayer(player -> {
            player.sendTitle("§c❤ HEART CRYSTAL", "§fClaim it alone for an extra life", 5, 40, 5);
            player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 1f, 1.2f);
        });
    }

    private void drawHeartCrystal() {
        List<Player> viewers = Fx.near(heartCenter, 64);
        double rotation = ticks * 0.12;
        for (int i = 0; i < 12; i++) {
            double angle = Math.PI * 2 * i / 12.0 + rotation;
            Particle.DUST.builder().location(heartCenter.clone().add(Math.cos(angle) * 2.0,
                    -1.3 + Math.sin(rotation + i) * 0.2, Math.sin(angle) * 2.0))
                    .count(1).data(HEART_RED).receivers(viewers).spawn();
        }
        Particle.HEART.builder().location(heartCenter.clone().add(0, 0.6 + Math.sin(rotation) * 0.3, 0))
                .count(1).offset(0.3, 0.2, 0.3).receivers(viewers).spawn();
        if (ticks % 20 == 0) {
            world.playSound(heartCenter, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 0.8f);
        }
    }

    private boolean insideHeart(Location location) {
        return location.getWorld() == world
                && Math.hypot(location.getX() - heartCenter.getX(), location.getZ() - heartCenter.getZ()) <= 2.2
                && Math.abs(location.getY() + 1.5 - heartCenter.getY()) <= 2.0;
    }

    private void tickHeartCapture(List<Player> occupants) {
        if (heartCenter == null || occupants.isEmpty()) {
            return;
        }
        if (occupants.size() > 1) {
            occupants.forEach(player -> player.sendActionBar(
                    Component.text("❤ CRYSTAL CONTESTED ❤", NamedTextColor.RED, TextDecoration.BOLD)));
            return;
        }
        Player player = occupants.getFirst();
        UUID id = player.getUniqueId();
        int value = heartCharge.merge(id, 1, Integer::sum);
        int filled = Math.min(10, value * 10 / HEART_CLAIM_TICKS);
        player.sendActionBar(Component.text("❤ CLAIMING " + "■".repeat(filled), NamedTextColor.RED)
                .append(Component.text("□".repeat(10 - filled), NamedTextColor.DARK_GRAY)));
        if (value < HEART_CLAIM_TICKS) {
            return;
        }
        heartCenter = null;
        heartCharge.clear();
        int current = lives.getOrDefault(id, 0);
        if (current < SumoRules.LIFE_CAP) {
            lives.put(id, current + 1);
            player.sendTitle("§c§l+1 LIFE", "§f" + (current + 1) + " lives", 5, 35, 5);
            broadcast(Component.text(player.getName() + " claimed the Heart Crystal: +1 life!", NamedTextColor.RED));
        } else {
            grantOvercharge(player);
            broadcast(Component.text(player.getName() + " claimed the Heart Crystal at full lives and overloaded!",
                    NamedTextColor.RED));
        }
        world.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 0.7f, 1.3f);
        Particle.TOTEM_OF_UNDYING.builder().location(player.getLocation().add(0, 1, 0)).count(40)
                .offset(0.5, 0.8, 0.5).extra(0.3).receivers(64, true).spawn();
        updateScoreboard();
    }

    private boolean isShielded(Player player) {
        int until = respawnShieldUntil.getOrDefault(player.getUniqueId(), 0);
        if (until <= ticks) {
            respawnShieldUntil.remove(player.getUniqueId());
            return false;
        }
        player.sendActionBar(Component.text("RESPAWN SHIELD", NamedTextColor.AQUA));
        return true;
    }

    private void replenishWool() {
        forEachPlayer(player -> {
            Material color = woolColors.getOrDefault(player.getUniqueId(), Material.WHITE_WOOL);
            int amount = countMaterial(player, color);
            if (amount < 24) {
                player.getInventory().addItem(ItemStack.of(color, Math.min(12, 24 - amount)));
                player.sendActionBar(Component.text("+ WOOL", NamedTextColor.GREEN));
            }
        });
    }

    /** Old player wool cracks for five seconds, then crumbles, so forts cannot stall a long match. */
    private void decayWool() {
        boolean crackFrame = ticks % 20 == 0;
        for (Iterator<Map.Entry<Location, Integer>> iterator = placedWool.entrySet().iterator(); iterator.hasNext(); ) {
            Map.Entry<Location, Integer> entry = iterator.next();
            int age = ticks - entry.getValue();
            if (age < SumoRules.WOOL_LIFETIME - SumoRules.WOOL_WARNING) continue;
            Block block = entry.getKey().getBlock();
            if (!block.getType().name().endsWith("_WOOL")) {
                iterator.remove();
                continue;
            }
            Location center = entry.getKey().clone().add(0.5, 0.5, 0.5);
            if (age >= SumoRules.WOOL_LIFETIME) {
                Particle.BLOCK.builder().location(center).count(10).offset(0.3, 0.3, 0.3)
                        .data(block.getBlockData()).receivers(32, true).spawn();
                if (random.nextInt(4) == 0) world.playSound(center, Sound.BLOCK_WOOL_BREAK, 0.6f, 0.8f);
                block.setType(Material.AIR, false);
                iterator.remove();
            } else if (crackFrame) {
                Particle.BLOCK.builder().location(center).count(3).offset(0.35, 0.35, 0.35)
                        .data(block.getBlockData()).receivers(32, true).spawn();
            }
        }
    }

    private void rechargePowerups() {
        forEachPlayer(player -> {
            int level = levels.getOrDefault(player.getUniqueId(), 0);
            topUp(player, Material.SNOWBALL, level >= 1 ? 12 : 6, level >= 1 ? 4 : 2);
            if (level >= 4) {
                topUp(player, Material.ENDER_PEARL, 2, 1);
            }
        });
    }

    private void topUp(Player player, Material material, int maximum, int refill) {
        int amount = countMaterial(player, material);
        if (amount < maximum) {
            int added = Math.min(refill, maximum - amount);
            player.getInventory().addItem(powerStack(material, added));
            player.sendActionBar(Component.text("ENERGY RECHARGE  +" + added + " "
                    + (material == Material.SNOWBALL ? "RIFT BOLTS" : "PHASE PEARL"), NamedTextColor.AQUA));
        }
    }

    private int countMaterial(Player player, Material material) {
        int amount = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == material) {
                amount += item.getAmount();
            }
        }
        return amount;
    }

    private void spawnEnergyCube() {
        List<int[]> available = survivingSpots();
        if (heartCenter != null && available.size() > 1) {
            available.removeIf(spot -> Math.abs(spot[0] + 0.5 - heartCenter.getX()) < 1
                    && Math.abs(spot[2] + 0.5 - heartCenter.getZ()) < 1);
        }
        if (available.isEmpty()) {
            return;
        }
        int[] spot = available.get(random.nextInt(available.size()));
        energyCenter = new Location(world, spot[0] + 0.5, spot[1] + 2.5, spot[2] + 0.5);
        energyUntil = ticks + ENERGY_DURATION;
        charge.clear();
        world.strikeLightningEffect(energyCenter);
        world.playSound(energyCenter, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1.5f);
        broadcast(Component.text("An Energy Sphere ignited for 10 seconds. Hold it alone!",
                NamedTextColor.LIGHT_PURPLE));
    }

    private void drawEnergyCube() {
        // Viewers are found once per frame (not once per particle), and 16 points per ring keep the
        // rotating shape while sending a third fewer packets.
        List<Player> viewers = Fx.near(energyCenter, 48);
        if (viewers.isEmpty()) {
            return;
        }
        double rotation = ticks * 0.08;
        for (int i = 0; i < 16; i++) {
            double angle = Math.PI * 2 * i / 16.0 + rotation;
            double wave = Math.sin(angle * 2 + rotation) * 0.65;
            Particle.END_ROD.builder().location(energyCenter.clone().add(Math.cos(angle) * 3.0, wave,
                    Math.sin(angle) * 3.0)).count(1).receivers(viewers).spawn();
            Particle.ELECTRIC_SPARK.builder().location(energyCenter.clone().add(Math.cos(angle) * 2.15,
                    Math.sin(angle) * 2.15, Math.sin(rotation) * 0.35)).count(1).receivers(viewers).spawn();
        }
        Particle.REVERSE_PORTAL.builder().location(energyCenter).count(12).offset(1.2, 1.2, 1.2)
                .extra(0.05).receivers(viewers).spawn();
    }

    private boolean insideEnergy(Location location) {
        return location.getWorld() == world
                && Math.hypot(location.getX() - energyCenter.getX(), location.getZ() - energyCenter.getZ()) <= 3.4
                && Math.abs(location.getY() - energyCenter.getY()) <= 3.0;
    }

    private Component energyBar(int level, int progress, int needed) {
        int filled = Math.min(10, (int) Math.ceil(progress * 10.0 / needed));
        return Component.text("ENERGY " + "■".repeat(filled), NamedTextColor.LIGHT_PURPLE)
                .append(Component.text("□".repeat(10 - filled), NamedTextColor.DARK_GRAY))
                .append(Component.text("  Power " + level + "/" + MAX_LEVEL, NamedTextColor.WHITE));
    }

    private void grantReward(Player player, int level) {
        switch (level) {
            case 1 -> topUp(player, Material.SNOWBALL, 12, 12);
            case 2 -> {
                Set<Integer> slots = new HashSet<>(player.getInventory().all(Material.FEATHER).keySet());
                if (slots.isEmpty()) player.getInventory().addItem(vaultItem(2));
                else slots.forEach(slot -> player.getInventory().setItem(slot, vaultItem(2)));
                vaultCooldownUntil.remove(player.getUniqueId());
            }
            case 3 -> player.getInventory().addItem(powerItem(Material.HEART_OF_THE_SEA, "Rift Repulsor",
                    "Right-click: blast every nearby rival away", "12 second cooldown"));
            case 4 -> player.getInventory().addItem(powerStack(Material.ENDER_PEARL, 2));
            case 5 -> {
                player.getInventory().addItem(powerItem(Material.BLAZE_ROD, "Overdrive Scepter",
                        "Massive melee knockback", "Also grants Speed I and Jump Boost I"));
                applyOverdrive(player);
            }
            default -> { }
        }
        String[] names = {"", "HEAVY RIFT BOLTS", "QUICK VAULT", "RIFT REPULSOR", "PHASE PEARLS", "OVERDRIVE"};
        player.sendTitle("§d§lPOWER " + level, "§fUnlocked: §b" + names[level], 5, 40, 5);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f + level * 0.04f);
    }

    private void grantOvercharge(Player player) {
        topUp(player, Material.SNOWBALL, 16, 16);
        topUp(player, Material.ENDER_PEARL, 3, 3);
        vaultCooldownUntil.remove(player.getUniqueId());
        repulsorCooldownUntil.remove(player.getUniqueId());
        player.sendTitle("§f§lSPHERE OVERLOAD", "§bAmmo full · cooldowns reset", 5, 35, 5);
    }

    private ItemStack named(Material material, String name) {
        ItemStack item = ItemStack.of(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack powerItem(Material material, String name, String... loreLines) {
        ItemStack item = named(material, name);
        ItemMeta meta = item.getItemMeta();
        List<Component> lore = new ArrayList<>();
        for (String line : loreLines) {
            lore.add(Component.text(line, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack powerStack(Material material, int amount) {
        ItemStack item;
        if (material == Material.SNOWBALL) {
            item = powerItem(material, "Rift Bolt", "Heavy ranged knockback", "Regenerates every 12 seconds");
        } else if (material == Material.ENDER_PEARL) {
            item = powerItem(material, "Phase Pearl", "Emergency escape or high-ground attack",
                    "Regenerates every 12 seconds");
        } else {
            item = ItemStack.of(material);
        }
        item.setAmount(amount);
        return item;
    }

    private void giveBaseKit(Player player) {
        player.getInventory().clear();
        player.getInventory().setHeldItemSlot(0);
        player.setAllowFlight(false);
        player.setFireTicks(0);
        player.setFallDistance(0);
        player.setExp(0);
        player.setLevel(0);
        if (mutator.building) {
            Material color = woolColors.getOrDefault(player.getUniqueId(), Material.WHITE_WOOL);
            player.getInventory().setItemInMainHand(ItemStack.of(color, 48));
            ItemStack shears = named(Material.SHEARS, "Builder's Shears");
            ItemMeta shearsMeta = shears.getItemMeta();
            shearsMeta.setUnbreakable(true);
            shears.setItemMeta(shearsMeta);
            player.getInventory().setItem(1, shears);
        }
        player.setHealth(20);
        player.setFoodLevel(20);
        player.setSaturation(20);
        int level = levels.getOrDefault(player.getUniqueId(), 0);
        player.getInventory().setItem(2, powerStack(Material.SNOWBALL, level >= 1 ? 12 : 6));
        player.getInventory().setItem(3, vaultItem(level));
        if (level >= 3) {
            player.getInventory().setItem(4, powerItem(Material.HEART_OF_THE_SEA, "Rift Repulsor",
                    "Right-click: blast every nearby rival away", "12 second cooldown"));
        }
        if (level >= 4) {
            player.getInventory().setItem(5, powerStack(Material.ENDER_PEARL, 2));
        }
        if (level >= 5) {
            player.getInventory().setItem(6, powerItem(Material.BLAZE_ROD, "Overdrive Scepter",
                    "Massive melee knockback", "Also grants Speed I and Jump Boost I"));
            applyOverdrive(player);
        }
        if (mutator == SumoMutator.WIND_CHARGES) {
            player.getInventory().addItem(ItemStack.of(Material.WIND_CHARGE, 4));
        }
    }

    private void giveVoteItems(Player player) {
        ItemStack gauntlet = powerItem(Material.LIME_DYE, "Vote: Gauntlet", SumoRules.Mode.GAUNTLET.description);
        ItemStack marathon = powerItem(Material.ORANGE_DYE, "Vote: Marathon", SumoRules.Mode.MARATHON.description);
        player.getInventory().setItem(7, gauntlet);
        player.getInventory().setItem(8, marathon);
    }

    private ItemStack vaultItem(int level) {
        return powerItem(Material.FEATHER, level >= 2 ? "Quick Vault" : "Kinetic Vault",
                "Right-click: launch forward and upward", "Save yourself after a hit!",
                level >= 2 ? "6 second cooldown" : "10 second cooldown · Power 2 upgrades to 6s");
    }

    private void useKineticVault(Player player) {
        UUID id = player.getUniqueId();
        int remaining = vaultCooldownUntil.getOrDefault(id, 0) - ticks;
        if (remaining > 0) {
            player.sendActionBar(Component.text("KINETIC VAULT  " + formatCooldown(remaining), NamedTextColor.RED));
            return;
        }
        Vector direction = player.getLocation().getDirection().setY(0);
        if (direction.lengthSquared() < 0.01) {
            direction.setX(1);
        }
        player.setVelocity(direction.normalize().multiply(1.25).setY(0.9));
        player.setFallDistance(0);
        vaultCooldownUntil.put(id, ticks + SumoRules.vaultCooldown(
                levels.getOrDefault(id, 0), arenaEvent));
        Particle.CLOUD.builder().location(player.getLocation().add(0, 0.2, 0)).count(20)
                .offset(0.5, 0.1, 0.5).extra(0.08).receivers(48, true).spawn();
        world.playSound(player.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1f, 1.25f);
        player.sendActionBar(Component.text("KINETIC VAULT!", NamedTextColor.AQUA, TextDecoration.BOLD));
    }

    private void useRepulsor(Player player) {
        UUID id = player.getUniqueId();
        int remaining = repulsorCooldownUntil.getOrDefault(id, 0) - ticks;
        if (remaining > 0) {
            player.sendActionBar(Component.text("RIFT REPULSOR  " + formatCooldown(remaining), NamedTextColor.RED));
            return;
        }
        List<Player> targets = alivePlayers().stream()
                .filter(other -> !other.equals(player))
                .filter(other -> other.getLocation().distanceSquared(player.getLocation()) <= 8 * 8)
                .filter(other -> !immune(other))
                .toList();
        if (targets.isEmpty()) {
            player.sendActionBar(Component.text("No rival is in repulsor range", NamedTextColor.GRAY));
            return;
        }
        for (Player target : targets) {
            Vector blast = target.getLocation().toVector().subtract(player.getLocation().toVector()).setY(0);
            if (blast.lengthSquared() < 0.01) {
                blast.setX(1);
            }
            knock(target, blast.normalize().multiply(1.65).setY(0.62), player);
        }
        repulsorCooldownUntil.put(id, ticks + 12 * 20);
        Particle.SONIC_BOOM.builder().location(player.getLocation().add(0, 1, 0)).count(1)
                .receivers(64, true).spawn();
        Particle.ELECTRIC_SPARK.builder().location(player.getLocation().add(0, 1, 0)).count(45)
                .offset(3.0, 1.2, 3.0).extra(0.15).receivers(64, true).spawn();
        world.playSound(player.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 1.6f);
        player.sendActionBar(Component.text("RIFT REPULSOR  » " + targets.size() + " HIT",
                NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
    }

    private String formatCooldown(int remainingTicks) {
        return String.format("%.1fs", remainingTicks / 20.0);
    }

    private void applyOverdrive(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0,
                true, false, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 0,
                true, false, true));
    }

    // ---- Arena building -----------------------------------------------------------------------

    private void buildNow(SumoArena layout) {
        for (SumoArena.Block block : layout.blocks()) {
            addBlock(block.x(), block.y(), block.z(), block.material());
        }
        arenaRadius = layout.startRadius();
    }

    private void collapseTo(int radius, String announcement) {
        arenaRadius = radius;
        if (energyCenter != null && Math.hypot(energyCenter.getX() - 0.5, energyCenter.getZ() - 0.5) > radius) {
            energyCenter = null;
            charge.clear();
        }
        if (heartCenter != null && Math.hypot(heartCenter.getX() - 0.5, heartCenter.getZ() - 0.5) > radius) {
            heartCenter = null;
            heartCharge.clear();
        }
        broadcast(Component.text(announcement));
        world.playSound(new Location(world, 0, BASE_Y, 0), Sound.ENTITY_WITHER_BREAK_BLOCK, 2f, 0.7f);
        for (Location location : new ArrayList<>(arenaBlocks)) {
            if (Math.hypot(location.getBlockX(), location.getBlockZ()) > radius + 0.4) {
                location.getBlock().setType(Material.AIR, false);
                arenaBlocks.remove(location);
                if (random.nextInt(7) == 0) {
                    Particle.LARGE_SMOKE.builder().location(location.clone().add(0.5, 0.5, 0.5))
                            .count(2).receivers(48, true).spawn();
                }
            }
        }
        for (Location location : new ArrayList<>(placedWool.keySet())) {
            if (Math.hypot(location.getBlockX(), location.getBlockZ()) > radius + 3.0) {
                location.getBlock().setType(Material.AIR, false);
                placedWool.remove(location);
            }
        }
    }

    private void addBlock(int x, int y, int z, Material material) {
        Location location = new Location(world, x, y, z);
        location.getBlock().setType(material, false);
        arenaBlocks.add(location);
    }

    /**
     * Chooses the arena spawn furthest from every other living player and clears it out,
     * so nobody ever drops in on top of an opponent or inside somebody's wool tower.
     */
    Location spawnFor(Player self) {
        Location best = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (int[] spot : arena.spawns()) {
            Location candidate = new Location(world, spot[0] + 0.5, spot[1], spot[2] + 0.5);
            if (Math.hypot(candidate.getX() - 0.5, candidate.getZ() - 0.5) > arenaRadius - 0.5) {
                continue;
            }
            // Cap the distance reward so a far-but-blocked spawn never beats a clear one.
            double score = Math.min(nearestPlayerDistance(candidate, self), MIN_SPAWN_SEPARATION * 2);
            if (!hasHeadroom(candidate)) {
                score -= 100;
            }
            if (!world.getBlockAt(candidate.getBlockX(), candidate.getBlockY() - 1,
                    candidate.getBlockZ()).getType().isSolid()) {
                score -= 100;
            }
            if (score > bestScore) {
                bestScore = score;
                best = candidate;
            }
        }
        if (best == null) {
            int[] center = arena.spawns().stream().min(Comparator.comparingDouble(spot -> Math.hypot(spot[0], spot[2])))
                    .orElse(new int[]{0, BASE_Y + 7, 0});
            best = new Location(world, center[0] + 0.5, center[1], center[2] + 0.5);
        }
        return prepareSpawn(best);
    }

    private double nearestPlayerDistance(Location spot, Player self) {
        double nearest = Double.MAX_VALUE;
        for (UUID id : players) {
            if (id.equals(self.getUniqueId())) {
                continue;
            }
            Player other = Bukkit.getPlayer(id);
            if (other == null || !other.isOnline() || other.getWorld() != world
                    || other.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            nearest = Math.min(nearest, other.getLocation().distance(spot));
        }
        return nearest;
    }

    private boolean hasHeadroom(Location spot) {
        int x = spot.getBlockX();
        int y = spot.getBlockY();
        int z = spot.getBlockZ();
        return world.getBlockAt(x, y, z).getType().isAir()
                && world.getBlockAt(x, y + 1, z).getType().isAir();
    }

    private Location prepareSpawn(Location spot) {
        int x = spot.getBlockX();
        int y = spot.getBlockY();
        int z = spot.getBlockZ();
        for (int dy = 0; dy < 2; dy++) {
            Block body = world.getBlockAt(x, y + dy, z);
            if (!body.getType().isAir()) {
                placedWool.remove(body.getLocation());
                arenaBlocks.remove(body.getLocation());
                body.setType(Material.AIR, false);
            }
        }
        Block floor = world.getBlockAt(x, y - 1, z);
        if (!floor.getType().isSolid()) {
            addBlock(x, y - 1, z, Material.POLISHED_BLACKSTONE);
        }
        Location location = new Location(world, x + 0.5, y, z + 0.5);
        // Face the middle of the arena.
        location.setDirection(new Vector(0.5 - location.getX(), 0, 0.5 - location.getZ()).add(new Vector(0.001, 0, 0)));
        return location;
    }

    // ---- Standings and endings ----------------------------------------------------------------

    private Comparator<UUID> standings() {
        return Comparator.comparingInt((UUID id) -> lives.getOrDefault(id, 0))
                .thenComparingInt(id -> levels.getOrDefault(id, 0))
                .thenComparingInt(id -> eliminations.getOrDefault(id, 0));
    }

    /** Overall match ranking: round wins first in Gauntlet. */
    private Comparator<UUID> matchStandings() {
        return Comparator.comparingInt((UUID id) -> roundWins.getOrDefault(id, 0))
                .thenComparingInt(id -> eliminations.getOrDefault(id, 0))
                .thenComparingInt(id -> -falls.getOrDefault(id, 0));
    }

    private void updateScoreboard() {
        if (sidebar == null) {
            sidebar = new Sidebar("blocksumo", Component.text("BLOCK SUMO", NamedTextColor.AQUA, TextDecoration.BOLD));
        }
        List<String> lines = new ArrayList<>();
        List<Integer> scores = new ArrayList<>();
        int score = 110;
        if (voting) {
            long gauntlet = votes.values().stream().filter(vote -> vote == SumoRules.Mode.GAUNTLET).count();
            lines.add(ChatColor.YELLOW + "Vote: " + ChatColor.GREEN + "Gauntlet " + gauntlet
                    + ChatColor.GRAY + " · " + ChatColor.GOLD + "Marathon " + (votes.size() - gauntlet));
        } else if (mode == SumoRules.Mode.GAUNTLET) {
            lines.add(ChatColor.YELLOW + "Round " + round + ChatColor.GRAY + " · first to " + SumoRules.ROUND_WINS);
        } else {
            lines.add(ChatColor.GOLD + "Marathon");
        }
        scores.add(score--);
        lines.add(ChatColor.AQUA + "Arena: " + ChatColor.WHITE + (intermission && nextArena != null && intermissionTicks >= 100
                ? nextArena.kind().label : arena.kind().label));
        scores.add(score--);
        lines.add(ChatColor.LIGHT_PURPLE + "Twist: " + ChatColor.WHITE + (intermission && nextMutator != null && intermissionTicks >= 100
                ? nextMutator.label : mutator.label));
        scores.add(score--);
        if (intermission) {
            lines.add(ChatColor.GRAY + "Next round loading...");
            scores.add(score--);
        } else {
            int end = suddenDeath ? SumoRules.matchTicks(mode) + SumoRules.suddenDeathTicks(mode) : SumoRules.matchTicks(mode);
            int remaining = Math.max(0, end - Math.max(0, roundTicks));
            lines.add((suddenDeath ? ChatColor.DARK_RED + "Sudden death " : ChatColor.WHITE + "Time ")
                    + ChatColor.AQUA + clock(remaining));
            scores.add(score--);
            int nextCollapse = SumoRules.nextCollapseTick(mode, roundTicks);
            lines.add(ChatColor.GOLD + (suddenDeath ? "ONE LIFE EACH" : nextCollapse < 0 ? "FINAL ARENA"
                    : "Collapse in " + clock(Math.max(0, nextCollapse - Math.max(0, roundTicks)))));
            scores.add(score--);
            lines.add(ChatColor.LIGHT_PURPLE + "Event: " + arenaEvent.label
                    + (arenaEvent == SumoRules.Event.GALE ? " " + events.galeName() : ""));
            scores.add(score--);
            if (mode == SumoRules.Mode.MARATHON && !voting) {
                int nextHeart = SumoRules.nextHeartTick(mode, roundTicks);
                lines.add(ChatColor.RED + (heartCenter != null ? "❤ Crystal: ACTIVE"
                        : nextHeart < 0 || suddenDeath ? "❤ Crystals: done"
                        : "❤ Crystal in " + clock(nextHeart - Math.max(0, roundTicks))));
                scores.add(score--);
            }
        }
        lines.add(ChatColor.DARK_GRAY + "----------------");
        scores.add(score--);
        List<UUID> ranked = new ArrayList<>(mode == SumoRules.Mode.GAUNTLET ? roster : players);
        ranked.sort((mode == SumoRules.Mode.GAUNTLET ? matchStandings().thenComparing(standings()) : standings()).reversed());
        for (UUID id : ranked) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) continue;
            boolean alive = players.contains(id);
            boolean bounty = streaks.getOrDefault(id, 0) >= SumoRules.BOUNTY_STREAK;
            StringBuilder line = new StringBuilder();
            if (bounty) line.append(ChatColor.RED).append("★");
            line.append(alive || intermission ? ChatColor.WHITE : ChatColor.DARK_GRAY).append(player.getName());
            if (mode == SumoRules.Mode.GAUNTLET && !voting) {
                line.append(ChatColor.GOLD).append(" ").append("●".repeat(roundWins.getOrDefault(id, 0)))
                        .append(ChatColor.DARK_GRAY).append("○".repeat(Math.max(0, SumoRules.ROUND_WINS - roundWins.getOrDefault(id, 0))));
            }
            if (!intermission) line.append(ChatColor.RED).append(" ♥").append(lives.getOrDefault(id, 0));
            if (mode == SumoRules.Mode.MARATHON) line.append(ChatColor.LIGHT_PURPLE).append(" P").append(levels.getOrDefault(id, 0));
            line.append(ChatColor.GOLD).append(" ⚔").append(eliminations.getOrDefault(id, 0));
            lines.add(line.toString());
            scores.add(score--);
        }
        // Updated in place: a brand-new board every second re-sent everything and made the sidebar flicker.
        sidebar.set(lines, scores);
        for (Player player : world.getPlayers()) {
            sidebar.show(player);
        }
    }

    private String clock(int remainingTicks) {
        return String.format("%d:%02d", remainingTicks / 1200, (remainingTicks / 20) % 60);
    }

    private void resolveTimeUp() {
        List<UUID> alive = new ArrayList<>(players);
        int best = alive.stream().mapToInt(id -> lives.getOrDefault(id, 0)).max().orElse(0);
        List<UUID> leaders = alive.stream().filter(id -> lives.getOrDefault(id, 0) == best).toList();
        if (leaders.size() < 2) {
            finishRoundByStandings();
            return;
        }
        suddenDeath = true;
        if (arenaEvent != SumoRules.Event.CALM) {
            events.stop(arenaEvent);
            arenaEvent = SumoRules.Event.CALM;
        }
        events.clear();
        heartCenter = null;
        heartCharge.clear();
        for (UUID id : alive) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && !leaders.contains(id)) {
                eliminate(player, "§7Outlasted on lives at time-up");
            }
        }
        if (ending || intermission) return;
        collapseTo(arena.suddenDeathRadius(), "§4§lSUDDEN DEATH! §fOne life each · last one standing wins");
        for (UUID id : leaders) {
            Player player = Bukkit.getPlayer(id);
            if (player == null) continue;
            lives.put(id, 1);
            player.teleport(spawnFor(player));
            player.setVelocity(new Vector());
            player.setFallDistance(0);
            respawnShieldUntil.put(id, ticks + 40);
            player.sendTitle("§4§lSUDDEN DEATH", "§fOne life · last one standing wins", 5, 50, 10);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 0.7f);
        }
        updateScoreboard();
    }

    private void checkEnd() {
        if (!running || ending || intermission || players.size() > 1) {
            return;
        }
        endRound(players.isEmpty() ? null : players.iterator().next());
    }

    private void finishRoundByStandings() {
        if (!running || ending || intermission) {
            return;
        }
        endRound(players.stream().max(standings()).orElse(null));
    }

    private void endRound(UUID winner) {
        if (mode == SumoRules.Mode.MARATHON || voting) {
            finishMatch(winner);
            return;
        }
        roundsPlayed++;
        Player winnerPlayer = winner == null ? null : Bukkit.getPlayer(winner);
        if (winner != null && roster.contains(winner)) {
            int wins = roundWins.merge(winner, 1, Integer::sum);
            String name = participants.getOrDefault(winner, "?");
            boolean fastest = records.roundWin(winner, name, arena.kind(), Math.max(0, roundTicks));
            broadcast(Component.text(name + " wins round " + round + " on " + arena.kind().label + "! ", NamedTextColor.GOLD,
                            TextDecoration.BOLD)
                    .append(Component.text("(" + wins + "/" + SumoRules.ROUND_WINS + ")", NamedTextColor.YELLOW)
                            .decoration(TextDecoration.BOLD, false)));
            if (fastest && winnerPlayer != null) {
                winnerPlayer.sendMessage(Component.text("New personal best: fastest round win in " + clock(Math.max(0, roundTicks)) + "!",
                        NamedTextColor.GREEN));
            }
            if (winnerPlayer != null) celebrate(winnerPlayer);
            String subtitle = "§f" + name + " takes it · " + wins + "/" + SumoRules.ROUND_WINS;
            forEachRoster(player -> player.sendTitle(player.getUniqueId().equals(winner) ? "§6§lROUND WON!" : "§c§lROUND OVER",
                    subtitle, 5, 40, 10));
        } else {
            broadcast(Component.text("Round " + round + " is a draw!", NamedTextColor.GRAY));
        }
        int best = roundWins.values().stream().mapToInt(Integer::intValue).max().orElse(0);
        if (SumoRules.gauntletOver(best, roundsPlayed) || roster.size() < 2) {
            finishMatch(roster.stream().max(matchStandings()).orElse(winner));
            return;
        }
        intermission = true;
        intermissionTicks = 0;
        players.clear();
        if (arenaEvent != SumoRules.Event.CALM) {
            events.stop(arenaEvent);
            arenaEvent = SumoRules.Event.CALM;
        }
        nextArena = SumoArenas.get(arenaBag.next(kind -> kind != arena.kind()));
        nextMutator = drawMutator(nextArena);
        updateScoreboard();
    }

    private void finishMatch(UUID winner) {
        if (!running || ending) {
            return;
        }
        ending = true;
        if (voting) {
            // Someone left before the first GO: nothing was played, so nothing is recorded.
            broadcast(Component.text("Not enough players left to start. Back to the lobby!", NamedTextColor.GRAY));
            finishTask = Bukkit.getScheduler().runTaskLater(plugin, this::endGame, 40L);
            return;
        }
        Player winnerPlayer = winner == null ? null : Bukkit.getPlayer(winner);
        if (winnerPlayer != null && winnerPlayer.isOnline()) {
            String how = mode == SumoRules.Mode.GAUNTLET
                    ? " wins the Gauntlet with " + roundWins.getOrDefault(winner, 0) + " round wins!"
                    : players.size() > 1 ? " wins on lives, power and knockouts!" : " wins Block Sumo!";
            broadcast(Component.text(winnerPlayer.getName() + how, NamedTextColor.GOLD, TextDecoration.BOLD));
            winnerPlayer.sendTitle("§6§lYOU WIN!", "§bBlock Sumo champion", 10, 60, 10);
            celebrate(winnerPlayer);
        }
        for (Map.Entry<UUID, String> entry : participants.entrySet()) {
            UUID id = entry.getKey();
            boolean best = records.match(id, entry.getValue(), mode, id.equals(winner), eliminations.getOrDefault(id, 0),
                    falls.getOrDefault(id, 0), bestStreaks.getOrDefault(id, 0), crates.opened(id));
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                if (best) player.sendMessage(Component.text("New personal best: " + eliminations.getOrDefault(id, 0)
                        + " knockouts in one match!", NamedTextColor.GREEN));
                player.sendMessage(Component.text("Lifetime: " + records.summary(id), NamedTextColor.GRAY));
            }
        }
        records.save();
        showResults();
        finishTask = Bukkit.getScheduler().runTaskLater(plugin, this::endGame, 100L);
    }

    private void celebrate(Player winner) {
        Particle.TOTEM_OF_UNDYING.builder().location(winner.getLocation().add(0, 1, 0)).count(80)
                .offset(0.6, 1, 0.6).extra(0.4).receivers(96, true).spawn();
        world.playSound(winner.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
    }

    /** Final podium and awards, sent to everyone who started the match. */
    private void showResults() {
        List<UUID> ranking;
        if (mode == SumoRules.Mode.GAUNTLET) {
            ranking = new ArrayList<>(participants.keySet());
            ranking.sort(matchStandings().reversed());
        } else {
            ranking = new ArrayList<>(players);
            ranking.sort(standings().reversed());
            List<UUID> out = new ArrayList<>(knockedOut);
            Collections.reverse(out);
            for (UUID id : out) if (!ranking.contains(id)) ranking.add(id);
        }
        List<Component> lines = new ArrayList<>();
        lines.add(Component.text("━━━━━━ BLOCK SUMO RESULTS ━━━━━━", NamedTextColor.AQUA, TextDecoration.BOLD));
        lines.add(Component.text(mode.label + (mode == SumoRules.Mode.GAUNTLET ? " · " + roundsPlayed + " rounds" : "")
                + " · " + arena.kind().label, NamedTextColor.GRAY));
        NamedTextColor[] podium = {NamedTextColor.GOLD, NamedTextColor.WHITE, NamedTextColor.RED};
        for (int i = 0; i < ranking.size(); i++) {
            UUID id = ranking.get(i);
            String rounds = mode == SumoRules.Mode.GAUNTLET ? roundWins.getOrDefault(id, 0) + " rounds · " : "";
            lines.add(Component.text("#" + (i + 1) + " " + participants.getOrDefault(id, "?"),
                            i < podium.length ? podium[i] : NamedTextColor.GRAY, TextDecoration.BOLD)
                    .append(Component.text("  " + rounds + "⚔ " + eliminations.getOrDefault(id, 0) + " KOs · "
                            + falls.getOrDefault(id, 0) + " falls · " + crates.opened(id) + " crates"
                            + (mode == SumoRules.Mode.MARATHON ? " · ✦ " + spheres.getOrDefault(id, 0) + " spheres" : "")
                            + " · best streak " + bestStreaks.getOrDefault(id, 0), NamedTextColor.GRAY)
                            .decoration(TextDecoration.BOLD, false)));
        }
        award(lines, "Brawler (most knockouts)", eliminations, 1);
        if (mode == SumoRules.Mode.MARATHON) award(lines, "Rift Hoarder (most spheres)", spheres, 1);
        Map<UUID, Integer> opened = new HashMap<>();
        for (UUID id : participants.keySet()) opened.put(id, crates.opened(id));
        award(lines, "Crate Goblin (most crates)", opened, 2);
        award(lines, "Rampage (longest streak)", bestStreaks, 2);
        for (UUID id : participants.keySet()) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                lines.forEach(player::sendMessage);
            }
        }
    }

    private void award(List<Component> lines, String title, Map<UUID, Integer> stat, int minimum) {
        stat.entrySet().stream()
                .filter(entry -> participants.containsKey(entry.getKey()) && entry.getValue() >= minimum)
                .max(Map.Entry.comparingByValue())
                .ifPresent(entry -> lines.add(Component.text("★ " + title + ": ", NamedTextColor.YELLOW)
                        .append(Component.text(participants.get(entry.getKey()) + " (" + entry.getValue() + ")",
                                NamedTextColor.WHITE))));
    }

    void forEachPlayer(Consumer<Player> action) {
        for (UUID id : new ArrayList<>(players)) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline() && player.getWorld() == world) {
                action.accept(player);
            }
        }
    }

    private void resetArena(boolean sweep) {
        // A projectile or display from the previous round must not reach a fresh one.
        for (Entity entity : world.getEntities()) {
            if (entity instanceof Projectile || entity instanceof Display || entity.getScoreboardTags().contains(FX_TAG)) {
                entity.remove();
            }
        }
        arenaBlocks.forEach(location -> location.getBlock().setType(Material.AIR, false));
        placedWool.keySet().forEach(location -> location.getBlock().setType(Material.AIR, false));
        arenaBlocks.clear();
        placedWool.clear();
        heartCenter = null;
        energyCenter = null;
        if (!sweep) {
            return;
        }
        // Safety net for anything the tracked sets missed. Reads are cheap; only real strays get written,
        // instead of 42k unconditional writes in one tick.
        int r = SumoArena.SWEEP_RADIUS;
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                for (int y = SumoArena.SWEEP_BOTTOM; y <= SumoArena.SWEEP_TOP; y++) {
                    if (!world.getType(x, y, z).isAir()) {
                        world.getBlockAt(x, y, z).setType(Material.AIR, false);
                    }
                }
            }
        }
    }

    /** Messages everyone in the arena, including eliminated players who are still watching. */
    void broadcast(Component message) {
        for (Player player : world.getPlayers()) {
            player.sendMessage(Component.text("[Block Sumo] ", NamedTextColor.AQUA).append(message));
        }
    }
}
