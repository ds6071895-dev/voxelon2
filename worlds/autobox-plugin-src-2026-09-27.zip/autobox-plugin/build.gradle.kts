import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

plugins {
    java
}

group = "dev.autobox"
version = "1.0.0"

repositories {
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:26.2.build.92-stable")
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

tasks.jar {
    archiveFileName.set("AutoBox.jar")
}

// Paper keeps its plugin JAR open for lazy class loading. Replacing that file in place can
// make nested classes disappear mid-session. This task publishes by atomic rename, leaving
// the running server's old inode intact until the next restart.
tasks.register("deployPlugin") {
    dependsOn(tasks.jar)
    doLast {
        val source = tasks.jar.get().archiveFile.get().asFile.toPath()
        val pluginDir = rootProject.projectDir.parentFile.resolve("plugins").toPath()
        val temporary = pluginDir.resolve(".AutoBox.jar.next")
        val destination = pluginDir.resolve("AutoBox.jar")
        Files.copy(source, temporary, StandardCopyOption.REPLACE_EXISTING)
        try {
            Files.move(temporary, destination,
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING)
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(temporary, destination,
                StandardCopyOption.REPLACE_EXISTING)
        }
    }
}

// Exercise the generated arena geometry without a running server or a test framework.
val arenaCheck = sourceSets.create("arenaCheck") {
    compileClasspath += sourceSets.main.get().output + sourceSets.main.get().compileClasspath
    runtimeClasspath = output + compileClasspath
}
val checkRatSeekHouse = tasks.register<JavaExec>("checkRatSeekHouse") {
    dependsOn(tasks.named(arenaCheck.classesTaskName))
    classpath = arenaCheck.runtimeClasspath
    mainClass.set("dev.autobox.ratseek.RatSeekHouseCheck")
}
tasks.check { dependsOn(checkRatSeekHouse) }
val checkRatSeekNav = tasks.register<JavaExec>("checkRatSeekNav") {
    dependsOn(tasks.named(arenaCheck.classesTaskName))
    classpath = arenaCheck.runtimeClasspath
    mainClass.set("dev.autobox.ratseek.RatSeekNavCheck")
}
tasks.check { dependsOn(checkRatSeekNav) }
val checkRatSeekReach = tasks.register<JavaExec>("checkRatSeekReach") {
    dependsOn(tasks.named(arenaCheck.classesTaskName))
    classpath = arenaCheck.runtimeClasspath
    mainClass.set("dev.autobox.ratseek.RatSeekReachCheck")
}
tasks.check { dependsOn(checkRatSeekReach) }

// Generates the in-match Splatoon resource pack bundled in the plugin JAR. Uses main's class
// directories only (not its resources), because processResources depends on this output.
val splatPack = sourceSets.create("splatPack") {
    compileClasspath += sourceSets.main.get().output.classesDirs + sourceSets.main.get().compileClasspath
    runtimeClasspath = output + compileClasspath
}
val splatPackZip = layout.buildDirectory.file("generated/splatPack/splat-pack.zip")
val generateSplatPack = tasks.register<JavaExec>("generateSplatPack") {
    dependsOn(tasks.named(splatPack.classesTaskName))
    classpath = splatPack.runtimeClasspath
    mainClass.set("dev.autobox.splatpack.PackGenerator")
    inputs.files(splatPack.runtimeClasspath)
    outputs.file(splatPackZip)
    args(splatPackZip.get().asFile.absolutePath)
}
tasks.processResources { from(generateSplatPack) }

val checkSplat = tasks.register<JavaExec>("checkSplat") {
    dependsOn(tasks.named(arenaCheck.classesTaskName), generateSplatPack)
    classpath = arenaCheck.runtimeClasspath
    mainClass.set("dev.autobox.splat.SplatCheck")
    args(splatPackZip.get().asFile.absolutePath)
}
tasks.check { dependsOn(checkSplat) }

// Serves the pack through worlds-pack-tunnel.service and downloads it back via Cloudflare.
tasks.register<JavaExec>("packServeCheck") {
    dependsOn(tasks.named(arenaCheck.classesTaskName), generateSplatPack)
    classpath = arenaCheck.runtimeClasspath
    mainClass.set("dev.autobox.splat.PackServeCheck")
    args(splatPackZip.get().asFile.absolutePath)
}

val checkZombie = tasks.register<JavaExec>("checkZombie") {
    dependsOn(tasks.named(arenaCheck.classesTaskName))
    classpath = arenaCheck.runtimeClasspath
    mainClass.set("dev.autobox.zombie.ZombieCheck")
}
tasks.check { dependsOn(checkZombie) }
val checkArcade = tasks.register<JavaExec>("checkArcade") {
    dependsOn(tasks.named(arenaCheck.classesTaskName))
    classpath = arenaCheck.runtimeClasspath
    mainClass.set("dev.autobox.arcade.ArcadeCheck")
}
tasks.check { dependsOn(checkArcade) }
tasks.named("deployPlugin") { dependsOn(tasks.check) }

// Test-only plugin for an isolated Paper server; excluded from the production JAR.
val zombieSmoke = sourceSets.create("zombieSmoke") {
    compileClasspath += sourceSets.main.get().output + sourceSets.main.get().compileClasspath
}
tasks.register<Jar>("zombieSmokeJar") {
    dependsOn(tasks.named(zombieSmoke.classesTaskName))
    archiveFileName.set("ZombieSmoke-test-only.jar")
    from(zombieSmoke.output)
}
